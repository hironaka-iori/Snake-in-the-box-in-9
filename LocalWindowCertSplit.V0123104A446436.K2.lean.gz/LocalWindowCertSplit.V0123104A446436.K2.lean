module

-- LocalWindowCertSplit.V0123104A446436: kernel checks of segments 165..249 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V0123104A446436.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V0123104A446436

theorem warm165 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t165 165) = true := by
  decide +kernel

theorem ok165 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t165 165 = true := (Snake9.LratV3.andB_eq_true warm165).2

theorem warm166 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t166 166) = true := by
  decide +kernel

theorem ok166 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t166 166 = true := (Snake9.LratV3.andB_eq_true warm166).2

theorem warm167 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t167 167) = true := by
  decide +kernel

theorem ok167 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t167 167 = true := (Snake9.LratV3.andB_eq_true warm167).2

theorem warm168 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t168 168) = true := by
  decide +kernel

theorem ok168 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t168 168 = true := (Snake9.LratV3.andB_eq_true warm168).2

theorem warm169 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t169 169) = true := by
  decide +kernel

theorem ok169 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t169 169 = true := (Snake9.LratV3.andB_eq_true warm169).2

theorem warm170 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t170 170) = true := by
  decide +kernel

theorem ok170 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t170 170 = true := (Snake9.LratV3.andB_eq_true warm170).2

theorem warm171 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t171 171) = true := by
  decide +kernel

theorem ok171 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t171 171 = true := (Snake9.LratV3.andB_eq_true warm171).2

theorem warm172 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t172 172) = true := by
  decide +kernel

theorem ok172 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t172 172 = true := (Snake9.LratV3.andB_eq_true warm172).2

theorem warm173 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t173 173) = true := by
  decide +kernel

theorem ok173 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t173 173 = true := (Snake9.LratV3.andB_eq_true warm173).2

theorem warm174 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t174 174) = true := by
  decide +kernel

theorem ok174 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t174 174 = true := (Snake9.LratV3.andB_eq_true warm174).2

theorem warm175 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t175 175) = true := by
  decide +kernel

theorem ok175 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t175 175 = true := (Snake9.LratV3.andB_eq_true warm175).2

theorem warm176 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t176 176) = true := by
  decide +kernel

theorem ok176 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t176 176 = true := (Snake9.LratV3.andB_eq_true warm176).2

theorem warm177 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t177 177) = true := by
  decide +kernel

theorem ok177 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t177 177 = true := (Snake9.LratV3.andB_eq_true warm177).2

theorem warm178 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t178 178) = true := by
  decide +kernel

theorem ok178 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t178 178 = true := (Snake9.LratV3.andB_eq_true warm178).2

theorem warm179 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t179 179) = true := by
  decide +kernel

theorem ok179 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t179 179 = true := (Snake9.LratV3.andB_eq_true warm179).2

theorem warm180 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t180 180) = true := by
  decide +kernel

theorem ok180 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t180 180 = true := (Snake9.LratV3.andB_eq_true warm180).2

theorem warm181 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t181 181) = true := by
  decide +kernel

theorem ok181 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t181 181 = true := (Snake9.LratV3.andB_eq_true warm181).2

theorem warm182 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t182 182) = true := by
  decide +kernel

theorem ok182 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t182 182 = true := (Snake9.LratV3.andB_eq_true warm182).2

theorem warm183 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t183 183) = true := by
  decide +kernel

theorem ok183 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t183 183 = true := (Snake9.LratV3.andB_eq_true warm183).2

theorem warm184 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t184 184) = true := by
  decide +kernel

theorem ok184 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t184 184 = true := (Snake9.LratV3.andB_eq_true warm184).2

theorem warm185 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t185 185) = true := by
  decide +kernel

theorem ok185 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t185 185 = true := (Snake9.LratV3.andB_eq_true warm185).2

theorem warm186 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t186 186) = true := by
  decide +kernel

theorem ok186 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t186 186 = true := (Snake9.LratV3.andB_eq_true warm186).2

theorem warm187 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t187 187) = true := by
  decide +kernel

theorem ok187 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t187 187 = true := (Snake9.LratV3.andB_eq_true warm187).2

theorem warm188 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t188 188) = true := by
  decide +kernel

theorem ok188 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t188 188 = true := (Snake9.LratV3.andB_eq_true warm188).2

theorem warm189 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t189 189) = true := by
  decide +kernel

theorem ok189 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t189 189 = true := (Snake9.LratV3.andB_eq_true warm189).2

theorem warm190 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t190 190) = true := by
  decide +kernel

theorem ok190 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t190 190 = true := (Snake9.LratV3.andB_eq_true warm190).2

theorem warm191 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t191 191) = true := by
  decide +kernel

theorem ok191 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t191 191 = true := (Snake9.LratV3.andB_eq_true warm191).2

theorem warm192 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t192 192) = true := by
  decide +kernel

theorem ok192 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t192 192 = true := (Snake9.LratV3.andB_eq_true warm192).2

theorem warm193 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t193 193) = true := by
  decide +kernel

theorem ok193 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t193 193 = true := (Snake9.LratV3.andB_eq_true warm193).2

theorem warm194 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t194 194) = true := by
  decide +kernel

theorem ok194 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t194 194 = true := (Snake9.LratV3.andB_eq_true warm194).2

theorem warm195 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t195 195) = true := by
  decide +kernel

theorem ok195 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t195 195 = true := (Snake9.LratV3.andB_eq_true warm195).2

theorem warm196 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t196 196) = true := by
  decide +kernel

theorem ok196 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t196 196 = true := (Snake9.LratV3.andB_eq_true warm196).2

theorem warm197 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t197 197) = true := by
  decide +kernel

theorem ok197 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t197 197 = true := (Snake9.LratV3.andB_eq_true warm197).2

theorem warm198 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t198 198) = true := by
  decide +kernel

theorem ok198 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t198 198 = true := (Snake9.LratV3.andB_eq_true warm198).2

theorem warm199 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t199 199) = true := by
  decide +kernel

theorem ok199 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t199 199 = true := (Snake9.LratV3.andB_eq_true warm199).2

theorem warm200 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t200 200) = true := by
  decide +kernel

theorem ok200 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t200 200 = true := (Snake9.LratV3.andB_eq_true warm200).2

theorem warm201 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t201 201) = true := by
  decide +kernel

theorem ok201 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t201 201 = true := (Snake9.LratV3.andB_eq_true warm201).2

theorem warm202 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t202 202) = true := by
  decide +kernel

theorem ok202 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t202 202 = true := (Snake9.LratV3.andB_eq_true warm202).2

theorem warm203 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t203 203) = true := by
  decide +kernel

theorem ok203 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t203 203 = true := (Snake9.LratV3.andB_eq_true warm203).2

theorem warm204 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t204 204) = true := by
  decide +kernel

theorem ok204 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t204 204 = true := (Snake9.LratV3.andB_eq_true warm204).2

theorem warm205 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t205 205) = true := by
  decide +kernel

theorem ok205 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t205 205 = true := (Snake9.LratV3.andB_eq_true warm205).2

theorem warm206 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t206 206) = true := by
  decide +kernel

theorem ok206 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t206 206 = true := (Snake9.LratV3.andB_eq_true warm206).2

theorem warm207 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t207 207) = true := by
  decide +kernel

theorem ok207 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t207 207 = true := (Snake9.LratV3.andB_eq_true warm207).2

theorem warm208 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t208 208) = true := by
  decide +kernel

theorem ok208 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t208 208 = true := (Snake9.LratV3.andB_eq_true warm208).2

theorem warm209 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t209 209) = true := by
  decide +kernel

theorem ok209 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t209 209 = true := (Snake9.LratV3.andB_eq_true warm209).2

theorem warm210 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t210 210) = true := by
  decide +kernel

theorem ok210 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t210 210 = true := (Snake9.LratV3.andB_eq_true warm210).2

theorem warm211 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t211 211) = true := by
  decide +kernel

theorem ok211 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t211 211 = true := (Snake9.LratV3.andB_eq_true warm211).2

theorem warm212 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t212 212) = true := by
  decide +kernel

theorem ok212 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t212 212 = true := (Snake9.LratV3.andB_eq_true warm212).2

theorem warm213 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t213 213) = true := by
  decide +kernel

theorem ok213 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t213 213 = true := (Snake9.LratV3.andB_eq_true warm213).2

theorem warm214 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t214 214) = true := by
  decide +kernel

theorem ok214 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t214 214 = true := (Snake9.LratV3.andB_eq_true warm214).2

theorem warm215 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t215 215) = true := by
  decide +kernel

theorem ok215 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t215 215 = true := (Snake9.LratV3.andB_eq_true warm215).2

theorem warm216 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t216 216) = true := by
  decide +kernel

theorem ok216 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t216 216 = true := (Snake9.LratV3.andB_eq_true warm216).2

theorem warm217 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t217 217) = true := by
  decide +kernel

theorem ok217 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t217 217 = true := (Snake9.LratV3.andB_eq_true warm217).2

theorem warm218 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t218 218) = true := by
  decide +kernel

theorem ok218 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t218 218 = true := (Snake9.LratV3.andB_eq_true warm218).2

theorem warm219 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t219 219) = true := by
  decide +kernel

theorem ok219 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t219 219 = true := (Snake9.LratV3.andB_eq_true warm219).2

theorem warm220 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t220 220) = true := by
  decide +kernel

theorem ok220 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t220 220 = true := (Snake9.LratV3.andB_eq_true warm220).2

theorem warm221 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t221 221) = true := by
  decide +kernel

theorem ok221 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t221 221 = true := (Snake9.LratV3.andB_eq_true warm221).2

theorem warm222 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t222 222) = true := by
  decide +kernel

theorem ok222 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t222 222 = true := (Snake9.LratV3.andB_eq_true warm222).2

theorem warm223 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t223 223) = true := by
  decide +kernel

theorem ok223 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t223 223 = true := (Snake9.LratV3.andB_eq_true warm223).2

theorem warm224 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t224 224) = true := by
  decide +kernel

theorem ok224 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t224 224 = true := (Snake9.LratV3.andB_eq_true warm224).2

theorem warm225 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t225 225) = true := by
  decide +kernel

theorem ok225 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t225 225 = true := (Snake9.LratV3.andB_eq_true warm225).2

theorem warm226 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t226 226) = true := by
  decide +kernel

theorem ok226 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t226 226 = true := (Snake9.LratV3.andB_eq_true warm226).2

theorem warm227 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t227 227) = true := by
  decide +kernel

theorem ok227 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t227 227 = true := (Snake9.LratV3.andB_eq_true warm227).2

theorem warm228 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t228 228) = true := by
  decide +kernel

theorem ok228 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t228 228 = true := (Snake9.LratV3.andB_eq_true warm228).2

theorem warm229 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t229 229) = true := by
  decide +kernel

theorem ok229 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t229 229 = true := (Snake9.LratV3.andB_eq_true warm229).2

theorem warm230 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t230 230) = true := by
  decide +kernel

theorem ok230 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t230 230 = true := (Snake9.LratV3.andB_eq_true warm230).2

theorem warm231 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t231 231) = true := by
  decide +kernel

theorem ok231 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t231 231 = true := (Snake9.LratV3.andB_eq_true warm231).2

theorem warm232 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t232 232) = true := by
  decide +kernel

theorem ok232 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t232 232 = true := (Snake9.LratV3.andB_eq_true warm232).2

theorem warm233 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t233 233) = true := by
  decide +kernel

theorem ok233 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t233 233 = true := (Snake9.LratV3.andB_eq_true warm233).2

theorem warm234 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t234 234) = true := by
  decide +kernel

theorem ok234 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t234 234 = true := (Snake9.LratV3.andB_eq_true warm234).2

theorem warm235 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t235 235) = true := by
  decide +kernel

theorem ok235 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t235 235 = true := (Snake9.LratV3.andB_eq_true warm235).2

theorem warm236 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t236 236) = true := by
  decide +kernel

theorem ok236 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t236 236 = true := (Snake9.LratV3.andB_eq_true warm236).2

theorem warm237 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t237 237) = true := by
  decide +kernel

theorem ok237 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t237 237 = true := (Snake9.LratV3.andB_eq_true warm237).2

theorem warm238 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t238 238) = true := by
  decide +kernel

theorem ok238 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t238 238 = true := (Snake9.LratV3.andB_eq_true warm238).2

theorem warm239 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t239 239) = true := by
  decide +kernel

theorem ok239 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t239 239 = true := (Snake9.LratV3.andB_eq_true warm239).2

theorem warm240 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t240 240) = true := by
  decide +kernel

theorem ok240 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t240 240 = true := (Snake9.LratV3.andB_eq_true warm240).2

theorem warm241 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t241 241) = true := by
  decide +kernel

theorem ok241 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t241 241 = true := (Snake9.LratV3.andB_eq_true warm241).2

theorem warm242 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t242 242) = true := by
  decide +kernel

theorem ok242 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t242 242 = true := (Snake9.LratV3.andB_eq_true warm242).2

theorem warm243 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t243 243) = true := by
  decide +kernel

theorem ok243 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t243 243 = true := (Snake9.LratV3.andB_eq_true warm243).2

theorem warm244 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true)))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t244 244) = true := by
  decide +kernel

theorem ok244 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t244 244 = true := (Snake9.LratV3.andB_eq_true warm244).2

theorem warm245 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t245 245) = true := by
  decide +kernel

theorem ok245 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t245 245 = true := (Snake9.LratV3.andB_eq_true warm245).2

theorem warm246 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t246 246) = true := by
  decide +kernel

theorem ok246 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t246 246 = true := (Snake9.LratV3.andB_eq_true warm246).2

theorem warm247 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t247 247) = true := by
  decide +kernel

theorem ok247 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t247 247 = true := (Snake9.LratV3.andB_eq_true warm247).2

theorem warm248 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t248 248) = true := by
  decide +kernel

theorem ok248 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t248 248 = true := (Snake9.LratV3.andB_eq_true warm248).2

theorem warm249 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 4000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 4000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 176) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 4000 14 16383 8192 raw Ps t249 249) = true := by
  decide +kernel

theorem ok249 : Snake9.LratV3.check 4000 14 16383 8192 raw Ps t249 249 = true := (Snake9.LratV3.andB_eq_true warm249).2

end Snake9.LocalWindow.V0123104A446436
