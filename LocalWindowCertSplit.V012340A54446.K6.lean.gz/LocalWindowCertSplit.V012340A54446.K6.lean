module

-- LocalWindowCertSplit.V012340A54446: kernel checks of segments 334..390 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012340A54446.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012340A54446

theorem warm334 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t334 334) = true := by
  decide +kernel

theorem ok334 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t334 334 = true := (Snake9.LratV3.andB_eq_true warm334).2

theorem warm335 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t335 335) = true := by
  decide +kernel

theorem ok335 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t335 335 = true := (Snake9.LratV3.andB_eq_true warm335).2

theorem warm336 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t336 336) = true := by
  decide +kernel

theorem ok336 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t336 336 = true := (Snake9.LratV3.andB_eq_true warm336).2

theorem warm337 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t337 337) = true := by
  decide +kernel

theorem ok337 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t337 337 = true := (Snake9.LratV3.andB_eq_true warm337).2

theorem warm338 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t338 338) = true := by
  decide +kernel

theorem ok338 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t338 338 = true := (Snake9.LratV3.andB_eq_true warm338).2

theorem warm339 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t339 339) = true := by
  decide +kernel

theorem ok339 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t339 339 = true := (Snake9.LratV3.andB_eq_true warm339).2

theorem warm340 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t340 340) = true := by
  decide +kernel

theorem ok340 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t340 340 = true := (Snake9.LratV3.andB_eq_true warm340).2

theorem warm341 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t341 341) = true := by
  decide +kernel

theorem ok341 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t341 341 = true := (Snake9.LratV3.andB_eq_true warm341).2

theorem warm342 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t342 342) = true := by
  decide +kernel

theorem ok342 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t342 342 = true := (Snake9.LratV3.andB_eq_true warm342).2

theorem warm343 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 150) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t343 343) = true := by
  decide +kernel

theorem ok343 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t343 343 = true := (Snake9.LratV3.andB_eq_true warm343).2

theorem warm344 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t344 344) = true := by
  decide +kernel

theorem ok344 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t344 344 = true := (Snake9.LratV3.andB_eq_true warm344).2

theorem warm345 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 28) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t345 345) = true := by
  decide +kernel

theorem ok345 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t345 345 = true := (Snake9.LratV3.andB_eq_true warm345).2

theorem warm346 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t346 346) = true := by
  decide +kernel

theorem ok346 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t346 346 = true := (Snake9.LratV3.andB_eq_true warm346).2

theorem warm347 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 28) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t347 347) = true := by
  decide +kernel

theorem ok347 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t347 347 = true := (Snake9.LratV3.andB_eq_true warm347).2

theorem warm348 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t348 348) = true := by
  decide +kernel

theorem ok348 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t348 348 = true := (Snake9.LratV3.andB_eq_true warm348).2

theorem warm349 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t349 349) = true := by
  decide +kernel

theorem ok349 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t349 349 = true := (Snake9.LratV3.andB_eq_true warm349).2

theorem warm350 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t350 350) = true := by
  decide +kernel

theorem ok350 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t350 350 = true := (Snake9.LratV3.andB_eq_true warm350).2

theorem warm351 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t351 351) = true := by
  decide +kernel

theorem ok351 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t351 351 = true := (Snake9.LratV3.andB_eq_true warm351).2

theorem warm352 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t352 352) = true := by
  decide +kernel

theorem ok352 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t352 352 = true := (Snake9.LratV3.andB_eq_true warm352).2

theorem warm353 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t353 353) = true := by
  decide +kernel

theorem ok353 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t353 353 = true := (Snake9.LratV3.andB_eq_true warm353).2

theorem warm354 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 150) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t354 354) = true := by
  decide +kernel

theorem ok354 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t354 354 = true := (Snake9.LratV3.andB_eq_true warm354).2

theorem warm355 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 28) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t355 355) = true := by
  decide +kernel

theorem ok355 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t355 355 = true := (Snake9.LratV3.andB_eq_true warm355).2

theorem warm356 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t356 356) = true := by
  decide +kernel

theorem ok356 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t356 356 = true := (Snake9.LratV3.andB_eq_true warm356).2

theorem warm357 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t357 357) = true := by
  decide +kernel

theorem ok357 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t357 357 = true := (Snake9.LratV3.andB_eq_true warm357).2

theorem warm358 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t358 358) = true := by
  decide +kernel

theorem ok358 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t358 358 = true := (Snake9.LratV3.andB_eq_true warm358).2

theorem warm359 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t359 359) = true := by
  decide +kernel

theorem ok359 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t359 359 = true := (Snake9.LratV3.andB_eq_true warm359).2

theorem warm360 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t360 360) = true := by
  decide +kernel

theorem ok360 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t360 360 = true := (Snake9.LratV3.andB_eq_true warm360).2

theorem warm361 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t361 361) = true := by
  decide +kernel

theorem ok361 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t361 361 = true := (Snake9.LratV3.andB_eq_true warm361).2

theorem warm362 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t362 362) = true := by
  decide +kernel

theorem ok362 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t362 362 = true := (Snake9.LratV3.andB_eq_true warm362).2

theorem warm363 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t363 363) = true := by
  decide +kernel

theorem ok363 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t363 363 = true := (Snake9.LratV3.andB_eq_true warm363).2

theorem warm364 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t364 364) = true := by
  decide +kernel

theorem ok364 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t364 364 = true := (Snake9.LratV3.andB_eq_true warm364).2

theorem warm365 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t365 365) = true := by
  decide +kernel

theorem ok365 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t365 365 = true := (Snake9.LratV3.andB_eq_true warm365).2

theorem warm366 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t366 366) = true := by
  decide +kernel

theorem ok366 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t366 366 = true := (Snake9.LratV3.andB_eq_true warm366).2

theorem warm367 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t367 367) = true := by
  decide +kernel

theorem ok367 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t367 367 = true := (Snake9.LratV3.andB_eq_true warm367).2

theorem warm368 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t368 368) = true := by
  decide +kernel

theorem ok368 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t368 368 = true := (Snake9.LratV3.andB_eq_true warm368).2

theorem warm369 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 28) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t369 369) = true := by
  decide +kernel

theorem ok369 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t369 369 = true := (Snake9.LratV3.andB_eq_true warm369).2

theorem warm370 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t370 370) = true := by
  decide +kernel

theorem ok370 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t370 370 = true := (Snake9.LratV3.andB_eq_true warm370).2

theorem warm371 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t371 371) = true := by
  decide +kernel

theorem ok371 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t371 371 = true := (Snake9.LratV3.andB_eq_true warm371).2

theorem warm372 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t372 372) = true := by
  decide +kernel

theorem ok372 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t372 372 = true := (Snake9.LratV3.andB_eq_true warm372).2

theorem warm373 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t373 373) = true := by
  decide +kernel

theorem ok373 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t373 373 = true := (Snake9.LratV3.andB_eq_true warm373).2

theorem warm374 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t374 374) = true := by
  decide +kernel

theorem ok374 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t374 374 = true := (Snake9.LratV3.andB_eq_true warm374).2

theorem warm375 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t375 375) = true := by
  decide +kernel

theorem ok375 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t375 375 = true := (Snake9.LratV3.andB_eq_true warm375).2

theorem warm376 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 28) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t376 376) = true := by
  decide +kernel

theorem ok376 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t376 376 = true := (Snake9.LratV3.andB_eq_true warm376).2

theorem warm377 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t377 377) = true := by
  decide +kernel

theorem ok377 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t377 377 = true := (Snake9.LratV3.andB_eq_true warm377).2

theorem warm378 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t378 378) = true := by
  decide +kernel

theorem ok378 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t378 378 = true := (Snake9.LratV3.andB_eq_true warm378).2

theorem warm379 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t379 379) = true := by
  decide +kernel

theorem ok379 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t379 379 = true := (Snake9.LratV3.andB_eq_true warm379).2

theorem warm380 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 379) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t380 380) = true := by
  decide +kernel

theorem ok380 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t380 380 = true := (Snake9.LratV3.andB_eq_true warm380).2

theorem warm381 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 380) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t381 381) = true := by
  decide +kernel

theorem ok381 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t381 381 = true := (Snake9.LratV3.andB_eq_true warm381).2

theorem warm382 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 237) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 379) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t382 382) = true := by
  decide +kernel

theorem ok382 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t382 382 = true := (Snake9.LratV3.andB_eq_true warm382).2

theorem warm383 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t383 383) = true := by
  decide +kernel

theorem ok383 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t383 383 = true := (Snake9.LratV3.andB_eq_true warm383).2

theorem warm384 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 28) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 379) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t384 384) = true := by
  decide +kernel

theorem ok384 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t384 384 = true := (Snake9.LratV3.andB_eq_true warm384).2

theorem warm385 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t385 385) = true := by
  decide +kernel

theorem ok385 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t385 385 = true := (Snake9.LratV3.andB_eq_true warm385).2

theorem warm386 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 150) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 379) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 380) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t386 386) = true := by
  decide +kernel

theorem ok386 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t386 386 = true := (Snake9.LratV3.andB_eq_true warm386).2

theorem warm387 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t387 387) = true := by
  decide +kernel

theorem ok387 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t387 387 = true := (Snake9.LratV3.andB_eq_true warm387).2

theorem warm388 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t388 388) = true := by
  decide +kernel

theorem ok388 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t388 388 = true := (Snake9.LratV3.andB_eq_true warm388).2

theorem warm389 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 237) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 379) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t389 389) = true := by
  decide +kernel

theorem ok389 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t389 389 = true := (Snake9.LratV3.andB_eq_true warm389).2

theorem warm390 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 322) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 379) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 380) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t390 390) = true := by
  decide +kernel

theorem ok390 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t390 390 = true := (Snake9.LratV3.andB_eq_true warm390).2

end Snake9.LocalWindow.V012340A54446
