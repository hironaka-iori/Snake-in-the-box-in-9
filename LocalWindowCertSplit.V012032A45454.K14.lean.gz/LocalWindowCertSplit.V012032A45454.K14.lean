module

-- LocalWindowCertSplit.V012032A45454: kernel checks of segments 1287..1378 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012032A45454.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012032A45454

theorem warm1287 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1287 1287) = true := by
  decide +kernel

theorem ok1287 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1287 1287 = true := (Snake9.LratV3.andB_eq_true warm1287).2

theorem warm1288 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1288 1288) = true := by
  decide +kernel

theorem ok1288 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1288 1288 = true := (Snake9.LratV3.andB_eq_true warm1288).2

theorem warm1289 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1289 1289) = true := by
  decide +kernel

theorem ok1289 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1289 1289 = true := (Snake9.LratV3.andB_eq_true warm1289).2

theorem warm1290 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1290 1290) = true := by
  decide +kernel

theorem ok1290 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1290 1290 = true := (Snake9.LratV3.andB_eq_true warm1290).2

theorem warm1291 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1291 1291) = true := by
  decide +kernel

theorem ok1291 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1291 1291 = true := (Snake9.LratV3.andB_eq_true warm1291).2

theorem warm1292 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 14) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1292 1292) = true := by
  decide +kernel

theorem ok1292 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1292 1292 = true := (Snake9.LratV3.andB_eq_true warm1292).2

theorem warm1293 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1293 1293) = true := by
  decide +kernel

theorem ok1293 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1293 1293 = true := (Snake9.LratV3.andB_eq_true warm1293).2

theorem warm1294 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1294 1294) = true := by
  decide +kernel

theorem ok1294 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1294 1294 = true := (Snake9.LratV3.andB_eq_true warm1294).2

theorem warm1295 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1295 1295) = true := by
  decide +kernel

theorem ok1295 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1295 1295 = true := (Snake9.LratV3.andB_eq_true warm1295).2

theorem warm1296 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1000) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1296 1296) = true := by
  decide +kernel

theorem ok1296 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1296 1296 = true := (Snake9.LratV3.andB_eq_true warm1296).2

theorem warm1297 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1297 1297) = true := by
  decide +kernel

theorem ok1297 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1297 1297 = true := (Snake9.LratV3.andB_eq_true warm1297).2

theorem warm1298 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1298 1298) = true := by
  decide +kernel

theorem ok1298 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1298 1298 = true := (Snake9.LratV3.andB_eq_true warm1298).2

theorem warm1299 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1299 1299) = true := by
  decide +kernel

theorem ok1299 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1299 1299 = true := (Snake9.LratV3.andB_eq_true warm1299).2

theorem warm1300 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1300 1300) = true := by
  decide +kernel

theorem ok1300 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1300 1300 = true := (Snake9.LratV3.andB_eq_true warm1300).2

theorem warm1301 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1301 1301) = true := by
  decide +kernel

theorem ok1301 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1301 1301 = true := (Snake9.LratV3.andB_eq_true warm1301).2

theorem warm1302 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1302 1302) = true := by
  decide +kernel

theorem ok1302 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1302 1302 = true := (Snake9.LratV3.andB_eq_true warm1302).2

theorem warm1303 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1303 1303) = true := by
  decide +kernel

theorem ok1303 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1303 1303 = true := (Snake9.LratV3.andB_eq_true warm1303).2

theorem warm1304 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1304 1304) = true := by
  decide +kernel

theorem ok1304 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1304 1304 = true := (Snake9.LratV3.andB_eq_true warm1304).2

theorem warm1305 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1305 1305) = true := by
  decide +kernel

theorem ok1305 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1305 1305 = true := (Snake9.LratV3.andB_eq_true warm1305).2

theorem warm1306 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1306 1306) = true := by
  decide +kernel

theorem ok1306 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1306 1306 = true := (Snake9.LratV3.andB_eq_true warm1306).2

theorem warm1307 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1307 1307) = true := by
  decide +kernel

theorem ok1307 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1307 1307 = true := (Snake9.LratV3.andB_eq_true warm1307).2

theorem warm1308 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1308 1308) = true := by
  decide +kernel

theorem ok1308 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1308 1308 = true := (Snake9.LratV3.andB_eq_true warm1308).2

theorem warm1309 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1309 1309) = true := by
  decide +kernel

theorem ok1309 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1309 1309 = true := (Snake9.LratV3.andB_eq_true warm1309).2

theorem warm1310 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1310 1310) = true := by
  decide +kernel

theorem ok1310 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1310 1310 = true := (Snake9.LratV3.andB_eq_true warm1310).2

theorem warm1311 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1311 1311) = true := by
  decide +kernel

theorem ok1311 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1311 1311 = true := (Snake9.LratV3.andB_eq_true warm1311).2

theorem warm1312 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1312 1312) = true := by
  decide +kernel

theorem ok1312 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1312 1312 = true := (Snake9.LratV3.andB_eq_true warm1312).2

theorem warm1313 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1313 1313) = true := by
  decide +kernel

theorem ok1313 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1313 1313 = true := (Snake9.LratV3.andB_eq_true warm1313).2

theorem warm1314 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 64) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1314 1314) = true := by
  decide +kernel

theorem ok1314 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1314 1314 = true := (Snake9.LratV3.andB_eq_true warm1314).2

theorem warm1315 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1315 1315) = true := by
  decide +kernel

theorem ok1315 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1315 1315 = true := (Snake9.LratV3.andB_eq_true warm1315).2

theorem warm1316 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1316 1316) = true := by
  decide +kernel

theorem ok1316 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1316 1316 = true := (Snake9.LratV3.andB_eq_true warm1316).2

theorem warm1317 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1317 1317) = true := by
  decide +kernel

theorem ok1317 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1317 1317 = true := (Snake9.LratV3.andB_eq_true warm1317).2

theorem warm1318 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1318 1318) = true := by
  decide +kernel

theorem ok1318 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1318 1318 = true := (Snake9.LratV3.andB_eq_true warm1318).2

theorem warm1319 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1319 1319) = true := by
  decide +kernel

theorem ok1319 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1319 1319 = true := (Snake9.LratV3.andB_eq_true warm1319).2

theorem warm1320 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1320 1320) = true := by
  decide +kernel

theorem ok1320 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1320 1320 = true := (Snake9.LratV3.andB_eq_true warm1320).2

theorem warm1321 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1321 1321) = true := by
  decide +kernel

theorem ok1321 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1321 1321 = true := (Snake9.LratV3.andB_eq_true warm1321).2

theorem warm1322 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1322 1322) = true := by
  decide +kernel

theorem ok1322 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1322 1322 = true := (Snake9.LratV3.andB_eq_true warm1322).2

theorem warm1323 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1323 1323) = true := by
  decide +kernel

theorem ok1323 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1323 1323 = true := (Snake9.LratV3.andB_eq_true warm1323).2

theorem warm1324 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1324 1324) = true := by
  decide +kernel

theorem ok1324 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1324 1324 = true := (Snake9.LratV3.andB_eq_true warm1324).2

theorem warm1325 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1325 1325) = true := by
  decide +kernel

theorem ok1325 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1325 1325 = true := (Snake9.LratV3.andB_eq_true warm1325).2

theorem warm1326 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1326 1326) = true := by
  decide +kernel

theorem ok1326 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1326 1326 = true := (Snake9.LratV3.andB_eq_true warm1326).2

theorem warm1327 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1327 1327) = true := by
  decide +kernel

theorem ok1327 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1327 1327 = true := (Snake9.LratV3.andB_eq_true warm1327).2

theorem warm1328 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1328 1328) = true := by
  decide +kernel

theorem ok1328 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1328 1328 = true := (Snake9.LratV3.andB_eq_true warm1328).2

theorem warm1329 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1329 1329) = true := by
  decide +kernel

theorem ok1329 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1329 1329 = true := (Snake9.LratV3.andB_eq_true warm1329).2

theorem warm1330 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1330 1330) = true := by
  decide +kernel

theorem ok1330 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1330 1330 = true := (Snake9.LratV3.andB_eq_true warm1330).2

theorem warm1331 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1331 1331) = true := by
  decide +kernel

theorem ok1331 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1331 1331 = true := (Snake9.LratV3.andB_eq_true warm1331).2

theorem warm1332 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1332 1332) = true := by
  decide +kernel

theorem ok1332 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1332 1332 = true := (Snake9.LratV3.andB_eq_true warm1332).2

theorem warm1333 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1333 1333) = true := by
  decide +kernel

theorem ok1333 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1333 1333 = true := (Snake9.LratV3.andB_eq_true warm1333).2

theorem warm1334 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1334 1334) = true := by
  decide +kernel

theorem ok1334 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1334 1334 = true := (Snake9.LratV3.andB_eq_true warm1334).2

theorem warm1335 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1335 1335) = true := by
  decide +kernel

theorem ok1335 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1335 1335 = true := (Snake9.LratV3.andB_eq_true warm1335).2

theorem warm1336 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1336 1336) = true := by
  decide +kernel

theorem ok1336 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1336 1336 = true := (Snake9.LratV3.andB_eq_true warm1336).2

theorem warm1337 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1337 1337) = true := by
  decide +kernel

theorem ok1337 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1337 1337 = true := (Snake9.LratV3.andB_eq_true warm1337).2

theorem warm1338 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1338 1338) = true := by
  decide +kernel

theorem ok1338 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1338 1338 = true := (Snake9.LratV3.andB_eq_true warm1338).2

theorem warm1339 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1339 1339) = true := by
  decide +kernel

theorem ok1339 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1339 1339 = true := (Snake9.LratV3.andB_eq_true warm1339).2

theorem warm1340 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1340 1340) = true := by
  decide +kernel

theorem ok1340 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1340 1340 = true := (Snake9.LratV3.andB_eq_true warm1340).2

theorem warm1341 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1341 1341) = true := by
  decide +kernel

theorem ok1341 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1341 1341 = true := (Snake9.LratV3.andB_eq_true warm1341).2

theorem warm1342 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1342 1342) = true := by
  decide +kernel

theorem ok1342 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1342 1342 = true := (Snake9.LratV3.andB_eq_true warm1342).2

theorem warm1343 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1343 1343) = true := by
  decide +kernel

theorem ok1343 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1343 1343 = true := (Snake9.LratV3.andB_eq_true warm1343).2

theorem warm1344 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1344 1344) = true := by
  decide +kernel

theorem ok1344 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1344 1344 = true := (Snake9.LratV3.andB_eq_true warm1344).2

theorem warm1345 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 84) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1345 1345) = true := by
  decide +kernel

theorem ok1345 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1345 1345 = true := (Snake9.LratV3.andB_eq_true warm1345).2

theorem warm1346 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1346 1346) = true := by
  decide +kernel

theorem ok1346 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1346 1346 = true := (Snake9.LratV3.andB_eq_true warm1346).2

theorem warm1347 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1347 1347) = true := by
  decide +kernel

theorem ok1347 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1347 1347 = true := (Snake9.LratV3.andB_eq_true warm1347).2

theorem warm1348 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1348 1348) = true := by
  decide +kernel

theorem ok1348 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1348 1348 = true := (Snake9.LratV3.andB_eq_true warm1348).2

theorem warm1349 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1349 1349) = true := by
  decide +kernel

theorem ok1349 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1349 1349 = true := (Snake9.LratV3.andB_eq_true warm1349).2

theorem warm1350 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1350 1350) = true := by
  decide +kernel

theorem ok1350 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1350 1350 = true := (Snake9.LratV3.andB_eq_true warm1350).2

theorem warm1351 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1351 1351) = true := by
  decide +kernel

theorem ok1351 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1351 1351 = true := (Snake9.LratV3.andB_eq_true warm1351).2

theorem warm1352 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1352 1352) = true := by
  decide +kernel

theorem ok1352 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1352 1352 = true := (Snake9.LratV3.andB_eq_true warm1352).2

theorem warm1353 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1353 1353) = true := by
  decide +kernel

theorem ok1353 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1353 1353 = true := (Snake9.LratV3.andB_eq_true warm1353).2

theorem warm1354 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1354 1354) = true := by
  decide +kernel

theorem ok1354 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1354 1354 = true := (Snake9.LratV3.andB_eq_true warm1354).2

theorem warm1355 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1355 1355) = true := by
  decide +kernel

theorem ok1355 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1355 1355 = true := (Snake9.LratV3.andB_eq_true warm1355).2

theorem warm1356 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1356 1356) = true := by
  decide +kernel

theorem ok1356 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1356 1356 = true := (Snake9.LratV3.andB_eq_true warm1356).2

theorem warm1357 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1357 1357) = true := by
  decide +kernel

theorem ok1357 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1357 1357 = true := (Snake9.LratV3.andB_eq_true warm1357).2

theorem warm1358 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1358 1358) = true := by
  decide +kernel

theorem ok1358 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1358 1358 = true := (Snake9.LratV3.andB_eq_true warm1358).2

theorem warm1359 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1359 1359) = true := by
  decide +kernel

theorem ok1359 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1359 1359 = true := (Snake9.LratV3.andB_eq_true warm1359).2

theorem warm1360 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1360 1360) = true := by
  decide +kernel

theorem ok1360 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1360 1360 = true := (Snake9.LratV3.andB_eq_true warm1360).2

theorem warm1361 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1361 1361) = true := by
  decide +kernel

theorem ok1361 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1361 1361 = true := (Snake9.LratV3.andB_eq_true warm1361).2

theorem warm1362 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1362 1362) = true := by
  decide +kernel

theorem ok1362 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1362 1362 = true := (Snake9.LratV3.andB_eq_true warm1362).2

theorem warm1363 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 14) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1363 1363) = true := by
  decide +kernel

theorem ok1363 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1363 1363 = true := (Snake9.LratV3.andB_eq_true warm1363).2

theorem warm1364 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1364 1364) = true := by
  decide +kernel

theorem ok1364 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1364 1364 = true := (Snake9.LratV3.andB_eq_true warm1364).2

theorem warm1365 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1365 1365) = true := by
  decide +kernel

theorem ok1365 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1365 1365 = true := (Snake9.LratV3.andB_eq_true warm1365).2

theorem warm1366 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1366 1366) = true := by
  decide +kernel

theorem ok1366 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1366 1366 = true := (Snake9.LratV3.andB_eq_true warm1366).2

theorem warm1367 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1367 1367) = true := by
  decide +kernel

theorem ok1367 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1367 1367 = true := (Snake9.LratV3.andB_eq_true warm1367).2

theorem warm1368 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1368 1368) = true := by
  decide +kernel

theorem ok1368 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1368 1368 = true := (Snake9.LratV3.andB_eq_true warm1368).2

theorem warm1369 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1369 1369) = true := by
  decide +kernel

theorem ok1369 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1369 1369 = true := (Snake9.LratV3.andB_eq_true warm1369).2

theorem warm1370 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1000) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1370 1370) = true := by
  decide +kernel

theorem ok1370 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1370 1370 = true := (Snake9.LratV3.andB_eq_true warm1370).2

theorem warm1371 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1371 1371) = true := by
  decide +kernel

theorem ok1371 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1371 1371 = true := (Snake9.LratV3.andB_eq_true warm1371).2

theorem warm1372 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1372 1372) = true := by
  decide +kernel

theorem ok1372 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1372 1372 = true := (Snake9.LratV3.andB_eq_true warm1372).2

theorem warm1373 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1373 1373) = true := by
  decide +kernel

theorem ok1373 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1373 1373 = true := (Snake9.LratV3.andB_eq_true warm1373).2

theorem warm1374 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1374 1374) = true := by
  decide +kernel

theorem ok1374 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1374 1374 = true := (Snake9.LratV3.andB_eq_true warm1374).2

theorem warm1375 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1375 1375) = true := by
  decide +kernel

theorem ok1375 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1375 1375 = true := (Snake9.LratV3.andB_eq_true warm1375).2

theorem warm1376 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1376 1376) = true := by
  decide +kernel

theorem ok1376 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1376 1376 = true := (Snake9.LratV3.andB_eq_true warm1376).2

theorem warm1377 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1377 1377) = true := by
  decide +kernel

theorem ok1377 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1377 1377 = true := (Snake9.LratV3.andB_eq_true warm1377).2

theorem warm1378 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1378 1378) = true := by
  decide +kernel

theorem ok1378 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1378 1378 = true := (Snake9.LratV3.andB_eq_true warm1378).2

end Snake9.LocalWindow.V012032A45454
