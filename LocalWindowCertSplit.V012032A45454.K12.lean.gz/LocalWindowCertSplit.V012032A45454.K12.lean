module

-- LocalWindowCertSplit.V012032A45454: kernel checks of segments 1085..1188 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012032A45454.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012032A45454

theorem warm1085 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1085 1085) = true := by
  decide +kernel

theorem ok1085 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1085 1085 = true := (Snake9.LratV3.andB_eq_true warm1085).2

theorem warm1086 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1086 1086) = true := by
  decide +kernel

theorem ok1086 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1086 1086 = true := (Snake9.LratV3.andB_eq_true warm1086).2

theorem warm1087 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1087 1087) = true := by
  decide +kernel

theorem ok1087 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1087 1087 = true := (Snake9.LratV3.andB_eq_true warm1087).2

theorem warm1088 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1088 1088) = true := by
  decide +kernel

theorem ok1088 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1088 1088 = true := (Snake9.LratV3.andB_eq_true warm1088).2

theorem warm1089 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1089 1089) = true := by
  decide +kernel

theorem ok1089 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1089 1089 = true := (Snake9.LratV3.andB_eq_true warm1089).2

theorem warm1090 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1090 1090) = true := by
  decide +kernel

theorem ok1090 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1090 1090 = true := (Snake9.LratV3.andB_eq_true warm1090).2

theorem warm1091 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1000) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1091 1091) = true := by
  decide +kernel

theorem ok1091 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1091 1091 = true := (Snake9.LratV3.andB_eq_true warm1091).2

theorem warm1092 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1092 1092) = true := by
  decide +kernel

theorem ok1092 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1092 1092 = true := (Snake9.LratV3.andB_eq_true warm1092).2

theorem warm1093 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1093 1093) = true := by
  decide +kernel

theorem ok1093 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1093 1093 = true := (Snake9.LratV3.andB_eq_true warm1093).2

theorem warm1094 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1094 1094) = true := by
  decide +kernel

theorem ok1094 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1094 1094 = true := (Snake9.LratV3.andB_eq_true warm1094).2

theorem warm1095 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1095 1095) = true := by
  decide +kernel

theorem ok1095 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1095 1095 = true := (Snake9.LratV3.andB_eq_true warm1095).2

theorem warm1096 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1096 1096) = true := by
  decide +kernel

theorem ok1096 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1096 1096 = true := (Snake9.LratV3.andB_eq_true warm1096).2

theorem warm1097 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 84) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1097 1097) = true := by
  decide +kernel

theorem ok1097 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1097 1097 = true := (Snake9.LratV3.andB_eq_true warm1097).2

theorem warm1098 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1098 1098) = true := by
  decide +kernel

theorem ok1098 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1098 1098 = true := (Snake9.LratV3.andB_eq_true warm1098).2

theorem warm1099 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1099 1099) = true := by
  decide +kernel

theorem ok1099 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1099 1099 = true := (Snake9.LratV3.andB_eq_true warm1099).2

theorem warm1100 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1100 1100) = true := by
  decide +kernel

theorem ok1100 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1100 1100 = true := (Snake9.LratV3.andB_eq_true warm1100).2

theorem warm1101 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1101 1101) = true := by
  decide +kernel

theorem ok1101 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1101 1101 = true := (Snake9.LratV3.andB_eq_true warm1101).2

theorem warm1102 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1102 1102) = true := by
  decide +kernel

theorem ok1102 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1102 1102 = true := (Snake9.LratV3.andB_eq_true warm1102).2

theorem warm1103 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1103 1103) = true := by
  decide +kernel

theorem ok1103 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1103 1103 = true := (Snake9.LratV3.andB_eq_true warm1103).2

theorem warm1104 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1104 1104) = true := by
  decide +kernel

theorem ok1104 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1104 1104 = true := (Snake9.LratV3.andB_eq_true warm1104).2

theorem warm1105 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1105 1105) = true := by
  decide +kernel

theorem ok1105 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1105 1105 = true := (Snake9.LratV3.andB_eq_true warm1105).2

theorem warm1106 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1106 1106) = true := by
  decide +kernel

theorem ok1106 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1106 1106 = true := (Snake9.LratV3.andB_eq_true warm1106).2

theorem warm1107 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1107 1107) = true := by
  decide +kernel

theorem ok1107 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1107 1107 = true := (Snake9.LratV3.andB_eq_true warm1107).2

theorem warm1108 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1108 1108) = true := by
  decide +kernel

theorem ok1108 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1108 1108 = true := (Snake9.LratV3.andB_eq_true warm1108).2

theorem warm1109 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1109 1109) = true := by
  decide +kernel

theorem ok1109 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1109 1109 = true := (Snake9.LratV3.andB_eq_true warm1109).2

theorem warm1110 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1110 1110) = true := by
  decide +kernel

theorem ok1110 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1110 1110 = true := (Snake9.LratV3.andB_eq_true warm1110).2

theorem warm1111 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1111 1111) = true := by
  decide +kernel

theorem ok1111 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1111 1111 = true := (Snake9.LratV3.andB_eq_true warm1111).2

theorem warm1112 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1112 1112) = true := by
  decide +kernel

theorem ok1112 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1112 1112 = true := (Snake9.LratV3.andB_eq_true warm1112).2

theorem warm1113 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1113 1113) = true := by
  decide +kernel

theorem ok1113 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1113 1113 = true := (Snake9.LratV3.andB_eq_true warm1113).2

theorem warm1114 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1114 1114) = true := by
  decide +kernel

theorem ok1114 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1114 1114 = true := (Snake9.LratV3.andB_eq_true warm1114).2

theorem warm1115 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1115 1115) = true := by
  decide +kernel

theorem ok1115 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1115 1115 = true := (Snake9.LratV3.andB_eq_true warm1115).2

theorem warm1116 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1116 1116) = true := by
  decide +kernel

theorem ok1116 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1116 1116 = true := (Snake9.LratV3.andB_eq_true warm1116).2

theorem warm1117 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1117 1117) = true := by
  decide +kernel

theorem ok1117 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1117 1117 = true := (Snake9.LratV3.andB_eq_true warm1117).2

theorem warm1118 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1118 1118) = true := by
  decide +kernel

theorem ok1118 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1118 1118 = true := (Snake9.LratV3.andB_eq_true warm1118).2

theorem warm1119 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1119 1119) = true := by
  decide +kernel

theorem ok1119 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1119 1119 = true := (Snake9.LratV3.andB_eq_true warm1119).2

theorem warm1120 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1120 1120) = true := by
  decide +kernel

theorem ok1120 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1120 1120 = true := (Snake9.LratV3.andB_eq_true warm1120).2

theorem warm1121 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1121 1121) = true := by
  decide +kernel

theorem ok1121 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1121 1121 = true := (Snake9.LratV3.andB_eq_true warm1121).2

theorem warm1122 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1122 1122) = true := by
  decide +kernel

theorem ok1122 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1122 1122 = true := (Snake9.LratV3.andB_eq_true warm1122).2

theorem warm1123 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1123 1123) = true := by
  decide +kernel

theorem ok1123 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1123 1123 = true := (Snake9.LratV3.andB_eq_true warm1123).2

theorem warm1124 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1124 1124) = true := by
  decide +kernel

theorem ok1124 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1124 1124 = true := (Snake9.LratV3.andB_eq_true warm1124).2

theorem warm1125 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1125 1125) = true := by
  decide +kernel

theorem ok1125 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1125 1125 = true := (Snake9.LratV3.andB_eq_true warm1125).2

theorem warm1126 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1126 1126) = true := by
  decide +kernel

theorem ok1126 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1126 1126 = true := (Snake9.LratV3.andB_eq_true warm1126).2

theorem warm1127 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1127 1127) = true := by
  decide +kernel

theorem ok1127 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1127 1127 = true := (Snake9.LratV3.andB_eq_true warm1127).2

theorem warm1128 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1128 1128) = true := by
  decide +kernel

theorem ok1128 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1128 1128 = true := (Snake9.LratV3.andB_eq_true warm1128).2

theorem warm1129 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1129 1129) = true := by
  decide +kernel

theorem ok1129 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1129 1129 = true := (Snake9.LratV3.andB_eq_true warm1129).2

theorem warm1130 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1130 1130) = true := by
  decide +kernel

theorem ok1130 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1130 1130 = true := (Snake9.LratV3.andB_eq_true warm1130).2

theorem warm1131 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1131 1131) = true := by
  decide +kernel

theorem ok1131 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1131 1131 = true := (Snake9.LratV3.andB_eq_true warm1131).2

theorem warm1132 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1132 1132) = true := by
  decide +kernel

theorem ok1132 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1132 1132 = true := (Snake9.LratV3.andB_eq_true warm1132).2

theorem warm1133 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1133 1133) = true := by
  decide +kernel

theorem ok1133 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1133 1133 = true := (Snake9.LratV3.andB_eq_true warm1133).2

theorem warm1134 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1134 1134) = true := by
  decide +kernel

theorem ok1134 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1134 1134 = true := (Snake9.LratV3.andB_eq_true warm1134).2

theorem warm1135 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1135 1135) = true := by
  decide +kernel

theorem ok1135 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1135 1135 = true := (Snake9.LratV3.andB_eq_true warm1135).2

theorem warm1136 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 14) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1136 1136) = true := by
  decide +kernel

theorem ok1136 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1136 1136 = true := (Snake9.LratV3.andB_eq_true warm1136).2

theorem warm1137 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1137 1137) = true := by
  decide +kernel

theorem ok1137 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1137 1137 = true := (Snake9.LratV3.andB_eq_true warm1137).2

theorem warm1138 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1138 1138) = true := by
  decide +kernel

theorem ok1138 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1138 1138 = true := (Snake9.LratV3.andB_eq_true warm1138).2

theorem warm1139 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1139 1139) = true := by
  decide +kernel

theorem ok1139 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1139 1139 = true := (Snake9.LratV3.andB_eq_true warm1139).2

theorem warm1140 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1140 1140) = true := by
  decide +kernel

theorem ok1140 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1140 1140 = true := (Snake9.LratV3.andB_eq_true warm1140).2

theorem warm1141 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1141 1141) = true := by
  decide +kernel

theorem ok1141 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1141 1141 = true := (Snake9.LratV3.andB_eq_true warm1141).2

theorem warm1142 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1142 1142) = true := by
  decide +kernel

theorem ok1142 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1142 1142 = true := (Snake9.LratV3.andB_eq_true warm1142).2

theorem warm1143 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1143 1143) = true := by
  decide +kernel

theorem ok1143 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1143 1143 = true := (Snake9.LratV3.andB_eq_true warm1143).2

theorem warm1144 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1144 1144) = true := by
  decide +kernel

theorem ok1144 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1144 1144 = true := (Snake9.LratV3.andB_eq_true warm1144).2

theorem warm1145 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1145 1145) = true := by
  decide +kernel

theorem ok1145 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1145 1145 = true := (Snake9.LratV3.andB_eq_true warm1145).2

theorem warm1146 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1146 1146) = true := by
  decide +kernel

theorem ok1146 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1146 1146 = true := (Snake9.LratV3.andB_eq_true warm1146).2

theorem warm1147 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1147 1147) = true := by
  decide +kernel

theorem ok1147 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1147 1147 = true := (Snake9.LratV3.andB_eq_true warm1147).2

theorem warm1148 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1148 1148) = true := by
  decide +kernel

theorem ok1148 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1148 1148 = true := (Snake9.LratV3.andB_eq_true warm1148).2

theorem warm1149 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1149 1149) = true := by
  decide +kernel

theorem ok1149 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1149 1149 = true := (Snake9.LratV3.andB_eq_true warm1149).2

theorem warm1150 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 170) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1150 1150) = true := by
  decide +kernel

theorem ok1150 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1150 1150 = true := (Snake9.LratV3.andB_eq_true warm1150).2

theorem warm1151 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1151 1151) = true := by
  decide +kernel

theorem ok1151 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1151 1151 = true := (Snake9.LratV3.andB_eq_true warm1151).2

theorem warm1152 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1152 1152) = true := by
  decide +kernel

theorem ok1152 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1152 1152 = true := (Snake9.LratV3.andB_eq_true warm1152).2

theorem warm1153 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1153 1153) = true := by
  decide +kernel

theorem ok1153 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1153 1153 = true := (Snake9.LratV3.andB_eq_true warm1153).2

theorem warm1154 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1154 1154) = true := by
  decide +kernel

theorem ok1154 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1154 1154 = true := (Snake9.LratV3.andB_eq_true warm1154).2

theorem warm1155 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 84) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1155 1155) = true := by
  decide +kernel

theorem ok1155 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1155 1155 = true := (Snake9.LratV3.andB_eq_true warm1155).2

theorem warm1156 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1156 1156) = true := by
  decide +kernel

theorem ok1156 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1156 1156 = true := (Snake9.LratV3.andB_eq_true warm1156).2

theorem warm1157 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1157 1157) = true := by
  decide +kernel

theorem ok1157 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1157 1157 = true := (Snake9.LratV3.andB_eq_true warm1157).2

theorem warm1158 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1158 1158) = true := by
  decide +kernel

theorem ok1158 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1158 1158 = true := (Snake9.LratV3.andB_eq_true warm1158).2

theorem warm1159 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 170) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1159 1159) = true := by
  decide +kernel

theorem ok1159 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1159 1159 = true := (Snake9.LratV3.andB_eq_true warm1159).2

theorem warm1160 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1160 1160) = true := by
  decide +kernel

theorem ok1160 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1160 1160 = true := (Snake9.LratV3.andB_eq_true warm1160).2

theorem warm1161 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1161 1161) = true := by
  decide +kernel

theorem ok1161 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1161 1161 = true := (Snake9.LratV3.andB_eq_true warm1161).2

theorem warm1162 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1162 1162) = true := by
  decide +kernel

theorem ok1162 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1162 1162 = true := (Snake9.LratV3.andB_eq_true warm1162).2

theorem warm1163 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1163 1163) = true := by
  decide +kernel

theorem ok1163 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1163 1163 = true := (Snake9.LratV3.andB_eq_true warm1163).2

theorem warm1164 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1164 1164) = true := by
  decide +kernel

theorem ok1164 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1164 1164 = true := (Snake9.LratV3.andB_eq_true warm1164).2

theorem warm1165 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1165 1165) = true := by
  decide +kernel

theorem ok1165 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1165 1165 = true := (Snake9.LratV3.andB_eq_true warm1165).2

theorem warm1166 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1166 1166) = true := by
  decide +kernel

theorem ok1166 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1166 1166 = true := (Snake9.LratV3.andB_eq_true warm1166).2

theorem warm1167 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1167 1167) = true := by
  decide +kernel

theorem ok1167 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1167 1167 = true := (Snake9.LratV3.andB_eq_true warm1167).2

theorem warm1168 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1168 1168) = true := by
  decide +kernel

theorem ok1168 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1168 1168 = true := (Snake9.LratV3.andB_eq_true warm1168).2

theorem warm1169 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1169 1169) = true := by
  decide +kernel

theorem ok1169 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1169 1169 = true := (Snake9.LratV3.andB_eq_true warm1169).2

theorem warm1170 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1170 1170) = true := by
  decide +kernel

theorem ok1170 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1170 1170 = true := (Snake9.LratV3.andB_eq_true warm1170).2

theorem warm1171 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1171 1171) = true := by
  decide +kernel

theorem ok1171 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1171 1171 = true := (Snake9.LratV3.andB_eq_true warm1171).2

theorem warm1172 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1172 1172) = true := by
  decide +kernel

theorem ok1172 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1172 1172 = true := (Snake9.LratV3.andB_eq_true warm1172).2

theorem warm1173 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1173 1173) = true := by
  decide +kernel

theorem ok1173 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1173 1173 = true := (Snake9.LratV3.andB_eq_true warm1173).2

theorem warm1174 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1174 1174) = true := by
  decide +kernel

theorem ok1174 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1174 1174 = true := (Snake9.LratV3.andB_eq_true warm1174).2

theorem warm1175 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1175 1175) = true := by
  decide +kernel

theorem ok1175 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1175 1175 = true := (Snake9.LratV3.andB_eq_true warm1175).2

theorem warm1176 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1176 1176) = true := by
  decide +kernel

theorem ok1176 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1176 1176 = true := (Snake9.LratV3.andB_eq_true warm1176).2

theorem warm1177 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1177 1177) = true := by
  decide +kernel

theorem ok1177 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1177 1177 = true := (Snake9.LratV3.andB_eq_true warm1177).2

theorem warm1178 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1178 1178) = true := by
  decide +kernel

theorem ok1178 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1178 1178 = true := (Snake9.LratV3.andB_eq_true warm1178).2

theorem warm1179 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1179 1179) = true := by
  decide +kernel

theorem ok1179 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1179 1179 = true := (Snake9.LratV3.andB_eq_true warm1179).2

theorem warm1180 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1180 1180) = true := by
  decide +kernel

theorem ok1180 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1180 1180 = true := (Snake9.LratV3.andB_eq_true warm1180).2

theorem warm1181 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 170) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1181 1181) = true := by
  decide +kernel

theorem ok1181 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1181 1181 = true := (Snake9.LratV3.andB_eq_true warm1181).2

theorem warm1182 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1182 1182) = true := by
  decide +kernel

theorem ok1182 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1182 1182 = true := (Snake9.LratV3.andB_eq_true warm1182).2

theorem warm1183 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1183 1183) = true := by
  decide +kernel

theorem ok1183 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1183 1183 = true := (Snake9.LratV3.andB_eq_true warm1183).2

theorem warm1184 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1184 1184) = true := by
  decide +kernel

theorem ok1184 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1184 1184 = true := (Snake9.LratV3.andB_eq_true warm1184).2

theorem warm1185 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1185 1185) = true := by
  decide +kernel

theorem ok1185 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1185 1185 = true := (Snake9.LratV3.andB_eq_true warm1185).2

theorem warm1186 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1186 1186) = true := by
  decide +kernel

theorem ok1186 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1186 1186 = true := (Snake9.LratV3.andB_eq_true warm1186).2

theorem warm1187 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1187 1187) = true := by
  decide +kernel

theorem ok1187 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1187 1187 = true := (Snake9.LratV3.andB_eq_true warm1187).2

theorem warm1188 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1188 1188) = true := by
  decide +kernel

theorem ok1188 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1188 1188 = true := (Snake9.LratV3.andB_eq_true warm1188).2

end Snake9.LocalWindow.V012032A45454
