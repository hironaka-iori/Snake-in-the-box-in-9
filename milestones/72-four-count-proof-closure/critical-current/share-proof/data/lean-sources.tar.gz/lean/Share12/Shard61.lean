import Share12.Data
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Snake9.LocalWindow.ShareWindow12
open Snake9.LocalWindow.Tags
theorem shard61 : ckAllS meaning smeaning resolution ctrs tots window cap tags61 raw61 = true := by decide +kernel
#print axioms shard61
end Snake9.LocalWindow.ShareWindow12
