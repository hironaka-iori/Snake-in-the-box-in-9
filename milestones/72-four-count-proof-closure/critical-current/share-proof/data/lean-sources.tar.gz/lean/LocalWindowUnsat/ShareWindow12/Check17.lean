import LocalWindowUnsat.ShareWindow12.Data96
import LocalWindowUnsat.ShareWindow12.Data97
import LocalWindowUnsat.ShareWindow12.Data98
import LocalWindowUnsat.ShareWindow12.Data99
import LocalWindowUnsat.ShareWindow12.Data100
import LocalWindowUnsat.ShareWindow12.Data101
import LocalWindowUnsat.ShareWindow12.Data102

/-! Kernel checks of segments 97-102 of `share12` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow12
open Snake9.LratFastO8k14
open Snake9.LratO8k (Tree TreeTrue andB)

theorem ok97 : check start97 proof97 = true := by
  decide +kernel

theorem ok98 : check start98 proof98 = true := by
  decide +kernel

theorem ok99 : check start99 proof99 = true := by
  decide +kernel

theorem ok100 : andB (check start100 proof100) (cpOk (replay start100 proof100) start101) = true := by
  decide +kernel

theorem ok101 : check start101 proof101 = true := by
  decide +kernel

theorem ok102 : check start102 proof102 = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow12
