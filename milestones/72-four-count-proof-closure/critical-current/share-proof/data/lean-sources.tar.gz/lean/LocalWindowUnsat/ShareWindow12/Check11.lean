import LocalWindowUnsat.ShareWindow12.Data60
import LocalWindowUnsat.ShareWindow12.Data61
import LocalWindowUnsat.ShareWindow12.Data62
import LocalWindowUnsat.ShareWindow12.Data63
import LocalWindowUnsat.ShareWindow12.Data64
import LocalWindowUnsat.ShareWindow12.Data65
import LocalWindowUnsat.ShareWindow12.Data66

/-! Kernel checks of segments 61-66 of `share12` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow12
open Snake9.LratFastO8k14
open Snake9.LratO8k (Tree TreeTrue andB)

theorem ok61 : check start61 proof61 = true := by
  decide +kernel

theorem ok62 : check start62 proof62 = true := by
  decide +kernel

theorem ok63 : check start63 proof63 = true := by
  decide +kernel

theorem ok64 : andB (check start64 proof64) (cpOk (replay start64 proof64) start65) = true := by
  decide +kernel

theorem ok65 : check start65 proof65 = true := by
  decide +kernel

theorem ok66 : check start66 proof66 = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow12
