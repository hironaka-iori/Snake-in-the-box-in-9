import LocalWindowUnsat.ShareWindow12.Data114
import LocalWindowUnsat.ShareWindow12.Data115
import LocalWindowUnsat.ShareWindow12.Data116

/-! Kernel checks of segments 115-116 of `share12` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow12
open Snake9.LratFastO8k14
open Snake9.LratO8k (Tree TreeTrue andB)

theorem ok115 : check start115 proof115 = true := by
  decide +kernel

theorem ok116 : andB (check start116 proof116) (hasEmpty (replay start116 proof116) 8192) = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow12
