import Share120.Data
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Snake9.LocalWindow.ShareWindow120
open Snake9.LocalWindow.Tags
theorem shard28 : ckAllS meaning smeaning resolution ctrs tots window cap tags28 raw28 = true := by decide +kernel
#print axioms shard28
end Snake9.LocalWindow.ShareWindow120
