import LocalWindowUnsat.CycleWindow7206.Data390
import LocalWindowUnsat.CycleWindow7206.Data391
import LocalWindowUnsat.CycleWindow7206.Data392

/-! Kernel checks of segments 391-392 of `cycle7206` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7206
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok391 : check start391 proof391 = true := by
  decide +kernel

theorem ok392 : andB (check start392 proof392) (hasEmpty (replay start392 proof392) 16384) = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7206
