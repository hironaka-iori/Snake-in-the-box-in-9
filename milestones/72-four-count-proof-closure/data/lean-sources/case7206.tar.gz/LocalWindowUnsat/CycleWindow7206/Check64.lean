import LocalWindowUnsat.CycleWindow7206.Data378
import LocalWindowUnsat.CycleWindow7206.Data379
import LocalWindowUnsat.CycleWindow7206.Data380
import LocalWindowUnsat.CycleWindow7206.Data381
import LocalWindowUnsat.CycleWindow7206.Data382
import LocalWindowUnsat.CycleWindow7206.Data383
import LocalWindowUnsat.CycleWindow7206.Data384

/-! Kernel checks of segments 379-384 of `cycle7206` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7206
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok379 : check start379 proof379 = true := by
  decide +kernel

theorem ok380 : andB (check start380 proof380) (cpOk (replay start380 proof380) start381) = true := by
  decide +kernel

theorem ok381 : check start381 proof381 = true := by
  decide +kernel

theorem ok382 : check start382 proof382 = true := by
  decide +kernel

theorem ok383 : check start383 proof383 = true := by
  decide +kernel

theorem ok384 : andB (check start384 proof384) (cpOk (replay start384 proof384) start385) = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7206
