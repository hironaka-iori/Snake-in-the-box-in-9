import LocalWindowUnsat.CycleWindow7206.Data372
import LocalWindowUnsat.CycleWindow7206.Data373
import LocalWindowUnsat.CycleWindow7206.Data374
import LocalWindowUnsat.CycleWindow7206.Data375
import LocalWindowUnsat.CycleWindow7206.Data376
import LocalWindowUnsat.CycleWindow7206.Data377
import LocalWindowUnsat.CycleWindow7206.Data378

/-! Kernel checks of segments 373-378 of `cycle7206` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7206
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok373 : check start373 proof373 = true := by
  decide +kernel

theorem ok374 : check start374 proof374 = true := by
  decide +kernel

theorem ok375 : check start375 proof375 = true := by
  decide +kernel

theorem ok376 : andB (check start376 proof376) (cpOk (replay start376 proof376) start377) = true := by
  decide +kernel

theorem ok377 : check start377 proof377 = true := by
  decide +kernel

theorem ok378 : check start378 proof378 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7206
