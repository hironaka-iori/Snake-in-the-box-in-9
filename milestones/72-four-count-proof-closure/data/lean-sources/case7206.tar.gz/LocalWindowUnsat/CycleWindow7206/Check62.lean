import LocalWindowUnsat.CycleWindow7206.Data366
import LocalWindowUnsat.CycleWindow7206.Data367
import LocalWindowUnsat.CycleWindow7206.Data368
import LocalWindowUnsat.CycleWindow7206.Data369
import LocalWindowUnsat.CycleWindow7206.Data370
import LocalWindowUnsat.CycleWindow7206.Data371
import LocalWindowUnsat.CycleWindow7206.Data372

/-! Kernel checks of segments 367-372 of `cycle7206` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7206
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok367 : check start367 proof367 = true := by
  decide +kernel

theorem ok368 : andB (check start368 proof368) (cpOk (replay start368 proof368) start369) = true := by
  decide +kernel

theorem ok369 : check start369 proof369 = true := by
  decide +kernel

theorem ok370 : check start370 proof370 = true := by
  decide +kernel

theorem ok371 : check start371 proof371 = true := by
  decide +kernel

theorem ok372 : andB (check start372 proof372) (cpOk (replay start372 proof372) start373) = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7206
