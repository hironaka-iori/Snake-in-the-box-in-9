import LocalWindowUnsat.CycleWindow7206.Data228
import LocalWindowUnsat.CycleWindow7206.Data229
import LocalWindowUnsat.CycleWindow7206.Data230
import LocalWindowUnsat.CycleWindow7206.Data231
import LocalWindowUnsat.CycleWindow7206.Data232
import LocalWindowUnsat.CycleWindow7206.Data233
import LocalWindowUnsat.CycleWindow7206.Data234

/-! Kernel checks of segments 229-234 of `cycle7206` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7206
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok229 : check start229 proof229 = true := by
  decide +kernel

theorem ok230 : check start230 proof230 = true := by
  decide +kernel

theorem ok231 : check start231 proof231 = true := by
  decide +kernel

theorem ok232 : andB (check start232 proof232) (cpOk (replay start232 proof232) start233) = true := by
  decide +kernel

theorem ok233 : check start233 proof233 = true := by
  decide +kernel

theorem ok234 : check start234 proof234 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7206
