import LocalWindowUnsat.CycleWindow7202.Data462
import LocalWindowUnsat.CycleWindow7202.Data463
import LocalWindowUnsat.CycleWindow7202.Data464

/-! Kernel checks of segments 463-464 of `cycle7202` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7202
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok463 : check start463 proof463 = true := by
  decide +kernel

theorem ok464 : andB (check start464 proof464) (hasEmpty (replay start464 proof464) 16384) = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7202
