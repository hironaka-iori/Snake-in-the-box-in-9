import LocalWindowUnsat.CycleWindow7202.Data444
import LocalWindowUnsat.CycleWindow7202.Data445
import LocalWindowUnsat.CycleWindow7202.Data446
import LocalWindowUnsat.CycleWindow7202.Data447
import LocalWindowUnsat.CycleWindow7202.Data448
import LocalWindowUnsat.CycleWindow7202.Data449
import LocalWindowUnsat.CycleWindow7202.Data450

/-! Kernel checks of segments 445-450 of `cycle7202` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7202
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok445 : check start445 proof445 = true := by
  decide +kernel

theorem ok446 : check start446 proof446 = true := by
  decide +kernel

theorem ok447 : check start447 proof447 = true := by
  decide +kernel

theorem ok448 : andB (check start448 proof448) (cpOk (replay start448 proof448) start449) = true := by
  decide +kernel

theorem ok449 : check start449 proof449 = true := by
  decide +kernel

theorem ok450 : check start450 proof450 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7202
