import LocalWindowUnsat.CycleWindow7202.Data396
import LocalWindowUnsat.CycleWindow7202.Data397
import LocalWindowUnsat.CycleWindow7202.Data398
import LocalWindowUnsat.CycleWindow7202.Data399
import LocalWindowUnsat.CycleWindow7202.Data400
import LocalWindowUnsat.CycleWindow7202.Data401
import LocalWindowUnsat.CycleWindow7202.Data402

/-! Kernel checks of segments 397-402 of `cycle7202` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7202
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok397 : check start397 proof397 = true := by
  decide +kernel

theorem ok398 : check start398 proof398 = true := by
  decide +kernel

theorem ok399 : check start399 proof399 = true := by
  decide +kernel

theorem ok400 : andB (check start400 proof400) (cpOk (replay start400 proof400) start401) = true := by
  decide +kernel

theorem ok401 : check start401 proof401 = true := by
  decide +kernel

theorem ok402 : check start402 proof402 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7202
