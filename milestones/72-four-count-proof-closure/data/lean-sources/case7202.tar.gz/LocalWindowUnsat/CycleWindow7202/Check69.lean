import LocalWindowUnsat.CycleWindow7202.Data408
import LocalWindowUnsat.CycleWindow7202.Data409
import LocalWindowUnsat.CycleWindow7202.Data410
import LocalWindowUnsat.CycleWindow7202.Data411
import LocalWindowUnsat.CycleWindow7202.Data412
import LocalWindowUnsat.CycleWindow7202.Data413
import LocalWindowUnsat.CycleWindow7202.Data414

/-! Kernel checks of segments 409-414 of `cycle7202` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7202
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok409 : check start409 proof409 = true := by
  decide +kernel

theorem ok410 : check start410 proof410 = true := by
  decide +kernel

theorem ok411 : check start411 proof411 = true := by
  decide +kernel

theorem ok412 : andB (check start412 proof412) (cpOk (replay start412 proof412) start413) = true := by
  decide +kernel

theorem ok413 : check start413 proof413 = true := by
  decide +kernel

theorem ok414 : check start414 proof414 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7202
