import LocalWindowUnsat.CycleWindow7202.Data456
import LocalWindowUnsat.CycleWindow7202.Data457
import LocalWindowUnsat.CycleWindow7202.Data458
import LocalWindowUnsat.CycleWindow7202.Data459
import LocalWindowUnsat.CycleWindow7202.Data460
import LocalWindowUnsat.CycleWindow7202.Data461
import LocalWindowUnsat.CycleWindow7202.Data462

/-! Kernel checks of segments 457-462 of `cycle7202` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7202
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok457 : check start457 proof457 = true := by
  decide +kernel

theorem ok458 : check start458 proof458 = true := by
  decide +kernel

theorem ok459 : check start459 proof459 = true := by
  decide +kernel

theorem ok460 : andB (check start460 proof460) (cpOk (replay start460 proof460) start461) = true := by
  decide +kernel

theorem ok461 : check start461 proof461 = true := by
  decide +kernel

theorem ok462 : check start462 proof462 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7202
