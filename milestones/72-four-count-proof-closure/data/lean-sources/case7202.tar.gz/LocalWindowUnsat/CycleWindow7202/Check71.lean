import LocalWindowUnsat.CycleWindow7202.Data420
import LocalWindowUnsat.CycleWindow7202.Data421
import LocalWindowUnsat.CycleWindow7202.Data422
import LocalWindowUnsat.CycleWindow7202.Data423
import LocalWindowUnsat.CycleWindow7202.Data424
import LocalWindowUnsat.CycleWindow7202.Data425
import LocalWindowUnsat.CycleWindow7202.Data426

/-! Kernel checks of segments 421-426 of `cycle7202` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7202
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok421 : check start421 proof421 = true := by
  decide +kernel

theorem ok422 : check start422 proof422 = true := by
  decide +kernel

theorem ok423 : check start423 proof423 = true := by
  decide +kernel

theorem ok424 : andB (check start424 proof424) (cpOk (replay start424 proof424) start425) = true := by
  decide +kernel

theorem ok425 : check start425 proof425 = true := by
  decide +kernel

theorem ok426 : check start426 proof426 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7202
