import LocalWindowUnsat.CycleWindow7202.Data432
import LocalWindowUnsat.CycleWindow7202.Data433
import LocalWindowUnsat.CycleWindow7202.Data434
import LocalWindowUnsat.CycleWindow7202.Data435
import LocalWindowUnsat.CycleWindow7202.Data436
import LocalWindowUnsat.CycleWindow7202.Data437
import LocalWindowUnsat.CycleWindow7202.Data438

/-! Kernel checks of segments 433-438 of `cycle7202` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7202
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok433 : check start433 proof433 = true := by
  decide +kernel

theorem ok434 : check start434 proof434 = true := by
  decide +kernel

theorem ok435 : check start435 proof435 = true := by
  decide +kernel

theorem ok436 : andB (check start436 proof436) (cpOk (replay start436 proof436) start437) = true := by
  decide +kernel

theorem ok437 : check start437 proof437 = true := by
  decide +kernel

theorem ok438 : check start438 proof438 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7202
