import LocalWindowUnsat.CycleWindow7202.Data384
import LocalWindowUnsat.CycleWindow7202.Data385
import LocalWindowUnsat.CycleWindow7202.Data386
import LocalWindowUnsat.CycleWindow7202.Data387
import LocalWindowUnsat.CycleWindow7202.Data388
import LocalWindowUnsat.CycleWindow7202.Data389
import LocalWindowUnsat.CycleWindow7202.Data390

/-! Kernel checks of segments 385-390 of `cycle7202` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7202
open Snake9.LratFast15
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok385 : check start385 proof385 = true := by
  decide +kernel

theorem ok386 : check start386 proof386 = true := by
  decide +kernel

theorem ok387 : check start387 proof387 = true := by
  decide +kernel

theorem ok388 : andB (check start388 proof388) (cpOk (replay start388 proof388) start389) = true := by
  decide +kernel

theorem ok389 : check start389 proof389 = true := by
  decide +kernel

theorem ok390 : check start390 proof390 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7202
