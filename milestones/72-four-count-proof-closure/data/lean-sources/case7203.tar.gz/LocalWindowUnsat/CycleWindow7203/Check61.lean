import LocalWindowUnsat.CycleWindow7203.Data360
import LocalWindowUnsat.CycleWindow7203.Data361
import LocalWindowUnsat.CycleWindow7203.Data362
import LocalWindowUnsat.CycleWindow7203.Data363
import LocalWindowUnsat.CycleWindow7203.Data364
import LocalWindowUnsat.CycleWindow7203.Data365
import LocalWindowUnsat.CycleWindow7203.Data366

/-! Kernel checks of segments 361-366 of `cycle7203` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7203
open Snake9.LratFast14
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok361 : check start361 proof361 = true := by
  decide +kernel

theorem ok362 : check start362 proof362 = true := by
  decide +kernel

theorem ok363 : check start363 proof363 = true := by
  decide +kernel

theorem ok364 : andB (check start364 proof364) (cpOk (replay start364 proof364) start365) = true := by
  decide +kernel

theorem ok365 : check start365 proof365 = true := by
  decide +kernel

theorem ok366 : check start366 proof366 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7203
