import LocalWindowUnsat.CycleWindow7203.Data414
import LocalWindowUnsat.CycleWindow7203.Data415

/-! Kernel checks of segments 415-415 of `cycle7203` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7203
open Snake9.LratFast14
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok415 : andB (check start415 proof415) (hasEmpty (replay start415 proof415) 8192) = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7203
