import LocalWindowUnsat.CycleWindow7212.Data294
import LocalWindowUnsat.CycleWindow7212.Data295
import LocalWindowUnsat.CycleWindow7212.Data296

/-! Kernel checks of segments 295-296 of `cycle7212` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7212
open Snake9.LratFast14
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok295 : check start295 proof295 = true := by
  decide +kernel

theorem ok296 : andB (check start296 proof296) (hasEmpty (replay start296 proof296) 8192) = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7212
