import LocalWindowUnsat.CycleWindow7212.Data288
import LocalWindowUnsat.CycleWindow7212.Data289
import LocalWindowUnsat.CycleWindow7212.Data290
import LocalWindowUnsat.CycleWindow7212.Data291
import LocalWindowUnsat.CycleWindow7212.Data292
import LocalWindowUnsat.CycleWindow7212.Data293
import LocalWindowUnsat.CycleWindow7212.Data294

/-! Kernel checks of segments 289-294 of `cycle7212` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7212
open Snake9.LratFast14
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok289 : check start289 proof289 = true := by
  decide +kernel

theorem ok290 : check start290 proof290 = true := by
  decide +kernel

theorem ok291 : check start291 proof291 = true := by
  decide +kernel

theorem ok292 : andB (check start292 proof292) (cpOk (replay start292 proof292) start293) = true := by
  decide +kernel

theorem ok293 : check start293 proof293 = true := by
  decide +kernel

theorem ok294 : check start294 proof294 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7212
