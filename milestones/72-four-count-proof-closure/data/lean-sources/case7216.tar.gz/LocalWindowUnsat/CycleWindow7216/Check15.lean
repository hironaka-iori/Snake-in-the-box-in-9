import LocalWindowUnsat.CycleWindow7216.Data84
import LocalWindowUnsat.CycleWindow7216.Data85
import LocalWindowUnsat.CycleWindow7216.Data86
import LocalWindowUnsat.CycleWindow7216.Data87
import LocalWindowUnsat.CycleWindow7216.Data88
import LocalWindowUnsat.CycleWindow7216.Data89
import LocalWindowUnsat.CycleWindow7216.Data90

/-! Kernel checks of segments 85-90 of `cycle7216` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7216
open Snake9.LratFast
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok85 : check start85 proof85 = true := by
  decide +kernel

theorem ok86 : check start86 proof86 = true := by
  decide +kernel

theorem ok87 : check start87 proof87 = true := by
  decide +kernel

theorem ok88 : andB (check start88 proof88) (cpOk (replay start88 proof88) start89) = true := by
  decide +kernel

theorem ok89 : check start89 proof89 = true := by
  decide +kernel

theorem ok90 : check start90 proof90 = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7216
