import LocalWindowUnsat.CycleWindow7216.Data120
import LocalWindowUnsat.CycleWindow7216.Data121

/-! Kernel checks of segments 121-121 of `cycle7216` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7216
open Snake9.LratFast
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok121 : andB (check start121 proof121) (hasEmpty (replay start121 proof121) 4096) = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7216
