import LocalWindowUnsat.CycleWindow7211.Data66
import LocalWindowUnsat.CycleWindow7211.Data67

/-! Kernel checks of segments 67-67 of `cycle7211` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.CycleWindow7211
open Snake9.LratFast
open Snake9.Lrat (Tree TreeTrue andB)

theorem ok67 : andB (check start67 proof67) (hasEmpty (replay start67 proof67) 4096) = true := by
  decide +kernel

end Snake9.LocalWindow.CycleWindow7211
