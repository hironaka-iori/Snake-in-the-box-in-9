import ReplayData147_0057
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1836 : check start1836 proof1836 = true := by
  decide +kernel
#print axioms ok1836
theorem ok1837 : check start1837 proof1837 = true := by
  decide +kernel
#print axioms ok1837
theorem ok1838 : check start1838 proof1838 = true := by
  decide +kernel
#print axioms ok1838
theorem ok1839 : check start1839 proof1839 = true := by
  decide +kernel
#print axioms ok1839
end Snake9.ReplayFull147
