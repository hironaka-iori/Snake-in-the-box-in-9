import ReplayData147_0023
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok736 : check start736 proof736 = true := by
  decide +kernel
#print axioms ok736
theorem ok737 : check start737 proof737 = true := by
  decide +kernel
#print axioms ok737
theorem ok738 : check start738 proof738 = true := by
  decide +kernel
#print axioms ok738
theorem ok739 : check start739 proof739 = true := by
  decide +kernel
#print axioms ok739
end Snake9.ReplayFull147
