import ReplayData147_0045
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1464 : check start1464 proof1464 = true := by
  decide +kernel
#print axioms ok1464
theorem ok1465 : check start1465 proof1465 = true := by
  decide +kernel
#print axioms ok1465
theorem ok1466 : check start1466 proof1466 = true := by
  decide +kernel
#print axioms ok1466
theorem ok1467 : check start1467 proof1467 = true := by
  decide +kernel
#print axioms ok1467
end Snake9.ReplayFull147
