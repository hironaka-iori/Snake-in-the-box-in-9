import ReplayData147_0051
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1632 : check start1632 proof1632 = true := by
  decide +kernel
#print axioms ok1632
theorem ok1633 : check start1633 proof1633 = true := by
  decide +kernel
#print axioms ok1633
theorem ok1634 : check start1634 proof1634 = true := by
  decide +kernel
#print axioms ok1634
theorem ok1635 : check start1635 proof1635 = true := by
  decide +kernel
#print axioms ok1635
end Snake9.ReplayFull147
