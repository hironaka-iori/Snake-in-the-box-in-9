import ReplayData147_0057
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1844 : check start1844 proof1844 = true := by
  decide +kernel
#print axioms ok1844
theorem ok1845 : check start1845 proof1845 = true := by
  decide +kernel
#print axioms ok1845
theorem ok1846 : check start1846 proof1846 = true := by
  decide +kernel
#print axioms ok1846
theorem ok1847 : check start1847 proof1847 = true := by
  decide +kernel
#print axioms ok1847
end Snake9.ReplayFull147
