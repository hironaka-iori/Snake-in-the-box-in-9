import ReplayData147_0057
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1832 : check start1832 proof1832 = true := by
  decide +kernel
#print axioms ok1832
theorem ok1833 : check start1833 proof1833 = true := by
  decide +kernel
#print axioms ok1833
theorem ok1834 : check start1834 proof1834 = true := by
  decide +kernel
#print axioms ok1834
theorem ok1835 : check start1835 proof1835 = true := by
  decide +kernel
#print axioms ok1835
end Snake9.ReplayFull147
