import ReplayData147_0031
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1004 : check start1004 proof1004 = true := by
  decide +kernel
#print axioms ok1004
theorem ok1005 : check start1005 proof1005 = true := by
  decide +kernel
#print axioms ok1005
theorem ok1006 : check start1006 proof1006 = true := by
  decide +kernel
#print axioms ok1006
theorem ok1007 : check start1007 proof1007 = true := by
  decide +kernel
#print axioms ok1007
end Snake9.ReplayFull147
