import ReplayData147_0001
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok36 : check start36 proof36 = true := by
  decide +kernel
#print axioms ok36
theorem ok37 : check start37 proof37 = true := by
  decide +kernel
#print axioms ok37
theorem ok38 : check start38 proof38 = true := by
  decide +kernel
#print axioms ok38
theorem ok39 : check start39 proof39 = true := by
  decide +kernel
#print axioms ok39
end Snake9.ReplayFull147
