import ReplayData147_0031
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1008 : check start1008 proof1008 = true := by
  decide +kernel
#print axioms ok1008
theorem ok1009 : check start1009 proof1009 = true := by
  decide +kernel
#print axioms ok1009
theorem ok1010 : check start1010 proof1010 = true := by
  decide +kernel
#print axioms ok1010
theorem ok1011 : check start1011 proof1011 = true := by
  decide +kernel
#print axioms ok1011
end Snake9.ReplayFull147
