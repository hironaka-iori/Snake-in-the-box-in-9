import ReplayData147_0023
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok744 : check start744 proof744 = true := by
  decide +kernel
#print axioms ok744
theorem ok745 : check start745 proof745 = true := by
  decide +kernel
#print axioms ok745
theorem ok746 : check start746 proof746 = true := by
  decide +kernel
#print axioms ok746
theorem ok747 : check start747 proof747 = true := by
  decide +kernel
#print axioms ok747
end Snake9.ReplayFull147
