import ReplayData147_0009
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok300 : check start300 proof300 = true := by
  decide +kernel
#print axioms ok300
theorem ok301 : check start301 proof301 = true := by
  decide +kernel
#print axioms ok301
theorem ok302 : check start302 proof302 = true := by
  decide +kernel
#print axioms ok302
theorem ok303 : check start303 proof303 = true := by
  decide +kernel
#print axioms ok303
end Snake9.ReplayFull147
