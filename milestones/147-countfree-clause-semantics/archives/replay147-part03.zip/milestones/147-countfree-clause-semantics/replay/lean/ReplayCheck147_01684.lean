import ReplayData147_0052
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1684 : check start1684 proof1684 = true := by
  decide +kernel
#print axioms ok1684
theorem ok1685 : check start1685 proof1685 = true := by
  decide +kernel
#print axioms ok1685
theorem ok1686 : check start1686 proof1686 = true := by
  decide +kernel
#print axioms ok1686
theorem ok1687 : check start1687 proof1687 = true := by
  decide +kernel
#print axioms ok1687
end Snake9.ReplayFull147
