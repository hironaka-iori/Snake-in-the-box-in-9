import ReplayData147_0050
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1624 : check start1624 proof1624 = true := by
  decide +kernel
#print axioms ok1624
theorem ok1625 : check start1625 proof1625 = true := by
  decide +kernel
#print axioms ok1625
theorem ok1626 : check start1626 proof1626 = true := by
  decide +kernel
#print axioms ok1626
theorem ok1627 : check start1627 proof1627 = true := by
  decide +kernel
#print axioms ok1627
end Snake9.ReplayFull147
