import ReplayData147_0048
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1536 : check start1536 proof1536 = true := by
  decide +kernel
#print axioms ok1536
theorem ok1537 : check start1537 proof1537 = true := by
  decide +kernel
#print axioms ok1537
theorem ok1538 : check start1538 proof1538 = true := by
  decide +kernel
#print axioms ok1538
theorem ok1539 : check start1539 proof1539 = true := by
  decide +kernel
#print axioms ok1539
end Snake9.ReplayFull147
