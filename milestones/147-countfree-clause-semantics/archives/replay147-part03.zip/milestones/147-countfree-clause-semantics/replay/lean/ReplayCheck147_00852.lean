import ReplayData147_0026
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok852 : check start852 proof852 = true := by
  decide +kernel
#print axioms ok852
theorem ok853 : check start853 proof853 = true := by
  decide +kernel
#print axioms ok853
theorem ok854 : check start854 proof854 = true := by
  decide +kernel
#print axioms ok854
theorem ok855 : check start855 proof855 = true := by
  decide +kernel
#print axioms ok855
end Snake9.ReplayFull147
