import ReplayData147_0053
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1716 : check start1716 proof1716 = true := by
  decide +kernel
#print axioms ok1716
theorem ok1717 : check start1717 proof1717 = true := by
  decide +kernel
#print axioms ok1717
theorem ok1718 : check start1718 proof1718 = true := by
  decide +kernel
#print axioms ok1718
theorem ok1719 : check start1719 proof1719 = true := by
  decide +kernel
#print axioms ok1719
end Snake9.ReplayFull147
