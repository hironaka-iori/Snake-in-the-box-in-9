import ReplayData147_0025
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok816 : check start816 proof816 = true := by
  decide +kernel
#print axioms ok816
theorem ok817 : check start817 proof817 = true := by
  decide +kernel
#print axioms ok817
theorem ok818 : check start818 proof818 = true := by
  decide +kernel
#print axioms ok818
theorem ok819 : check start819 proof819 = true := by
  decide +kernel
#print axioms ok819
end Snake9.ReplayFull147
