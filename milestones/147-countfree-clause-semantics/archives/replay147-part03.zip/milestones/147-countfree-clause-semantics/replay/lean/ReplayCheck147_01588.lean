import ReplayData147_0049
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1588 : check start1588 proof1588 = true := by
  decide +kernel
#print axioms ok1588
theorem ok1589 : check start1589 proof1589 = true := by
  decide +kernel
#print axioms ok1589
theorem ok1590 : check start1590 proof1590 = true := by
  decide +kernel
#print axioms ok1590
theorem ok1591 : check start1591 proof1591 = true := by
  decide +kernel
#print axioms ok1591
end Snake9.ReplayFull147
