import ReplayData147_0056
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1792 : check start1792 proof1792 = true := by
  decide +kernel
#print axioms ok1792
theorem ok1793 : check start1793 proof1793 = true := by
  decide +kernel
#print axioms ok1793
theorem ok1794 : check start1794 proof1794 = true := by
  decide +kernel
#print axioms ok1794
theorem ok1795 : check start1795 proof1795 = true := by
  decide +kernel
#print axioms ok1795
end Snake9.ReplayFull147
