import ReplayData147_0033
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1072 : check start1072 proof1072 = true := by
  decide +kernel
#print axioms ok1072
theorem ok1073 : check start1073 proof1073 = true := by
  decide +kernel
#print axioms ok1073
theorem ok1074 : check start1074 proof1074 = true := by
  decide +kernel
#print axioms ok1074
theorem ok1075 : check start1075 proof1075 = true := by
  decide +kernel
#print axioms ok1075
end Snake9.ReplayFull147
