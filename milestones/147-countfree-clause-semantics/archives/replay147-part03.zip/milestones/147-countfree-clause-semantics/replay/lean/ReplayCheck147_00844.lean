import ReplayData147_0026
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok844 : check start844 proof844 = true := by
  decide +kernel
#print axioms ok844
theorem ok845 : check start845 proof845 = true := by
  decide +kernel
#print axioms ok845
theorem ok846 : check start846 proof846 = true := by
  decide +kernel
#print axioms ok846
theorem ok847 : check start847 proof847 = true := by
  decide +kernel
#print axioms ok847
end Snake9.ReplayFull147
