import ReplayData147_0039
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1272 : check start1272 proof1272 = true := by
  decide +kernel
#print axioms ok1272
theorem ok1273 : check start1273 proof1273 = true := by
  decide +kernel
#print axioms ok1273
theorem ok1274 : check start1274 proof1274 = true := by
  decide +kernel
#print axioms ok1274
theorem ok1275 : check start1275 proof1275 = true := by
  decide +kernel
#print axioms ok1275
end Snake9.ReplayFull147
