import ReplayData147_0041
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1332 : check start1332 proof1332 = true := by
  decide +kernel
#print axioms ok1332
theorem ok1333 : check start1333 proof1333 = true := by
  decide +kernel
#print axioms ok1333
theorem ok1334 : check start1334 proof1334 = true := by
  decide +kernel
#print axioms ok1334
theorem ok1335 : check start1335 proof1335 = true := by
  decide +kernel
#print axioms ok1335
end Snake9.ReplayFull147
