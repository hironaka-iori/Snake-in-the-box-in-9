import ReplayData147_0049
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1592 : check start1592 proof1592 = true := by
  decide +kernel
#print axioms ok1592
theorem ok1593 : check start1593 proof1593 = true := by
  decide +kernel
#print axioms ok1593
theorem ok1594 : check start1594 proof1594 = true := by
  decide +kernel
#print axioms ok1594
theorem ok1595 : check start1595 proof1595 = true := by
  decide +kernel
#print axioms ok1595
end Snake9.ReplayFull147
