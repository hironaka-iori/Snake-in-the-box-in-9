import ReplayData147_0033
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1080 : check start1080 proof1080 = true := by
  decide +kernel
#print axioms ok1080
theorem ok1081 : check start1081 proof1081 = true := by
  decide +kernel
#print axioms ok1081
theorem ok1082 : check start1082 proof1082 = true := by
  decide +kernel
#print axioms ok1082
theorem ok1083 : check start1083 proof1083 = true := by
  decide +kernel
#print axioms ok1083
end Snake9.ReplayFull147
