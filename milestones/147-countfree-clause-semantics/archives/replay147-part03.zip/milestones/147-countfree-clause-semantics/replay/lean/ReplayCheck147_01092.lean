import ReplayData147_0034
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1092 : check start1092 proof1092 = true := by
  decide +kernel
#print axioms ok1092
theorem ok1093 : check start1093 proof1093 = true := by
  decide +kernel
#print axioms ok1093
theorem ok1094 : check start1094 proof1094 = true := by
  decide +kernel
#print axioms ok1094
theorem ok1095 : check start1095 proof1095 = true := by
  decide +kernel
#print axioms ok1095
end Snake9.ReplayFull147
