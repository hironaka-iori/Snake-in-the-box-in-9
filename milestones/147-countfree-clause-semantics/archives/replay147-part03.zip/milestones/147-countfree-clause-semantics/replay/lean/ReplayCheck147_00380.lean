import ReplayData147_0011
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok380 : check start380 proof380 = true := by
  decide +kernel
#print axioms ok380
theorem ok381 : check start381 proof381 = true := by
  decide +kernel
#print axioms ok381
theorem ok382 : check start382 proof382 = true := by
  decide +kernel
#print axioms ok382
theorem ok383 : andB (check start383 proof383) (cpOk (replay start383 proof383) start384) = true := by
  decide +kernel
#print axioms ok383
end Snake9.ReplayFull147
