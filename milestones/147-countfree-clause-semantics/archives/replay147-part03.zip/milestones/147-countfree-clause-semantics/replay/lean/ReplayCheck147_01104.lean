import ReplayData147_0034
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1104 : check start1104 proof1104 = true := by
  decide +kernel
#print axioms ok1104
theorem ok1105 : check start1105 proof1105 = true := by
  decide +kernel
#print axioms ok1105
theorem ok1106 : check start1106 proof1106 = true := by
  decide +kernel
#print axioms ok1106
theorem ok1107 : check start1107 proof1107 = true := by
  decide +kernel
#print axioms ok1107
end Snake9.ReplayFull147
