import ReplayData147_0003
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok112 : check start112 proof112 = true := by
  decide +kernel
#print axioms ok112
theorem ok113 : check start113 proof113 = true := by
  decide +kernel
#print axioms ok113
theorem ok114 : check start114 proof114 = true := by
  decide +kernel
#print axioms ok114
theorem ok115 : check start115 proof115 = true := by
  decide +kernel
#print axioms ok115
end Snake9.ReplayFull147
