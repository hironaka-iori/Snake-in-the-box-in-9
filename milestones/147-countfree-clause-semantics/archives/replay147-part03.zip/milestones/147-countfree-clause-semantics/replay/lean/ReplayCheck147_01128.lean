import ReplayData147_0035
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1128 : check start1128 proof1128 = true := by
  decide +kernel
#print axioms ok1128
theorem ok1129 : check start1129 proof1129 = true := by
  decide +kernel
#print axioms ok1129
theorem ok1130 : check start1130 proof1130 = true := by
  decide +kernel
#print axioms ok1130
theorem ok1131 : check start1131 proof1131 = true := by
  decide +kernel
#print axioms ok1131
end Snake9.ReplayFull147
