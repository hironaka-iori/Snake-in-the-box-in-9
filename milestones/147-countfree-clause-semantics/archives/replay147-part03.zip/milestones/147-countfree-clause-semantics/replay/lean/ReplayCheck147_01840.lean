import ReplayData147_0057
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1840 : check start1840 proof1840 = true := by
  decide +kernel
#print axioms ok1840
theorem ok1841 : check start1841 proof1841 = true := by
  decide +kernel
#print axioms ok1841
theorem ok1842 : check start1842 proof1842 = true := by
  decide +kernel
#print axioms ok1842
theorem ok1843 : check start1843 proof1843 = true := by
  decide +kernel
#print axioms ok1843
end Snake9.ReplayFull147
