import ReplayData147_0060
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1940 : check start1940 proof1940 = true := by
  decide +kernel
#print axioms ok1940
theorem ok1941 : check start1941 proof1941 = true := by
  decide +kernel
#print axioms ok1941
theorem ok1942 : check start1942 proof1942 = true := by
  decide +kernel
#print axioms ok1942
theorem ok1943 : check start1943 proof1943 = true := by
  decide +kernel
#print axioms ok1943
end Snake9.ReplayFull147
