import ReplayData147_0047
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1512 : check start1512 proof1512 = true := by
  decide +kernel
#print axioms ok1512
theorem ok1513 : check start1513 proof1513 = true := by
  decide +kernel
#print axioms ok1513
theorem ok1514 : check start1514 proof1514 = true := by
  decide +kernel
#print axioms ok1514
theorem ok1515 : check start1515 proof1515 = true := by
  decide +kernel
#print axioms ok1515
end Snake9.ReplayFull147
