import ReplayData147_0056
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1808 : check start1808 proof1808 = true := by
  decide +kernel
#print axioms ok1808
theorem ok1809 : check start1809 proof1809 = true := by
  decide +kernel
#print axioms ok1809
theorem ok1810 : check start1810 proof1810 = true := by
  decide +kernel
#print axioms ok1810
theorem ok1811 : check start1811 proof1811 = true := by
  decide +kernel
#print axioms ok1811
end Snake9.ReplayFull147
