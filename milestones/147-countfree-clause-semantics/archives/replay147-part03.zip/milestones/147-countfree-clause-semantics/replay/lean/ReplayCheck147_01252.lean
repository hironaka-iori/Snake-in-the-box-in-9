import ReplayData147_0039
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1252 : check start1252 proof1252 = true := by
  decide +kernel
#print axioms ok1252
theorem ok1253 : check start1253 proof1253 = true := by
  decide +kernel
#print axioms ok1253
theorem ok1254 : check start1254 proof1254 = true := by
  decide +kernel
#print axioms ok1254
theorem ok1255 : check start1255 proof1255 = true := by
  decide +kernel
#print axioms ok1255
end Snake9.ReplayFull147
