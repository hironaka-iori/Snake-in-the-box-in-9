import ReplayData147_0054
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1744 : check start1744 proof1744 = true := by
  decide +kernel
#print axioms ok1744
theorem ok1745 : check start1745 proof1745 = true := by
  decide +kernel
#print axioms ok1745
theorem ok1746 : check start1746 proof1746 = true := by
  decide +kernel
#print axioms ok1746
theorem ok1747 : check start1747 proof1747 = true := by
  decide +kernel
#print axioms ok1747
end Snake9.ReplayFull147
