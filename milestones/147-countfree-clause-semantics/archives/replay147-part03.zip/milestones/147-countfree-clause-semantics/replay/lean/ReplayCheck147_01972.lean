import ReplayData147_0061
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1972 : check start1972 proof1972 = true := by
  decide +kernel
#print axioms ok1972
theorem ok1973 : check start1973 proof1973 = true := by
  decide +kernel
#print axioms ok1973
theorem ok1974 : check start1974 proof1974 = true := by
  decide +kernel
#print axioms ok1974
theorem ok1975 : check start1975 proof1975 = true := by
  decide +kernel
#print axioms ok1975
end Snake9.ReplayFull147
