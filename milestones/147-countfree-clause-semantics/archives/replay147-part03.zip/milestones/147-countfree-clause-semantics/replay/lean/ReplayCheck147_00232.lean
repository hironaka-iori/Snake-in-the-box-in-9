import ReplayData147_0007
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok232 : check start232 proof232 = true := by
  decide +kernel
#print axioms ok232
theorem ok233 : check start233 proof233 = true := by
  decide +kernel
#print axioms ok233
theorem ok234 : check start234 proof234 = true := by
  decide +kernel
#print axioms ok234
theorem ok235 : check start235 proof235 = true := by
  decide +kernel
#print axioms ok235
end Snake9.ReplayFull147
