import ReplayData147_0060
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1928 : check start1928 proof1928 = true := by
  decide +kernel
#print axioms ok1928
theorem ok1929 : check start1929 proof1929 = true := by
  decide +kernel
#print axioms ok1929
theorem ok1930 : check start1930 proof1930 = true := by
  decide +kernel
#print axioms ok1930
theorem ok1931 : check start1931 proof1931 = true := by
  decide +kernel
#print axioms ok1931
end Snake9.ReplayFull147
