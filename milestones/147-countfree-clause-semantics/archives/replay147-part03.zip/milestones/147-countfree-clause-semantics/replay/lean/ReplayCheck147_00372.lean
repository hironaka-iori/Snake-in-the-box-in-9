import ReplayData147_0011
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok372 : check start372 proof372 = true := by
  decide +kernel
#print axioms ok372
theorem ok373 : check start373 proof373 = true := by
  decide +kernel
#print axioms ok373
theorem ok374 : check start374 proof374 = true := by
  decide +kernel
#print axioms ok374
theorem ok375 : check start375 proof375 = true := by
  decide +kernel
#print axioms ok375
end Snake9.ReplayFull147
