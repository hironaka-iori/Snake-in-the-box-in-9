import ReplayData147_0009
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok308 : check start308 proof308 = true := by
  decide +kernel
#print axioms ok308
theorem ok309 : check start309 proof309 = true := by
  decide +kernel
#print axioms ok309
theorem ok310 : check start310 proof310 = true := by
  decide +kernel
#print axioms ok310
theorem ok311 : check start311 proof311 = true := by
  decide +kernel
#print axioms ok311
end Snake9.ReplayFull147
