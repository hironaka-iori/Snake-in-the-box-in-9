import ReplayData147_0032
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1048 : check start1048 proof1048 = true := by
  decide +kernel
#print axioms ok1048
theorem ok1049 : check start1049 proof1049 = true := by
  decide +kernel
#print axioms ok1049
theorem ok1050 : check start1050 proof1050 = true := by
  decide +kernel
#print axioms ok1050
theorem ok1051 : check start1051 proof1051 = true := by
  decide +kernel
#print axioms ok1051
end Snake9.ReplayFull147
