import ReplayData147_0030
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok960 : check start960 proof960 = true := by
  decide +kernel
#print axioms ok960
theorem ok961 : check start961 proof961 = true := by
  decide +kernel
#print axioms ok961
theorem ok962 : check start962 proof962 = true := by
  decide +kernel
#print axioms ok962
theorem ok963 : check start963 proof963 = true := by
  decide +kernel
#print axioms ok963
end Snake9.ReplayFull147
