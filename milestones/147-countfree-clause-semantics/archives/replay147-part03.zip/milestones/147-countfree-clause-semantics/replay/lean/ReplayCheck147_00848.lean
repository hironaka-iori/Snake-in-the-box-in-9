import ReplayData147_0026
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok848 : check start848 proof848 = true := by
  decide +kernel
#print axioms ok848
theorem ok849 : check start849 proof849 = true := by
  decide +kernel
#print axioms ok849
theorem ok850 : check start850 proof850 = true := by
  decide +kernel
#print axioms ok850
theorem ok851 : check start851 proof851 = true := by
  decide +kernel
#print axioms ok851
end Snake9.ReplayFull147
