import ReplayData147_0038
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1216 : check start1216 proof1216 = true := by
  decide +kernel
#print axioms ok1216
theorem ok1217 : check start1217 proof1217 = true := by
  decide +kernel
#print axioms ok1217
theorem ok1218 : check start1218 proof1218 = true := by
  decide +kernel
#print axioms ok1218
theorem ok1219 : check start1219 proof1219 = true := by
  decide +kernel
#print axioms ok1219
end Snake9.ReplayFull147
