import ReplayData147_0021
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok684 : check start684 proof684 = true := by
  decide +kernel
#print axioms ok684
theorem ok685 : check start685 proof685 = true := by
  decide +kernel
#print axioms ok685
theorem ok686 : check start686 proof686 = true := by
  decide +kernel
#print axioms ok686
theorem ok687 : check start687 proof687 = true := by
  decide +kernel
#print axioms ok687
end Snake9.ReplayFull147
