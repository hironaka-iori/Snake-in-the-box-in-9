import ReplayData147_0027
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok888 : check start888 proof888 = true := by
  decide +kernel
#print axioms ok888
theorem ok889 : check start889 proof889 = true := by
  decide +kernel
#print axioms ok889
theorem ok890 : check start890 proof890 = true := by
  decide +kernel
#print axioms ok890
theorem ok891 : check start891 proof891 = true := by
  decide +kernel
#print axioms ok891
end Snake9.ReplayFull147
