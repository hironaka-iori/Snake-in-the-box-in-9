import ReplayData147_0035
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1120 : check start1120 proof1120 = true := by
  decide +kernel
#print axioms ok1120
theorem ok1121 : check start1121 proof1121 = true := by
  decide +kernel
#print axioms ok1121
theorem ok1122 : check start1122 proof1122 = true := by
  decide +kernel
#print axioms ok1122
theorem ok1123 : check start1123 proof1123 = true := by
  decide +kernel
#print axioms ok1123
end Snake9.ReplayFull147
