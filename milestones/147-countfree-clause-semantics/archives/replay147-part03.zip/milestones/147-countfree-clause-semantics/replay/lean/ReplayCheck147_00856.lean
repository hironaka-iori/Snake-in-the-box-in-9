import ReplayData147_0026
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok856 : check start856 proof856 = true := by
  decide +kernel
#print axioms ok856
theorem ok857 : check start857 proof857 = true := by
  decide +kernel
#print axioms ok857
theorem ok858 : check start858 proof858 = true := by
  decide +kernel
#print axioms ok858
theorem ok859 : check start859 proof859 = true := by
  decide +kernel
#print axioms ok859
end Snake9.ReplayFull147
