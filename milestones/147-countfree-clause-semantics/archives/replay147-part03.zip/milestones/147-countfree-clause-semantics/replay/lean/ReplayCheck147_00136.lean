import ReplayData147_0004
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok136 : check start136 proof136 = true := by
  decide +kernel
#print axioms ok136
theorem ok137 : check start137 proof137 = true := by
  decide +kernel
#print axioms ok137
theorem ok138 : check start138 proof138 = true := by
  decide +kernel
#print axioms ok138
theorem ok139 : check start139 proof139 = true := by
  decide +kernel
#print axioms ok139
end Snake9.ReplayFull147
