import ReplayData147_0017
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok564 : check start564 proof564 = true := by
  decide +kernel
#print axioms ok564
theorem ok565 : check start565 proof565 = true := by
  decide +kernel
#print axioms ok565
theorem ok566 : check start566 proof566 = true := by
  decide +kernel
#print axioms ok566
theorem ok567 : check start567 proof567 = true := by
  decide +kernel
#print axioms ok567
end Snake9.ReplayFull147
