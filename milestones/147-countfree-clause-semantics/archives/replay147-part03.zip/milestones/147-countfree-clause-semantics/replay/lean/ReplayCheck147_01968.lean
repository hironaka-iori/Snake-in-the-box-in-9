import ReplayData147_0061
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem ok1968 : check start1968 proof1968 = true := by
  decide +kernel
#print axioms ok1968
theorem ok1969 : check start1969 proof1969 = true := by
  decide +kernel
#print axioms ok1969
theorem ok1970 : check start1970 proof1970 = true := by
  decide +kernel
#print axioms ok1970
theorem ok1971 : check start1971 proof1971 = true := by
  decide +kernel
#print axioms ok1971
end Snake9.ReplayFull147
