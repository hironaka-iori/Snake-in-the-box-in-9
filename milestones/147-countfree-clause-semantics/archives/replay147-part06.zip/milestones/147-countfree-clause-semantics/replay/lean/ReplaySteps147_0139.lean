import ReplayCheck147_04448
import ReplayCheck147_04452
import ReplayCheck147_04456
import ReplayCheck147_04460
import ReplayCheck147_04464
import ReplayCheck147_04468
import ReplayCheck147_04472
import ReplayCheck147_04476
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps139 (τ : Nat → Bool) (h4448 : TreeTrue τ start4448) : TreeTrue τ start4480 := by
  have h4449 : TreeTrue τ start4449 := replay_true τ ok4448 h4448
  have h4450 : TreeTrue τ start4450 := replay_true τ ok4449 h4449
  have h4451 : TreeTrue τ start4451 := replay_true τ ok4450 h4450
  have h4452 : TreeTrue τ start4452 := replay_true τ ok4451 h4451
  have h4453 : TreeTrue τ start4453 := replay_true τ ok4452 h4452
  have h4454 : TreeTrue τ start4454 := replay_true τ ok4453 h4453
  have h4455 : TreeTrue τ start4455 := replay_true τ ok4454 h4454
  have h4456 : TreeTrue τ start4456 := replay_true τ ok4455 h4455
  have h4457 : TreeTrue τ start4457 := replay_true τ ok4456 h4456
  have h4458 : TreeTrue τ start4458 := replay_true τ ok4457 h4457
  have h4459 : TreeTrue τ start4459 := replay_true τ ok4458 h4458
  have h4460 : TreeTrue τ start4460 := replay_true τ ok4459 h4459
  have h4461 : TreeTrue τ start4461 := replay_true τ ok4460 h4460
  have h4462 : TreeTrue τ start4462 := replay_true τ ok4461 h4461
  have h4463 : TreeTrue τ start4463 := replay_true τ ok4462 h4462
  have h4464 : TreeTrue τ start4464 := replay_true τ ok4463 h4463
  have h4465 : TreeTrue τ start4465 := replay_true τ ok4464 h4464
  have h4466 : TreeTrue τ start4466 := replay_true τ ok4465 h4465
  have h4467 : TreeTrue τ start4467 := replay_true τ ok4466 h4466
  have h4468 : TreeTrue τ start4468 := replay_true τ ok4467 h4467
  have h4469 : TreeTrue τ start4469 := replay_true τ ok4468 h4468
  have h4470 : TreeTrue τ start4470 := replay_true τ ok4469 h4469
  have h4471 : TreeTrue τ start4471 := replay_true τ ok4470 h4470
  have h4472 : TreeTrue τ start4472 := replay_true τ ok4471 h4471
  have h4473 : TreeTrue τ start4473 := replay_true τ ok4472 h4472
  have h4474 : TreeTrue τ start4474 := replay_true τ ok4473 h4473
  have h4475 : TreeTrue τ start4475 := replay_true τ ok4474 h4474
  have h4476 : TreeTrue τ start4476 := replay_true τ ok4475 h4475
  have h4477 : TreeTrue τ start4477 := replay_true τ ok4476 h4476
  have h4478 : TreeTrue τ start4478 := replay_true τ ok4477 h4477
  have h4479 : TreeTrue τ start4479 := replay_true τ ok4478 h4478
  have h4480 : TreeTrue τ start4480 := cp_true τ ok4479 h4479
  exact h4480
#print axioms steps139
end Snake9.ReplayFull147
