import ReplayCheck147_04480
import ReplayCheck147_04484
import ReplayCheck147_04488
import ReplayCheck147_04492
import ReplayCheck147_04496
import ReplayCheck147_04500
import ReplayCheck147_04504
import ReplayCheck147_04508
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps140 (τ : Nat → Bool) (h4480 : TreeTrue τ start4480) : TreeTrue τ start4512 := by
  have h4481 : TreeTrue τ start4481 := replay_true τ ok4480 h4480
  have h4482 : TreeTrue τ start4482 := replay_true τ ok4481 h4481
  have h4483 : TreeTrue τ start4483 := replay_true τ ok4482 h4482
  have h4484 : TreeTrue τ start4484 := replay_true τ ok4483 h4483
  have h4485 : TreeTrue τ start4485 := replay_true τ ok4484 h4484
  have h4486 : TreeTrue τ start4486 := replay_true τ ok4485 h4485
  have h4487 : TreeTrue τ start4487 := replay_true τ ok4486 h4486
  have h4488 : TreeTrue τ start4488 := replay_true τ ok4487 h4487
  have h4489 : TreeTrue τ start4489 := replay_true τ ok4488 h4488
  have h4490 : TreeTrue τ start4490 := replay_true τ ok4489 h4489
  have h4491 : TreeTrue τ start4491 := replay_true τ ok4490 h4490
  have h4492 : TreeTrue τ start4492 := replay_true τ ok4491 h4491
  have h4493 : TreeTrue τ start4493 := replay_true τ ok4492 h4492
  have h4494 : TreeTrue τ start4494 := replay_true τ ok4493 h4493
  have h4495 : TreeTrue τ start4495 := replay_true τ ok4494 h4494
  have h4496 : TreeTrue τ start4496 := replay_true τ ok4495 h4495
  have h4497 : TreeTrue τ start4497 := replay_true τ ok4496 h4496
  have h4498 : TreeTrue τ start4498 := replay_true τ ok4497 h4497
  have h4499 : TreeTrue τ start4499 := replay_true τ ok4498 h4498
  have h4500 : TreeTrue τ start4500 := replay_true τ ok4499 h4499
  have h4501 : TreeTrue τ start4501 := replay_true τ ok4500 h4500
  have h4502 : TreeTrue τ start4502 := replay_true τ ok4501 h4501
  have h4503 : TreeTrue τ start4503 := replay_true τ ok4502 h4502
  have h4504 : TreeTrue τ start4504 := replay_true τ ok4503 h4503
  have h4505 : TreeTrue τ start4505 := replay_true τ ok4504 h4504
  have h4506 : TreeTrue τ start4506 := replay_true τ ok4505 h4505
  have h4507 : TreeTrue τ start4507 := replay_true τ ok4506 h4506
  have h4508 : TreeTrue τ start4508 := replay_true τ ok4507 h4507
  have h4509 : TreeTrue τ start4509 := replay_true τ ok4508 h4508
  have h4510 : TreeTrue τ start4510 := replay_true τ ok4509 h4509
  have h4511 : TreeTrue τ start4511 := replay_true τ ok4510 h4510
  have h4512 : TreeTrue τ start4512 := cp_true τ ok4511 h4511
  exact h4512
#print axioms steps140
end Snake9.ReplayFull147
