import ReplayCheck147_04768
import ReplayCheck147_04772
import ReplayCheck147_04776
import ReplayCheck147_04780
import ReplayCheck147_04784
import ReplayCheck147_04788
import ReplayCheck147_04792
import ReplayCheck147_04796
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps149 (τ : Nat → Bool) (h4768 : TreeTrue τ start4768) : TreeTrue τ start4800 := by
  have h4769 : TreeTrue τ start4769 := replay_true τ ok4768 h4768
  have h4770 : TreeTrue τ start4770 := replay_true τ ok4769 h4769
  have h4771 : TreeTrue τ start4771 := replay_true τ ok4770 h4770
  have h4772 : TreeTrue τ start4772 := replay_true τ ok4771 h4771
  have h4773 : TreeTrue τ start4773 := replay_true τ ok4772 h4772
  have h4774 : TreeTrue τ start4774 := replay_true τ ok4773 h4773
  have h4775 : TreeTrue τ start4775 := replay_true τ ok4774 h4774
  have h4776 : TreeTrue τ start4776 := replay_true τ ok4775 h4775
  have h4777 : TreeTrue τ start4777 := replay_true τ ok4776 h4776
  have h4778 : TreeTrue τ start4778 := replay_true τ ok4777 h4777
  have h4779 : TreeTrue τ start4779 := replay_true τ ok4778 h4778
  have h4780 : TreeTrue τ start4780 := replay_true τ ok4779 h4779
  have h4781 : TreeTrue τ start4781 := replay_true τ ok4780 h4780
  have h4782 : TreeTrue τ start4782 := replay_true τ ok4781 h4781
  have h4783 : TreeTrue τ start4783 := replay_true τ ok4782 h4782
  have h4784 : TreeTrue τ start4784 := replay_true τ ok4783 h4783
  have h4785 : TreeTrue τ start4785 := replay_true τ ok4784 h4784
  have h4786 : TreeTrue τ start4786 := replay_true τ ok4785 h4785
  have h4787 : TreeTrue τ start4787 := replay_true τ ok4786 h4786
  have h4788 : TreeTrue τ start4788 := replay_true τ ok4787 h4787
  have h4789 : TreeTrue τ start4789 := replay_true τ ok4788 h4788
  have h4790 : TreeTrue τ start4790 := replay_true τ ok4789 h4789
  have h4791 : TreeTrue τ start4791 := replay_true τ ok4790 h4790
  have h4792 : TreeTrue τ start4792 := replay_true τ ok4791 h4791
  have h4793 : TreeTrue τ start4793 := replay_true τ ok4792 h4792
  have h4794 : TreeTrue τ start4794 := replay_true τ ok4793 h4793
  have h4795 : TreeTrue τ start4795 := replay_true τ ok4794 h4794
  have h4796 : TreeTrue τ start4796 := replay_true τ ok4795 h4795
  have h4797 : TreeTrue τ start4797 := replay_true τ ok4796 h4796
  have h4798 : TreeTrue τ start4798 := replay_true τ ok4797 h4797
  have h4799 : TreeTrue τ start4799 := replay_true τ ok4798 h4798
  have h4800 : TreeTrue τ start4800 := cp_true τ ok4799 h4799
  exact h4800
#print axioms steps149
end Snake9.ReplayFull147
