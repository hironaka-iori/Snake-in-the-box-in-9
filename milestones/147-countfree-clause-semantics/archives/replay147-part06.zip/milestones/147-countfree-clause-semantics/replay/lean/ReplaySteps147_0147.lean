import ReplayCheck147_04704
import ReplayCheck147_04708
import ReplayCheck147_04712
import ReplayCheck147_04716
import ReplayCheck147_04720
import ReplayCheck147_04724
import ReplayCheck147_04728
import ReplayCheck147_04732
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps147 (τ : Nat → Bool) (h4704 : TreeTrue τ start4704) : TreeTrue τ start4736 := by
  have h4705 : TreeTrue τ start4705 := replay_true τ ok4704 h4704
  have h4706 : TreeTrue τ start4706 := replay_true τ ok4705 h4705
  have h4707 : TreeTrue τ start4707 := replay_true τ ok4706 h4706
  have h4708 : TreeTrue τ start4708 := replay_true τ ok4707 h4707
  have h4709 : TreeTrue τ start4709 := replay_true τ ok4708 h4708
  have h4710 : TreeTrue τ start4710 := replay_true τ ok4709 h4709
  have h4711 : TreeTrue τ start4711 := replay_true τ ok4710 h4710
  have h4712 : TreeTrue τ start4712 := replay_true τ ok4711 h4711
  have h4713 : TreeTrue τ start4713 := replay_true τ ok4712 h4712
  have h4714 : TreeTrue τ start4714 := replay_true τ ok4713 h4713
  have h4715 : TreeTrue τ start4715 := replay_true τ ok4714 h4714
  have h4716 : TreeTrue τ start4716 := replay_true τ ok4715 h4715
  have h4717 : TreeTrue τ start4717 := replay_true τ ok4716 h4716
  have h4718 : TreeTrue τ start4718 := replay_true τ ok4717 h4717
  have h4719 : TreeTrue τ start4719 := replay_true τ ok4718 h4718
  have h4720 : TreeTrue τ start4720 := replay_true τ ok4719 h4719
  have h4721 : TreeTrue τ start4721 := replay_true τ ok4720 h4720
  have h4722 : TreeTrue τ start4722 := replay_true τ ok4721 h4721
  have h4723 : TreeTrue τ start4723 := replay_true τ ok4722 h4722
  have h4724 : TreeTrue τ start4724 := replay_true τ ok4723 h4723
  have h4725 : TreeTrue τ start4725 := replay_true τ ok4724 h4724
  have h4726 : TreeTrue τ start4726 := replay_true τ ok4725 h4725
  have h4727 : TreeTrue τ start4727 := replay_true τ ok4726 h4726
  have h4728 : TreeTrue τ start4728 := replay_true τ ok4727 h4727
  have h4729 : TreeTrue τ start4729 := replay_true τ ok4728 h4728
  have h4730 : TreeTrue τ start4730 := replay_true τ ok4729 h4729
  have h4731 : TreeTrue τ start4731 := replay_true τ ok4730 h4730
  have h4732 : TreeTrue τ start4732 := replay_true τ ok4731 h4731
  have h4733 : TreeTrue τ start4733 := replay_true τ ok4732 h4732
  have h4734 : TreeTrue τ start4734 := replay_true τ ok4733 h4733
  have h4735 : TreeTrue τ start4735 := replay_true τ ok4734 h4734
  have h4736 : TreeTrue τ start4736 := cp_true τ ok4735 h4735
  exact h4736
#print axioms steps147
end Snake9.ReplayFull147
