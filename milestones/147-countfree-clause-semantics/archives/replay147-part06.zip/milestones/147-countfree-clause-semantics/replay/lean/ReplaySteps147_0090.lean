import ReplayCheck147_02880
import ReplayCheck147_02884
import ReplayCheck147_02888
import ReplayCheck147_02892
import ReplayCheck147_02896
import ReplayCheck147_02900
import ReplayCheck147_02904
import ReplayCheck147_02908
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps90 (τ : Nat → Bool) (h2880 : TreeTrue τ start2880) : TreeTrue τ start2912 := by
  have h2881 : TreeTrue τ start2881 := replay_true τ ok2880 h2880
  have h2882 : TreeTrue τ start2882 := replay_true τ ok2881 h2881
  have h2883 : TreeTrue τ start2883 := replay_true τ ok2882 h2882
  have h2884 : TreeTrue τ start2884 := replay_true τ ok2883 h2883
  have h2885 : TreeTrue τ start2885 := replay_true τ ok2884 h2884
  have h2886 : TreeTrue τ start2886 := replay_true τ ok2885 h2885
  have h2887 : TreeTrue τ start2887 := replay_true τ ok2886 h2886
  have h2888 : TreeTrue τ start2888 := replay_true τ ok2887 h2887
  have h2889 : TreeTrue τ start2889 := replay_true τ ok2888 h2888
  have h2890 : TreeTrue τ start2890 := replay_true τ ok2889 h2889
  have h2891 : TreeTrue τ start2891 := replay_true τ ok2890 h2890
  have h2892 : TreeTrue τ start2892 := replay_true τ ok2891 h2891
  have h2893 : TreeTrue τ start2893 := replay_true τ ok2892 h2892
  have h2894 : TreeTrue τ start2894 := replay_true τ ok2893 h2893
  have h2895 : TreeTrue τ start2895 := replay_true τ ok2894 h2894
  have h2896 : TreeTrue τ start2896 := replay_true τ ok2895 h2895
  have h2897 : TreeTrue τ start2897 := replay_true τ ok2896 h2896
  have h2898 : TreeTrue τ start2898 := replay_true τ ok2897 h2897
  have h2899 : TreeTrue τ start2899 := replay_true τ ok2898 h2898
  have h2900 : TreeTrue τ start2900 := replay_true τ ok2899 h2899
  have h2901 : TreeTrue τ start2901 := replay_true τ ok2900 h2900
  have h2902 : TreeTrue τ start2902 := replay_true τ ok2901 h2901
  have h2903 : TreeTrue τ start2903 := replay_true τ ok2902 h2902
  have h2904 : TreeTrue τ start2904 := replay_true τ ok2903 h2903
  have h2905 : TreeTrue τ start2905 := replay_true τ ok2904 h2904
  have h2906 : TreeTrue τ start2906 := replay_true τ ok2905 h2905
  have h2907 : TreeTrue τ start2907 := replay_true τ ok2906 h2906
  have h2908 : TreeTrue τ start2908 := replay_true τ ok2907 h2907
  have h2909 : TreeTrue τ start2909 := replay_true τ ok2908 h2908
  have h2910 : TreeTrue τ start2910 := replay_true τ ok2909 h2909
  have h2911 : TreeTrue τ start2911 := replay_true τ ok2910 h2910
  have h2912 : TreeTrue τ start2912 := cp_true τ ok2911 h2911
  exact h2912
#print axioms steps90
end Snake9.ReplayFull147
