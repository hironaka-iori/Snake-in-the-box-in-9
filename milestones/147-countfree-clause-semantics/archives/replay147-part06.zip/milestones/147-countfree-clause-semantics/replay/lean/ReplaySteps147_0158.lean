import ReplayCheck147_05056
import ReplayCheck147_05060
import ReplayCheck147_05064
import ReplayCheck147_05068
import ReplayCheck147_05072
import ReplayCheck147_05076
import ReplayCheck147_05080
import ReplayCheck147_05084
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps158 (τ : Nat → Bool) (h5056 : TreeTrue τ start5056) : TreeTrue τ start5088 := by
  have h5057 : TreeTrue τ start5057 := replay_true τ ok5056 h5056
  have h5058 : TreeTrue τ start5058 := replay_true τ ok5057 h5057
  have h5059 : TreeTrue τ start5059 := replay_true τ ok5058 h5058
  have h5060 : TreeTrue τ start5060 := replay_true τ ok5059 h5059
  have h5061 : TreeTrue τ start5061 := replay_true τ ok5060 h5060
  have h5062 : TreeTrue τ start5062 := replay_true τ ok5061 h5061
  have h5063 : TreeTrue τ start5063 := replay_true τ ok5062 h5062
  have h5064 : TreeTrue τ start5064 := replay_true τ ok5063 h5063
  have h5065 : TreeTrue τ start5065 := replay_true τ ok5064 h5064
  have h5066 : TreeTrue τ start5066 := replay_true τ ok5065 h5065
  have h5067 : TreeTrue τ start5067 := replay_true τ ok5066 h5066
  have h5068 : TreeTrue τ start5068 := replay_true τ ok5067 h5067
  have h5069 : TreeTrue τ start5069 := replay_true τ ok5068 h5068
  have h5070 : TreeTrue τ start5070 := replay_true τ ok5069 h5069
  have h5071 : TreeTrue τ start5071 := replay_true τ ok5070 h5070
  have h5072 : TreeTrue τ start5072 := replay_true τ ok5071 h5071
  have h5073 : TreeTrue τ start5073 := replay_true τ ok5072 h5072
  have h5074 : TreeTrue τ start5074 := replay_true τ ok5073 h5073
  have h5075 : TreeTrue τ start5075 := replay_true τ ok5074 h5074
  have h5076 : TreeTrue τ start5076 := replay_true τ ok5075 h5075
  have h5077 : TreeTrue τ start5077 := replay_true τ ok5076 h5076
  have h5078 : TreeTrue τ start5078 := replay_true τ ok5077 h5077
  have h5079 : TreeTrue τ start5079 := replay_true τ ok5078 h5078
  have h5080 : TreeTrue τ start5080 := replay_true τ ok5079 h5079
  have h5081 : TreeTrue τ start5081 := replay_true τ ok5080 h5080
  have h5082 : TreeTrue τ start5082 := replay_true τ ok5081 h5081
  have h5083 : TreeTrue τ start5083 := replay_true τ ok5082 h5082
  have h5084 : TreeTrue τ start5084 := replay_true τ ok5083 h5083
  have h5085 : TreeTrue τ start5085 := replay_true τ ok5084 h5084
  have h5086 : TreeTrue τ start5086 := replay_true τ ok5085 h5085
  have h5087 : TreeTrue τ start5087 := replay_true τ ok5086 h5086
  have h5088 : TreeTrue τ start5088 := cp_true τ ok5087 h5087
  exact h5088
#print axioms steps158
end Snake9.ReplayFull147
