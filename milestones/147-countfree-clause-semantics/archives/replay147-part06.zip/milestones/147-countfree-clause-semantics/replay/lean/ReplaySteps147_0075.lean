import ReplayCheck147_02400
import ReplayCheck147_02404
import ReplayCheck147_02408
import ReplayCheck147_02412
import ReplayCheck147_02416
import ReplayCheck147_02420
import ReplayCheck147_02424
import ReplayCheck147_02428
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps75 (τ : Nat → Bool) (h2400 : TreeTrue τ start2400) : TreeTrue τ start2432 := by
  have h2401 : TreeTrue τ start2401 := replay_true τ ok2400 h2400
  have h2402 : TreeTrue τ start2402 := replay_true τ ok2401 h2401
  have h2403 : TreeTrue τ start2403 := replay_true τ ok2402 h2402
  have h2404 : TreeTrue τ start2404 := replay_true τ ok2403 h2403
  have h2405 : TreeTrue τ start2405 := replay_true τ ok2404 h2404
  have h2406 : TreeTrue τ start2406 := replay_true τ ok2405 h2405
  have h2407 : TreeTrue τ start2407 := replay_true τ ok2406 h2406
  have h2408 : TreeTrue τ start2408 := replay_true τ ok2407 h2407
  have h2409 : TreeTrue τ start2409 := replay_true τ ok2408 h2408
  have h2410 : TreeTrue τ start2410 := replay_true τ ok2409 h2409
  have h2411 : TreeTrue τ start2411 := replay_true τ ok2410 h2410
  have h2412 : TreeTrue τ start2412 := replay_true τ ok2411 h2411
  have h2413 : TreeTrue τ start2413 := replay_true τ ok2412 h2412
  have h2414 : TreeTrue τ start2414 := replay_true τ ok2413 h2413
  have h2415 : TreeTrue τ start2415 := replay_true τ ok2414 h2414
  have h2416 : TreeTrue τ start2416 := replay_true τ ok2415 h2415
  have h2417 : TreeTrue τ start2417 := replay_true τ ok2416 h2416
  have h2418 : TreeTrue τ start2418 := replay_true τ ok2417 h2417
  have h2419 : TreeTrue τ start2419 := replay_true τ ok2418 h2418
  have h2420 : TreeTrue τ start2420 := replay_true τ ok2419 h2419
  have h2421 : TreeTrue τ start2421 := replay_true τ ok2420 h2420
  have h2422 : TreeTrue τ start2422 := replay_true τ ok2421 h2421
  have h2423 : TreeTrue τ start2423 := replay_true τ ok2422 h2422
  have h2424 : TreeTrue τ start2424 := replay_true τ ok2423 h2423
  have h2425 : TreeTrue τ start2425 := replay_true τ ok2424 h2424
  have h2426 : TreeTrue τ start2426 := replay_true τ ok2425 h2425
  have h2427 : TreeTrue τ start2427 := replay_true τ ok2426 h2426
  have h2428 : TreeTrue τ start2428 := replay_true τ ok2427 h2427
  have h2429 : TreeTrue τ start2429 := replay_true τ ok2428 h2428
  have h2430 : TreeTrue τ start2430 := replay_true τ ok2429 h2429
  have h2431 : TreeTrue τ start2431 := replay_true τ ok2430 h2430
  have h2432 : TreeTrue τ start2432 := cp_true τ ok2431 h2431
  exact h2432
#print axioms steps75
end Snake9.ReplayFull147
