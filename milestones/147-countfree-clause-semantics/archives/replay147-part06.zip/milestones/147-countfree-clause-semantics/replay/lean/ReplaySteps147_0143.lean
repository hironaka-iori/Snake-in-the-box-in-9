import ReplayCheck147_04576
import ReplayCheck147_04580
import ReplayCheck147_04584
import ReplayCheck147_04588
import ReplayCheck147_04592
import ReplayCheck147_04596
import ReplayCheck147_04600
import ReplayCheck147_04604
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps143 (τ : Nat → Bool) (h4576 : TreeTrue τ start4576) : TreeTrue τ start4608 := by
  have h4577 : TreeTrue τ start4577 := replay_true τ ok4576 h4576
  have h4578 : TreeTrue τ start4578 := replay_true τ ok4577 h4577
  have h4579 : TreeTrue τ start4579 := replay_true τ ok4578 h4578
  have h4580 : TreeTrue τ start4580 := replay_true τ ok4579 h4579
  have h4581 : TreeTrue τ start4581 := replay_true τ ok4580 h4580
  have h4582 : TreeTrue τ start4582 := replay_true τ ok4581 h4581
  have h4583 : TreeTrue τ start4583 := replay_true τ ok4582 h4582
  have h4584 : TreeTrue τ start4584 := replay_true τ ok4583 h4583
  have h4585 : TreeTrue τ start4585 := replay_true τ ok4584 h4584
  have h4586 : TreeTrue τ start4586 := replay_true τ ok4585 h4585
  have h4587 : TreeTrue τ start4587 := replay_true τ ok4586 h4586
  have h4588 : TreeTrue τ start4588 := replay_true τ ok4587 h4587
  have h4589 : TreeTrue τ start4589 := replay_true τ ok4588 h4588
  have h4590 : TreeTrue τ start4590 := replay_true τ ok4589 h4589
  have h4591 : TreeTrue τ start4591 := replay_true τ ok4590 h4590
  have h4592 : TreeTrue τ start4592 := replay_true τ ok4591 h4591
  have h4593 : TreeTrue τ start4593 := replay_true τ ok4592 h4592
  have h4594 : TreeTrue τ start4594 := replay_true τ ok4593 h4593
  have h4595 : TreeTrue τ start4595 := replay_true τ ok4594 h4594
  have h4596 : TreeTrue τ start4596 := replay_true τ ok4595 h4595
  have h4597 : TreeTrue τ start4597 := replay_true τ ok4596 h4596
  have h4598 : TreeTrue τ start4598 := replay_true τ ok4597 h4597
  have h4599 : TreeTrue τ start4599 := replay_true τ ok4598 h4598
  have h4600 : TreeTrue τ start4600 := replay_true τ ok4599 h4599
  have h4601 : TreeTrue τ start4601 := replay_true τ ok4600 h4600
  have h4602 : TreeTrue τ start4602 := replay_true τ ok4601 h4601
  have h4603 : TreeTrue τ start4603 := replay_true τ ok4602 h4602
  have h4604 : TreeTrue τ start4604 := replay_true τ ok4603 h4603
  have h4605 : TreeTrue τ start4605 := replay_true τ ok4604 h4604
  have h4606 : TreeTrue τ start4606 := replay_true τ ok4605 h4605
  have h4607 : TreeTrue τ start4607 := replay_true τ ok4606 h4606
  have h4608 : TreeTrue τ start4608 := cp_true τ ok4607 h4607
  exact h4608
#print axioms steps143
end Snake9.ReplayFull147
