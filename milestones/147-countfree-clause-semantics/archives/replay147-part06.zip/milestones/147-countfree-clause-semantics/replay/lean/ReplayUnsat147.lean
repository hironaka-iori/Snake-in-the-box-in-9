import ReplayAssembly147
import ReplaySteps147_0000
import ReplaySteps147_0001
import ReplaySteps147_0002
import ReplaySteps147_0003
import ReplaySteps147_0004
import ReplaySteps147_0005
import ReplaySteps147_0006
import ReplaySteps147_0007
import ReplaySteps147_0008
import ReplaySteps147_0009
import ReplaySteps147_0010
import ReplaySteps147_0011
import ReplaySteps147_0012
import ReplaySteps147_0013
import ReplaySteps147_0014
import ReplaySteps147_0015
import ReplaySteps147_0016
import ReplaySteps147_0017
import ReplaySteps147_0018
import ReplaySteps147_0019
import ReplaySteps147_0020
import ReplaySteps147_0021
import ReplaySteps147_0022
import ReplaySteps147_0023
import ReplaySteps147_0024
import ReplaySteps147_0025
import ReplaySteps147_0026
import ReplaySteps147_0027
import ReplaySteps147_0028
import ReplaySteps147_0029
import ReplaySteps147_0030
import ReplaySteps147_0031
import ReplaySteps147_0032
import ReplaySteps147_0033
import ReplaySteps147_0034
import ReplaySteps147_0035
import ReplaySteps147_0036
import ReplaySteps147_0037
import ReplaySteps147_0038
import ReplaySteps147_0039
import ReplaySteps147_0040
import ReplaySteps147_0041
import ReplaySteps147_0042
import ReplaySteps147_0043
import ReplaySteps147_0044
import ReplaySteps147_0045
import ReplaySteps147_0046
import ReplaySteps147_0047
import ReplaySteps147_0048
import ReplaySteps147_0049
import ReplaySteps147_0050
import ReplaySteps147_0051
import ReplaySteps147_0052
import ReplaySteps147_0053
import ReplaySteps147_0054
import ReplaySteps147_0055
import ReplaySteps147_0056
import ReplaySteps147_0057
import ReplaySteps147_0058
import ReplaySteps147_0059
import ReplaySteps147_0060
import ReplaySteps147_0061
import ReplaySteps147_0062
import ReplaySteps147_0063
import ReplaySteps147_0064
import ReplaySteps147_0065
import ReplaySteps147_0066
import ReplaySteps147_0067
import ReplaySteps147_0068
import ReplaySteps147_0069
import ReplaySteps147_0070
import ReplaySteps147_0071
import ReplaySteps147_0072
import ReplaySteps147_0073
import ReplaySteps147_0074
import ReplaySteps147_0075
import ReplaySteps147_0076
import ReplaySteps147_0077
import ReplaySteps147_0078
import ReplaySteps147_0079
import ReplaySteps147_0080
import ReplaySteps147_0081
import ReplaySteps147_0082
import ReplaySteps147_0083
import ReplaySteps147_0084
import ReplaySteps147_0085
import ReplaySteps147_0086
import ReplaySteps147_0087
import ReplaySteps147_0088
import ReplaySteps147_0089
import ReplaySteps147_0090
import ReplaySteps147_0091
import ReplaySteps147_0092
import ReplaySteps147_0093
import ReplaySteps147_0094
import ReplaySteps147_0095
import ReplaySteps147_0096
import ReplaySteps147_0097
import ReplaySteps147_0098
import ReplaySteps147_0099
import ReplaySteps147_0100
import ReplaySteps147_0101
import ReplaySteps147_0102
import ReplaySteps147_0103
import ReplaySteps147_0104
import ReplaySteps147_0105
import ReplaySteps147_0106
import ReplaySteps147_0107
import ReplaySteps147_0108
import ReplaySteps147_0109
import ReplaySteps147_0110
import ReplaySteps147_0111
import ReplaySteps147_0112
import ReplaySteps147_0113
import ReplaySteps147_0114
import ReplaySteps147_0115
import ReplaySteps147_0116
import ReplaySteps147_0117
import ReplaySteps147_0118
import ReplaySteps147_0119
import ReplaySteps147_0120
import ReplaySteps147_0121
import ReplaySteps147_0122
import ReplaySteps147_0123
import ReplaySteps147_0124
import ReplaySteps147_0125
import ReplaySteps147_0126
import ReplaySteps147_0127
import ReplaySteps147_0128
import ReplaySteps147_0129
import ReplaySteps147_0130
import ReplaySteps147_0131
import ReplaySteps147_0132
import ReplaySteps147_0133
import ReplaySteps147_0134
import ReplaySteps147_0135
import ReplaySteps147_0136
import ReplaySteps147_0137
import ReplaySteps147_0138
import ReplaySteps147_0139
import ReplaySteps147_0140
import ReplaySteps147_0141
import ReplaySteps147_0142
import ReplaySteps147_0143
import ReplaySteps147_0144
import ReplaySteps147_0145
import ReplaySteps147_0146
import ReplaySteps147_0147
import ReplaySteps147_0148
import ReplaySteps147_0149
import ReplaySteps147_0150
import ReplaySteps147_0151
import ReplaySteps147_0152
import ReplaySteps147_0153
import ReplaySteps147_0154
import ReplaySteps147_0155
import ReplaySteps147_0156
import ReplaySteps147_0157
import ReplaySteps147_0158
import ReplaySteps147_0159
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue unsat_of_raw)
theorem unsat : Snake9.LocalWindow.Unsat Snake9.LocalWindow.ShareWindow146.cnf := by
  apply unsat_of_raw
  intro τ h
  have h0 : TreeTrue τ start0 := Snake9.ReplayData147.start_true τ h
  have h32 : TreeTrue τ start32 := steps0 τ h0
  have h64 : TreeTrue τ start64 := steps1 τ h32
  have h96 : TreeTrue τ start96 := steps2 τ h64
  have h128 : TreeTrue τ start128 := steps3 τ h96
  have h160 : TreeTrue τ start160 := steps4 τ h128
  have h192 : TreeTrue τ start192 := steps5 τ h160
  have h224 : TreeTrue τ start224 := steps6 τ h192
  have h256 : TreeTrue τ start256 := steps7 τ h224
  have h288 : TreeTrue τ start288 := steps8 τ h256
  have h320 : TreeTrue τ start320 := steps9 τ h288
  have h352 : TreeTrue τ start352 := steps10 τ h320
  have h384 : TreeTrue τ start384 := steps11 τ h352
  have h416 : TreeTrue τ start416 := steps12 τ h384
  have h448 : TreeTrue τ start448 := steps13 τ h416
  have h480 : TreeTrue τ start480 := steps14 τ h448
  have h512 : TreeTrue τ start512 := steps15 τ h480
  have h544 : TreeTrue τ start544 := steps16 τ h512
  have h576 : TreeTrue τ start576 := steps17 τ h544
  have h608 : TreeTrue τ start608 := steps18 τ h576
  have h640 : TreeTrue τ start640 := steps19 τ h608
  have h672 : TreeTrue τ start672 := steps20 τ h640
  have h704 : TreeTrue τ start704 := steps21 τ h672
  have h736 : TreeTrue τ start736 := steps22 τ h704
  have h768 : TreeTrue τ start768 := steps23 τ h736
  have h800 : TreeTrue τ start800 := steps24 τ h768
  have h832 : TreeTrue τ start832 := steps25 τ h800
  have h864 : TreeTrue τ start864 := steps26 τ h832
  have h896 : TreeTrue τ start896 := steps27 τ h864
  have h928 : TreeTrue τ start928 := steps28 τ h896
  have h960 : TreeTrue τ start960 := steps29 τ h928
  have h992 : TreeTrue τ start992 := steps30 τ h960
  have h1024 : TreeTrue τ start1024 := steps31 τ h992
  have h1056 : TreeTrue τ start1056 := steps32 τ h1024
  have h1088 : TreeTrue τ start1088 := steps33 τ h1056
  have h1120 : TreeTrue τ start1120 := steps34 τ h1088
  have h1152 : TreeTrue τ start1152 := steps35 τ h1120
  have h1184 : TreeTrue τ start1184 := steps36 τ h1152
  have h1216 : TreeTrue τ start1216 := steps37 τ h1184
  have h1248 : TreeTrue τ start1248 := steps38 τ h1216
  have h1280 : TreeTrue τ start1280 := steps39 τ h1248
  have h1312 : TreeTrue τ start1312 := steps40 τ h1280
  have h1344 : TreeTrue τ start1344 := steps41 τ h1312
  have h1376 : TreeTrue τ start1376 := steps42 τ h1344
  have h1408 : TreeTrue τ start1408 := steps43 τ h1376
  have h1440 : TreeTrue τ start1440 := steps44 τ h1408
  have h1472 : TreeTrue τ start1472 := steps45 τ h1440
  have h1504 : TreeTrue τ start1504 := steps46 τ h1472
  have h1536 : TreeTrue τ start1536 := steps47 τ h1504
  have h1568 : TreeTrue τ start1568 := steps48 τ h1536
  have h1600 : TreeTrue τ start1600 := steps49 τ h1568
  have h1632 : TreeTrue τ start1632 := steps50 τ h1600
  have h1664 : TreeTrue τ start1664 := steps51 τ h1632
  have h1696 : TreeTrue τ start1696 := steps52 τ h1664
  have h1728 : TreeTrue τ start1728 := steps53 τ h1696
  have h1760 : TreeTrue τ start1760 := steps54 τ h1728
  have h1792 : TreeTrue τ start1792 := steps55 τ h1760
  have h1824 : TreeTrue τ start1824 := steps56 τ h1792
  have h1856 : TreeTrue τ start1856 := steps57 τ h1824
  have h1888 : TreeTrue τ start1888 := steps58 τ h1856
  have h1920 : TreeTrue τ start1920 := steps59 τ h1888
  have h1952 : TreeTrue τ start1952 := steps60 τ h1920
  have h1984 : TreeTrue τ start1984 := steps61 τ h1952
  have h2016 : TreeTrue τ start2016 := steps62 τ h1984
  have h2048 : TreeTrue τ start2048 := steps63 τ h2016
  have h2080 : TreeTrue τ start2080 := steps64 τ h2048
  have h2112 : TreeTrue τ start2112 := steps65 τ h2080
  have h2144 : TreeTrue τ start2144 := steps66 τ h2112
  have h2176 : TreeTrue τ start2176 := steps67 τ h2144
  have h2208 : TreeTrue τ start2208 := steps68 τ h2176
  have h2240 : TreeTrue τ start2240 := steps69 τ h2208
  have h2272 : TreeTrue τ start2272 := steps70 τ h2240
  have h2304 : TreeTrue τ start2304 := steps71 τ h2272
  have h2336 : TreeTrue τ start2336 := steps72 τ h2304
  have h2368 : TreeTrue τ start2368 := steps73 τ h2336
  have h2400 : TreeTrue τ start2400 := steps74 τ h2368
  have h2432 : TreeTrue τ start2432 := steps75 τ h2400
  have h2464 : TreeTrue τ start2464 := steps76 τ h2432
  have h2496 : TreeTrue τ start2496 := steps77 τ h2464
  have h2528 : TreeTrue τ start2528 := steps78 τ h2496
  have h2560 : TreeTrue τ start2560 := steps79 τ h2528
  have h2592 : TreeTrue τ start2592 := steps80 τ h2560
  have h2624 : TreeTrue τ start2624 := steps81 τ h2592
  have h2656 : TreeTrue τ start2656 := steps82 τ h2624
  have h2688 : TreeTrue τ start2688 := steps83 τ h2656
  have h2720 : TreeTrue τ start2720 := steps84 τ h2688
  have h2752 : TreeTrue τ start2752 := steps85 τ h2720
  have h2784 : TreeTrue τ start2784 := steps86 τ h2752
  have h2816 : TreeTrue τ start2816 := steps87 τ h2784
  have h2848 : TreeTrue τ start2848 := steps88 τ h2816
  have h2880 : TreeTrue τ start2880 := steps89 τ h2848
  have h2912 : TreeTrue τ start2912 := steps90 τ h2880
  have h2944 : TreeTrue τ start2944 := steps91 τ h2912
  have h2976 : TreeTrue τ start2976 := steps92 τ h2944
  have h3008 : TreeTrue τ start3008 := steps93 τ h2976
  have h3040 : TreeTrue τ start3040 := steps94 τ h3008
  have h3072 : TreeTrue τ start3072 := steps95 τ h3040
  have h3104 : TreeTrue τ start3104 := steps96 τ h3072
  have h3136 : TreeTrue τ start3136 := steps97 τ h3104
  have h3168 : TreeTrue τ start3168 := steps98 τ h3136
  have h3200 : TreeTrue τ start3200 := steps99 τ h3168
  have h3232 : TreeTrue τ start3232 := steps100 τ h3200
  have h3264 : TreeTrue τ start3264 := steps101 τ h3232
  have h3296 : TreeTrue τ start3296 := steps102 τ h3264
  have h3328 : TreeTrue τ start3328 := steps103 τ h3296
  have h3360 : TreeTrue τ start3360 := steps104 τ h3328
  have h3392 : TreeTrue τ start3392 := steps105 τ h3360
  have h3424 : TreeTrue τ start3424 := steps106 τ h3392
  have h3456 : TreeTrue τ start3456 := steps107 τ h3424
  have h3488 : TreeTrue τ start3488 := steps108 τ h3456
  have h3520 : TreeTrue τ start3520 := steps109 τ h3488
  have h3552 : TreeTrue τ start3552 := steps110 τ h3520
  have h3584 : TreeTrue τ start3584 := steps111 τ h3552
  have h3616 : TreeTrue τ start3616 := steps112 τ h3584
  have h3648 : TreeTrue τ start3648 := steps113 τ h3616
  have h3680 : TreeTrue τ start3680 := steps114 τ h3648
  have h3712 : TreeTrue τ start3712 := steps115 τ h3680
  have h3744 : TreeTrue τ start3744 := steps116 τ h3712
  have h3776 : TreeTrue τ start3776 := steps117 τ h3744
  have h3808 : TreeTrue τ start3808 := steps118 τ h3776
  have h3840 : TreeTrue τ start3840 := steps119 τ h3808
  have h3872 : TreeTrue τ start3872 := steps120 τ h3840
  have h3904 : TreeTrue τ start3904 := steps121 τ h3872
  have h3936 : TreeTrue τ start3936 := steps122 τ h3904
  have h3968 : TreeTrue τ start3968 := steps123 τ h3936
  have h4000 : TreeTrue τ start4000 := steps124 τ h3968
  have h4032 : TreeTrue τ start4032 := steps125 τ h4000
  have h4064 : TreeTrue τ start4064 := steps126 τ h4032
  have h4096 : TreeTrue τ start4096 := steps127 τ h4064
  have h4128 : TreeTrue τ start4128 := steps128 τ h4096
  have h4160 : TreeTrue τ start4160 := steps129 τ h4128
  have h4192 : TreeTrue τ start4192 := steps130 τ h4160
  have h4224 : TreeTrue τ start4224 := steps131 τ h4192
  have h4256 : TreeTrue τ start4256 := steps132 τ h4224
  have h4288 : TreeTrue τ start4288 := steps133 τ h4256
  have h4320 : TreeTrue τ start4320 := steps134 τ h4288
  have h4352 : TreeTrue τ start4352 := steps135 τ h4320
  have h4384 : TreeTrue τ start4384 := steps136 τ h4352
  have h4416 : TreeTrue τ start4416 := steps137 τ h4384
  have h4448 : TreeTrue τ start4448 := steps138 τ h4416
  have h4480 : TreeTrue τ start4480 := steps139 τ h4448
  have h4512 : TreeTrue τ start4512 := steps140 τ h4480
  have h4544 : TreeTrue τ start4544 := steps141 τ h4512
  have h4576 : TreeTrue τ start4576 := steps142 τ h4544
  have h4608 : TreeTrue τ start4608 := steps143 τ h4576
  have h4640 : TreeTrue τ start4640 := steps144 τ h4608
  have h4672 : TreeTrue τ start4672 := steps145 τ h4640
  have h4704 : TreeTrue τ start4704 := steps146 τ h4672
  have h4736 : TreeTrue τ start4736 := steps147 τ h4704
  have h4768 : TreeTrue τ start4768 := steps148 τ h4736
  have h4800 : TreeTrue τ start4800 := steps149 τ h4768
  have h4832 : TreeTrue τ start4832 := steps150 τ h4800
  have h4864 : TreeTrue τ start4864 := steps151 τ h4832
  have h4896 : TreeTrue τ start4896 := steps152 τ h4864
  have h4928 : TreeTrue τ start4928 := steps153 τ h4896
  have h4960 : TreeTrue τ start4960 := steps154 τ h4928
  have h4992 : TreeTrue τ start4992 := steps155 τ h4960
  have h5024 : TreeTrue τ start5024 := steps156 τ h4992
  have h5056 : TreeTrue τ start5056 := steps157 τ h5024
  have h5088 : TreeTrue τ start5088 := steps158 τ h5056
  exact steps159 τ h5088
#print axioms unsat
end Snake9.ReplayFull147
