import ReplayCheck147_02976
import ReplayCheck147_02980
import ReplayCheck147_02984
import ReplayCheck147_02988
import ReplayCheck147_02992
import ReplayCheck147_02996
import ReplayCheck147_03000
import ReplayCheck147_03004
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps93 (τ : Nat → Bool) (h2976 : TreeTrue τ start2976) : TreeTrue τ start3008 := by
  have h2977 : TreeTrue τ start2977 := replay_true τ ok2976 h2976
  have h2978 : TreeTrue τ start2978 := replay_true τ ok2977 h2977
  have h2979 : TreeTrue τ start2979 := replay_true τ ok2978 h2978
  have h2980 : TreeTrue τ start2980 := replay_true τ ok2979 h2979
  have h2981 : TreeTrue τ start2981 := replay_true τ ok2980 h2980
  have h2982 : TreeTrue τ start2982 := replay_true τ ok2981 h2981
  have h2983 : TreeTrue τ start2983 := replay_true τ ok2982 h2982
  have h2984 : TreeTrue τ start2984 := replay_true τ ok2983 h2983
  have h2985 : TreeTrue τ start2985 := replay_true τ ok2984 h2984
  have h2986 : TreeTrue τ start2986 := replay_true τ ok2985 h2985
  have h2987 : TreeTrue τ start2987 := replay_true τ ok2986 h2986
  have h2988 : TreeTrue τ start2988 := replay_true τ ok2987 h2987
  have h2989 : TreeTrue τ start2989 := replay_true τ ok2988 h2988
  have h2990 : TreeTrue τ start2990 := replay_true τ ok2989 h2989
  have h2991 : TreeTrue τ start2991 := replay_true τ ok2990 h2990
  have h2992 : TreeTrue τ start2992 := replay_true τ ok2991 h2991
  have h2993 : TreeTrue τ start2993 := replay_true τ ok2992 h2992
  have h2994 : TreeTrue τ start2994 := replay_true τ ok2993 h2993
  have h2995 : TreeTrue τ start2995 := replay_true τ ok2994 h2994
  have h2996 : TreeTrue τ start2996 := replay_true τ ok2995 h2995
  have h2997 : TreeTrue τ start2997 := replay_true τ ok2996 h2996
  have h2998 : TreeTrue τ start2998 := replay_true τ ok2997 h2997
  have h2999 : TreeTrue τ start2999 := replay_true τ ok2998 h2998
  have h3000 : TreeTrue τ start3000 := replay_true τ ok2999 h2999
  have h3001 : TreeTrue τ start3001 := replay_true τ ok3000 h3000
  have h3002 : TreeTrue τ start3002 := replay_true τ ok3001 h3001
  have h3003 : TreeTrue τ start3003 := replay_true τ ok3002 h3002
  have h3004 : TreeTrue τ start3004 := replay_true τ ok3003 h3003
  have h3005 : TreeTrue τ start3005 := replay_true τ ok3004 h3004
  have h3006 : TreeTrue τ start3006 := replay_true τ ok3005 h3005
  have h3007 : TreeTrue τ start3007 := replay_true τ ok3006 h3006
  have h3008 : TreeTrue τ start3008 := cp_true τ ok3007 h3007
  exact h3008
#print axioms steps93
end Snake9.ReplayFull147
