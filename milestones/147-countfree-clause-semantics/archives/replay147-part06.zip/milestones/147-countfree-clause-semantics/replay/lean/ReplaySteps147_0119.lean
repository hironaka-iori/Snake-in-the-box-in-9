import ReplayCheck147_03808
import ReplayCheck147_03812
import ReplayCheck147_03816
import ReplayCheck147_03820
import ReplayCheck147_03824
import ReplayCheck147_03828
import ReplayCheck147_03832
import ReplayCheck147_03836
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps119 (τ : Nat → Bool) (h3808 : TreeTrue τ start3808) : TreeTrue τ start3840 := by
  have h3809 : TreeTrue τ start3809 := replay_true τ ok3808 h3808
  have h3810 : TreeTrue τ start3810 := replay_true τ ok3809 h3809
  have h3811 : TreeTrue τ start3811 := replay_true τ ok3810 h3810
  have h3812 : TreeTrue τ start3812 := replay_true τ ok3811 h3811
  have h3813 : TreeTrue τ start3813 := replay_true τ ok3812 h3812
  have h3814 : TreeTrue τ start3814 := replay_true τ ok3813 h3813
  have h3815 : TreeTrue τ start3815 := replay_true τ ok3814 h3814
  have h3816 : TreeTrue τ start3816 := replay_true τ ok3815 h3815
  have h3817 : TreeTrue τ start3817 := replay_true τ ok3816 h3816
  have h3818 : TreeTrue τ start3818 := replay_true τ ok3817 h3817
  have h3819 : TreeTrue τ start3819 := replay_true τ ok3818 h3818
  have h3820 : TreeTrue τ start3820 := replay_true τ ok3819 h3819
  have h3821 : TreeTrue τ start3821 := replay_true τ ok3820 h3820
  have h3822 : TreeTrue τ start3822 := replay_true τ ok3821 h3821
  have h3823 : TreeTrue τ start3823 := replay_true τ ok3822 h3822
  have h3824 : TreeTrue τ start3824 := replay_true τ ok3823 h3823
  have h3825 : TreeTrue τ start3825 := replay_true τ ok3824 h3824
  have h3826 : TreeTrue τ start3826 := replay_true τ ok3825 h3825
  have h3827 : TreeTrue τ start3827 := replay_true τ ok3826 h3826
  have h3828 : TreeTrue τ start3828 := replay_true τ ok3827 h3827
  have h3829 : TreeTrue τ start3829 := replay_true τ ok3828 h3828
  have h3830 : TreeTrue τ start3830 := replay_true τ ok3829 h3829
  have h3831 : TreeTrue τ start3831 := replay_true τ ok3830 h3830
  have h3832 : TreeTrue τ start3832 := replay_true τ ok3831 h3831
  have h3833 : TreeTrue τ start3833 := replay_true τ ok3832 h3832
  have h3834 : TreeTrue τ start3834 := replay_true τ ok3833 h3833
  have h3835 : TreeTrue τ start3835 := replay_true τ ok3834 h3834
  have h3836 : TreeTrue τ start3836 := replay_true τ ok3835 h3835
  have h3837 : TreeTrue τ start3837 := replay_true τ ok3836 h3836
  have h3838 : TreeTrue τ start3838 := replay_true τ ok3837 h3837
  have h3839 : TreeTrue τ start3839 := replay_true τ ok3838 h3838
  have h3840 : TreeTrue τ start3840 := cp_true τ ok3839 h3839
  exact h3840
#print axioms steps119
end Snake9.ReplayFull147
