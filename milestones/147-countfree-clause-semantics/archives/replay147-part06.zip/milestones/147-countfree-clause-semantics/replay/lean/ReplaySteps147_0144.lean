import ReplayCheck147_04608
import ReplayCheck147_04612
import ReplayCheck147_04616
import ReplayCheck147_04620
import ReplayCheck147_04624
import ReplayCheck147_04628
import ReplayCheck147_04632
import ReplayCheck147_04636
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps144 (τ : Nat → Bool) (h4608 : TreeTrue τ start4608) : TreeTrue τ start4640 := by
  have h4609 : TreeTrue τ start4609 := replay_true τ ok4608 h4608
  have h4610 : TreeTrue τ start4610 := replay_true τ ok4609 h4609
  have h4611 : TreeTrue τ start4611 := replay_true τ ok4610 h4610
  have h4612 : TreeTrue τ start4612 := replay_true τ ok4611 h4611
  have h4613 : TreeTrue τ start4613 := replay_true τ ok4612 h4612
  have h4614 : TreeTrue τ start4614 := replay_true τ ok4613 h4613
  have h4615 : TreeTrue τ start4615 := replay_true τ ok4614 h4614
  have h4616 : TreeTrue τ start4616 := replay_true τ ok4615 h4615
  have h4617 : TreeTrue τ start4617 := replay_true τ ok4616 h4616
  have h4618 : TreeTrue τ start4618 := replay_true τ ok4617 h4617
  have h4619 : TreeTrue τ start4619 := replay_true τ ok4618 h4618
  have h4620 : TreeTrue τ start4620 := replay_true τ ok4619 h4619
  have h4621 : TreeTrue τ start4621 := replay_true τ ok4620 h4620
  have h4622 : TreeTrue τ start4622 := replay_true τ ok4621 h4621
  have h4623 : TreeTrue τ start4623 := replay_true τ ok4622 h4622
  have h4624 : TreeTrue τ start4624 := replay_true τ ok4623 h4623
  have h4625 : TreeTrue τ start4625 := replay_true τ ok4624 h4624
  have h4626 : TreeTrue τ start4626 := replay_true τ ok4625 h4625
  have h4627 : TreeTrue τ start4627 := replay_true τ ok4626 h4626
  have h4628 : TreeTrue τ start4628 := replay_true τ ok4627 h4627
  have h4629 : TreeTrue τ start4629 := replay_true τ ok4628 h4628
  have h4630 : TreeTrue τ start4630 := replay_true τ ok4629 h4629
  have h4631 : TreeTrue τ start4631 := replay_true τ ok4630 h4630
  have h4632 : TreeTrue τ start4632 := replay_true τ ok4631 h4631
  have h4633 : TreeTrue τ start4633 := replay_true τ ok4632 h4632
  have h4634 : TreeTrue τ start4634 := replay_true τ ok4633 h4633
  have h4635 : TreeTrue τ start4635 := replay_true τ ok4634 h4634
  have h4636 : TreeTrue τ start4636 := replay_true τ ok4635 h4635
  have h4637 : TreeTrue τ start4637 := replay_true τ ok4636 h4636
  have h4638 : TreeTrue τ start4638 := replay_true τ ok4637 h4637
  have h4639 : TreeTrue τ start4639 := replay_true τ ok4638 h4638
  have h4640 : TreeTrue τ start4640 := cp_true τ ok4639 h4639
  exact h4640
#print axioms steps144
end Snake9.ReplayFull147
