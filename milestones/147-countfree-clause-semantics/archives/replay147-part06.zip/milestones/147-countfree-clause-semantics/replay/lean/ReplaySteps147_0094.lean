import ReplayCheck147_03008
import ReplayCheck147_03012
import ReplayCheck147_03016
import ReplayCheck147_03020
import ReplayCheck147_03024
import ReplayCheck147_03028
import ReplayCheck147_03032
import ReplayCheck147_03036
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps94 (τ : Nat → Bool) (h3008 : TreeTrue τ start3008) : TreeTrue τ start3040 := by
  have h3009 : TreeTrue τ start3009 := replay_true τ ok3008 h3008
  have h3010 : TreeTrue τ start3010 := replay_true τ ok3009 h3009
  have h3011 : TreeTrue τ start3011 := replay_true τ ok3010 h3010
  have h3012 : TreeTrue τ start3012 := replay_true τ ok3011 h3011
  have h3013 : TreeTrue τ start3013 := replay_true τ ok3012 h3012
  have h3014 : TreeTrue τ start3014 := replay_true τ ok3013 h3013
  have h3015 : TreeTrue τ start3015 := replay_true τ ok3014 h3014
  have h3016 : TreeTrue τ start3016 := replay_true τ ok3015 h3015
  have h3017 : TreeTrue τ start3017 := replay_true τ ok3016 h3016
  have h3018 : TreeTrue τ start3018 := replay_true τ ok3017 h3017
  have h3019 : TreeTrue τ start3019 := replay_true τ ok3018 h3018
  have h3020 : TreeTrue τ start3020 := replay_true τ ok3019 h3019
  have h3021 : TreeTrue τ start3021 := replay_true τ ok3020 h3020
  have h3022 : TreeTrue τ start3022 := replay_true τ ok3021 h3021
  have h3023 : TreeTrue τ start3023 := replay_true τ ok3022 h3022
  have h3024 : TreeTrue τ start3024 := replay_true τ ok3023 h3023
  have h3025 : TreeTrue τ start3025 := replay_true τ ok3024 h3024
  have h3026 : TreeTrue τ start3026 := replay_true τ ok3025 h3025
  have h3027 : TreeTrue τ start3027 := replay_true τ ok3026 h3026
  have h3028 : TreeTrue τ start3028 := replay_true τ ok3027 h3027
  have h3029 : TreeTrue τ start3029 := replay_true τ ok3028 h3028
  have h3030 : TreeTrue τ start3030 := replay_true τ ok3029 h3029
  have h3031 : TreeTrue τ start3031 := replay_true τ ok3030 h3030
  have h3032 : TreeTrue τ start3032 := replay_true τ ok3031 h3031
  have h3033 : TreeTrue τ start3033 := replay_true τ ok3032 h3032
  have h3034 : TreeTrue τ start3034 := replay_true τ ok3033 h3033
  have h3035 : TreeTrue τ start3035 := replay_true τ ok3034 h3034
  have h3036 : TreeTrue τ start3036 := replay_true τ ok3035 h3035
  have h3037 : TreeTrue τ start3037 := replay_true τ ok3036 h3036
  have h3038 : TreeTrue τ start3038 := replay_true τ ok3037 h3037
  have h3039 : TreeTrue τ start3039 := replay_true τ ok3038 h3038
  have h3040 : TreeTrue τ start3040 := cp_true τ ok3039 h3039
  exact h3040
#print axioms steps94
end Snake9.ReplayFull147
