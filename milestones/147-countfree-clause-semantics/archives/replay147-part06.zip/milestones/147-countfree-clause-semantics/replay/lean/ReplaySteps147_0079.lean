import ReplayCheck147_02528
import ReplayCheck147_02532
import ReplayCheck147_02536
import ReplayCheck147_02540
import ReplayCheck147_02544
import ReplayCheck147_02548
import ReplayCheck147_02552
import ReplayCheck147_02556
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps79 (τ : Nat → Bool) (h2528 : TreeTrue τ start2528) : TreeTrue τ start2560 := by
  have h2529 : TreeTrue τ start2529 := replay_true τ ok2528 h2528
  have h2530 : TreeTrue τ start2530 := replay_true τ ok2529 h2529
  have h2531 : TreeTrue τ start2531 := replay_true τ ok2530 h2530
  have h2532 : TreeTrue τ start2532 := replay_true τ ok2531 h2531
  have h2533 : TreeTrue τ start2533 := replay_true τ ok2532 h2532
  have h2534 : TreeTrue τ start2534 := replay_true τ ok2533 h2533
  have h2535 : TreeTrue τ start2535 := replay_true τ ok2534 h2534
  have h2536 : TreeTrue τ start2536 := replay_true τ ok2535 h2535
  have h2537 : TreeTrue τ start2537 := replay_true τ ok2536 h2536
  have h2538 : TreeTrue τ start2538 := replay_true τ ok2537 h2537
  have h2539 : TreeTrue τ start2539 := replay_true τ ok2538 h2538
  have h2540 : TreeTrue τ start2540 := replay_true τ ok2539 h2539
  have h2541 : TreeTrue τ start2541 := replay_true τ ok2540 h2540
  have h2542 : TreeTrue τ start2542 := replay_true τ ok2541 h2541
  have h2543 : TreeTrue τ start2543 := replay_true τ ok2542 h2542
  have h2544 : TreeTrue τ start2544 := replay_true τ ok2543 h2543
  have h2545 : TreeTrue τ start2545 := replay_true τ ok2544 h2544
  have h2546 : TreeTrue τ start2546 := replay_true τ ok2545 h2545
  have h2547 : TreeTrue τ start2547 := replay_true τ ok2546 h2546
  have h2548 : TreeTrue τ start2548 := replay_true τ ok2547 h2547
  have h2549 : TreeTrue τ start2549 := replay_true τ ok2548 h2548
  have h2550 : TreeTrue τ start2550 := replay_true τ ok2549 h2549
  have h2551 : TreeTrue τ start2551 := replay_true τ ok2550 h2550
  have h2552 : TreeTrue τ start2552 := replay_true τ ok2551 h2551
  have h2553 : TreeTrue τ start2553 := replay_true τ ok2552 h2552
  have h2554 : TreeTrue τ start2554 := replay_true τ ok2553 h2553
  have h2555 : TreeTrue τ start2555 := replay_true τ ok2554 h2554
  have h2556 : TreeTrue τ start2556 := replay_true τ ok2555 h2555
  have h2557 : TreeTrue τ start2557 := replay_true τ ok2556 h2556
  have h2558 : TreeTrue τ start2558 := replay_true τ ok2557 h2557
  have h2559 : TreeTrue τ start2559 := replay_true τ ok2558 h2558
  have h2560 : TreeTrue τ start2560 := cp_true τ ok2559 h2559
  exact h2560
#print axioms steps79
end Snake9.ReplayFull147
