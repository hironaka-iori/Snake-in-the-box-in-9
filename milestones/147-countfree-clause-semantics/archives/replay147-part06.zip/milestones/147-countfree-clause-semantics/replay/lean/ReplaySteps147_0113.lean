import ReplayCheck147_03616
import ReplayCheck147_03620
import ReplayCheck147_03624
import ReplayCheck147_03628
import ReplayCheck147_03632
import ReplayCheck147_03636
import ReplayCheck147_03640
import ReplayCheck147_03644
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps113 (τ : Nat → Bool) (h3616 : TreeTrue τ start3616) : TreeTrue τ start3648 := by
  have h3617 : TreeTrue τ start3617 := replay_true τ ok3616 h3616
  have h3618 : TreeTrue τ start3618 := replay_true τ ok3617 h3617
  have h3619 : TreeTrue τ start3619 := replay_true τ ok3618 h3618
  have h3620 : TreeTrue τ start3620 := replay_true τ ok3619 h3619
  have h3621 : TreeTrue τ start3621 := replay_true τ ok3620 h3620
  have h3622 : TreeTrue τ start3622 := replay_true τ ok3621 h3621
  have h3623 : TreeTrue τ start3623 := replay_true τ ok3622 h3622
  have h3624 : TreeTrue τ start3624 := replay_true τ ok3623 h3623
  have h3625 : TreeTrue τ start3625 := replay_true τ ok3624 h3624
  have h3626 : TreeTrue τ start3626 := replay_true τ ok3625 h3625
  have h3627 : TreeTrue τ start3627 := replay_true τ ok3626 h3626
  have h3628 : TreeTrue τ start3628 := replay_true τ ok3627 h3627
  have h3629 : TreeTrue τ start3629 := replay_true τ ok3628 h3628
  have h3630 : TreeTrue τ start3630 := replay_true τ ok3629 h3629
  have h3631 : TreeTrue τ start3631 := replay_true τ ok3630 h3630
  have h3632 : TreeTrue τ start3632 := replay_true τ ok3631 h3631
  have h3633 : TreeTrue τ start3633 := replay_true τ ok3632 h3632
  have h3634 : TreeTrue τ start3634 := replay_true τ ok3633 h3633
  have h3635 : TreeTrue τ start3635 := replay_true τ ok3634 h3634
  have h3636 : TreeTrue τ start3636 := replay_true τ ok3635 h3635
  have h3637 : TreeTrue τ start3637 := replay_true τ ok3636 h3636
  have h3638 : TreeTrue τ start3638 := replay_true τ ok3637 h3637
  have h3639 : TreeTrue τ start3639 := replay_true τ ok3638 h3638
  have h3640 : TreeTrue τ start3640 := replay_true τ ok3639 h3639
  have h3641 : TreeTrue τ start3641 := replay_true τ ok3640 h3640
  have h3642 : TreeTrue τ start3642 := replay_true τ ok3641 h3641
  have h3643 : TreeTrue τ start3643 := replay_true τ ok3642 h3642
  have h3644 : TreeTrue τ start3644 := replay_true τ ok3643 h3643
  have h3645 : TreeTrue τ start3645 := replay_true τ ok3644 h3644
  have h3646 : TreeTrue τ start3646 := replay_true τ ok3645 h3645
  have h3647 : TreeTrue τ start3647 := replay_true τ ok3646 h3646
  have h3648 : TreeTrue τ start3648 := cp_true τ ok3647 h3647
  exact h3648
#print axioms steps113
end Snake9.ReplayFull147
