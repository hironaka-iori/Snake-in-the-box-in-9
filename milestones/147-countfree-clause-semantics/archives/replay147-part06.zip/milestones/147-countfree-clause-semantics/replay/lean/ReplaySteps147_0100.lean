import ReplayCheck147_03200
import ReplayCheck147_03204
import ReplayCheck147_03208
import ReplayCheck147_03212
import ReplayCheck147_03216
import ReplayCheck147_03220
import ReplayCheck147_03224
import ReplayCheck147_03228
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps100 (τ : Nat → Bool) (h3200 : TreeTrue τ start3200) : TreeTrue τ start3232 := by
  have h3201 : TreeTrue τ start3201 := replay_true τ ok3200 h3200
  have h3202 : TreeTrue τ start3202 := replay_true τ ok3201 h3201
  have h3203 : TreeTrue τ start3203 := replay_true τ ok3202 h3202
  have h3204 : TreeTrue τ start3204 := replay_true τ ok3203 h3203
  have h3205 : TreeTrue τ start3205 := replay_true τ ok3204 h3204
  have h3206 : TreeTrue τ start3206 := replay_true τ ok3205 h3205
  have h3207 : TreeTrue τ start3207 := replay_true τ ok3206 h3206
  have h3208 : TreeTrue τ start3208 := replay_true τ ok3207 h3207
  have h3209 : TreeTrue τ start3209 := replay_true τ ok3208 h3208
  have h3210 : TreeTrue τ start3210 := replay_true τ ok3209 h3209
  have h3211 : TreeTrue τ start3211 := replay_true τ ok3210 h3210
  have h3212 : TreeTrue τ start3212 := replay_true τ ok3211 h3211
  have h3213 : TreeTrue τ start3213 := replay_true τ ok3212 h3212
  have h3214 : TreeTrue τ start3214 := replay_true τ ok3213 h3213
  have h3215 : TreeTrue τ start3215 := replay_true τ ok3214 h3214
  have h3216 : TreeTrue τ start3216 := replay_true τ ok3215 h3215
  have h3217 : TreeTrue τ start3217 := replay_true τ ok3216 h3216
  have h3218 : TreeTrue τ start3218 := replay_true τ ok3217 h3217
  have h3219 : TreeTrue τ start3219 := replay_true τ ok3218 h3218
  have h3220 : TreeTrue τ start3220 := replay_true τ ok3219 h3219
  have h3221 : TreeTrue τ start3221 := replay_true τ ok3220 h3220
  have h3222 : TreeTrue τ start3222 := replay_true τ ok3221 h3221
  have h3223 : TreeTrue τ start3223 := replay_true τ ok3222 h3222
  have h3224 : TreeTrue τ start3224 := replay_true τ ok3223 h3223
  have h3225 : TreeTrue τ start3225 := replay_true τ ok3224 h3224
  have h3226 : TreeTrue τ start3226 := replay_true τ ok3225 h3225
  have h3227 : TreeTrue τ start3227 := replay_true τ ok3226 h3226
  have h3228 : TreeTrue τ start3228 := replay_true τ ok3227 h3227
  have h3229 : TreeTrue τ start3229 := replay_true τ ok3228 h3228
  have h3230 : TreeTrue τ start3230 := replay_true τ ok3229 h3229
  have h3231 : TreeTrue τ start3231 := replay_true τ ok3230 h3230
  have h3232 : TreeTrue τ start3232 := cp_true τ ok3231 h3231
  exact h3232
#print axioms steps100
end Snake9.ReplayFull147
