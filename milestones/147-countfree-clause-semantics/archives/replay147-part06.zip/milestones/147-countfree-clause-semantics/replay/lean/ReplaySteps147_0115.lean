import ReplayCheck147_03680
import ReplayCheck147_03684
import ReplayCheck147_03688
import ReplayCheck147_03692
import ReplayCheck147_03696
import ReplayCheck147_03700
import ReplayCheck147_03704
import ReplayCheck147_03708
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps115 (τ : Nat → Bool) (h3680 : TreeTrue τ start3680) : TreeTrue τ start3712 := by
  have h3681 : TreeTrue τ start3681 := replay_true τ ok3680 h3680
  have h3682 : TreeTrue τ start3682 := replay_true τ ok3681 h3681
  have h3683 : TreeTrue τ start3683 := replay_true τ ok3682 h3682
  have h3684 : TreeTrue τ start3684 := replay_true τ ok3683 h3683
  have h3685 : TreeTrue τ start3685 := replay_true τ ok3684 h3684
  have h3686 : TreeTrue τ start3686 := replay_true τ ok3685 h3685
  have h3687 : TreeTrue τ start3687 := replay_true τ ok3686 h3686
  have h3688 : TreeTrue τ start3688 := replay_true τ ok3687 h3687
  have h3689 : TreeTrue τ start3689 := replay_true τ ok3688 h3688
  have h3690 : TreeTrue τ start3690 := replay_true τ ok3689 h3689
  have h3691 : TreeTrue τ start3691 := replay_true τ ok3690 h3690
  have h3692 : TreeTrue τ start3692 := replay_true τ ok3691 h3691
  have h3693 : TreeTrue τ start3693 := replay_true τ ok3692 h3692
  have h3694 : TreeTrue τ start3694 := replay_true τ ok3693 h3693
  have h3695 : TreeTrue τ start3695 := replay_true τ ok3694 h3694
  have h3696 : TreeTrue τ start3696 := replay_true τ ok3695 h3695
  have h3697 : TreeTrue τ start3697 := replay_true τ ok3696 h3696
  have h3698 : TreeTrue τ start3698 := replay_true τ ok3697 h3697
  have h3699 : TreeTrue τ start3699 := replay_true τ ok3698 h3698
  have h3700 : TreeTrue τ start3700 := replay_true τ ok3699 h3699
  have h3701 : TreeTrue τ start3701 := replay_true τ ok3700 h3700
  have h3702 : TreeTrue τ start3702 := replay_true τ ok3701 h3701
  have h3703 : TreeTrue τ start3703 := replay_true τ ok3702 h3702
  have h3704 : TreeTrue τ start3704 := replay_true τ ok3703 h3703
  have h3705 : TreeTrue τ start3705 := replay_true τ ok3704 h3704
  have h3706 : TreeTrue τ start3706 := replay_true τ ok3705 h3705
  have h3707 : TreeTrue τ start3707 := replay_true τ ok3706 h3706
  have h3708 : TreeTrue τ start3708 := replay_true τ ok3707 h3707
  have h3709 : TreeTrue τ start3709 := replay_true τ ok3708 h3708
  have h3710 : TreeTrue τ start3710 := replay_true τ ok3709 h3709
  have h3711 : TreeTrue τ start3711 := replay_true τ ok3710 h3710
  have h3712 : TreeTrue τ start3712 := cp_true τ ok3711 h3711
  exact h3712
#print axioms steps115
end Snake9.ReplayFull147
