import ReplayCheck147_03072
import ReplayCheck147_03076
import ReplayCheck147_03080
import ReplayCheck147_03084
import ReplayCheck147_03088
import ReplayCheck147_03092
import ReplayCheck147_03096
import ReplayCheck147_03100
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps96 (τ : Nat → Bool) (h3072 : TreeTrue τ start3072) : TreeTrue τ start3104 := by
  have h3073 : TreeTrue τ start3073 := replay_true τ ok3072 h3072
  have h3074 : TreeTrue τ start3074 := replay_true τ ok3073 h3073
  have h3075 : TreeTrue τ start3075 := replay_true τ ok3074 h3074
  have h3076 : TreeTrue τ start3076 := replay_true τ ok3075 h3075
  have h3077 : TreeTrue τ start3077 := replay_true τ ok3076 h3076
  have h3078 : TreeTrue τ start3078 := replay_true τ ok3077 h3077
  have h3079 : TreeTrue τ start3079 := replay_true τ ok3078 h3078
  have h3080 : TreeTrue τ start3080 := replay_true τ ok3079 h3079
  have h3081 : TreeTrue τ start3081 := replay_true τ ok3080 h3080
  have h3082 : TreeTrue τ start3082 := replay_true τ ok3081 h3081
  have h3083 : TreeTrue τ start3083 := replay_true τ ok3082 h3082
  have h3084 : TreeTrue τ start3084 := replay_true τ ok3083 h3083
  have h3085 : TreeTrue τ start3085 := replay_true τ ok3084 h3084
  have h3086 : TreeTrue τ start3086 := replay_true τ ok3085 h3085
  have h3087 : TreeTrue τ start3087 := replay_true τ ok3086 h3086
  have h3088 : TreeTrue τ start3088 := replay_true τ ok3087 h3087
  have h3089 : TreeTrue τ start3089 := replay_true τ ok3088 h3088
  have h3090 : TreeTrue τ start3090 := replay_true τ ok3089 h3089
  have h3091 : TreeTrue τ start3091 := replay_true τ ok3090 h3090
  have h3092 : TreeTrue τ start3092 := replay_true τ ok3091 h3091
  have h3093 : TreeTrue τ start3093 := replay_true τ ok3092 h3092
  have h3094 : TreeTrue τ start3094 := replay_true τ ok3093 h3093
  have h3095 : TreeTrue τ start3095 := replay_true τ ok3094 h3094
  have h3096 : TreeTrue τ start3096 := replay_true τ ok3095 h3095
  have h3097 : TreeTrue τ start3097 := replay_true τ ok3096 h3096
  have h3098 : TreeTrue τ start3098 := replay_true τ ok3097 h3097
  have h3099 : TreeTrue τ start3099 := replay_true τ ok3098 h3098
  have h3100 : TreeTrue τ start3100 := replay_true τ ok3099 h3099
  have h3101 : TreeTrue τ start3101 := replay_true τ ok3100 h3100
  have h3102 : TreeTrue τ start3102 := replay_true τ ok3101 h3101
  have h3103 : TreeTrue τ start3103 := replay_true τ ok3102 h3102
  have h3104 : TreeTrue τ start3104 := cp_true τ ok3103 h3103
  exact h3104
#print axioms steps96
end Snake9.ReplayFull147
