import ReplayCheck147_02464
import ReplayCheck147_02468
import ReplayCheck147_02472
import ReplayCheck147_02476
import ReplayCheck147_02480
import ReplayCheck147_02484
import ReplayCheck147_02488
import ReplayCheck147_02492
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps77 (τ : Nat → Bool) (h2464 : TreeTrue τ start2464) : TreeTrue τ start2496 := by
  have h2465 : TreeTrue τ start2465 := replay_true τ ok2464 h2464
  have h2466 : TreeTrue τ start2466 := replay_true τ ok2465 h2465
  have h2467 : TreeTrue τ start2467 := replay_true τ ok2466 h2466
  have h2468 : TreeTrue τ start2468 := replay_true τ ok2467 h2467
  have h2469 : TreeTrue τ start2469 := replay_true τ ok2468 h2468
  have h2470 : TreeTrue τ start2470 := replay_true τ ok2469 h2469
  have h2471 : TreeTrue τ start2471 := replay_true τ ok2470 h2470
  have h2472 : TreeTrue τ start2472 := replay_true τ ok2471 h2471
  have h2473 : TreeTrue τ start2473 := replay_true τ ok2472 h2472
  have h2474 : TreeTrue τ start2474 := replay_true τ ok2473 h2473
  have h2475 : TreeTrue τ start2475 := replay_true τ ok2474 h2474
  have h2476 : TreeTrue τ start2476 := replay_true τ ok2475 h2475
  have h2477 : TreeTrue τ start2477 := replay_true τ ok2476 h2476
  have h2478 : TreeTrue τ start2478 := replay_true τ ok2477 h2477
  have h2479 : TreeTrue τ start2479 := replay_true τ ok2478 h2478
  have h2480 : TreeTrue τ start2480 := replay_true τ ok2479 h2479
  have h2481 : TreeTrue τ start2481 := replay_true τ ok2480 h2480
  have h2482 : TreeTrue τ start2482 := replay_true τ ok2481 h2481
  have h2483 : TreeTrue τ start2483 := replay_true τ ok2482 h2482
  have h2484 : TreeTrue τ start2484 := replay_true τ ok2483 h2483
  have h2485 : TreeTrue τ start2485 := replay_true τ ok2484 h2484
  have h2486 : TreeTrue τ start2486 := replay_true τ ok2485 h2485
  have h2487 : TreeTrue τ start2487 := replay_true τ ok2486 h2486
  have h2488 : TreeTrue τ start2488 := replay_true τ ok2487 h2487
  have h2489 : TreeTrue τ start2489 := replay_true τ ok2488 h2488
  have h2490 : TreeTrue τ start2490 := replay_true τ ok2489 h2489
  have h2491 : TreeTrue τ start2491 := replay_true τ ok2490 h2490
  have h2492 : TreeTrue τ start2492 := replay_true τ ok2491 h2491
  have h2493 : TreeTrue τ start2493 := replay_true τ ok2492 h2492
  have h2494 : TreeTrue τ start2494 := replay_true τ ok2493 h2493
  have h2495 : TreeTrue τ start2495 := replay_true τ ok2494 h2494
  have h2496 : TreeTrue τ start2496 := cp_true τ ok2495 h2495
  exact h2496
#print axioms steps77
end Snake9.ReplayFull147
