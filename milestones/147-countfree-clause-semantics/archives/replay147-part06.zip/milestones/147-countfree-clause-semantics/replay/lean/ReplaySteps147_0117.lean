import ReplayCheck147_03744
import ReplayCheck147_03748
import ReplayCheck147_03752
import ReplayCheck147_03756
import ReplayCheck147_03760
import ReplayCheck147_03764
import ReplayCheck147_03768
import ReplayCheck147_03772
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps117 (τ : Nat → Bool) (h3744 : TreeTrue τ start3744) : TreeTrue τ start3776 := by
  have h3745 : TreeTrue τ start3745 := replay_true τ ok3744 h3744
  have h3746 : TreeTrue τ start3746 := replay_true τ ok3745 h3745
  have h3747 : TreeTrue τ start3747 := replay_true τ ok3746 h3746
  have h3748 : TreeTrue τ start3748 := replay_true τ ok3747 h3747
  have h3749 : TreeTrue τ start3749 := replay_true τ ok3748 h3748
  have h3750 : TreeTrue τ start3750 := replay_true τ ok3749 h3749
  have h3751 : TreeTrue τ start3751 := replay_true τ ok3750 h3750
  have h3752 : TreeTrue τ start3752 := replay_true τ ok3751 h3751
  have h3753 : TreeTrue τ start3753 := replay_true τ ok3752 h3752
  have h3754 : TreeTrue τ start3754 := replay_true τ ok3753 h3753
  have h3755 : TreeTrue τ start3755 := replay_true τ ok3754 h3754
  have h3756 : TreeTrue τ start3756 := replay_true τ ok3755 h3755
  have h3757 : TreeTrue τ start3757 := replay_true τ ok3756 h3756
  have h3758 : TreeTrue τ start3758 := replay_true τ ok3757 h3757
  have h3759 : TreeTrue τ start3759 := replay_true τ ok3758 h3758
  have h3760 : TreeTrue τ start3760 := replay_true τ ok3759 h3759
  have h3761 : TreeTrue τ start3761 := replay_true τ ok3760 h3760
  have h3762 : TreeTrue τ start3762 := replay_true τ ok3761 h3761
  have h3763 : TreeTrue τ start3763 := replay_true τ ok3762 h3762
  have h3764 : TreeTrue τ start3764 := replay_true τ ok3763 h3763
  have h3765 : TreeTrue τ start3765 := replay_true τ ok3764 h3764
  have h3766 : TreeTrue τ start3766 := replay_true τ ok3765 h3765
  have h3767 : TreeTrue τ start3767 := replay_true τ ok3766 h3766
  have h3768 : TreeTrue τ start3768 := replay_true τ ok3767 h3767
  have h3769 : TreeTrue τ start3769 := replay_true τ ok3768 h3768
  have h3770 : TreeTrue τ start3770 := replay_true τ ok3769 h3769
  have h3771 : TreeTrue τ start3771 := replay_true τ ok3770 h3770
  have h3772 : TreeTrue τ start3772 := replay_true τ ok3771 h3771
  have h3773 : TreeTrue τ start3773 := replay_true τ ok3772 h3772
  have h3774 : TreeTrue τ start3774 := replay_true τ ok3773 h3773
  have h3775 : TreeTrue τ start3775 := replay_true τ ok3774 h3774
  have h3776 : TreeTrue τ start3776 := cp_true τ ok3775 h3775
  exact h3776
#print axioms steps117
end Snake9.ReplayFull147
