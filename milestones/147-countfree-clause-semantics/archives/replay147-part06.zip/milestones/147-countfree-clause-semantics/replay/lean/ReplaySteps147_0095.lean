import ReplayCheck147_03040
import ReplayCheck147_03044
import ReplayCheck147_03048
import ReplayCheck147_03052
import ReplayCheck147_03056
import ReplayCheck147_03060
import ReplayCheck147_03064
import ReplayCheck147_03068
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps95 (τ : Nat → Bool) (h3040 : TreeTrue τ start3040) : TreeTrue τ start3072 := by
  have h3041 : TreeTrue τ start3041 := replay_true τ ok3040 h3040
  have h3042 : TreeTrue τ start3042 := replay_true τ ok3041 h3041
  have h3043 : TreeTrue τ start3043 := replay_true τ ok3042 h3042
  have h3044 : TreeTrue τ start3044 := replay_true τ ok3043 h3043
  have h3045 : TreeTrue τ start3045 := replay_true τ ok3044 h3044
  have h3046 : TreeTrue τ start3046 := replay_true τ ok3045 h3045
  have h3047 : TreeTrue τ start3047 := replay_true τ ok3046 h3046
  have h3048 : TreeTrue τ start3048 := replay_true τ ok3047 h3047
  have h3049 : TreeTrue τ start3049 := replay_true τ ok3048 h3048
  have h3050 : TreeTrue τ start3050 := replay_true τ ok3049 h3049
  have h3051 : TreeTrue τ start3051 := replay_true τ ok3050 h3050
  have h3052 : TreeTrue τ start3052 := replay_true τ ok3051 h3051
  have h3053 : TreeTrue τ start3053 := replay_true τ ok3052 h3052
  have h3054 : TreeTrue τ start3054 := replay_true τ ok3053 h3053
  have h3055 : TreeTrue τ start3055 := replay_true τ ok3054 h3054
  have h3056 : TreeTrue τ start3056 := replay_true τ ok3055 h3055
  have h3057 : TreeTrue τ start3057 := replay_true τ ok3056 h3056
  have h3058 : TreeTrue τ start3058 := replay_true τ ok3057 h3057
  have h3059 : TreeTrue τ start3059 := replay_true τ ok3058 h3058
  have h3060 : TreeTrue τ start3060 := replay_true τ ok3059 h3059
  have h3061 : TreeTrue τ start3061 := replay_true τ ok3060 h3060
  have h3062 : TreeTrue τ start3062 := replay_true τ ok3061 h3061
  have h3063 : TreeTrue τ start3063 := replay_true τ ok3062 h3062
  have h3064 : TreeTrue τ start3064 := replay_true τ ok3063 h3063
  have h3065 : TreeTrue τ start3065 := replay_true τ ok3064 h3064
  have h3066 : TreeTrue τ start3066 := replay_true τ ok3065 h3065
  have h3067 : TreeTrue τ start3067 := replay_true τ ok3066 h3066
  have h3068 : TreeTrue τ start3068 := replay_true τ ok3067 h3067
  have h3069 : TreeTrue τ start3069 := replay_true τ ok3068 h3068
  have h3070 : TreeTrue τ start3070 := replay_true τ ok3069 h3069
  have h3071 : TreeTrue τ start3071 := replay_true τ ok3070 h3070
  have h3072 : TreeTrue τ start3072 := cp_true τ ok3071 h3071
  exact h3072
#print axioms steps95
end Snake9.ReplayFull147
