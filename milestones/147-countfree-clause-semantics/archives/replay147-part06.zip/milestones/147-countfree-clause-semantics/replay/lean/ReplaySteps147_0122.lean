import ReplayCheck147_03904
import ReplayCheck147_03908
import ReplayCheck147_03912
import ReplayCheck147_03916
import ReplayCheck147_03920
import ReplayCheck147_03924
import ReplayCheck147_03928
import ReplayCheck147_03932
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps122 (τ : Nat → Bool) (h3904 : TreeTrue τ start3904) : TreeTrue τ start3936 := by
  have h3905 : TreeTrue τ start3905 := replay_true τ ok3904 h3904
  have h3906 : TreeTrue τ start3906 := replay_true τ ok3905 h3905
  have h3907 : TreeTrue τ start3907 := replay_true τ ok3906 h3906
  have h3908 : TreeTrue τ start3908 := replay_true τ ok3907 h3907
  have h3909 : TreeTrue τ start3909 := replay_true τ ok3908 h3908
  have h3910 : TreeTrue τ start3910 := replay_true τ ok3909 h3909
  have h3911 : TreeTrue τ start3911 := replay_true τ ok3910 h3910
  have h3912 : TreeTrue τ start3912 := replay_true τ ok3911 h3911
  have h3913 : TreeTrue τ start3913 := replay_true τ ok3912 h3912
  have h3914 : TreeTrue τ start3914 := replay_true τ ok3913 h3913
  have h3915 : TreeTrue τ start3915 := replay_true τ ok3914 h3914
  have h3916 : TreeTrue τ start3916 := replay_true τ ok3915 h3915
  have h3917 : TreeTrue τ start3917 := replay_true τ ok3916 h3916
  have h3918 : TreeTrue τ start3918 := replay_true τ ok3917 h3917
  have h3919 : TreeTrue τ start3919 := replay_true τ ok3918 h3918
  have h3920 : TreeTrue τ start3920 := replay_true τ ok3919 h3919
  have h3921 : TreeTrue τ start3921 := replay_true τ ok3920 h3920
  have h3922 : TreeTrue τ start3922 := replay_true τ ok3921 h3921
  have h3923 : TreeTrue τ start3923 := replay_true τ ok3922 h3922
  have h3924 : TreeTrue τ start3924 := replay_true τ ok3923 h3923
  have h3925 : TreeTrue τ start3925 := replay_true τ ok3924 h3924
  have h3926 : TreeTrue τ start3926 := replay_true τ ok3925 h3925
  have h3927 : TreeTrue τ start3927 := replay_true τ ok3926 h3926
  have h3928 : TreeTrue τ start3928 := replay_true τ ok3927 h3927
  have h3929 : TreeTrue τ start3929 := replay_true τ ok3928 h3928
  have h3930 : TreeTrue τ start3930 := replay_true τ ok3929 h3929
  have h3931 : TreeTrue τ start3931 := replay_true τ ok3930 h3930
  have h3932 : TreeTrue τ start3932 := replay_true τ ok3931 h3931
  have h3933 : TreeTrue τ start3933 := replay_true τ ok3932 h3932
  have h3934 : TreeTrue τ start3934 := replay_true τ ok3933 h3933
  have h3935 : TreeTrue τ start3935 := replay_true τ ok3934 h3934
  have h3936 : TreeTrue τ start3936 := cp_true τ ok3935 h3935
  exact h3936
#print axioms steps122
end Snake9.ReplayFull147
