import ReplayCheck147_02432
import ReplayCheck147_02436
import ReplayCheck147_02440
import ReplayCheck147_02444
import ReplayCheck147_02448
import ReplayCheck147_02452
import ReplayCheck147_02456
import ReplayCheck147_02460
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps76 (τ : Nat → Bool) (h2432 : TreeTrue τ start2432) : TreeTrue τ start2464 := by
  have h2433 : TreeTrue τ start2433 := replay_true τ ok2432 h2432
  have h2434 : TreeTrue τ start2434 := replay_true τ ok2433 h2433
  have h2435 : TreeTrue τ start2435 := replay_true τ ok2434 h2434
  have h2436 : TreeTrue τ start2436 := replay_true τ ok2435 h2435
  have h2437 : TreeTrue τ start2437 := replay_true τ ok2436 h2436
  have h2438 : TreeTrue τ start2438 := replay_true τ ok2437 h2437
  have h2439 : TreeTrue τ start2439 := replay_true τ ok2438 h2438
  have h2440 : TreeTrue τ start2440 := replay_true τ ok2439 h2439
  have h2441 : TreeTrue τ start2441 := replay_true τ ok2440 h2440
  have h2442 : TreeTrue τ start2442 := replay_true τ ok2441 h2441
  have h2443 : TreeTrue τ start2443 := replay_true τ ok2442 h2442
  have h2444 : TreeTrue τ start2444 := replay_true τ ok2443 h2443
  have h2445 : TreeTrue τ start2445 := replay_true τ ok2444 h2444
  have h2446 : TreeTrue τ start2446 := replay_true τ ok2445 h2445
  have h2447 : TreeTrue τ start2447 := replay_true τ ok2446 h2446
  have h2448 : TreeTrue τ start2448 := replay_true τ ok2447 h2447
  have h2449 : TreeTrue τ start2449 := replay_true τ ok2448 h2448
  have h2450 : TreeTrue τ start2450 := replay_true τ ok2449 h2449
  have h2451 : TreeTrue τ start2451 := replay_true τ ok2450 h2450
  have h2452 : TreeTrue τ start2452 := replay_true τ ok2451 h2451
  have h2453 : TreeTrue τ start2453 := replay_true τ ok2452 h2452
  have h2454 : TreeTrue τ start2454 := replay_true τ ok2453 h2453
  have h2455 : TreeTrue τ start2455 := replay_true τ ok2454 h2454
  have h2456 : TreeTrue τ start2456 := replay_true τ ok2455 h2455
  have h2457 : TreeTrue τ start2457 := replay_true τ ok2456 h2456
  have h2458 : TreeTrue τ start2458 := replay_true τ ok2457 h2457
  have h2459 : TreeTrue τ start2459 := replay_true τ ok2458 h2458
  have h2460 : TreeTrue τ start2460 := replay_true τ ok2459 h2459
  have h2461 : TreeTrue τ start2461 := replay_true τ ok2460 h2460
  have h2462 : TreeTrue τ start2462 := replay_true τ ok2461 h2461
  have h2463 : TreeTrue τ start2463 := replay_true τ ok2462 h2462
  have h2464 : TreeTrue τ start2464 := cp_true τ ok2463 h2463
  exact h2464
#print axioms steps76
end Snake9.ReplayFull147
