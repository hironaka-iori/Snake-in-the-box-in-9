import ReplayCheck147_03872
import ReplayCheck147_03876
import ReplayCheck147_03880
import ReplayCheck147_03884
import ReplayCheck147_03888
import ReplayCheck147_03892
import ReplayCheck147_03896
import ReplayCheck147_03900
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps121 (τ : Nat → Bool) (h3872 : TreeTrue τ start3872) : TreeTrue τ start3904 := by
  have h3873 : TreeTrue τ start3873 := replay_true τ ok3872 h3872
  have h3874 : TreeTrue τ start3874 := replay_true τ ok3873 h3873
  have h3875 : TreeTrue τ start3875 := replay_true τ ok3874 h3874
  have h3876 : TreeTrue τ start3876 := replay_true τ ok3875 h3875
  have h3877 : TreeTrue τ start3877 := replay_true τ ok3876 h3876
  have h3878 : TreeTrue τ start3878 := replay_true τ ok3877 h3877
  have h3879 : TreeTrue τ start3879 := replay_true τ ok3878 h3878
  have h3880 : TreeTrue τ start3880 := replay_true τ ok3879 h3879
  have h3881 : TreeTrue τ start3881 := replay_true τ ok3880 h3880
  have h3882 : TreeTrue τ start3882 := replay_true τ ok3881 h3881
  have h3883 : TreeTrue τ start3883 := replay_true τ ok3882 h3882
  have h3884 : TreeTrue τ start3884 := replay_true τ ok3883 h3883
  have h3885 : TreeTrue τ start3885 := replay_true τ ok3884 h3884
  have h3886 : TreeTrue τ start3886 := replay_true τ ok3885 h3885
  have h3887 : TreeTrue τ start3887 := replay_true τ ok3886 h3886
  have h3888 : TreeTrue τ start3888 := replay_true τ ok3887 h3887
  have h3889 : TreeTrue τ start3889 := replay_true τ ok3888 h3888
  have h3890 : TreeTrue τ start3890 := replay_true τ ok3889 h3889
  have h3891 : TreeTrue τ start3891 := replay_true τ ok3890 h3890
  have h3892 : TreeTrue τ start3892 := replay_true τ ok3891 h3891
  have h3893 : TreeTrue τ start3893 := replay_true τ ok3892 h3892
  have h3894 : TreeTrue τ start3894 := replay_true τ ok3893 h3893
  have h3895 : TreeTrue τ start3895 := replay_true τ ok3894 h3894
  have h3896 : TreeTrue τ start3896 := replay_true τ ok3895 h3895
  have h3897 : TreeTrue τ start3897 := replay_true τ ok3896 h3896
  have h3898 : TreeTrue τ start3898 := replay_true τ ok3897 h3897
  have h3899 : TreeTrue τ start3899 := replay_true τ ok3898 h3898
  have h3900 : TreeTrue τ start3900 := replay_true τ ok3899 h3899
  have h3901 : TreeTrue τ start3901 := replay_true τ ok3900 h3900
  have h3902 : TreeTrue τ start3902 := replay_true τ ok3901 h3901
  have h3903 : TreeTrue τ start3903 := replay_true τ ok3902 h3902
  have h3904 : TreeTrue τ start3904 := cp_true τ ok3903 h3903
  exact h3904
#print axioms steps121
end Snake9.ReplayFull147
