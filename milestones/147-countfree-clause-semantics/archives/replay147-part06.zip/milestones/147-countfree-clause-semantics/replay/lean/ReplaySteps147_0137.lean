import ReplayCheck147_04384
import ReplayCheck147_04388
import ReplayCheck147_04392
import ReplayCheck147_04396
import ReplayCheck147_04400
import ReplayCheck147_04404
import ReplayCheck147_04408
import ReplayCheck147_04412
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps137 (τ : Nat → Bool) (h4384 : TreeTrue τ start4384) : TreeTrue τ start4416 := by
  have h4385 : TreeTrue τ start4385 := replay_true τ ok4384 h4384
  have h4386 : TreeTrue τ start4386 := replay_true τ ok4385 h4385
  have h4387 : TreeTrue τ start4387 := replay_true τ ok4386 h4386
  have h4388 : TreeTrue τ start4388 := replay_true τ ok4387 h4387
  have h4389 : TreeTrue τ start4389 := replay_true τ ok4388 h4388
  have h4390 : TreeTrue τ start4390 := replay_true τ ok4389 h4389
  have h4391 : TreeTrue τ start4391 := replay_true τ ok4390 h4390
  have h4392 : TreeTrue τ start4392 := replay_true τ ok4391 h4391
  have h4393 : TreeTrue τ start4393 := replay_true τ ok4392 h4392
  have h4394 : TreeTrue τ start4394 := replay_true τ ok4393 h4393
  have h4395 : TreeTrue τ start4395 := replay_true τ ok4394 h4394
  have h4396 : TreeTrue τ start4396 := replay_true τ ok4395 h4395
  have h4397 : TreeTrue τ start4397 := replay_true τ ok4396 h4396
  have h4398 : TreeTrue τ start4398 := replay_true τ ok4397 h4397
  have h4399 : TreeTrue τ start4399 := replay_true τ ok4398 h4398
  have h4400 : TreeTrue τ start4400 := replay_true τ ok4399 h4399
  have h4401 : TreeTrue τ start4401 := replay_true τ ok4400 h4400
  have h4402 : TreeTrue τ start4402 := replay_true τ ok4401 h4401
  have h4403 : TreeTrue τ start4403 := replay_true τ ok4402 h4402
  have h4404 : TreeTrue τ start4404 := replay_true τ ok4403 h4403
  have h4405 : TreeTrue τ start4405 := replay_true τ ok4404 h4404
  have h4406 : TreeTrue τ start4406 := replay_true τ ok4405 h4405
  have h4407 : TreeTrue τ start4407 := replay_true τ ok4406 h4406
  have h4408 : TreeTrue τ start4408 := replay_true τ ok4407 h4407
  have h4409 : TreeTrue τ start4409 := replay_true τ ok4408 h4408
  have h4410 : TreeTrue τ start4410 := replay_true τ ok4409 h4409
  have h4411 : TreeTrue τ start4411 := replay_true τ ok4410 h4410
  have h4412 : TreeTrue τ start4412 := replay_true τ ok4411 h4411
  have h4413 : TreeTrue τ start4413 := replay_true τ ok4412 h4412
  have h4414 : TreeTrue τ start4414 := replay_true τ ok4413 h4413
  have h4415 : TreeTrue τ start4415 := replay_true τ ok4414 h4414
  have h4416 : TreeTrue τ start4416 := cp_true τ ok4415 h4415
  exact h4416
#print axioms steps137
end Snake9.ReplayFull147
