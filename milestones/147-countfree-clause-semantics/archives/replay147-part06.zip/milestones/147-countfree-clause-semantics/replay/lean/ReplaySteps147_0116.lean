import ReplayCheck147_03712
import ReplayCheck147_03716
import ReplayCheck147_03720
import ReplayCheck147_03724
import ReplayCheck147_03728
import ReplayCheck147_03732
import ReplayCheck147_03736
import ReplayCheck147_03740
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps116 (τ : Nat → Bool) (h3712 : TreeTrue τ start3712) : TreeTrue τ start3744 := by
  have h3713 : TreeTrue τ start3713 := replay_true τ ok3712 h3712
  have h3714 : TreeTrue τ start3714 := replay_true τ ok3713 h3713
  have h3715 : TreeTrue τ start3715 := replay_true τ ok3714 h3714
  have h3716 : TreeTrue τ start3716 := replay_true τ ok3715 h3715
  have h3717 : TreeTrue τ start3717 := replay_true τ ok3716 h3716
  have h3718 : TreeTrue τ start3718 := replay_true τ ok3717 h3717
  have h3719 : TreeTrue τ start3719 := replay_true τ ok3718 h3718
  have h3720 : TreeTrue τ start3720 := replay_true τ ok3719 h3719
  have h3721 : TreeTrue τ start3721 := replay_true τ ok3720 h3720
  have h3722 : TreeTrue τ start3722 := replay_true τ ok3721 h3721
  have h3723 : TreeTrue τ start3723 := replay_true τ ok3722 h3722
  have h3724 : TreeTrue τ start3724 := replay_true τ ok3723 h3723
  have h3725 : TreeTrue τ start3725 := replay_true τ ok3724 h3724
  have h3726 : TreeTrue τ start3726 := replay_true τ ok3725 h3725
  have h3727 : TreeTrue τ start3727 := replay_true τ ok3726 h3726
  have h3728 : TreeTrue τ start3728 := replay_true τ ok3727 h3727
  have h3729 : TreeTrue τ start3729 := replay_true τ ok3728 h3728
  have h3730 : TreeTrue τ start3730 := replay_true τ ok3729 h3729
  have h3731 : TreeTrue τ start3731 := replay_true τ ok3730 h3730
  have h3732 : TreeTrue τ start3732 := replay_true τ ok3731 h3731
  have h3733 : TreeTrue τ start3733 := replay_true τ ok3732 h3732
  have h3734 : TreeTrue τ start3734 := replay_true τ ok3733 h3733
  have h3735 : TreeTrue τ start3735 := replay_true τ ok3734 h3734
  have h3736 : TreeTrue τ start3736 := replay_true τ ok3735 h3735
  have h3737 : TreeTrue τ start3737 := replay_true τ ok3736 h3736
  have h3738 : TreeTrue τ start3738 := replay_true τ ok3737 h3737
  have h3739 : TreeTrue τ start3739 := replay_true τ ok3738 h3738
  have h3740 : TreeTrue τ start3740 := replay_true τ ok3739 h3739
  have h3741 : TreeTrue τ start3741 := replay_true τ ok3740 h3740
  have h3742 : TreeTrue τ start3742 := replay_true τ ok3741 h3741
  have h3743 : TreeTrue τ start3743 := replay_true τ ok3742 h3742
  have h3744 : TreeTrue τ start3744 := cp_true τ ok3743 h3743
  exact h3744
#print axioms steps116
end Snake9.ReplayFull147
