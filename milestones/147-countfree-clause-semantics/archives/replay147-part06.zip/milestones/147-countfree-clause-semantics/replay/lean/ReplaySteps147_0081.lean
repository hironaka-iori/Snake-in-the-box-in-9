import ReplayCheck147_02592
import ReplayCheck147_02596
import ReplayCheck147_02600
import ReplayCheck147_02604
import ReplayCheck147_02608
import ReplayCheck147_02612
import ReplayCheck147_02616
import ReplayCheck147_02620
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps81 (τ : Nat → Bool) (h2592 : TreeTrue τ start2592) : TreeTrue τ start2624 := by
  have h2593 : TreeTrue τ start2593 := replay_true τ ok2592 h2592
  have h2594 : TreeTrue τ start2594 := replay_true τ ok2593 h2593
  have h2595 : TreeTrue τ start2595 := replay_true τ ok2594 h2594
  have h2596 : TreeTrue τ start2596 := replay_true τ ok2595 h2595
  have h2597 : TreeTrue τ start2597 := replay_true τ ok2596 h2596
  have h2598 : TreeTrue τ start2598 := replay_true τ ok2597 h2597
  have h2599 : TreeTrue τ start2599 := replay_true τ ok2598 h2598
  have h2600 : TreeTrue τ start2600 := replay_true τ ok2599 h2599
  have h2601 : TreeTrue τ start2601 := replay_true τ ok2600 h2600
  have h2602 : TreeTrue τ start2602 := replay_true τ ok2601 h2601
  have h2603 : TreeTrue τ start2603 := replay_true τ ok2602 h2602
  have h2604 : TreeTrue τ start2604 := replay_true τ ok2603 h2603
  have h2605 : TreeTrue τ start2605 := replay_true τ ok2604 h2604
  have h2606 : TreeTrue τ start2606 := replay_true τ ok2605 h2605
  have h2607 : TreeTrue τ start2607 := replay_true τ ok2606 h2606
  have h2608 : TreeTrue τ start2608 := replay_true τ ok2607 h2607
  have h2609 : TreeTrue τ start2609 := replay_true τ ok2608 h2608
  have h2610 : TreeTrue τ start2610 := replay_true τ ok2609 h2609
  have h2611 : TreeTrue τ start2611 := replay_true τ ok2610 h2610
  have h2612 : TreeTrue τ start2612 := replay_true τ ok2611 h2611
  have h2613 : TreeTrue τ start2613 := replay_true τ ok2612 h2612
  have h2614 : TreeTrue τ start2614 := replay_true τ ok2613 h2613
  have h2615 : TreeTrue τ start2615 := replay_true τ ok2614 h2614
  have h2616 : TreeTrue τ start2616 := replay_true τ ok2615 h2615
  have h2617 : TreeTrue τ start2617 := replay_true τ ok2616 h2616
  have h2618 : TreeTrue τ start2618 := replay_true τ ok2617 h2617
  have h2619 : TreeTrue τ start2619 := replay_true τ ok2618 h2618
  have h2620 : TreeTrue τ start2620 := replay_true τ ok2619 h2619
  have h2621 : TreeTrue τ start2621 := replay_true τ ok2620 h2620
  have h2622 : TreeTrue τ start2622 := replay_true τ ok2621 h2621
  have h2623 : TreeTrue τ start2623 := replay_true τ ok2622 h2622
  have h2624 : TreeTrue τ start2624 := cp_true τ ok2623 h2623
  exact h2624
#print axioms steps81
end Snake9.ReplayFull147
