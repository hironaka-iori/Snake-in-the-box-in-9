import ReplayCheck147_05024
import ReplayCheck147_05028
import ReplayCheck147_05032
import ReplayCheck147_05036
import ReplayCheck147_05040
import ReplayCheck147_05044
import ReplayCheck147_05048
import ReplayCheck147_05052
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps157 (τ : Nat → Bool) (h5024 : TreeTrue τ start5024) : TreeTrue τ start5056 := by
  have h5025 : TreeTrue τ start5025 := replay_true τ ok5024 h5024
  have h5026 : TreeTrue τ start5026 := replay_true τ ok5025 h5025
  have h5027 : TreeTrue τ start5027 := replay_true τ ok5026 h5026
  have h5028 : TreeTrue τ start5028 := replay_true τ ok5027 h5027
  have h5029 : TreeTrue τ start5029 := replay_true τ ok5028 h5028
  have h5030 : TreeTrue τ start5030 := replay_true τ ok5029 h5029
  have h5031 : TreeTrue τ start5031 := replay_true τ ok5030 h5030
  have h5032 : TreeTrue τ start5032 := replay_true τ ok5031 h5031
  have h5033 : TreeTrue τ start5033 := replay_true τ ok5032 h5032
  have h5034 : TreeTrue τ start5034 := replay_true τ ok5033 h5033
  have h5035 : TreeTrue τ start5035 := replay_true τ ok5034 h5034
  have h5036 : TreeTrue τ start5036 := replay_true τ ok5035 h5035
  have h5037 : TreeTrue τ start5037 := replay_true τ ok5036 h5036
  have h5038 : TreeTrue τ start5038 := replay_true τ ok5037 h5037
  have h5039 : TreeTrue τ start5039 := replay_true τ ok5038 h5038
  have h5040 : TreeTrue τ start5040 := replay_true τ ok5039 h5039
  have h5041 : TreeTrue τ start5041 := replay_true τ ok5040 h5040
  have h5042 : TreeTrue τ start5042 := replay_true τ ok5041 h5041
  have h5043 : TreeTrue τ start5043 := replay_true τ ok5042 h5042
  have h5044 : TreeTrue τ start5044 := replay_true τ ok5043 h5043
  have h5045 : TreeTrue τ start5045 := replay_true τ ok5044 h5044
  have h5046 : TreeTrue τ start5046 := replay_true τ ok5045 h5045
  have h5047 : TreeTrue τ start5047 := replay_true τ ok5046 h5046
  have h5048 : TreeTrue τ start5048 := replay_true τ ok5047 h5047
  have h5049 : TreeTrue τ start5049 := replay_true τ ok5048 h5048
  have h5050 : TreeTrue τ start5050 := replay_true τ ok5049 h5049
  have h5051 : TreeTrue τ start5051 := replay_true τ ok5050 h5050
  have h5052 : TreeTrue τ start5052 := replay_true τ ok5051 h5051
  have h5053 : TreeTrue τ start5053 := replay_true τ ok5052 h5052
  have h5054 : TreeTrue τ start5054 := replay_true τ ok5053 h5053
  have h5055 : TreeTrue τ start5055 := replay_true τ ok5054 h5054
  have h5056 : TreeTrue τ start5056 := cp_true τ ok5055 h5055
  exact h5056
#print axioms steps157
end Snake9.ReplayFull147
