import ReplayCheck147_04192
import ReplayCheck147_04196
import ReplayCheck147_04200
import ReplayCheck147_04204
import ReplayCheck147_04208
import ReplayCheck147_04212
import ReplayCheck147_04216
import ReplayCheck147_04220
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps131 (τ : Nat → Bool) (h4192 : TreeTrue τ start4192) : TreeTrue τ start4224 := by
  have h4193 : TreeTrue τ start4193 := replay_true τ ok4192 h4192
  have h4194 : TreeTrue τ start4194 := replay_true τ ok4193 h4193
  have h4195 : TreeTrue τ start4195 := replay_true τ ok4194 h4194
  have h4196 : TreeTrue τ start4196 := replay_true τ ok4195 h4195
  have h4197 : TreeTrue τ start4197 := replay_true τ ok4196 h4196
  have h4198 : TreeTrue τ start4198 := replay_true τ ok4197 h4197
  have h4199 : TreeTrue τ start4199 := replay_true τ ok4198 h4198
  have h4200 : TreeTrue τ start4200 := replay_true τ ok4199 h4199
  have h4201 : TreeTrue τ start4201 := replay_true τ ok4200 h4200
  have h4202 : TreeTrue τ start4202 := replay_true τ ok4201 h4201
  have h4203 : TreeTrue τ start4203 := replay_true τ ok4202 h4202
  have h4204 : TreeTrue τ start4204 := replay_true τ ok4203 h4203
  have h4205 : TreeTrue τ start4205 := replay_true τ ok4204 h4204
  have h4206 : TreeTrue τ start4206 := replay_true τ ok4205 h4205
  have h4207 : TreeTrue τ start4207 := replay_true τ ok4206 h4206
  have h4208 : TreeTrue τ start4208 := replay_true τ ok4207 h4207
  have h4209 : TreeTrue τ start4209 := replay_true τ ok4208 h4208
  have h4210 : TreeTrue τ start4210 := replay_true τ ok4209 h4209
  have h4211 : TreeTrue τ start4211 := replay_true τ ok4210 h4210
  have h4212 : TreeTrue τ start4212 := replay_true τ ok4211 h4211
  have h4213 : TreeTrue τ start4213 := replay_true τ ok4212 h4212
  have h4214 : TreeTrue τ start4214 := replay_true τ ok4213 h4213
  have h4215 : TreeTrue τ start4215 := replay_true τ ok4214 h4214
  have h4216 : TreeTrue τ start4216 := replay_true τ ok4215 h4215
  have h4217 : TreeTrue τ start4217 := replay_true τ ok4216 h4216
  have h4218 : TreeTrue τ start4218 := replay_true τ ok4217 h4217
  have h4219 : TreeTrue τ start4219 := replay_true τ ok4218 h4218
  have h4220 : TreeTrue τ start4220 := replay_true τ ok4219 h4219
  have h4221 : TreeTrue τ start4221 := replay_true τ ok4220 h4220
  have h4222 : TreeTrue τ start4222 := replay_true τ ok4221 h4221
  have h4223 : TreeTrue τ start4223 := replay_true τ ok4222 h4222
  have h4224 : TreeTrue τ start4224 := cp_true τ ok4223 h4223
  exact h4224
#print axioms steps131
end Snake9.ReplayFull147
