import ReplayCheck147_02624
import ReplayCheck147_02628
import ReplayCheck147_02632
import ReplayCheck147_02636
import ReplayCheck147_02640
import ReplayCheck147_02644
import ReplayCheck147_02648
import ReplayCheck147_02652
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps82 (τ : Nat → Bool) (h2624 : TreeTrue τ start2624) : TreeTrue τ start2656 := by
  have h2625 : TreeTrue τ start2625 := replay_true τ ok2624 h2624
  have h2626 : TreeTrue τ start2626 := replay_true τ ok2625 h2625
  have h2627 : TreeTrue τ start2627 := replay_true τ ok2626 h2626
  have h2628 : TreeTrue τ start2628 := replay_true τ ok2627 h2627
  have h2629 : TreeTrue τ start2629 := replay_true τ ok2628 h2628
  have h2630 : TreeTrue τ start2630 := replay_true τ ok2629 h2629
  have h2631 : TreeTrue τ start2631 := replay_true τ ok2630 h2630
  have h2632 : TreeTrue τ start2632 := replay_true τ ok2631 h2631
  have h2633 : TreeTrue τ start2633 := replay_true τ ok2632 h2632
  have h2634 : TreeTrue τ start2634 := replay_true τ ok2633 h2633
  have h2635 : TreeTrue τ start2635 := replay_true τ ok2634 h2634
  have h2636 : TreeTrue τ start2636 := replay_true τ ok2635 h2635
  have h2637 : TreeTrue τ start2637 := replay_true τ ok2636 h2636
  have h2638 : TreeTrue τ start2638 := replay_true τ ok2637 h2637
  have h2639 : TreeTrue τ start2639 := replay_true τ ok2638 h2638
  have h2640 : TreeTrue τ start2640 := replay_true τ ok2639 h2639
  have h2641 : TreeTrue τ start2641 := replay_true τ ok2640 h2640
  have h2642 : TreeTrue τ start2642 := replay_true τ ok2641 h2641
  have h2643 : TreeTrue τ start2643 := replay_true τ ok2642 h2642
  have h2644 : TreeTrue τ start2644 := replay_true τ ok2643 h2643
  have h2645 : TreeTrue τ start2645 := replay_true τ ok2644 h2644
  have h2646 : TreeTrue τ start2646 := replay_true τ ok2645 h2645
  have h2647 : TreeTrue τ start2647 := replay_true τ ok2646 h2646
  have h2648 : TreeTrue τ start2648 := replay_true τ ok2647 h2647
  have h2649 : TreeTrue τ start2649 := replay_true τ ok2648 h2648
  have h2650 : TreeTrue τ start2650 := replay_true τ ok2649 h2649
  have h2651 : TreeTrue τ start2651 := replay_true τ ok2650 h2650
  have h2652 : TreeTrue τ start2652 := replay_true τ ok2651 h2651
  have h2653 : TreeTrue τ start2653 := replay_true τ ok2652 h2652
  have h2654 : TreeTrue τ start2654 := replay_true τ ok2653 h2653
  have h2655 : TreeTrue τ start2655 := replay_true τ ok2654 h2654
  have h2656 : TreeTrue τ start2656 := cp_true τ ok2655 h2655
  exact h2656
#print axioms steps82
end Snake9.ReplayFull147
