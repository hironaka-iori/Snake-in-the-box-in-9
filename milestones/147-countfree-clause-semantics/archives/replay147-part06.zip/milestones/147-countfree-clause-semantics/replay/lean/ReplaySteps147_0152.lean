import ReplayCheck147_04864
import ReplayCheck147_04868
import ReplayCheck147_04872
import ReplayCheck147_04876
import ReplayCheck147_04880
import ReplayCheck147_04884
import ReplayCheck147_04888
import ReplayCheck147_04892
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps152 (τ : Nat → Bool) (h4864 : TreeTrue τ start4864) : TreeTrue τ start4896 := by
  have h4865 : TreeTrue τ start4865 := replay_true τ ok4864 h4864
  have h4866 : TreeTrue τ start4866 := replay_true τ ok4865 h4865
  have h4867 : TreeTrue τ start4867 := replay_true τ ok4866 h4866
  have h4868 : TreeTrue τ start4868 := replay_true τ ok4867 h4867
  have h4869 : TreeTrue τ start4869 := replay_true τ ok4868 h4868
  have h4870 : TreeTrue τ start4870 := replay_true τ ok4869 h4869
  have h4871 : TreeTrue τ start4871 := replay_true τ ok4870 h4870
  have h4872 : TreeTrue τ start4872 := replay_true τ ok4871 h4871
  have h4873 : TreeTrue τ start4873 := replay_true τ ok4872 h4872
  have h4874 : TreeTrue τ start4874 := replay_true τ ok4873 h4873
  have h4875 : TreeTrue τ start4875 := replay_true τ ok4874 h4874
  have h4876 : TreeTrue τ start4876 := replay_true τ ok4875 h4875
  have h4877 : TreeTrue τ start4877 := replay_true τ ok4876 h4876
  have h4878 : TreeTrue τ start4878 := replay_true τ ok4877 h4877
  have h4879 : TreeTrue τ start4879 := replay_true τ ok4878 h4878
  have h4880 : TreeTrue τ start4880 := replay_true τ ok4879 h4879
  have h4881 : TreeTrue τ start4881 := replay_true τ ok4880 h4880
  have h4882 : TreeTrue τ start4882 := replay_true τ ok4881 h4881
  have h4883 : TreeTrue τ start4883 := replay_true τ ok4882 h4882
  have h4884 : TreeTrue τ start4884 := replay_true τ ok4883 h4883
  have h4885 : TreeTrue τ start4885 := replay_true τ ok4884 h4884
  have h4886 : TreeTrue τ start4886 := replay_true τ ok4885 h4885
  have h4887 : TreeTrue τ start4887 := replay_true τ ok4886 h4886
  have h4888 : TreeTrue τ start4888 := replay_true τ ok4887 h4887
  have h4889 : TreeTrue τ start4889 := replay_true τ ok4888 h4888
  have h4890 : TreeTrue τ start4890 := replay_true τ ok4889 h4889
  have h4891 : TreeTrue τ start4891 := replay_true τ ok4890 h4890
  have h4892 : TreeTrue τ start4892 := replay_true τ ok4891 h4891
  have h4893 : TreeTrue τ start4893 := replay_true τ ok4892 h4892
  have h4894 : TreeTrue τ start4894 := replay_true τ ok4893 h4893
  have h4895 : TreeTrue τ start4895 := replay_true τ ok4894 h4894
  have h4896 : TreeTrue τ start4896 := cp_true τ ok4895 h4895
  exact h4896
#print axioms steps152
end Snake9.ReplayFull147
