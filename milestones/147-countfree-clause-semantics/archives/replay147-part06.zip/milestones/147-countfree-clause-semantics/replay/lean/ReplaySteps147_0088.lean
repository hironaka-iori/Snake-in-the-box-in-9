import ReplayCheck147_02816
import ReplayCheck147_02820
import ReplayCheck147_02824
import ReplayCheck147_02828
import ReplayCheck147_02832
import ReplayCheck147_02836
import ReplayCheck147_02840
import ReplayCheck147_02844
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps88 (τ : Nat → Bool) (h2816 : TreeTrue τ start2816) : TreeTrue τ start2848 := by
  have h2817 : TreeTrue τ start2817 := replay_true τ ok2816 h2816
  have h2818 : TreeTrue τ start2818 := replay_true τ ok2817 h2817
  have h2819 : TreeTrue τ start2819 := replay_true τ ok2818 h2818
  have h2820 : TreeTrue τ start2820 := replay_true τ ok2819 h2819
  have h2821 : TreeTrue τ start2821 := replay_true τ ok2820 h2820
  have h2822 : TreeTrue τ start2822 := replay_true τ ok2821 h2821
  have h2823 : TreeTrue τ start2823 := replay_true τ ok2822 h2822
  have h2824 : TreeTrue τ start2824 := replay_true τ ok2823 h2823
  have h2825 : TreeTrue τ start2825 := replay_true τ ok2824 h2824
  have h2826 : TreeTrue τ start2826 := replay_true τ ok2825 h2825
  have h2827 : TreeTrue τ start2827 := replay_true τ ok2826 h2826
  have h2828 : TreeTrue τ start2828 := replay_true τ ok2827 h2827
  have h2829 : TreeTrue τ start2829 := replay_true τ ok2828 h2828
  have h2830 : TreeTrue τ start2830 := replay_true τ ok2829 h2829
  have h2831 : TreeTrue τ start2831 := replay_true τ ok2830 h2830
  have h2832 : TreeTrue τ start2832 := replay_true τ ok2831 h2831
  have h2833 : TreeTrue τ start2833 := replay_true τ ok2832 h2832
  have h2834 : TreeTrue τ start2834 := replay_true τ ok2833 h2833
  have h2835 : TreeTrue τ start2835 := replay_true τ ok2834 h2834
  have h2836 : TreeTrue τ start2836 := replay_true τ ok2835 h2835
  have h2837 : TreeTrue τ start2837 := replay_true τ ok2836 h2836
  have h2838 : TreeTrue τ start2838 := replay_true τ ok2837 h2837
  have h2839 : TreeTrue τ start2839 := replay_true τ ok2838 h2838
  have h2840 : TreeTrue τ start2840 := replay_true τ ok2839 h2839
  have h2841 : TreeTrue τ start2841 := replay_true τ ok2840 h2840
  have h2842 : TreeTrue τ start2842 := replay_true τ ok2841 h2841
  have h2843 : TreeTrue τ start2843 := replay_true τ ok2842 h2842
  have h2844 : TreeTrue τ start2844 := replay_true τ ok2843 h2843
  have h2845 : TreeTrue τ start2845 := replay_true τ ok2844 h2844
  have h2846 : TreeTrue τ start2846 := replay_true τ ok2845 h2845
  have h2847 : TreeTrue τ start2847 := replay_true τ ok2846 h2846
  have h2848 : TreeTrue τ start2848 := cp_true τ ok2847 h2847
  exact h2848
#print axioms steps88
end Snake9.ReplayFull147
