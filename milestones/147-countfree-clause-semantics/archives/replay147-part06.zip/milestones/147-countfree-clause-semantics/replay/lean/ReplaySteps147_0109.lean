import ReplayCheck147_03488
import ReplayCheck147_03492
import ReplayCheck147_03496
import ReplayCheck147_03500
import ReplayCheck147_03504
import ReplayCheck147_03508
import ReplayCheck147_03512
import ReplayCheck147_03516
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps109 (τ : Nat → Bool) (h3488 : TreeTrue τ start3488) : TreeTrue τ start3520 := by
  have h3489 : TreeTrue τ start3489 := replay_true τ ok3488 h3488
  have h3490 : TreeTrue τ start3490 := replay_true τ ok3489 h3489
  have h3491 : TreeTrue τ start3491 := replay_true τ ok3490 h3490
  have h3492 : TreeTrue τ start3492 := replay_true τ ok3491 h3491
  have h3493 : TreeTrue τ start3493 := replay_true τ ok3492 h3492
  have h3494 : TreeTrue τ start3494 := replay_true τ ok3493 h3493
  have h3495 : TreeTrue τ start3495 := replay_true τ ok3494 h3494
  have h3496 : TreeTrue τ start3496 := replay_true τ ok3495 h3495
  have h3497 : TreeTrue τ start3497 := replay_true τ ok3496 h3496
  have h3498 : TreeTrue τ start3498 := replay_true τ ok3497 h3497
  have h3499 : TreeTrue τ start3499 := replay_true τ ok3498 h3498
  have h3500 : TreeTrue τ start3500 := replay_true τ ok3499 h3499
  have h3501 : TreeTrue τ start3501 := replay_true τ ok3500 h3500
  have h3502 : TreeTrue τ start3502 := replay_true τ ok3501 h3501
  have h3503 : TreeTrue τ start3503 := replay_true τ ok3502 h3502
  have h3504 : TreeTrue τ start3504 := replay_true τ ok3503 h3503
  have h3505 : TreeTrue τ start3505 := replay_true τ ok3504 h3504
  have h3506 : TreeTrue τ start3506 := replay_true τ ok3505 h3505
  have h3507 : TreeTrue τ start3507 := replay_true τ ok3506 h3506
  have h3508 : TreeTrue τ start3508 := replay_true τ ok3507 h3507
  have h3509 : TreeTrue τ start3509 := replay_true τ ok3508 h3508
  have h3510 : TreeTrue τ start3510 := replay_true τ ok3509 h3509
  have h3511 : TreeTrue τ start3511 := replay_true τ ok3510 h3510
  have h3512 : TreeTrue τ start3512 := replay_true τ ok3511 h3511
  have h3513 : TreeTrue τ start3513 := replay_true τ ok3512 h3512
  have h3514 : TreeTrue τ start3514 := replay_true τ ok3513 h3513
  have h3515 : TreeTrue τ start3515 := replay_true τ ok3514 h3514
  have h3516 : TreeTrue τ start3516 := replay_true τ ok3515 h3515
  have h3517 : TreeTrue τ start3517 := replay_true τ ok3516 h3516
  have h3518 : TreeTrue τ start3518 := replay_true τ ok3517 h3517
  have h3519 : TreeTrue τ start3519 := replay_true τ ok3518 h3518
  have h3520 : TreeTrue τ start3520 := cp_true τ ok3519 h3519
  exact h3520
#print axioms steps109
end Snake9.ReplayFull147
