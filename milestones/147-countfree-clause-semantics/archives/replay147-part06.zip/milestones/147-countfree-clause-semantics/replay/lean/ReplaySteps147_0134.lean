import ReplayCheck147_04288
import ReplayCheck147_04292
import ReplayCheck147_04296
import ReplayCheck147_04300
import ReplayCheck147_04304
import ReplayCheck147_04308
import ReplayCheck147_04312
import ReplayCheck147_04316
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps134 (τ : Nat → Bool) (h4288 : TreeTrue τ start4288) : TreeTrue τ start4320 := by
  have h4289 : TreeTrue τ start4289 := replay_true τ ok4288 h4288
  have h4290 : TreeTrue τ start4290 := replay_true τ ok4289 h4289
  have h4291 : TreeTrue τ start4291 := replay_true τ ok4290 h4290
  have h4292 : TreeTrue τ start4292 := replay_true τ ok4291 h4291
  have h4293 : TreeTrue τ start4293 := replay_true τ ok4292 h4292
  have h4294 : TreeTrue τ start4294 := replay_true τ ok4293 h4293
  have h4295 : TreeTrue τ start4295 := replay_true τ ok4294 h4294
  have h4296 : TreeTrue τ start4296 := replay_true τ ok4295 h4295
  have h4297 : TreeTrue τ start4297 := replay_true τ ok4296 h4296
  have h4298 : TreeTrue τ start4298 := replay_true τ ok4297 h4297
  have h4299 : TreeTrue τ start4299 := replay_true τ ok4298 h4298
  have h4300 : TreeTrue τ start4300 := replay_true τ ok4299 h4299
  have h4301 : TreeTrue τ start4301 := replay_true τ ok4300 h4300
  have h4302 : TreeTrue τ start4302 := replay_true τ ok4301 h4301
  have h4303 : TreeTrue τ start4303 := replay_true τ ok4302 h4302
  have h4304 : TreeTrue τ start4304 := replay_true τ ok4303 h4303
  have h4305 : TreeTrue τ start4305 := replay_true τ ok4304 h4304
  have h4306 : TreeTrue τ start4306 := replay_true τ ok4305 h4305
  have h4307 : TreeTrue τ start4307 := replay_true τ ok4306 h4306
  have h4308 : TreeTrue τ start4308 := replay_true τ ok4307 h4307
  have h4309 : TreeTrue τ start4309 := replay_true τ ok4308 h4308
  have h4310 : TreeTrue τ start4310 := replay_true τ ok4309 h4309
  have h4311 : TreeTrue τ start4311 := replay_true τ ok4310 h4310
  have h4312 : TreeTrue τ start4312 := replay_true τ ok4311 h4311
  have h4313 : TreeTrue τ start4313 := replay_true τ ok4312 h4312
  have h4314 : TreeTrue τ start4314 := replay_true τ ok4313 h4313
  have h4315 : TreeTrue τ start4315 := replay_true τ ok4314 h4314
  have h4316 : TreeTrue τ start4316 := replay_true τ ok4315 h4315
  have h4317 : TreeTrue τ start4317 := replay_true τ ok4316 h4316
  have h4318 : TreeTrue τ start4318 := replay_true τ ok4317 h4317
  have h4319 : TreeTrue τ start4319 := replay_true τ ok4318 h4318
  have h4320 : TreeTrue τ start4320 := cp_true τ ok4319 h4319
  exact h4320
#print axioms steps134
end Snake9.ReplayFull147
