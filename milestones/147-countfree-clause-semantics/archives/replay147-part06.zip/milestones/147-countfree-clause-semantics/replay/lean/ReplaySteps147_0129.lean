import ReplayCheck147_04128
import ReplayCheck147_04132
import ReplayCheck147_04136
import ReplayCheck147_04140
import ReplayCheck147_04144
import ReplayCheck147_04148
import ReplayCheck147_04152
import ReplayCheck147_04156
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps129 (τ : Nat → Bool) (h4128 : TreeTrue τ start4128) : TreeTrue τ start4160 := by
  have h4129 : TreeTrue τ start4129 := replay_true τ ok4128 h4128
  have h4130 : TreeTrue τ start4130 := replay_true τ ok4129 h4129
  have h4131 : TreeTrue τ start4131 := replay_true τ ok4130 h4130
  have h4132 : TreeTrue τ start4132 := replay_true τ ok4131 h4131
  have h4133 : TreeTrue τ start4133 := replay_true τ ok4132 h4132
  have h4134 : TreeTrue τ start4134 := replay_true τ ok4133 h4133
  have h4135 : TreeTrue τ start4135 := replay_true τ ok4134 h4134
  have h4136 : TreeTrue τ start4136 := replay_true τ ok4135 h4135
  have h4137 : TreeTrue τ start4137 := replay_true τ ok4136 h4136
  have h4138 : TreeTrue τ start4138 := replay_true τ ok4137 h4137
  have h4139 : TreeTrue τ start4139 := replay_true τ ok4138 h4138
  have h4140 : TreeTrue τ start4140 := replay_true τ ok4139 h4139
  have h4141 : TreeTrue τ start4141 := replay_true τ ok4140 h4140
  have h4142 : TreeTrue τ start4142 := replay_true τ ok4141 h4141
  have h4143 : TreeTrue τ start4143 := replay_true τ ok4142 h4142
  have h4144 : TreeTrue τ start4144 := replay_true τ ok4143 h4143
  have h4145 : TreeTrue τ start4145 := replay_true τ ok4144 h4144
  have h4146 : TreeTrue τ start4146 := replay_true τ ok4145 h4145
  have h4147 : TreeTrue τ start4147 := replay_true τ ok4146 h4146
  have h4148 : TreeTrue τ start4148 := replay_true τ ok4147 h4147
  have h4149 : TreeTrue τ start4149 := replay_true τ ok4148 h4148
  have h4150 : TreeTrue τ start4150 := replay_true τ ok4149 h4149
  have h4151 : TreeTrue τ start4151 := replay_true τ ok4150 h4150
  have h4152 : TreeTrue τ start4152 := replay_true τ ok4151 h4151
  have h4153 : TreeTrue τ start4153 := replay_true τ ok4152 h4152
  have h4154 : TreeTrue τ start4154 := replay_true τ ok4153 h4153
  have h4155 : TreeTrue τ start4155 := replay_true τ ok4154 h4154
  have h4156 : TreeTrue τ start4156 := replay_true τ ok4155 h4155
  have h4157 : TreeTrue τ start4157 := replay_true τ ok4156 h4156
  have h4158 : TreeTrue τ start4158 := replay_true τ ok4157 h4157
  have h4159 : TreeTrue τ start4159 := replay_true τ ok4158 h4158
  have h4160 : TreeTrue τ start4160 := cp_true τ ok4159 h4159
  exact h4160
#print axioms steps129
end Snake9.ReplayFull147
