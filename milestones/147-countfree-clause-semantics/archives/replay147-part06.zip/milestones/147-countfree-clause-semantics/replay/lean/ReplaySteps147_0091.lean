import ReplayCheck147_02912
import ReplayCheck147_02916
import ReplayCheck147_02920
import ReplayCheck147_02924
import ReplayCheck147_02928
import ReplayCheck147_02932
import ReplayCheck147_02936
import ReplayCheck147_02940
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps91 (τ : Nat → Bool) (h2912 : TreeTrue τ start2912) : TreeTrue τ start2944 := by
  have h2913 : TreeTrue τ start2913 := replay_true τ ok2912 h2912
  have h2914 : TreeTrue τ start2914 := replay_true τ ok2913 h2913
  have h2915 : TreeTrue τ start2915 := replay_true τ ok2914 h2914
  have h2916 : TreeTrue τ start2916 := replay_true τ ok2915 h2915
  have h2917 : TreeTrue τ start2917 := replay_true τ ok2916 h2916
  have h2918 : TreeTrue τ start2918 := replay_true τ ok2917 h2917
  have h2919 : TreeTrue τ start2919 := replay_true τ ok2918 h2918
  have h2920 : TreeTrue τ start2920 := replay_true τ ok2919 h2919
  have h2921 : TreeTrue τ start2921 := replay_true τ ok2920 h2920
  have h2922 : TreeTrue τ start2922 := replay_true τ ok2921 h2921
  have h2923 : TreeTrue τ start2923 := replay_true τ ok2922 h2922
  have h2924 : TreeTrue τ start2924 := replay_true τ ok2923 h2923
  have h2925 : TreeTrue τ start2925 := replay_true τ ok2924 h2924
  have h2926 : TreeTrue τ start2926 := replay_true τ ok2925 h2925
  have h2927 : TreeTrue τ start2927 := replay_true τ ok2926 h2926
  have h2928 : TreeTrue τ start2928 := replay_true τ ok2927 h2927
  have h2929 : TreeTrue τ start2929 := replay_true τ ok2928 h2928
  have h2930 : TreeTrue τ start2930 := replay_true τ ok2929 h2929
  have h2931 : TreeTrue τ start2931 := replay_true τ ok2930 h2930
  have h2932 : TreeTrue τ start2932 := replay_true τ ok2931 h2931
  have h2933 : TreeTrue τ start2933 := replay_true τ ok2932 h2932
  have h2934 : TreeTrue τ start2934 := replay_true τ ok2933 h2933
  have h2935 : TreeTrue τ start2935 := replay_true τ ok2934 h2934
  have h2936 : TreeTrue τ start2936 := replay_true τ ok2935 h2935
  have h2937 : TreeTrue τ start2937 := replay_true τ ok2936 h2936
  have h2938 : TreeTrue τ start2938 := replay_true τ ok2937 h2937
  have h2939 : TreeTrue τ start2939 := replay_true τ ok2938 h2938
  have h2940 : TreeTrue τ start2940 := replay_true τ ok2939 h2939
  have h2941 : TreeTrue τ start2941 := replay_true τ ok2940 h2940
  have h2942 : TreeTrue τ start2942 := replay_true τ ok2941 h2941
  have h2943 : TreeTrue τ start2943 := replay_true τ ok2942 h2942
  have h2944 : TreeTrue τ start2944 := cp_true τ ok2943 h2943
  exact h2944
#print axioms steps91
end Snake9.ReplayFull147
