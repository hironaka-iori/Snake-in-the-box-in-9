import ReplayCheck147_03520
import ReplayCheck147_03524
import ReplayCheck147_03528
import ReplayCheck147_03532
import ReplayCheck147_03536
import ReplayCheck147_03540
import ReplayCheck147_03544
import ReplayCheck147_03548
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps110 (τ : Nat → Bool) (h3520 : TreeTrue τ start3520) : TreeTrue τ start3552 := by
  have h3521 : TreeTrue τ start3521 := replay_true τ ok3520 h3520
  have h3522 : TreeTrue τ start3522 := replay_true τ ok3521 h3521
  have h3523 : TreeTrue τ start3523 := replay_true τ ok3522 h3522
  have h3524 : TreeTrue τ start3524 := replay_true τ ok3523 h3523
  have h3525 : TreeTrue τ start3525 := replay_true τ ok3524 h3524
  have h3526 : TreeTrue τ start3526 := replay_true τ ok3525 h3525
  have h3527 : TreeTrue τ start3527 := replay_true τ ok3526 h3526
  have h3528 : TreeTrue τ start3528 := replay_true τ ok3527 h3527
  have h3529 : TreeTrue τ start3529 := replay_true τ ok3528 h3528
  have h3530 : TreeTrue τ start3530 := replay_true τ ok3529 h3529
  have h3531 : TreeTrue τ start3531 := replay_true τ ok3530 h3530
  have h3532 : TreeTrue τ start3532 := replay_true τ ok3531 h3531
  have h3533 : TreeTrue τ start3533 := replay_true τ ok3532 h3532
  have h3534 : TreeTrue τ start3534 := replay_true τ ok3533 h3533
  have h3535 : TreeTrue τ start3535 := replay_true τ ok3534 h3534
  have h3536 : TreeTrue τ start3536 := replay_true τ ok3535 h3535
  have h3537 : TreeTrue τ start3537 := replay_true τ ok3536 h3536
  have h3538 : TreeTrue τ start3538 := replay_true τ ok3537 h3537
  have h3539 : TreeTrue τ start3539 := replay_true τ ok3538 h3538
  have h3540 : TreeTrue τ start3540 := replay_true τ ok3539 h3539
  have h3541 : TreeTrue τ start3541 := replay_true τ ok3540 h3540
  have h3542 : TreeTrue τ start3542 := replay_true τ ok3541 h3541
  have h3543 : TreeTrue τ start3543 := replay_true τ ok3542 h3542
  have h3544 : TreeTrue τ start3544 := replay_true τ ok3543 h3543
  have h3545 : TreeTrue τ start3545 := replay_true τ ok3544 h3544
  have h3546 : TreeTrue τ start3546 := replay_true τ ok3545 h3545
  have h3547 : TreeTrue τ start3547 := replay_true τ ok3546 h3546
  have h3548 : TreeTrue τ start3548 := replay_true τ ok3547 h3547
  have h3549 : TreeTrue τ start3549 := replay_true τ ok3548 h3548
  have h3550 : TreeTrue τ start3550 := replay_true τ ok3549 h3549
  have h3551 : TreeTrue τ start3551 := replay_true τ ok3550 h3550
  have h3552 : TreeTrue τ start3552 := cp_true τ ok3551 h3551
  exact h3552
#print axioms steps110
end Snake9.ReplayFull147
