import ReplayCheck147_04800
import ReplayCheck147_04804
import ReplayCheck147_04808
import ReplayCheck147_04812
import ReplayCheck147_04816
import ReplayCheck147_04820
import ReplayCheck147_04824
import ReplayCheck147_04828
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps150 (τ : Nat → Bool) (h4800 : TreeTrue τ start4800) : TreeTrue τ start4832 := by
  have h4801 : TreeTrue τ start4801 := replay_true τ ok4800 h4800
  have h4802 : TreeTrue τ start4802 := replay_true τ ok4801 h4801
  have h4803 : TreeTrue τ start4803 := replay_true τ ok4802 h4802
  have h4804 : TreeTrue τ start4804 := replay_true τ ok4803 h4803
  have h4805 : TreeTrue τ start4805 := replay_true τ ok4804 h4804
  have h4806 : TreeTrue τ start4806 := replay_true τ ok4805 h4805
  have h4807 : TreeTrue τ start4807 := replay_true τ ok4806 h4806
  have h4808 : TreeTrue τ start4808 := replay_true τ ok4807 h4807
  have h4809 : TreeTrue τ start4809 := replay_true τ ok4808 h4808
  have h4810 : TreeTrue τ start4810 := replay_true τ ok4809 h4809
  have h4811 : TreeTrue τ start4811 := replay_true τ ok4810 h4810
  have h4812 : TreeTrue τ start4812 := replay_true τ ok4811 h4811
  have h4813 : TreeTrue τ start4813 := replay_true τ ok4812 h4812
  have h4814 : TreeTrue τ start4814 := replay_true τ ok4813 h4813
  have h4815 : TreeTrue τ start4815 := replay_true τ ok4814 h4814
  have h4816 : TreeTrue τ start4816 := replay_true τ ok4815 h4815
  have h4817 : TreeTrue τ start4817 := replay_true τ ok4816 h4816
  have h4818 : TreeTrue τ start4818 := replay_true τ ok4817 h4817
  have h4819 : TreeTrue τ start4819 := replay_true τ ok4818 h4818
  have h4820 : TreeTrue τ start4820 := replay_true τ ok4819 h4819
  have h4821 : TreeTrue τ start4821 := replay_true τ ok4820 h4820
  have h4822 : TreeTrue τ start4822 := replay_true τ ok4821 h4821
  have h4823 : TreeTrue τ start4823 := replay_true τ ok4822 h4822
  have h4824 : TreeTrue τ start4824 := replay_true τ ok4823 h4823
  have h4825 : TreeTrue τ start4825 := replay_true τ ok4824 h4824
  have h4826 : TreeTrue τ start4826 := replay_true τ ok4825 h4825
  have h4827 : TreeTrue τ start4827 := replay_true τ ok4826 h4826
  have h4828 : TreeTrue τ start4828 := replay_true τ ok4827 h4827
  have h4829 : TreeTrue τ start4829 := replay_true τ ok4828 h4828
  have h4830 : TreeTrue τ start4830 := replay_true τ ok4829 h4829
  have h4831 : TreeTrue τ start4831 := replay_true τ ok4830 h4830
  have h4832 : TreeTrue τ start4832 := cp_true τ ok4831 h4831
  exact h4832
#print axioms steps150
end Snake9.ReplayFull147
