import ReplayCheck147_02944
import ReplayCheck147_02948
import ReplayCheck147_02952
import ReplayCheck147_02956
import ReplayCheck147_02960
import ReplayCheck147_02964
import ReplayCheck147_02968
import ReplayCheck147_02972
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps92 (τ : Nat → Bool) (h2944 : TreeTrue τ start2944) : TreeTrue τ start2976 := by
  have h2945 : TreeTrue τ start2945 := replay_true τ ok2944 h2944
  have h2946 : TreeTrue τ start2946 := replay_true τ ok2945 h2945
  have h2947 : TreeTrue τ start2947 := replay_true τ ok2946 h2946
  have h2948 : TreeTrue τ start2948 := replay_true τ ok2947 h2947
  have h2949 : TreeTrue τ start2949 := replay_true τ ok2948 h2948
  have h2950 : TreeTrue τ start2950 := replay_true τ ok2949 h2949
  have h2951 : TreeTrue τ start2951 := replay_true τ ok2950 h2950
  have h2952 : TreeTrue τ start2952 := replay_true τ ok2951 h2951
  have h2953 : TreeTrue τ start2953 := replay_true τ ok2952 h2952
  have h2954 : TreeTrue τ start2954 := replay_true τ ok2953 h2953
  have h2955 : TreeTrue τ start2955 := replay_true τ ok2954 h2954
  have h2956 : TreeTrue τ start2956 := replay_true τ ok2955 h2955
  have h2957 : TreeTrue τ start2957 := replay_true τ ok2956 h2956
  have h2958 : TreeTrue τ start2958 := replay_true τ ok2957 h2957
  have h2959 : TreeTrue τ start2959 := replay_true τ ok2958 h2958
  have h2960 : TreeTrue τ start2960 := replay_true τ ok2959 h2959
  have h2961 : TreeTrue τ start2961 := replay_true τ ok2960 h2960
  have h2962 : TreeTrue τ start2962 := replay_true τ ok2961 h2961
  have h2963 : TreeTrue τ start2963 := replay_true τ ok2962 h2962
  have h2964 : TreeTrue τ start2964 := replay_true τ ok2963 h2963
  have h2965 : TreeTrue τ start2965 := replay_true τ ok2964 h2964
  have h2966 : TreeTrue τ start2966 := replay_true τ ok2965 h2965
  have h2967 : TreeTrue τ start2967 := replay_true τ ok2966 h2966
  have h2968 : TreeTrue τ start2968 := replay_true τ ok2967 h2967
  have h2969 : TreeTrue τ start2969 := replay_true τ ok2968 h2968
  have h2970 : TreeTrue τ start2970 := replay_true τ ok2969 h2969
  have h2971 : TreeTrue τ start2971 := replay_true τ ok2970 h2970
  have h2972 : TreeTrue τ start2972 := replay_true τ ok2971 h2971
  have h2973 : TreeTrue τ start2973 := replay_true τ ok2972 h2972
  have h2974 : TreeTrue τ start2974 := replay_true τ ok2973 h2973
  have h2975 : TreeTrue τ start2975 := replay_true τ ok2974 h2974
  have h2976 : TreeTrue τ start2976 := cp_true τ ok2975 h2975
  exact h2976
#print axioms steps92
end Snake9.ReplayFull147
