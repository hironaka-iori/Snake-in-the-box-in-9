import ReplayCheck147_03840
import ReplayCheck147_03844
import ReplayCheck147_03848
import ReplayCheck147_03852
import ReplayCheck147_03856
import ReplayCheck147_03860
import ReplayCheck147_03864
import ReplayCheck147_03868
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps120 (τ : Nat → Bool) (h3840 : TreeTrue τ start3840) : TreeTrue τ start3872 := by
  have h3841 : TreeTrue τ start3841 := replay_true τ ok3840 h3840
  have h3842 : TreeTrue τ start3842 := replay_true τ ok3841 h3841
  have h3843 : TreeTrue τ start3843 := replay_true τ ok3842 h3842
  have h3844 : TreeTrue τ start3844 := replay_true τ ok3843 h3843
  have h3845 : TreeTrue τ start3845 := replay_true τ ok3844 h3844
  have h3846 : TreeTrue τ start3846 := replay_true τ ok3845 h3845
  have h3847 : TreeTrue τ start3847 := replay_true τ ok3846 h3846
  have h3848 : TreeTrue τ start3848 := replay_true τ ok3847 h3847
  have h3849 : TreeTrue τ start3849 := replay_true τ ok3848 h3848
  have h3850 : TreeTrue τ start3850 := replay_true τ ok3849 h3849
  have h3851 : TreeTrue τ start3851 := replay_true τ ok3850 h3850
  have h3852 : TreeTrue τ start3852 := replay_true τ ok3851 h3851
  have h3853 : TreeTrue τ start3853 := replay_true τ ok3852 h3852
  have h3854 : TreeTrue τ start3854 := replay_true τ ok3853 h3853
  have h3855 : TreeTrue τ start3855 := replay_true τ ok3854 h3854
  have h3856 : TreeTrue τ start3856 := replay_true τ ok3855 h3855
  have h3857 : TreeTrue τ start3857 := replay_true τ ok3856 h3856
  have h3858 : TreeTrue τ start3858 := replay_true τ ok3857 h3857
  have h3859 : TreeTrue τ start3859 := replay_true τ ok3858 h3858
  have h3860 : TreeTrue τ start3860 := replay_true τ ok3859 h3859
  have h3861 : TreeTrue τ start3861 := replay_true τ ok3860 h3860
  have h3862 : TreeTrue τ start3862 := replay_true τ ok3861 h3861
  have h3863 : TreeTrue τ start3863 := replay_true τ ok3862 h3862
  have h3864 : TreeTrue τ start3864 := replay_true τ ok3863 h3863
  have h3865 : TreeTrue τ start3865 := replay_true τ ok3864 h3864
  have h3866 : TreeTrue τ start3866 := replay_true τ ok3865 h3865
  have h3867 : TreeTrue τ start3867 := replay_true τ ok3866 h3866
  have h3868 : TreeTrue τ start3868 := replay_true τ ok3867 h3867
  have h3869 : TreeTrue τ start3869 := replay_true τ ok3868 h3868
  have h3870 : TreeTrue τ start3870 := replay_true τ ok3869 h3869
  have h3871 : TreeTrue τ start3871 := replay_true τ ok3870 h3870
  have h3872 : TreeTrue τ start3872 := cp_true τ ok3871 h3871
  exact h3872
#print axioms steps120
end Snake9.ReplayFull147
