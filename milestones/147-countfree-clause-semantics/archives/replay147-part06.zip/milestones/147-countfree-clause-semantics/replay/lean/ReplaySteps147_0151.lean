import ReplayCheck147_04832
import ReplayCheck147_04836
import ReplayCheck147_04840
import ReplayCheck147_04844
import ReplayCheck147_04848
import ReplayCheck147_04852
import ReplayCheck147_04856
import ReplayCheck147_04860
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps151 (τ : Nat → Bool) (h4832 : TreeTrue τ start4832) : TreeTrue τ start4864 := by
  have h4833 : TreeTrue τ start4833 := replay_true τ ok4832 h4832
  have h4834 : TreeTrue τ start4834 := replay_true τ ok4833 h4833
  have h4835 : TreeTrue τ start4835 := replay_true τ ok4834 h4834
  have h4836 : TreeTrue τ start4836 := replay_true τ ok4835 h4835
  have h4837 : TreeTrue τ start4837 := replay_true τ ok4836 h4836
  have h4838 : TreeTrue τ start4838 := replay_true τ ok4837 h4837
  have h4839 : TreeTrue τ start4839 := replay_true τ ok4838 h4838
  have h4840 : TreeTrue τ start4840 := replay_true τ ok4839 h4839
  have h4841 : TreeTrue τ start4841 := replay_true τ ok4840 h4840
  have h4842 : TreeTrue τ start4842 := replay_true τ ok4841 h4841
  have h4843 : TreeTrue τ start4843 := replay_true τ ok4842 h4842
  have h4844 : TreeTrue τ start4844 := replay_true τ ok4843 h4843
  have h4845 : TreeTrue τ start4845 := replay_true τ ok4844 h4844
  have h4846 : TreeTrue τ start4846 := replay_true τ ok4845 h4845
  have h4847 : TreeTrue τ start4847 := replay_true τ ok4846 h4846
  have h4848 : TreeTrue τ start4848 := replay_true τ ok4847 h4847
  have h4849 : TreeTrue τ start4849 := replay_true τ ok4848 h4848
  have h4850 : TreeTrue τ start4850 := replay_true τ ok4849 h4849
  have h4851 : TreeTrue τ start4851 := replay_true τ ok4850 h4850
  have h4852 : TreeTrue τ start4852 := replay_true τ ok4851 h4851
  have h4853 : TreeTrue τ start4853 := replay_true τ ok4852 h4852
  have h4854 : TreeTrue τ start4854 := replay_true τ ok4853 h4853
  have h4855 : TreeTrue τ start4855 := replay_true τ ok4854 h4854
  have h4856 : TreeTrue τ start4856 := replay_true τ ok4855 h4855
  have h4857 : TreeTrue τ start4857 := replay_true τ ok4856 h4856
  have h4858 : TreeTrue τ start4858 := replay_true τ ok4857 h4857
  have h4859 : TreeTrue τ start4859 := replay_true τ ok4858 h4858
  have h4860 : TreeTrue τ start4860 := replay_true τ ok4859 h4859
  have h4861 : TreeTrue τ start4861 := replay_true τ ok4860 h4860
  have h4862 : TreeTrue τ start4862 := replay_true τ ok4861 h4861
  have h4863 : TreeTrue τ start4863 := replay_true τ ok4862 h4862
  have h4864 : TreeTrue τ start4864 := cp_true τ ok4863 h4863
  exact h4864
#print axioms steps151
end Snake9.ReplayFull147
