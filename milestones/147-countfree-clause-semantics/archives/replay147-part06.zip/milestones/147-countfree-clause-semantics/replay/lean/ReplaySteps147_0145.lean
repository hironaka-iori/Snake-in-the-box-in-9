import ReplayCheck147_04640
import ReplayCheck147_04644
import ReplayCheck147_04648
import ReplayCheck147_04652
import ReplayCheck147_04656
import ReplayCheck147_04660
import ReplayCheck147_04664
import ReplayCheck147_04668
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps145 (τ : Nat → Bool) (h4640 : TreeTrue τ start4640) : TreeTrue τ start4672 := by
  have h4641 : TreeTrue τ start4641 := replay_true τ ok4640 h4640
  have h4642 : TreeTrue τ start4642 := replay_true τ ok4641 h4641
  have h4643 : TreeTrue τ start4643 := replay_true τ ok4642 h4642
  have h4644 : TreeTrue τ start4644 := replay_true τ ok4643 h4643
  have h4645 : TreeTrue τ start4645 := replay_true τ ok4644 h4644
  have h4646 : TreeTrue τ start4646 := replay_true τ ok4645 h4645
  have h4647 : TreeTrue τ start4647 := replay_true τ ok4646 h4646
  have h4648 : TreeTrue τ start4648 := replay_true τ ok4647 h4647
  have h4649 : TreeTrue τ start4649 := replay_true τ ok4648 h4648
  have h4650 : TreeTrue τ start4650 := replay_true τ ok4649 h4649
  have h4651 : TreeTrue τ start4651 := replay_true τ ok4650 h4650
  have h4652 : TreeTrue τ start4652 := replay_true τ ok4651 h4651
  have h4653 : TreeTrue τ start4653 := replay_true τ ok4652 h4652
  have h4654 : TreeTrue τ start4654 := replay_true τ ok4653 h4653
  have h4655 : TreeTrue τ start4655 := replay_true τ ok4654 h4654
  have h4656 : TreeTrue τ start4656 := replay_true τ ok4655 h4655
  have h4657 : TreeTrue τ start4657 := replay_true τ ok4656 h4656
  have h4658 : TreeTrue τ start4658 := replay_true τ ok4657 h4657
  have h4659 : TreeTrue τ start4659 := replay_true τ ok4658 h4658
  have h4660 : TreeTrue τ start4660 := replay_true τ ok4659 h4659
  have h4661 : TreeTrue τ start4661 := replay_true τ ok4660 h4660
  have h4662 : TreeTrue τ start4662 := replay_true τ ok4661 h4661
  have h4663 : TreeTrue τ start4663 := replay_true τ ok4662 h4662
  have h4664 : TreeTrue τ start4664 := replay_true τ ok4663 h4663
  have h4665 : TreeTrue τ start4665 := replay_true τ ok4664 h4664
  have h4666 : TreeTrue τ start4666 := replay_true τ ok4665 h4665
  have h4667 : TreeTrue τ start4667 := replay_true τ ok4666 h4666
  have h4668 : TreeTrue τ start4668 := replay_true τ ok4667 h4667
  have h4669 : TreeTrue τ start4669 := replay_true τ ok4668 h4668
  have h4670 : TreeTrue τ start4670 := replay_true τ ok4669 h4669
  have h4671 : TreeTrue τ start4671 := replay_true τ ok4670 h4670
  have h4672 : TreeTrue τ start4672 := cp_true τ ok4671 h4671
  exact h4672
#print axioms steps145
end Snake9.ReplayFull147
