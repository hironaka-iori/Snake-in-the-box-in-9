import ReplayCheck147_03360
import ReplayCheck147_03364
import ReplayCheck147_03368
import ReplayCheck147_03372
import ReplayCheck147_03376
import ReplayCheck147_03380
import ReplayCheck147_03384
import ReplayCheck147_03388
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps105 (τ : Nat → Bool) (h3360 : TreeTrue τ start3360) : TreeTrue τ start3392 := by
  have h3361 : TreeTrue τ start3361 := replay_true τ ok3360 h3360
  have h3362 : TreeTrue τ start3362 := replay_true τ ok3361 h3361
  have h3363 : TreeTrue τ start3363 := replay_true τ ok3362 h3362
  have h3364 : TreeTrue τ start3364 := replay_true τ ok3363 h3363
  have h3365 : TreeTrue τ start3365 := replay_true τ ok3364 h3364
  have h3366 : TreeTrue τ start3366 := replay_true τ ok3365 h3365
  have h3367 : TreeTrue τ start3367 := replay_true τ ok3366 h3366
  have h3368 : TreeTrue τ start3368 := replay_true τ ok3367 h3367
  have h3369 : TreeTrue τ start3369 := replay_true τ ok3368 h3368
  have h3370 : TreeTrue τ start3370 := replay_true τ ok3369 h3369
  have h3371 : TreeTrue τ start3371 := replay_true τ ok3370 h3370
  have h3372 : TreeTrue τ start3372 := replay_true τ ok3371 h3371
  have h3373 : TreeTrue τ start3373 := replay_true τ ok3372 h3372
  have h3374 : TreeTrue τ start3374 := replay_true τ ok3373 h3373
  have h3375 : TreeTrue τ start3375 := replay_true τ ok3374 h3374
  have h3376 : TreeTrue τ start3376 := replay_true τ ok3375 h3375
  have h3377 : TreeTrue τ start3377 := replay_true τ ok3376 h3376
  have h3378 : TreeTrue τ start3378 := replay_true τ ok3377 h3377
  have h3379 : TreeTrue τ start3379 := replay_true τ ok3378 h3378
  have h3380 : TreeTrue τ start3380 := replay_true τ ok3379 h3379
  have h3381 : TreeTrue τ start3381 := replay_true τ ok3380 h3380
  have h3382 : TreeTrue τ start3382 := replay_true τ ok3381 h3381
  have h3383 : TreeTrue τ start3383 := replay_true τ ok3382 h3382
  have h3384 : TreeTrue τ start3384 := replay_true τ ok3383 h3383
  have h3385 : TreeTrue τ start3385 := replay_true τ ok3384 h3384
  have h3386 : TreeTrue τ start3386 := replay_true τ ok3385 h3385
  have h3387 : TreeTrue τ start3387 := replay_true τ ok3386 h3386
  have h3388 : TreeTrue τ start3388 := replay_true τ ok3387 h3387
  have h3389 : TreeTrue τ start3389 := replay_true τ ok3388 h3388
  have h3390 : TreeTrue τ start3390 := replay_true τ ok3389 h3389
  have h3391 : TreeTrue τ start3391 := replay_true τ ok3390 h3390
  have h3392 : TreeTrue τ start3392 := cp_true τ ok3391 h3391
  exact h3392
#print axioms steps105
end Snake9.ReplayFull147
