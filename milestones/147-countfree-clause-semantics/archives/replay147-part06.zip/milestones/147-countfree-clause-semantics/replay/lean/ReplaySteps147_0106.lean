import ReplayCheck147_03392
import ReplayCheck147_03396
import ReplayCheck147_03400
import ReplayCheck147_03404
import ReplayCheck147_03408
import ReplayCheck147_03412
import ReplayCheck147_03416
import ReplayCheck147_03420
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps106 (τ : Nat → Bool) (h3392 : TreeTrue τ start3392) : TreeTrue τ start3424 := by
  have h3393 : TreeTrue τ start3393 := replay_true τ ok3392 h3392
  have h3394 : TreeTrue τ start3394 := replay_true τ ok3393 h3393
  have h3395 : TreeTrue τ start3395 := replay_true τ ok3394 h3394
  have h3396 : TreeTrue τ start3396 := replay_true τ ok3395 h3395
  have h3397 : TreeTrue τ start3397 := replay_true τ ok3396 h3396
  have h3398 : TreeTrue τ start3398 := replay_true τ ok3397 h3397
  have h3399 : TreeTrue τ start3399 := replay_true τ ok3398 h3398
  have h3400 : TreeTrue τ start3400 := replay_true τ ok3399 h3399
  have h3401 : TreeTrue τ start3401 := replay_true τ ok3400 h3400
  have h3402 : TreeTrue τ start3402 := replay_true τ ok3401 h3401
  have h3403 : TreeTrue τ start3403 := replay_true τ ok3402 h3402
  have h3404 : TreeTrue τ start3404 := replay_true τ ok3403 h3403
  have h3405 : TreeTrue τ start3405 := replay_true τ ok3404 h3404
  have h3406 : TreeTrue τ start3406 := replay_true τ ok3405 h3405
  have h3407 : TreeTrue τ start3407 := replay_true τ ok3406 h3406
  have h3408 : TreeTrue τ start3408 := replay_true τ ok3407 h3407
  have h3409 : TreeTrue τ start3409 := replay_true τ ok3408 h3408
  have h3410 : TreeTrue τ start3410 := replay_true τ ok3409 h3409
  have h3411 : TreeTrue τ start3411 := replay_true τ ok3410 h3410
  have h3412 : TreeTrue τ start3412 := replay_true τ ok3411 h3411
  have h3413 : TreeTrue τ start3413 := replay_true τ ok3412 h3412
  have h3414 : TreeTrue τ start3414 := replay_true τ ok3413 h3413
  have h3415 : TreeTrue τ start3415 := replay_true τ ok3414 h3414
  have h3416 : TreeTrue τ start3416 := replay_true τ ok3415 h3415
  have h3417 : TreeTrue τ start3417 := replay_true τ ok3416 h3416
  have h3418 : TreeTrue τ start3418 := replay_true τ ok3417 h3417
  have h3419 : TreeTrue τ start3419 := replay_true τ ok3418 h3418
  have h3420 : TreeTrue τ start3420 := replay_true τ ok3419 h3419
  have h3421 : TreeTrue τ start3421 := replay_true τ ok3420 h3420
  have h3422 : TreeTrue τ start3422 := replay_true τ ok3421 h3421
  have h3423 : TreeTrue τ start3423 := replay_true τ ok3422 h3422
  have h3424 : TreeTrue τ start3424 := cp_true τ ok3423 h3423
  exact h3424
#print axioms steps106
end Snake9.ReplayFull147
