import ReplayCheck147_03264
import ReplayCheck147_03268
import ReplayCheck147_03272
import ReplayCheck147_03276
import ReplayCheck147_03280
import ReplayCheck147_03284
import ReplayCheck147_03288
import ReplayCheck147_03292
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps102 (τ : Nat → Bool) (h3264 : TreeTrue τ start3264) : TreeTrue τ start3296 := by
  have h3265 : TreeTrue τ start3265 := replay_true τ ok3264 h3264
  have h3266 : TreeTrue τ start3266 := replay_true τ ok3265 h3265
  have h3267 : TreeTrue τ start3267 := replay_true τ ok3266 h3266
  have h3268 : TreeTrue τ start3268 := replay_true τ ok3267 h3267
  have h3269 : TreeTrue τ start3269 := replay_true τ ok3268 h3268
  have h3270 : TreeTrue τ start3270 := replay_true τ ok3269 h3269
  have h3271 : TreeTrue τ start3271 := replay_true τ ok3270 h3270
  have h3272 : TreeTrue τ start3272 := replay_true τ ok3271 h3271
  have h3273 : TreeTrue τ start3273 := replay_true τ ok3272 h3272
  have h3274 : TreeTrue τ start3274 := replay_true τ ok3273 h3273
  have h3275 : TreeTrue τ start3275 := replay_true τ ok3274 h3274
  have h3276 : TreeTrue τ start3276 := replay_true τ ok3275 h3275
  have h3277 : TreeTrue τ start3277 := replay_true τ ok3276 h3276
  have h3278 : TreeTrue τ start3278 := replay_true τ ok3277 h3277
  have h3279 : TreeTrue τ start3279 := replay_true τ ok3278 h3278
  have h3280 : TreeTrue τ start3280 := replay_true τ ok3279 h3279
  have h3281 : TreeTrue τ start3281 := replay_true τ ok3280 h3280
  have h3282 : TreeTrue τ start3282 := replay_true τ ok3281 h3281
  have h3283 : TreeTrue τ start3283 := replay_true τ ok3282 h3282
  have h3284 : TreeTrue τ start3284 := replay_true τ ok3283 h3283
  have h3285 : TreeTrue τ start3285 := replay_true τ ok3284 h3284
  have h3286 : TreeTrue τ start3286 := replay_true τ ok3285 h3285
  have h3287 : TreeTrue τ start3287 := replay_true τ ok3286 h3286
  have h3288 : TreeTrue τ start3288 := replay_true τ ok3287 h3287
  have h3289 : TreeTrue τ start3289 := replay_true τ ok3288 h3288
  have h3290 : TreeTrue τ start3290 := replay_true τ ok3289 h3289
  have h3291 : TreeTrue τ start3291 := replay_true τ ok3290 h3290
  have h3292 : TreeTrue τ start3292 := replay_true τ ok3291 h3291
  have h3293 : TreeTrue τ start3293 := replay_true τ ok3292 h3292
  have h3294 : TreeTrue τ start3294 := replay_true τ ok3293 h3293
  have h3295 : TreeTrue τ start3295 := replay_true τ ok3294 h3294
  have h3296 : TreeTrue τ start3296 := cp_true τ ok3295 h3295
  exact h3296
#print axioms steps102
end Snake9.ReplayFull147
