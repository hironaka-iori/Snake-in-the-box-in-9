import ReplayCheck147_04992
import ReplayCheck147_04996
import ReplayCheck147_05000
import ReplayCheck147_05004
import ReplayCheck147_05008
import ReplayCheck147_05012
import ReplayCheck147_05016
import ReplayCheck147_05020
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps156 (τ : Nat → Bool) (h4992 : TreeTrue τ start4992) : TreeTrue τ start5024 := by
  have h4993 : TreeTrue τ start4993 := replay_true τ ok4992 h4992
  have h4994 : TreeTrue τ start4994 := replay_true τ ok4993 h4993
  have h4995 : TreeTrue τ start4995 := replay_true τ ok4994 h4994
  have h4996 : TreeTrue τ start4996 := replay_true τ ok4995 h4995
  have h4997 : TreeTrue τ start4997 := replay_true τ ok4996 h4996
  have h4998 : TreeTrue τ start4998 := replay_true τ ok4997 h4997
  have h4999 : TreeTrue τ start4999 := replay_true τ ok4998 h4998
  have h5000 : TreeTrue τ start5000 := replay_true τ ok4999 h4999
  have h5001 : TreeTrue τ start5001 := replay_true τ ok5000 h5000
  have h5002 : TreeTrue τ start5002 := replay_true τ ok5001 h5001
  have h5003 : TreeTrue τ start5003 := replay_true τ ok5002 h5002
  have h5004 : TreeTrue τ start5004 := replay_true τ ok5003 h5003
  have h5005 : TreeTrue τ start5005 := replay_true τ ok5004 h5004
  have h5006 : TreeTrue τ start5006 := replay_true τ ok5005 h5005
  have h5007 : TreeTrue τ start5007 := replay_true τ ok5006 h5006
  have h5008 : TreeTrue τ start5008 := replay_true τ ok5007 h5007
  have h5009 : TreeTrue τ start5009 := replay_true τ ok5008 h5008
  have h5010 : TreeTrue τ start5010 := replay_true τ ok5009 h5009
  have h5011 : TreeTrue τ start5011 := replay_true τ ok5010 h5010
  have h5012 : TreeTrue τ start5012 := replay_true τ ok5011 h5011
  have h5013 : TreeTrue τ start5013 := replay_true τ ok5012 h5012
  have h5014 : TreeTrue τ start5014 := replay_true τ ok5013 h5013
  have h5015 : TreeTrue τ start5015 := replay_true τ ok5014 h5014
  have h5016 : TreeTrue τ start5016 := replay_true τ ok5015 h5015
  have h5017 : TreeTrue τ start5017 := replay_true τ ok5016 h5016
  have h5018 : TreeTrue τ start5018 := replay_true τ ok5017 h5017
  have h5019 : TreeTrue τ start5019 := replay_true τ ok5018 h5018
  have h5020 : TreeTrue τ start5020 := replay_true τ ok5019 h5019
  have h5021 : TreeTrue τ start5021 := replay_true τ ok5020 h5020
  have h5022 : TreeTrue τ start5022 := replay_true τ ok5021 h5021
  have h5023 : TreeTrue τ start5023 := replay_true τ ok5022 h5022
  have h5024 : TreeTrue τ start5024 := cp_true τ ok5023 h5023
  exact h5024
#print axioms steps156
end Snake9.ReplayFull147
