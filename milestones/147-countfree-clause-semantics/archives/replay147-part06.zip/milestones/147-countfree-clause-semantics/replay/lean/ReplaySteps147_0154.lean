import ReplayCheck147_04928
import ReplayCheck147_04932
import ReplayCheck147_04936
import ReplayCheck147_04940
import ReplayCheck147_04944
import ReplayCheck147_04948
import ReplayCheck147_04952
import ReplayCheck147_04956
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps154 (τ : Nat → Bool) (h4928 : TreeTrue τ start4928) : TreeTrue τ start4960 := by
  have h4929 : TreeTrue τ start4929 := replay_true τ ok4928 h4928
  have h4930 : TreeTrue τ start4930 := replay_true τ ok4929 h4929
  have h4931 : TreeTrue τ start4931 := replay_true τ ok4930 h4930
  have h4932 : TreeTrue τ start4932 := replay_true τ ok4931 h4931
  have h4933 : TreeTrue τ start4933 := replay_true τ ok4932 h4932
  have h4934 : TreeTrue τ start4934 := replay_true τ ok4933 h4933
  have h4935 : TreeTrue τ start4935 := replay_true τ ok4934 h4934
  have h4936 : TreeTrue τ start4936 := replay_true τ ok4935 h4935
  have h4937 : TreeTrue τ start4937 := replay_true τ ok4936 h4936
  have h4938 : TreeTrue τ start4938 := replay_true τ ok4937 h4937
  have h4939 : TreeTrue τ start4939 := replay_true τ ok4938 h4938
  have h4940 : TreeTrue τ start4940 := replay_true τ ok4939 h4939
  have h4941 : TreeTrue τ start4941 := replay_true τ ok4940 h4940
  have h4942 : TreeTrue τ start4942 := replay_true τ ok4941 h4941
  have h4943 : TreeTrue τ start4943 := replay_true τ ok4942 h4942
  have h4944 : TreeTrue τ start4944 := replay_true τ ok4943 h4943
  have h4945 : TreeTrue τ start4945 := replay_true τ ok4944 h4944
  have h4946 : TreeTrue τ start4946 := replay_true τ ok4945 h4945
  have h4947 : TreeTrue τ start4947 := replay_true τ ok4946 h4946
  have h4948 : TreeTrue τ start4948 := replay_true τ ok4947 h4947
  have h4949 : TreeTrue τ start4949 := replay_true τ ok4948 h4948
  have h4950 : TreeTrue τ start4950 := replay_true τ ok4949 h4949
  have h4951 : TreeTrue τ start4951 := replay_true τ ok4950 h4950
  have h4952 : TreeTrue τ start4952 := replay_true τ ok4951 h4951
  have h4953 : TreeTrue τ start4953 := replay_true τ ok4952 h4952
  have h4954 : TreeTrue τ start4954 := replay_true τ ok4953 h4953
  have h4955 : TreeTrue τ start4955 := replay_true τ ok4954 h4954
  have h4956 : TreeTrue τ start4956 := replay_true τ ok4955 h4955
  have h4957 : TreeTrue τ start4957 := replay_true τ ok4956 h4956
  have h4958 : TreeTrue τ start4958 := replay_true τ ok4957 h4957
  have h4959 : TreeTrue τ start4959 := replay_true τ ok4958 h4958
  have h4960 : TreeTrue τ start4960 := cp_true τ ok4959 h4959
  exact h4960
#print axioms steps154
end Snake9.ReplayFull147
