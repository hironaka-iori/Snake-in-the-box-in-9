import ReplayCheck147_03584
import ReplayCheck147_03588
import ReplayCheck147_03592
import ReplayCheck147_03596
import ReplayCheck147_03600
import ReplayCheck147_03604
import ReplayCheck147_03608
import ReplayCheck147_03612
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps112 (τ : Nat → Bool) (h3584 : TreeTrue τ start3584) : TreeTrue τ start3616 := by
  have h3585 : TreeTrue τ start3585 := replay_true τ ok3584 h3584
  have h3586 : TreeTrue τ start3586 := replay_true τ ok3585 h3585
  have h3587 : TreeTrue τ start3587 := replay_true τ ok3586 h3586
  have h3588 : TreeTrue τ start3588 := replay_true τ ok3587 h3587
  have h3589 : TreeTrue τ start3589 := replay_true τ ok3588 h3588
  have h3590 : TreeTrue τ start3590 := replay_true τ ok3589 h3589
  have h3591 : TreeTrue τ start3591 := replay_true τ ok3590 h3590
  have h3592 : TreeTrue τ start3592 := replay_true τ ok3591 h3591
  have h3593 : TreeTrue τ start3593 := replay_true τ ok3592 h3592
  have h3594 : TreeTrue τ start3594 := replay_true τ ok3593 h3593
  have h3595 : TreeTrue τ start3595 := replay_true τ ok3594 h3594
  have h3596 : TreeTrue τ start3596 := replay_true τ ok3595 h3595
  have h3597 : TreeTrue τ start3597 := replay_true τ ok3596 h3596
  have h3598 : TreeTrue τ start3598 := replay_true τ ok3597 h3597
  have h3599 : TreeTrue τ start3599 := replay_true τ ok3598 h3598
  have h3600 : TreeTrue τ start3600 := replay_true τ ok3599 h3599
  have h3601 : TreeTrue τ start3601 := replay_true τ ok3600 h3600
  have h3602 : TreeTrue τ start3602 := replay_true τ ok3601 h3601
  have h3603 : TreeTrue τ start3603 := replay_true τ ok3602 h3602
  have h3604 : TreeTrue τ start3604 := replay_true τ ok3603 h3603
  have h3605 : TreeTrue τ start3605 := replay_true τ ok3604 h3604
  have h3606 : TreeTrue τ start3606 := replay_true τ ok3605 h3605
  have h3607 : TreeTrue τ start3607 := replay_true τ ok3606 h3606
  have h3608 : TreeTrue τ start3608 := replay_true τ ok3607 h3607
  have h3609 : TreeTrue τ start3609 := replay_true τ ok3608 h3608
  have h3610 : TreeTrue τ start3610 := replay_true τ ok3609 h3609
  have h3611 : TreeTrue τ start3611 := replay_true τ ok3610 h3610
  have h3612 : TreeTrue τ start3612 := replay_true τ ok3611 h3611
  have h3613 : TreeTrue τ start3613 := replay_true τ ok3612 h3612
  have h3614 : TreeTrue τ start3614 := replay_true τ ok3613 h3613
  have h3615 : TreeTrue τ start3615 := replay_true τ ok3614 h3614
  have h3616 : TreeTrue τ start3616 := cp_true τ ok3615 h3615
  exact h3616
#print axioms steps112
end Snake9.ReplayFull147
