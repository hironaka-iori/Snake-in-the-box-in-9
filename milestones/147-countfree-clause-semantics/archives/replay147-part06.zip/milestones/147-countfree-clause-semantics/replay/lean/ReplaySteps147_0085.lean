import ReplayCheck147_02720
import ReplayCheck147_02724
import ReplayCheck147_02728
import ReplayCheck147_02732
import ReplayCheck147_02736
import ReplayCheck147_02740
import ReplayCheck147_02744
import ReplayCheck147_02748
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps85 (τ : Nat → Bool) (h2720 : TreeTrue τ start2720) : TreeTrue τ start2752 := by
  have h2721 : TreeTrue τ start2721 := replay_true τ ok2720 h2720
  have h2722 : TreeTrue τ start2722 := replay_true τ ok2721 h2721
  have h2723 : TreeTrue τ start2723 := replay_true τ ok2722 h2722
  have h2724 : TreeTrue τ start2724 := replay_true τ ok2723 h2723
  have h2725 : TreeTrue τ start2725 := replay_true τ ok2724 h2724
  have h2726 : TreeTrue τ start2726 := replay_true τ ok2725 h2725
  have h2727 : TreeTrue τ start2727 := replay_true τ ok2726 h2726
  have h2728 : TreeTrue τ start2728 := replay_true τ ok2727 h2727
  have h2729 : TreeTrue τ start2729 := replay_true τ ok2728 h2728
  have h2730 : TreeTrue τ start2730 := replay_true τ ok2729 h2729
  have h2731 : TreeTrue τ start2731 := replay_true τ ok2730 h2730
  have h2732 : TreeTrue τ start2732 := replay_true τ ok2731 h2731
  have h2733 : TreeTrue τ start2733 := replay_true τ ok2732 h2732
  have h2734 : TreeTrue τ start2734 := replay_true τ ok2733 h2733
  have h2735 : TreeTrue τ start2735 := replay_true τ ok2734 h2734
  have h2736 : TreeTrue τ start2736 := replay_true τ ok2735 h2735
  have h2737 : TreeTrue τ start2737 := replay_true τ ok2736 h2736
  have h2738 : TreeTrue τ start2738 := replay_true τ ok2737 h2737
  have h2739 : TreeTrue τ start2739 := replay_true τ ok2738 h2738
  have h2740 : TreeTrue τ start2740 := replay_true τ ok2739 h2739
  have h2741 : TreeTrue τ start2741 := replay_true τ ok2740 h2740
  have h2742 : TreeTrue τ start2742 := replay_true τ ok2741 h2741
  have h2743 : TreeTrue τ start2743 := replay_true τ ok2742 h2742
  have h2744 : TreeTrue τ start2744 := replay_true τ ok2743 h2743
  have h2745 : TreeTrue τ start2745 := replay_true τ ok2744 h2744
  have h2746 : TreeTrue τ start2746 := replay_true τ ok2745 h2745
  have h2747 : TreeTrue τ start2747 := replay_true τ ok2746 h2746
  have h2748 : TreeTrue τ start2748 := replay_true τ ok2747 h2747
  have h2749 : TreeTrue τ start2749 := replay_true τ ok2748 h2748
  have h2750 : TreeTrue τ start2750 := replay_true τ ok2749 h2749
  have h2751 : TreeTrue τ start2751 := replay_true τ ok2750 h2750
  have h2752 : TreeTrue τ start2752 := cp_true τ ok2751 h2751
  exact h2752
#print axioms steps85
end Snake9.ReplayFull147
