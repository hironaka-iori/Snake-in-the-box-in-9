import ReplayCheck147_05088
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps159 (τ : Nat → Bool) (h5088 : TreeTrue τ start5088) : False := by
  exact final_false τ ok5088 h5088
#print axioms steps159
end Snake9.ReplayFull147
