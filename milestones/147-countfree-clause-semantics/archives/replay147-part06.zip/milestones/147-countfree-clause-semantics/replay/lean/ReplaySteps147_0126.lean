import ReplayCheck147_04032
import ReplayCheck147_04036
import ReplayCheck147_04040
import ReplayCheck147_04044
import ReplayCheck147_04048
import ReplayCheck147_04052
import ReplayCheck147_04056
import ReplayCheck147_04060
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps126 (τ : Nat → Bool) (h4032 : TreeTrue τ start4032) : TreeTrue τ start4064 := by
  have h4033 : TreeTrue τ start4033 := replay_true τ ok4032 h4032
  have h4034 : TreeTrue τ start4034 := replay_true τ ok4033 h4033
  have h4035 : TreeTrue τ start4035 := replay_true τ ok4034 h4034
  have h4036 : TreeTrue τ start4036 := replay_true τ ok4035 h4035
  have h4037 : TreeTrue τ start4037 := replay_true τ ok4036 h4036
  have h4038 : TreeTrue τ start4038 := replay_true τ ok4037 h4037
  have h4039 : TreeTrue τ start4039 := replay_true τ ok4038 h4038
  have h4040 : TreeTrue τ start4040 := replay_true τ ok4039 h4039
  have h4041 : TreeTrue τ start4041 := replay_true τ ok4040 h4040
  have h4042 : TreeTrue τ start4042 := replay_true τ ok4041 h4041
  have h4043 : TreeTrue τ start4043 := replay_true τ ok4042 h4042
  have h4044 : TreeTrue τ start4044 := replay_true τ ok4043 h4043
  have h4045 : TreeTrue τ start4045 := replay_true τ ok4044 h4044
  have h4046 : TreeTrue τ start4046 := replay_true τ ok4045 h4045
  have h4047 : TreeTrue τ start4047 := replay_true τ ok4046 h4046
  have h4048 : TreeTrue τ start4048 := replay_true τ ok4047 h4047
  have h4049 : TreeTrue τ start4049 := replay_true τ ok4048 h4048
  have h4050 : TreeTrue τ start4050 := replay_true τ ok4049 h4049
  have h4051 : TreeTrue τ start4051 := replay_true τ ok4050 h4050
  have h4052 : TreeTrue τ start4052 := replay_true τ ok4051 h4051
  have h4053 : TreeTrue τ start4053 := replay_true τ ok4052 h4052
  have h4054 : TreeTrue τ start4054 := replay_true τ ok4053 h4053
  have h4055 : TreeTrue τ start4055 := replay_true τ ok4054 h4054
  have h4056 : TreeTrue τ start4056 := replay_true τ ok4055 h4055
  have h4057 : TreeTrue τ start4057 := replay_true τ ok4056 h4056
  have h4058 : TreeTrue τ start4058 := replay_true τ ok4057 h4057
  have h4059 : TreeTrue τ start4059 := replay_true τ ok4058 h4058
  have h4060 : TreeTrue τ start4060 := replay_true τ ok4059 h4059
  have h4061 : TreeTrue τ start4061 := replay_true τ ok4060 h4060
  have h4062 : TreeTrue τ start4062 := replay_true τ ok4061 h4061
  have h4063 : TreeTrue τ start4063 := replay_true τ ok4062 h4062
  have h4064 : TreeTrue τ start4064 := cp_true τ ok4063 h4063
  exact h4064
#print axioms steps126
end Snake9.ReplayFull147
