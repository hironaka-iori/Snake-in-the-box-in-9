import ReplayCheck147_02848
import ReplayCheck147_02852
import ReplayCheck147_02856
import ReplayCheck147_02860
import ReplayCheck147_02864
import ReplayCheck147_02868
import ReplayCheck147_02872
import ReplayCheck147_02876
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps89 (τ : Nat → Bool) (h2848 : TreeTrue τ start2848) : TreeTrue τ start2880 := by
  have h2849 : TreeTrue τ start2849 := replay_true τ ok2848 h2848
  have h2850 : TreeTrue τ start2850 := replay_true τ ok2849 h2849
  have h2851 : TreeTrue τ start2851 := replay_true τ ok2850 h2850
  have h2852 : TreeTrue τ start2852 := replay_true τ ok2851 h2851
  have h2853 : TreeTrue τ start2853 := replay_true τ ok2852 h2852
  have h2854 : TreeTrue τ start2854 := replay_true τ ok2853 h2853
  have h2855 : TreeTrue τ start2855 := replay_true τ ok2854 h2854
  have h2856 : TreeTrue τ start2856 := replay_true τ ok2855 h2855
  have h2857 : TreeTrue τ start2857 := replay_true τ ok2856 h2856
  have h2858 : TreeTrue τ start2858 := replay_true τ ok2857 h2857
  have h2859 : TreeTrue τ start2859 := replay_true τ ok2858 h2858
  have h2860 : TreeTrue τ start2860 := replay_true τ ok2859 h2859
  have h2861 : TreeTrue τ start2861 := replay_true τ ok2860 h2860
  have h2862 : TreeTrue τ start2862 := replay_true τ ok2861 h2861
  have h2863 : TreeTrue τ start2863 := replay_true τ ok2862 h2862
  have h2864 : TreeTrue τ start2864 := replay_true τ ok2863 h2863
  have h2865 : TreeTrue τ start2865 := replay_true τ ok2864 h2864
  have h2866 : TreeTrue τ start2866 := replay_true τ ok2865 h2865
  have h2867 : TreeTrue τ start2867 := replay_true τ ok2866 h2866
  have h2868 : TreeTrue τ start2868 := replay_true τ ok2867 h2867
  have h2869 : TreeTrue τ start2869 := replay_true τ ok2868 h2868
  have h2870 : TreeTrue τ start2870 := replay_true τ ok2869 h2869
  have h2871 : TreeTrue τ start2871 := replay_true τ ok2870 h2870
  have h2872 : TreeTrue τ start2872 := replay_true τ ok2871 h2871
  have h2873 : TreeTrue τ start2873 := replay_true τ ok2872 h2872
  have h2874 : TreeTrue τ start2874 := replay_true τ ok2873 h2873
  have h2875 : TreeTrue τ start2875 := replay_true τ ok2874 h2874
  have h2876 : TreeTrue τ start2876 := replay_true τ ok2875 h2875
  have h2877 : TreeTrue τ start2877 := replay_true τ ok2876 h2876
  have h2878 : TreeTrue τ start2878 := replay_true τ ok2877 h2877
  have h2879 : TreeTrue τ start2879 := replay_true τ ok2878 h2878
  have h2880 : TreeTrue τ start2880 := cp_true τ ok2879 h2879
  exact h2880
#print axioms steps89
end Snake9.ReplayFull147
