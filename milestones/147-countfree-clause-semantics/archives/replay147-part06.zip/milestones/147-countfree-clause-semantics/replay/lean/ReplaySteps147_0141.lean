import ReplayCheck147_04512
import ReplayCheck147_04516
import ReplayCheck147_04520
import ReplayCheck147_04524
import ReplayCheck147_04528
import ReplayCheck147_04532
import ReplayCheck147_04536
import ReplayCheck147_04540
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps141 (τ : Nat → Bool) (h4512 : TreeTrue τ start4512) : TreeTrue τ start4544 := by
  have h4513 : TreeTrue τ start4513 := replay_true τ ok4512 h4512
  have h4514 : TreeTrue τ start4514 := replay_true τ ok4513 h4513
  have h4515 : TreeTrue τ start4515 := replay_true τ ok4514 h4514
  have h4516 : TreeTrue τ start4516 := replay_true τ ok4515 h4515
  have h4517 : TreeTrue τ start4517 := replay_true τ ok4516 h4516
  have h4518 : TreeTrue τ start4518 := replay_true τ ok4517 h4517
  have h4519 : TreeTrue τ start4519 := replay_true τ ok4518 h4518
  have h4520 : TreeTrue τ start4520 := replay_true τ ok4519 h4519
  have h4521 : TreeTrue τ start4521 := replay_true τ ok4520 h4520
  have h4522 : TreeTrue τ start4522 := replay_true τ ok4521 h4521
  have h4523 : TreeTrue τ start4523 := replay_true τ ok4522 h4522
  have h4524 : TreeTrue τ start4524 := replay_true τ ok4523 h4523
  have h4525 : TreeTrue τ start4525 := replay_true τ ok4524 h4524
  have h4526 : TreeTrue τ start4526 := replay_true τ ok4525 h4525
  have h4527 : TreeTrue τ start4527 := replay_true τ ok4526 h4526
  have h4528 : TreeTrue τ start4528 := replay_true τ ok4527 h4527
  have h4529 : TreeTrue τ start4529 := replay_true τ ok4528 h4528
  have h4530 : TreeTrue τ start4530 := replay_true τ ok4529 h4529
  have h4531 : TreeTrue τ start4531 := replay_true τ ok4530 h4530
  have h4532 : TreeTrue τ start4532 := replay_true τ ok4531 h4531
  have h4533 : TreeTrue τ start4533 := replay_true τ ok4532 h4532
  have h4534 : TreeTrue τ start4534 := replay_true τ ok4533 h4533
  have h4535 : TreeTrue τ start4535 := replay_true τ ok4534 h4534
  have h4536 : TreeTrue τ start4536 := replay_true τ ok4535 h4535
  have h4537 : TreeTrue τ start4537 := replay_true τ ok4536 h4536
  have h4538 : TreeTrue τ start4538 := replay_true τ ok4537 h4537
  have h4539 : TreeTrue τ start4539 := replay_true τ ok4538 h4538
  have h4540 : TreeTrue τ start4540 := replay_true τ ok4539 h4539
  have h4541 : TreeTrue τ start4541 := replay_true τ ok4540 h4540
  have h4542 : TreeTrue τ start4542 := replay_true τ ok4541 h4541
  have h4543 : TreeTrue τ start4543 := replay_true τ ok4542 h4542
  have h4544 : TreeTrue τ start4544 := cp_true τ ok4543 h4543
  exact h4544
#print axioms steps141
end Snake9.ReplayFull147
