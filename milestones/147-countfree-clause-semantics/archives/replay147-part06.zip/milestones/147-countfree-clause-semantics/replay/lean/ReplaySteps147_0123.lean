import ReplayCheck147_03936
import ReplayCheck147_03940
import ReplayCheck147_03944
import ReplayCheck147_03948
import ReplayCheck147_03952
import ReplayCheck147_03956
import ReplayCheck147_03960
import ReplayCheck147_03964
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps123 (τ : Nat → Bool) (h3936 : TreeTrue τ start3936) : TreeTrue τ start3968 := by
  have h3937 : TreeTrue τ start3937 := replay_true τ ok3936 h3936
  have h3938 : TreeTrue τ start3938 := replay_true τ ok3937 h3937
  have h3939 : TreeTrue τ start3939 := replay_true τ ok3938 h3938
  have h3940 : TreeTrue τ start3940 := replay_true τ ok3939 h3939
  have h3941 : TreeTrue τ start3941 := replay_true τ ok3940 h3940
  have h3942 : TreeTrue τ start3942 := replay_true τ ok3941 h3941
  have h3943 : TreeTrue τ start3943 := replay_true τ ok3942 h3942
  have h3944 : TreeTrue τ start3944 := replay_true τ ok3943 h3943
  have h3945 : TreeTrue τ start3945 := replay_true τ ok3944 h3944
  have h3946 : TreeTrue τ start3946 := replay_true τ ok3945 h3945
  have h3947 : TreeTrue τ start3947 := replay_true τ ok3946 h3946
  have h3948 : TreeTrue τ start3948 := replay_true τ ok3947 h3947
  have h3949 : TreeTrue τ start3949 := replay_true τ ok3948 h3948
  have h3950 : TreeTrue τ start3950 := replay_true τ ok3949 h3949
  have h3951 : TreeTrue τ start3951 := replay_true τ ok3950 h3950
  have h3952 : TreeTrue τ start3952 := replay_true τ ok3951 h3951
  have h3953 : TreeTrue τ start3953 := replay_true τ ok3952 h3952
  have h3954 : TreeTrue τ start3954 := replay_true τ ok3953 h3953
  have h3955 : TreeTrue τ start3955 := replay_true τ ok3954 h3954
  have h3956 : TreeTrue τ start3956 := replay_true τ ok3955 h3955
  have h3957 : TreeTrue τ start3957 := replay_true τ ok3956 h3956
  have h3958 : TreeTrue τ start3958 := replay_true τ ok3957 h3957
  have h3959 : TreeTrue τ start3959 := replay_true τ ok3958 h3958
  have h3960 : TreeTrue τ start3960 := replay_true τ ok3959 h3959
  have h3961 : TreeTrue τ start3961 := replay_true τ ok3960 h3960
  have h3962 : TreeTrue τ start3962 := replay_true τ ok3961 h3961
  have h3963 : TreeTrue τ start3963 := replay_true τ ok3962 h3962
  have h3964 : TreeTrue τ start3964 := replay_true τ ok3963 h3963
  have h3965 : TreeTrue τ start3965 := replay_true τ ok3964 h3964
  have h3966 : TreeTrue τ start3966 := replay_true τ ok3965 h3965
  have h3967 : TreeTrue τ start3967 := replay_true τ ok3966 h3966
  have h3968 : TreeTrue τ start3968 := cp_true τ ok3967 h3967
  exact h3968
#print axioms steps123
end Snake9.ReplayFull147
