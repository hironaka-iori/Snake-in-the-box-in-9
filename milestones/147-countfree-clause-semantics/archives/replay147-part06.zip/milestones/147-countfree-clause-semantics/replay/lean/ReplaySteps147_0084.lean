import ReplayCheck147_02688
import ReplayCheck147_02692
import ReplayCheck147_02696
import ReplayCheck147_02700
import ReplayCheck147_02704
import ReplayCheck147_02708
import ReplayCheck147_02712
import ReplayCheck147_02716
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps84 (τ : Nat → Bool) (h2688 : TreeTrue τ start2688) : TreeTrue τ start2720 := by
  have h2689 : TreeTrue τ start2689 := replay_true τ ok2688 h2688
  have h2690 : TreeTrue τ start2690 := replay_true τ ok2689 h2689
  have h2691 : TreeTrue τ start2691 := replay_true τ ok2690 h2690
  have h2692 : TreeTrue τ start2692 := replay_true τ ok2691 h2691
  have h2693 : TreeTrue τ start2693 := replay_true τ ok2692 h2692
  have h2694 : TreeTrue τ start2694 := replay_true τ ok2693 h2693
  have h2695 : TreeTrue τ start2695 := replay_true τ ok2694 h2694
  have h2696 : TreeTrue τ start2696 := replay_true τ ok2695 h2695
  have h2697 : TreeTrue τ start2697 := replay_true τ ok2696 h2696
  have h2698 : TreeTrue τ start2698 := replay_true τ ok2697 h2697
  have h2699 : TreeTrue τ start2699 := replay_true τ ok2698 h2698
  have h2700 : TreeTrue τ start2700 := replay_true τ ok2699 h2699
  have h2701 : TreeTrue τ start2701 := replay_true τ ok2700 h2700
  have h2702 : TreeTrue τ start2702 := replay_true τ ok2701 h2701
  have h2703 : TreeTrue τ start2703 := replay_true τ ok2702 h2702
  have h2704 : TreeTrue τ start2704 := replay_true τ ok2703 h2703
  have h2705 : TreeTrue τ start2705 := replay_true τ ok2704 h2704
  have h2706 : TreeTrue τ start2706 := replay_true τ ok2705 h2705
  have h2707 : TreeTrue τ start2707 := replay_true τ ok2706 h2706
  have h2708 : TreeTrue τ start2708 := replay_true τ ok2707 h2707
  have h2709 : TreeTrue τ start2709 := replay_true τ ok2708 h2708
  have h2710 : TreeTrue τ start2710 := replay_true τ ok2709 h2709
  have h2711 : TreeTrue τ start2711 := replay_true τ ok2710 h2710
  have h2712 : TreeTrue τ start2712 := replay_true τ ok2711 h2711
  have h2713 : TreeTrue τ start2713 := replay_true τ ok2712 h2712
  have h2714 : TreeTrue τ start2714 := replay_true τ ok2713 h2713
  have h2715 : TreeTrue τ start2715 := replay_true τ ok2714 h2714
  have h2716 : TreeTrue τ start2716 := replay_true τ ok2715 h2715
  have h2717 : TreeTrue τ start2717 := replay_true τ ok2716 h2716
  have h2718 : TreeTrue τ start2718 := replay_true τ ok2717 h2717
  have h2719 : TreeTrue τ start2719 := replay_true τ ok2718 h2718
  have h2720 : TreeTrue τ start2720 := cp_true τ ok2719 h2719
  exact h2720
#print axioms steps84
end Snake9.ReplayFull147
