import ReplayCheck147_04096
import ReplayCheck147_04100
import ReplayCheck147_04104
import ReplayCheck147_04108
import ReplayCheck147_04112
import ReplayCheck147_04116
import ReplayCheck147_04120
import ReplayCheck147_04124
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps128 (τ : Nat → Bool) (h4096 : TreeTrue τ start4096) : TreeTrue τ start4128 := by
  have h4097 : TreeTrue τ start4097 := replay_true τ ok4096 h4096
  have h4098 : TreeTrue τ start4098 := replay_true τ ok4097 h4097
  have h4099 : TreeTrue τ start4099 := replay_true τ ok4098 h4098
  have h4100 : TreeTrue τ start4100 := replay_true τ ok4099 h4099
  have h4101 : TreeTrue τ start4101 := replay_true τ ok4100 h4100
  have h4102 : TreeTrue τ start4102 := replay_true τ ok4101 h4101
  have h4103 : TreeTrue τ start4103 := replay_true τ ok4102 h4102
  have h4104 : TreeTrue τ start4104 := replay_true τ ok4103 h4103
  have h4105 : TreeTrue τ start4105 := replay_true τ ok4104 h4104
  have h4106 : TreeTrue τ start4106 := replay_true τ ok4105 h4105
  have h4107 : TreeTrue τ start4107 := replay_true τ ok4106 h4106
  have h4108 : TreeTrue τ start4108 := replay_true τ ok4107 h4107
  have h4109 : TreeTrue τ start4109 := replay_true τ ok4108 h4108
  have h4110 : TreeTrue τ start4110 := replay_true τ ok4109 h4109
  have h4111 : TreeTrue τ start4111 := replay_true τ ok4110 h4110
  have h4112 : TreeTrue τ start4112 := replay_true τ ok4111 h4111
  have h4113 : TreeTrue τ start4113 := replay_true τ ok4112 h4112
  have h4114 : TreeTrue τ start4114 := replay_true τ ok4113 h4113
  have h4115 : TreeTrue τ start4115 := replay_true τ ok4114 h4114
  have h4116 : TreeTrue τ start4116 := replay_true τ ok4115 h4115
  have h4117 : TreeTrue τ start4117 := replay_true τ ok4116 h4116
  have h4118 : TreeTrue τ start4118 := replay_true τ ok4117 h4117
  have h4119 : TreeTrue τ start4119 := replay_true τ ok4118 h4118
  have h4120 : TreeTrue τ start4120 := replay_true τ ok4119 h4119
  have h4121 : TreeTrue τ start4121 := replay_true τ ok4120 h4120
  have h4122 : TreeTrue τ start4122 := replay_true τ ok4121 h4121
  have h4123 : TreeTrue τ start4123 := replay_true τ ok4122 h4122
  have h4124 : TreeTrue τ start4124 := replay_true τ ok4123 h4123
  have h4125 : TreeTrue τ start4125 := replay_true τ ok4124 h4124
  have h4126 : TreeTrue τ start4126 := replay_true τ ok4125 h4125
  have h4127 : TreeTrue τ start4127 := replay_true τ ok4126 h4126
  have h4128 : TreeTrue τ start4128 := cp_true τ ok4127 h4127
  exact h4128
#print axioms steps128
end Snake9.ReplayFull147
