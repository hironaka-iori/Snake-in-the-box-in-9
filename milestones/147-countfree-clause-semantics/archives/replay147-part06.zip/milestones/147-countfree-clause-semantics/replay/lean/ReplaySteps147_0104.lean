import ReplayCheck147_03328
import ReplayCheck147_03332
import ReplayCheck147_03336
import ReplayCheck147_03340
import ReplayCheck147_03344
import ReplayCheck147_03348
import ReplayCheck147_03352
import ReplayCheck147_03356
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps104 (τ : Nat → Bool) (h3328 : TreeTrue τ start3328) : TreeTrue τ start3360 := by
  have h3329 : TreeTrue τ start3329 := replay_true τ ok3328 h3328
  have h3330 : TreeTrue τ start3330 := replay_true τ ok3329 h3329
  have h3331 : TreeTrue τ start3331 := replay_true τ ok3330 h3330
  have h3332 : TreeTrue τ start3332 := replay_true τ ok3331 h3331
  have h3333 : TreeTrue τ start3333 := replay_true τ ok3332 h3332
  have h3334 : TreeTrue τ start3334 := replay_true τ ok3333 h3333
  have h3335 : TreeTrue τ start3335 := replay_true τ ok3334 h3334
  have h3336 : TreeTrue τ start3336 := replay_true τ ok3335 h3335
  have h3337 : TreeTrue τ start3337 := replay_true τ ok3336 h3336
  have h3338 : TreeTrue τ start3338 := replay_true τ ok3337 h3337
  have h3339 : TreeTrue τ start3339 := replay_true τ ok3338 h3338
  have h3340 : TreeTrue τ start3340 := replay_true τ ok3339 h3339
  have h3341 : TreeTrue τ start3341 := replay_true τ ok3340 h3340
  have h3342 : TreeTrue τ start3342 := replay_true τ ok3341 h3341
  have h3343 : TreeTrue τ start3343 := replay_true τ ok3342 h3342
  have h3344 : TreeTrue τ start3344 := replay_true τ ok3343 h3343
  have h3345 : TreeTrue τ start3345 := replay_true τ ok3344 h3344
  have h3346 : TreeTrue τ start3346 := replay_true τ ok3345 h3345
  have h3347 : TreeTrue τ start3347 := replay_true τ ok3346 h3346
  have h3348 : TreeTrue τ start3348 := replay_true τ ok3347 h3347
  have h3349 : TreeTrue τ start3349 := replay_true τ ok3348 h3348
  have h3350 : TreeTrue τ start3350 := replay_true τ ok3349 h3349
  have h3351 : TreeTrue τ start3351 := replay_true τ ok3350 h3350
  have h3352 : TreeTrue τ start3352 := replay_true τ ok3351 h3351
  have h3353 : TreeTrue τ start3353 := replay_true τ ok3352 h3352
  have h3354 : TreeTrue τ start3354 := replay_true τ ok3353 h3353
  have h3355 : TreeTrue τ start3355 := replay_true τ ok3354 h3354
  have h3356 : TreeTrue τ start3356 := replay_true τ ok3355 h3355
  have h3357 : TreeTrue τ start3357 := replay_true τ ok3356 h3356
  have h3358 : TreeTrue τ start3358 := replay_true τ ok3357 h3357
  have h3359 : TreeTrue τ start3359 := replay_true τ ok3358 h3358
  have h3360 : TreeTrue τ start3360 := cp_true τ ok3359 h3359
  exact h3360
#print axioms steps104
end Snake9.ReplayFull147
