import ReplayCheck147_02496
import ReplayCheck147_02500
import ReplayCheck147_02504
import ReplayCheck147_02508
import ReplayCheck147_02512
import ReplayCheck147_02516
import ReplayCheck147_02520
import ReplayCheck147_02524
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps78 (τ : Nat → Bool) (h2496 : TreeTrue τ start2496) : TreeTrue τ start2528 := by
  have h2497 : TreeTrue τ start2497 := replay_true τ ok2496 h2496
  have h2498 : TreeTrue τ start2498 := replay_true τ ok2497 h2497
  have h2499 : TreeTrue τ start2499 := replay_true τ ok2498 h2498
  have h2500 : TreeTrue τ start2500 := replay_true τ ok2499 h2499
  have h2501 : TreeTrue τ start2501 := replay_true τ ok2500 h2500
  have h2502 : TreeTrue τ start2502 := replay_true τ ok2501 h2501
  have h2503 : TreeTrue τ start2503 := replay_true τ ok2502 h2502
  have h2504 : TreeTrue τ start2504 := replay_true τ ok2503 h2503
  have h2505 : TreeTrue τ start2505 := replay_true τ ok2504 h2504
  have h2506 : TreeTrue τ start2506 := replay_true τ ok2505 h2505
  have h2507 : TreeTrue τ start2507 := replay_true τ ok2506 h2506
  have h2508 : TreeTrue τ start2508 := replay_true τ ok2507 h2507
  have h2509 : TreeTrue τ start2509 := replay_true τ ok2508 h2508
  have h2510 : TreeTrue τ start2510 := replay_true τ ok2509 h2509
  have h2511 : TreeTrue τ start2511 := replay_true τ ok2510 h2510
  have h2512 : TreeTrue τ start2512 := replay_true τ ok2511 h2511
  have h2513 : TreeTrue τ start2513 := replay_true τ ok2512 h2512
  have h2514 : TreeTrue τ start2514 := replay_true τ ok2513 h2513
  have h2515 : TreeTrue τ start2515 := replay_true τ ok2514 h2514
  have h2516 : TreeTrue τ start2516 := replay_true τ ok2515 h2515
  have h2517 : TreeTrue τ start2517 := replay_true τ ok2516 h2516
  have h2518 : TreeTrue τ start2518 := replay_true τ ok2517 h2517
  have h2519 : TreeTrue τ start2519 := replay_true τ ok2518 h2518
  have h2520 : TreeTrue τ start2520 := replay_true τ ok2519 h2519
  have h2521 : TreeTrue τ start2521 := replay_true τ ok2520 h2520
  have h2522 : TreeTrue τ start2522 := replay_true τ ok2521 h2521
  have h2523 : TreeTrue τ start2523 := replay_true τ ok2522 h2522
  have h2524 : TreeTrue τ start2524 := replay_true τ ok2523 h2523
  have h2525 : TreeTrue τ start2525 := replay_true τ ok2524 h2524
  have h2526 : TreeTrue τ start2526 := replay_true τ ok2525 h2525
  have h2527 : TreeTrue τ start2527 := replay_true τ ok2526 h2526
  have h2528 : TreeTrue τ start2528 := cp_true τ ok2527 h2527
  exact h2528
#print axioms steps78
end Snake9.ReplayFull147
