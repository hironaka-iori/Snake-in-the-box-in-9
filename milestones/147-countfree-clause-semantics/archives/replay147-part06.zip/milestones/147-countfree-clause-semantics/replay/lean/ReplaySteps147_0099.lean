import ReplayCheck147_03168
import ReplayCheck147_03172
import ReplayCheck147_03176
import ReplayCheck147_03180
import ReplayCheck147_03184
import ReplayCheck147_03188
import ReplayCheck147_03192
import ReplayCheck147_03196
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps99 (τ : Nat → Bool) (h3168 : TreeTrue τ start3168) : TreeTrue τ start3200 := by
  have h3169 : TreeTrue τ start3169 := replay_true τ ok3168 h3168
  have h3170 : TreeTrue τ start3170 := replay_true τ ok3169 h3169
  have h3171 : TreeTrue τ start3171 := replay_true τ ok3170 h3170
  have h3172 : TreeTrue τ start3172 := replay_true τ ok3171 h3171
  have h3173 : TreeTrue τ start3173 := replay_true τ ok3172 h3172
  have h3174 : TreeTrue τ start3174 := replay_true τ ok3173 h3173
  have h3175 : TreeTrue τ start3175 := replay_true τ ok3174 h3174
  have h3176 : TreeTrue τ start3176 := replay_true τ ok3175 h3175
  have h3177 : TreeTrue τ start3177 := replay_true τ ok3176 h3176
  have h3178 : TreeTrue τ start3178 := replay_true τ ok3177 h3177
  have h3179 : TreeTrue τ start3179 := replay_true τ ok3178 h3178
  have h3180 : TreeTrue τ start3180 := replay_true τ ok3179 h3179
  have h3181 : TreeTrue τ start3181 := replay_true τ ok3180 h3180
  have h3182 : TreeTrue τ start3182 := replay_true τ ok3181 h3181
  have h3183 : TreeTrue τ start3183 := replay_true τ ok3182 h3182
  have h3184 : TreeTrue τ start3184 := replay_true τ ok3183 h3183
  have h3185 : TreeTrue τ start3185 := replay_true τ ok3184 h3184
  have h3186 : TreeTrue τ start3186 := replay_true τ ok3185 h3185
  have h3187 : TreeTrue τ start3187 := replay_true τ ok3186 h3186
  have h3188 : TreeTrue τ start3188 := replay_true τ ok3187 h3187
  have h3189 : TreeTrue τ start3189 := replay_true τ ok3188 h3188
  have h3190 : TreeTrue τ start3190 := replay_true τ ok3189 h3189
  have h3191 : TreeTrue τ start3191 := replay_true τ ok3190 h3190
  have h3192 : TreeTrue τ start3192 := replay_true τ ok3191 h3191
  have h3193 : TreeTrue τ start3193 := replay_true τ ok3192 h3192
  have h3194 : TreeTrue τ start3194 := replay_true τ ok3193 h3193
  have h3195 : TreeTrue τ start3195 := replay_true τ ok3194 h3194
  have h3196 : TreeTrue τ start3196 := replay_true τ ok3195 h3195
  have h3197 : TreeTrue τ start3197 := replay_true τ ok3196 h3196
  have h3198 : TreeTrue τ start3198 := replay_true τ ok3197 h3197
  have h3199 : TreeTrue τ start3199 := replay_true τ ok3198 h3198
  have h3200 : TreeTrue τ start3200 := cp_true τ ok3199 h3199
  exact h3200
#print axioms steps99
end Snake9.ReplayFull147
