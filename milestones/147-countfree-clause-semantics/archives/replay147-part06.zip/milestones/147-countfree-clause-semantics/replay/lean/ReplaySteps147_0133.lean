import ReplayCheck147_04256
import ReplayCheck147_04260
import ReplayCheck147_04264
import ReplayCheck147_04268
import ReplayCheck147_04272
import ReplayCheck147_04276
import ReplayCheck147_04280
import ReplayCheck147_04284
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps133 (τ : Nat → Bool) (h4256 : TreeTrue τ start4256) : TreeTrue τ start4288 := by
  have h4257 : TreeTrue τ start4257 := replay_true τ ok4256 h4256
  have h4258 : TreeTrue τ start4258 := replay_true τ ok4257 h4257
  have h4259 : TreeTrue τ start4259 := replay_true τ ok4258 h4258
  have h4260 : TreeTrue τ start4260 := replay_true τ ok4259 h4259
  have h4261 : TreeTrue τ start4261 := replay_true τ ok4260 h4260
  have h4262 : TreeTrue τ start4262 := replay_true τ ok4261 h4261
  have h4263 : TreeTrue τ start4263 := replay_true τ ok4262 h4262
  have h4264 : TreeTrue τ start4264 := replay_true τ ok4263 h4263
  have h4265 : TreeTrue τ start4265 := replay_true τ ok4264 h4264
  have h4266 : TreeTrue τ start4266 := replay_true τ ok4265 h4265
  have h4267 : TreeTrue τ start4267 := replay_true τ ok4266 h4266
  have h4268 : TreeTrue τ start4268 := replay_true τ ok4267 h4267
  have h4269 : TreeTrue τ start4269 := replay_true τ ok4268 h4268
  have h4270 : TreeTrue τ start4270 := replay_true τ ok4269 h4269
  have h4271 : TreeTrue τ start4271 := replay_true τ ok4270 h4270
  have h4272 : TreeTrue τ start4272 := replay_true τ ok4271 h4271
  have h4273 : TreeTrue τ start4273 := replay_true τ ok4272 h4272
  have h4274 : TreeTrue τ start4274 := replay_true τ ok4273 h4273
  have h4275 : TreeTrue τ start4275 := replay_true τ ok4274 h4274
  have h4276 : TreeTrue τ start4276 := replay_true τ ok4275 h4275
  have h4277 : TreeTrue τ start4277 := replay_true τ ok4276 h4276
  have h4278 : TreeTrue τ start4278 := replay_true τ ok4277 h4277
  have h4279 : TreeTrue τ start4279 := replay_true τ ok4278 h4278
  have h4280 : TreeTrue τ start4280 := replay_true τ ok4279 h4279
  have h4281 : TreeTrue τ start4281 := replay_true τ ok4280 h4280
  have h4282 : TreeTrue τ start4282 := replay_true τ ok4281 h4281
  have h4283 : TreeTrue τ start4283 := replay_true τ ok4282 h4282
  have h4284 : TreeTrue τ start4284 := replay_true τ ok4283 h4283
  have h4285 : TreeTrue τ start4285 := replay_true τ ok4284 h4284
  have h4286 : TreeTrue τ start4286 := replay_true τ ok4285 h4285
  have h4287 : TreeTrue τ start4287 := replay_true τ ok4286 h4286
  have h4288 : TreeTrue τ start4288 := cp_true τ ok4287 h4287
  exact h4288
#print axioms steps133
end Snake9.ReplayFull147
