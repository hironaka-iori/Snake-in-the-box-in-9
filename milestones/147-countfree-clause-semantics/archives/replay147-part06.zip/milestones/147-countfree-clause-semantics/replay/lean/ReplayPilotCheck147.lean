import ReplayPilotData147
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayPilot147
open Snake9.Lrat147Replay (andB)
open Snake9.LratFast147Replay
theorem prefix_check : andB (check Snake9.ReplayData147.start proof)
    (cpOk (replay Snake9.ReplayData147.start proof) afterPrefix) = true := by
  decide +kernel
#print axioms prefix_check
end Snake9.ReplayPilot147
