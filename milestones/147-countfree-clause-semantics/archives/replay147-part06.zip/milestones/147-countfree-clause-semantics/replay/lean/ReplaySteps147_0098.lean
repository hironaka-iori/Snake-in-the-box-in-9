import ReplayCheck147_03136
import ReplayCheck147_03140
import ReplayCheck147_03144
import ReplayCheck147_03148
import ReplayCheck147_03152
import ReplayCheck147_03156
import ReplayCheck147_03160
import ReplayCheck147_03164
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps98 (τ : Nat → Bool) (h3136 : TreeTrue τ start3136) : TreeTrue τ start3168 := by
  have h3137 : TreeTrue τ start3137 := replay_true τ ok3136 h3136
  have h3138 : TreeTrue τ start3138 := replay_true τ ok3137 h3137
  have h3139 : TreeTrue τ start3139 := replay_true τ ok3138 h3138
  have h3140 : TreeTrue τ start3140 := replay_true τ ok3139 h3139
  have h3141 : TreeTrue τ start3141 := replay_true τ ok3140 h3140
  have h3142 : TreeTrue τ start3142 := replay_true τ ok3141 h3141
  have h3143 : TreeTrue τ start3143 := replay_true τ ok3142 h3142
  have h3144 : TreeTrue τ start3144 := replay_true τ ok3143 h3143
  have h3145 : TreeTrue τ start3145 := replay_true τ ok3144 h3144
  have h3146 : TreeTrue τ start3146 := replay_true τ ok3145 h3145
  have h3147 : TreeTrue τ start3147 := replay_true τ ok3146 h3146
  have h3148 : TreeTrue τ start3148 := replay_true τ ok3147 h3147
  have h3149 : TreeTrue τ start3149 := replay_true τ ok3148 h3148
  have h3150 : TreeTrue τ start3150 := replay_true τ ok3149 h3149
  have h3151 : TreeTrue τ start3151 := replay_true τ ok3150 h3150
  have h3152 : TreeTrue τ start3152 := replay_true τ ok3151 h3151
  have h3153 : TreeTrue τ start3153 := replay_true τ ok3152 h3152
  have h3154 : TreeTrue τ start3154 := replay_true τ ok3153 h3153
  have h3155 : TreeTrue τ start3155 := replay_true τ ok3154 h3154
  have h3156 : TreeTrue τ start3156 := replay_true τ ok3155 h3155
  have h3157 : TreeTrue τ start3157 := replay_true τ ok3156 h3156
  have h3158 : TreeTrue τ start3158 := replay_true τ ok3157 h3157
  have h3159 : TreeTrue τ start3159 := replay_true τ ok3158 h3158
  have h3160 : TreeTrue τ start3160 := replay_true τ ok3159 h3159
  have h3161 : TreeTrue τ start3161 := replay_true τ ok3160 h3160
  have h3162 : TreeTrue τ start3162 := replay_true τ ok3161 h3161
  have h3163 : TreeTrue τ start3163 := replay_true τ ok3162 h3162
  have h3164 : TreeTrue τ start3164 := replay_true τ ok3163 h3163
  have h3165 : TreeTrue τ start3165 := replay_true τ ok3164 h3164
  have h3166 : TreeTrue τ start3166 := replay_true τ ok3165 h3165
  have h3167 : TreeTrue τ start3167 := replay_true τ ok3166 h3166
  have h3168 : TreeTrue τ start3168 := cp_true τ ok3167 h3167
  exact h3168
#print axioms steps98
end Snake9.ReplayFull147
