import ReplayCheck147_04672
import ReplayCheck147_04676
import ReplayCheck147_04680
import ReplayCheck147_04684
import ReplayCheck147_04688
import ReplayCheck147_04692
import ReplayCheck147_04696
import ReplayCheck147_04700
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps146 (τ : Nat → Bool) (h4672 : TreeTrue τ start4672) : TreeTrue τ start4704 := by
  have h4673 : TreeTrue τ start4673 := replay_true τ ok4672 h4672
  have h4674 : TreeTrue τ start4674 := replay_true τ ok4673 h4673
  have h4675 : TreeTrue τ start4675 := replay_true τ ok4674 h4674
  have h4676 : TreeTrue τ start4676 := replay_true τ ok4675 h4675
  have h4677 : TreeTrue τ start4677 := replay_true τ ok4676 h4676
  have h4678 : TreeTrue τ start4678 := replay_true τ ok4677 h4677
  have h4679 : TreeTrue τ start4679 := replay_true τ ok4678 h4678
  have h4680 : TreeTrue τ start4680 := replay_true τ ok4679 h4679
  have h4681 : TreeTrue τ start4681 := replay_true τ ok4680 h4680
  have h4682 : TreeTrue τ start4682 := replay_true τ ok4681 h4681
  have h4683 : TreeTrue τ start4683 := replay_true τ ok4682 h4682
  have h4684 : TreeTrue τ start4684 := replay_true τ ok4683 h4683
  have h4685 : TreeTrue τ start4685 := replay_true τ ok4684 h4684
  have h4686 : TreeTrue τ start4686 := replay_true τ ok4685 h4685
  have h4687 : TreeTrue τ start4687 := replay_true τ ok4686 h4686
  have h4688 : TreeTrue τ start4688 := replay_true τ ok4687 h4687
  have h4689 : TreeTrue τ start4689 := replay_true τ ok4688 h4688
  have h4690 : TreeTrue τ start4690 := replay_true τ ok4689 h4689
  have h4691 : TreeTrue τ start4691 := replay_true τ ok4690 h4690
  have h4692 : TreeTrue τ start4692 := replay_true τ ok4691 h4691
  have h4693 : TreeTrue τ start4693 := replay_true τ ok4692 h4692
  have h4694 : TreeTrue τ start4694 := replay_true τ ok4693 h4693
  have h4695 : TreeTrue τ start4695 := replay_true τ ok4694 h4694
  have h4696 : TreeTrue τ start4696 := replay_true τ ok4695 h4695
  have h4697 : TreeTrue τ start4697 := replay_true τ ok4696 h4696
  have h4698 : TreeTrue τ start4698 := replay_true τ ok4697 h4697
  have h4699 : TreeTrue τ start4699 := replay_true τ ok4698 h4698
  have h4700 : TreeTrue τ start4700 := replay_true τ ok4699 h4699
  have h4701 : TreeTrue τ start4701 := replay_true τ ok4700 h4700
  have h4702 : TreeTrue τ start4702 := replay_true τ ok4701 h4701
  have h4703 : TreeTrue τ start4703 := replay_true τ ok4702 h4702
  have h4704 : TreeTrue τ start4704 := cp_true τ ok4703 h4703
  exact h4704
#print axioms steps146
end Snake9.ReplayFull147
