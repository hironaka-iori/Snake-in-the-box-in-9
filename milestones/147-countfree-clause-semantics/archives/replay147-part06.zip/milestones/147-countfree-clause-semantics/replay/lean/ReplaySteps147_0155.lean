import ReplayCheck147_04960
import ReplayCheck147_04964
import ReplayCheck147_04968
import ReplayCheck147_04972
import ReplayCheck147_04976
import ReplayCheck147_04980
import ReplayCheck147_04984
import ReplayCheck147_04988
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps155 (τ : Nat → Bool) (h4960 : TreeTrue τ start4960) : TreeTrue τ start4992 := by
  have h4961 : TreeTrue τ start4961 := replay_true τ ok4960 h4960
  have h4962 : TreeTrue τ start4962 := replay_true τ ok4961 h4961
  have h4963 : TreeTrue τ start4963 := replay_true τ ok4962 h4962
  have h4964 : TreeTrue τ start4964 := replay_true τ ok4963 h4963
  have h4965 : TreeTrue τ start4965 := replay_true τ ok4964 h4964
  have h4966 : TreeTrue τ start4966 := replay_true τ ok4965 h4965
  have h4967 : TreeTrue τ start4967 := replay_true τ ok4966 h4966
  have h4968 : TreeTrue τ start4968 := replay_true τ ok4967 h4967
  have h4969 : TreeTrue τ start4969 := replay_true τ ok4968 h4968
  have h4970 : TreeTrue τ start4970 := replay_true τ ok4969 h4969
  have h4971 : TreeTrue τ start4971 := replay_true τ ok4970 h4970
  have h4972 : TreeTrue τ start4972 := replay_true τ ok4971 h4971
  have h4973 : TreeTrue τ start4973 := replay_true τ ok4972 h4972
  have h4974 : TreeTrue τ start4974 := replay_true τ ok4973 h4973
  have h4975 : TreeTrue τ start4975 := replay_true τ ok4974 h4974
  have h4976 : TreeTrue τ start4976 := replay_true τ ok4975 h4975
  have h4977 : TreeTrue τ start4977 := replay_true τ ok4976 h4976
  have h4978 : TreeTrue τ start4978 := replay_true τ ok4977 h4977
  have h4979 : TreeTrue τ start4979 := replay_true τ ok4978 h4978
  have h4980 : TreeTrue τ start4980 := replay_true τ ok4979 h4979
  have h4981 : TreeTrue τ start4981 := replay_true τ ok4980 h4980
  have h4982 : TreeTrue τ start4982 := replay_true τ ok4981 h4981
  have h4983 : TreeTrue τ start4983 := replay_true τ ok4982 h4982
  have h4984 : TreeTrue τ start4984 := replay_true τ ok4983 h4983
  have h4985 : TreeTrue τ start4985 := replay_true τ ok4984 h4984
  have h4986 : TreeTrue τ start4986 := replay_true τ ok4985 h4985
  have h4987 : TreeTrue τ start4987 := replay_true τ ok4986 h4986
  have h4988 : TreeTrue τ start4988 := replay_true τ ok4987 h4987
  have h4989 : TreeTrue τ start4989 := replay_true τ ok4988 h4988
  have h4990 : TreeTrue τ start4990 := replay_true τ ok4989 h4989
  have h4991 : TreeTrue τ start4991 := replay_true τ ok4990 h4990
  have h4992 : TreeTrue τ start4992 := cp_true τ ok4991 h4991
  exact h4992
#print axioms steps155
end Snake9.ReplayFull147
