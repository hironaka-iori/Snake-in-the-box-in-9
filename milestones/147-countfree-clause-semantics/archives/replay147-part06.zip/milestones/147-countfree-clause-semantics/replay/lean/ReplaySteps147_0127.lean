import ReplayCheck147_04064
import ReplayCheck147_04068
import ReplayCheck147_04072
import ReplayCheck147_04076
import ReplayCheck147_04080
import ReplayCheck147_04084
import ReplayCheck147_04088
import ReplayCheck147_04092
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps127 (τ : Nat → Bool) (h4064 : TreeTrue τ start4064) : TreeTrue τ start4096 := by
  have h4065 : TreeTrue τ start4065 := replay_true τ ok4064 h4064
  have h4066 : TreeTrue τ start4066 := replay_true τ ok4065 h4065
  have h4067 : TreeTrue τ start4067 := replay_true τ ok4066 h4066
  have h4068 : TreeTrue τ start4068 := replay_true τ ok4067 h4067
  have h4069 : TreeTrue τ start4069 := replay_true τ ok4068 h4068
  have h4070 : TreeTrue τ start4070 := replay_true τ ok4069 h4069
  have h4071 : TreeTrue τ start4071 := replay_true τ ok4070 h4070
  have h4072 : TreeTrue τ start4072 := replay_true τ ok4071 h4071
  have h4073 : TreeTrue τ start4073 := replay_true τ ok4072 h4072
  have h4074 : TreeTrue τ start4074 := replay_true τ ok4073 h4073
  have h4075 : TreeTrue τ start4075 := replay_true τ ok4074 h4074
  have h4076 : TreeTrue τ start4076 := replay_true τ ok4075 h4075
  have h4077 : TreeTrue τ start4077 := replay_true τ ok4076 h4076
  have h4078 : TreeTrue τ start4078 := replay_true τ ok4077 h4077
  have h4079 : TreeTrue τ start4079 := replay_true τ ok4078 h4078
  have h4080 : TreeTrue τ start4080 := replay_true τ ok4079 h4079
  have h4081 : TreeTrue τ start4081 := replay_true τ ok4080 h4080
  have h4082 : TreeTrue τ start4082 := replay_true τ ok4081 h4081
  have h4083 : TreeTrue τ start4083 := replay_true τ ok4082 h4082
  have h4084 : TreeTrue τ start4084 := replay_true τ ok4083 h4083
  have h4085 : TreeTrue τ start4085 := replay_true τ ok4084 h4084
  have h4086 : TreeTrue τ start4086 := replay_true τ ok4085 h4085
  have h4087 : TreeTrue τ start4087 := replay_true τ ok4086 h4086
  have h4088 : TreeTrue τ start4088 := replay_true τ ok4087 h4087
  have h4089 : TreeTrue τ start4089 := replay_true τ ok4088 h4088
  have h4090 : TreeTrue τ start4090 := replay_true τ ok4089 h4089
  have h4091 : TreeTrue τ start4091 := replay_true τ ok4090 h4090
  have h4092 : TreeTrue τ start4092 := replay_true τ ok4091 h4091
  have h4093 : TreeTrue τ start4093 := replay_true τ ok4092 h4092
  have h4094 : TreeTrue τ start4094 := replay_true τ ok4093 h4093
  have h4095 : TreeTrue τ start4095 := replay_true τ ok4094 h4094
  have h4096 : TreeTrue τ start4096 := cp_true τ ok4095 h4095
  exact h4096
#print axioms steps127
end Snake9.ReplayFull147
