import ReplayParts14701
import ReplayTools147
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayData147
theorem part8_slice : input8.clauses = ((Snake9.LocalWindow.ShareWindow146.raw8 ++ Snake9.LocalWindow.ShareWindow146.raw9).drop 7).take 127 := by
  rw [part8_clauses]
  rfl
theorem part8_true (τ : Nat → Bool)
    (h8 : Snake9.LocalWindow.ShareWindow146.raw8.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h9 : Snake9.LocalWindow.ShareWindow146.raw9.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part8 := by
  rw [← part8_build]
  apply build_true_of_slice τ input8 (Snake9.LocalWindow.ShareWindow146.raw8 ++ Snake9.LocalWindow.ShareWindow146.raw9) 7 127 part8_slice
  rw [List.all_append]
  rw [h8, h9]
  rfl
#print axioms part8_true
theorem part9_slice : input9.clauses = ((Snake9.LocalWindow.ShareWindow146.raw9 ++ Snake9.LocalWindow.ShareWindow146.raw10).drop 6).take 127 := by
  rw [part9_clauses]
  rfl
theorem part9_true (τ : Nat → Bool)
    (h9 : Snake9.LocalWindow.ShareWindow146.raw9.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h10 : Snake9.LocalWindow.ShareWindow146.raw10.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part9 := by
  rw [← part9_build]
  apply build_true_of_slice τ input9 (Snake9.LocalWindow.ShareWindow146.raw9 ++ Snake9.LocalWindow.ShareWindow146.raw10) 6 127 part9_slice
  rw [List.all_append]
  rw [h9, h10]
  rfl
#print axioms part9_true
theorem part10_slice : input10.clauses = ((Snake9.LocalWindow.ShareWindow146.raw10 ++ Snake9.LocalWindow.ShareWindow146.raw11).drop 6).take 127 := by
  rw [part10_clauses]
  rfl
theorem part10_true (τ : Nat → Bool)
    (h10 : Snake9.LocalWindow.ShareWindow146.raw10.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h11 : Snake9.LocalWindow.ShareWindow146.raw11.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part10 := by
  rw [← part10_build]
  apply build_true_of_slice τ input10 (Snake9.LocalWindow.ShareWindow146.raw10 ++ Snake9.LocalWindow.ShareWindow146.raw11) 6 127 part10_slice
  rw [List.all_append]
  rw [h10, h11]
  rfl
#print axioms part10_true
theorem part11_slice : input11.clauses = ((Snake9.LocalWindow.ShareWindow146.raw11 ++ Snake9.LocalWindow.ShareWindow146.raw12).drop 5).take 127 := by
  rw [part11_clauses]
  rfl
theorem part11_true (τ : Nat → Bool)
    (h11 : Snake9.LocalWindow.ShareWindow146.raw11.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h12 : Snake9.LocalWindow.ShareWindow146.raw12.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part11 := by
  rw [← part11_build]
  apply build_true_of_slice τ input11 (Snake9.LocalWindow.ShareWindow146.raw11 ++ Snake9.LocalWindow.ShareWindow146.raw12) 5 127 part11_slice
  rw [List.all_append]
  rw [h11, h12]
  rfl
#print axioms part11_true
theorem part12_slice : input12.clauses = ((Snake9.LocalWindow.ShareWindow146.raw12 ++ Snake9.LocalWindow.ShareWindow146.raw13).drop 6).take 127 := by
  rw [part12_clauses]
  rfl
theorem part12_true (τ : Nat → Bool)
    (h12 : Snake9.LocalWindow.ShareWindow146.raw12.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h13 : Snake9.LocalWindow.ShareWindow146.raw13.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part12 := by
  rw [← part12_build]
  apply build_true_of_slice τ input12 (Snake9.LocalWindow.ShareWindow146.raw12 ++ Snake9.LocalWindow.ShareWindow146.raw13) 6 127 part12_slice
  rw [List.all_append]
  rw [h12, h13]
  rfl
#print axioms part12_true
theorem part13_slice : input13.clauses = ((Snake9.LocalWindow.ShareWindow146.raw13 ++ Snake9.LocalWindow.ShareWindow146.raw14).drop 5).take 127 := by
  rw [part13_clauses]
  rfl
theorem part13_true (τ : Nat → Bool)
    (h13 : Snake9.LocalWindow.ShareWindow146.raw13.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h14 : Snake9.LocalWindow.ShareWindow146.raw14.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part13 := by
  rw [← part13_build]
  apply build_true_of_slice τ input13 (Snake9.LocalWindow.ShareWindow146.raw13 ++ Snake9.LocalWindow.ShareWindow146.raw14) 5 127 part13_slice
  rw [List.all_append]
  rw [h13, h14]
  rfl
#print axioms part13_true
theorem part14_slice : input14.clauses = ((Snake9.LocalWindow.ShareWindow146.raw14 ++ Snake9.LocalWindow.ShareWindow146.raw15).drop 5).take 127 := by
  rw [part14_clauses]
  rfl
theorem part14_true (τ : Nat → Bool)
    (h14 : Snake9.LocalWindow.ShareWindow146.raw14.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h15 : Snake9.LocalWindow.ShareWindow146.raw15.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part14 := by
  rw [← part14_build]
  apply build_true_of_slice τ input14 (Snake9.LocalWindow.ShareWindow146.raw14 ++ Snake9.LocalWindow.ShareWindow146.raw15) 5 127 part14_slice
  rw [List.all_append]
  rw [h14, h15]
  rfl
#print axioms part14_true
theorem part15_slice : input15.clauses = ((Snake9.LocalWindow.ShareWindow146.raw15 ++ Snake9.LocalWindow.ShareWindow146.raw16).drop 4).take 127 := by
  rw [part15_clauses]
  rfl
theorem part15_true (τ : Nat → Bool)
    (h15 : Snake9.LocalWindow.ShareWindow146.raw15.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h16 : Snake9.LocalWindow.ShareWindow146.raw16.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part15 := by
  rw [← part15_build]
  apply build_true_of_slice τ input15 (Snake9.LocalWindow.ShareWindow146.raw15 ++ Snake9.LocalWindow.ShareWindow146.raw16) 4 127 part15_slice
  rw [List.all_append]
  rw [h15, h16]
  rfl
#print axioms part15_true
end Snake9.ReplayData147
