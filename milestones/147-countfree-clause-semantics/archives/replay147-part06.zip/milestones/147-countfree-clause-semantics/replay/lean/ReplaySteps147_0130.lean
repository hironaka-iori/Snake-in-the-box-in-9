import ReplayCheck147_04160
import ReplayCheck147_04164
import ReplayCheck147_04168
import ReplayCheck147_04172
import ReplayCheck147_04176
import ReplayCheck147_04180
import ReplayCheck147_04184
import ReplayCheck147_04188
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps130 (τ : Nat → Bool) (h4160 : TreeTrue τ start4160) : TreeTrue τ start4192 := by
  have h4161 : TreeTrue τ start4161 := replay_true τ ok4160 h4160
  have h4162 : TreeTrue τ start4162 := replay_true τ ok4161 h4161
  have h4163 : TreeTrue τ start4163 := replay_true τ ok4162 h4162
  have h4164 : TreeTrue τ start4164 := replay_true τ ok4163 h4163
  have h4165 : TreeTrue τ start4165 := replay_true τ ok4164 h4164
  have h4166 : TreeTrue τ start4166 := replay_true τ ok4165 h4165
  have h4167 : TreeTrue τ start4167 := replay_true τ ok4166 h4166
  have h4168 : TreeTrue τ start4168 := replay_true τ ok4167 h4167
  have h4169 : TreeTrue τ start4169 := replay_true τ ok4168 h4168
  have h4170 : TreeTrue τ start4170 := replay_true τ ok4169 h4169
  have h4171 : TreeTrue τ start4171 := replay_true τ ok4170 h4170
  have h4172 : TreeTrue τ start4172 := replay_true τ ok4171 h4171
  have h4173 : TreeTrue τ start4173 := replay_true τ ok4172 h4172
  have h4174 : TreeTrue τ start4174 := replay_true τ ok4173 h4173
  have h4175 : TreeTrue τ start4175 := replay_true τ ok4174 h4174
  have h4176 : TreeTrue τ start4176 := replay_true τ ok4175 h4175
  have h4177 : TreeTrue τ start4177 := replay_true τ ok4176 h4176
  have h4178 : TreeTrue τ start4178 := replay_true τ ok4177 h4177
  have h4179 : TreeTrue τ start4179 := replay_true τ ok4178 h4178
  have h4180 : TreeTrue τ start4180 := replay_true τ ok4179 h4179
  have h4181 : TreeTrue τ start4181 := replay_true τ ok4180 h4180
  have h4182 : TreeTrue τ start4182 := replay_true τ ok4181 h4181
  have h4183 : TreeTrue τ start4183 := replay_true τ ok4182 h4182
  have h4184 : TreeTrue τ start4184 := replay_true τ ok4183 h4183
  have h4185 : TreeTrue τ start4185 := replay_true τ ok4184 h4184
  have h4186 : TreeTrue τ start4186 := replay_true τ ok4185 h4185
  have h4187 : TreeTrue τ start4187 := replay_true τ ok4186 h4186
  have h4188 : TreeTrue τ start4188 := replay_true τ ok4187 h4187
  have h4189 : TreeTrue τ start4189 := replay_true τ ok4188 h4188
  have h4190 : TreeTrue τ start4190 := replay_true τ ok4189 h4189
  have h4191 : TreeTrue τ start4191 := replay_true τ ok4190 h4190
  have h4192 : TreeTrue τ start4192 := cp_true τ ok4191 h4191
  exact h4192
#print axioms steps130
end Snake9.ReplayFull147
