import ReplayCheck147_04320
import ReplayCheck147_04324
import ReplayCheck147_04328
import ReplayCheck147_04332
import ReplayCheck147_04336
import ReplayCheck147_04340
import ReplayCheck147_04344
import ReplayCheck147_04348
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps135 (τ : Nat → Bool) (h4320 : TreeTrue τ start4320) : TreeTrue τ start4352 := by
  have h4321 : TreeTrue τ start4321 := replay_true τ ok4320 h4320
  have h4322 : TreeTrue τ start4322 := replay_true τ ok4321 h4321
  have h4323 : TreeTrue τ start4323 := replay_true τ ok4322 h4322
  have h4324 : TreeTrue τ start4324 := replay_true τ ok4323 h4323
  have h4325 : TreeTrue τ start4325 := replay_true τ ok4324 h4324
  have h4326 : TreeTrue τ start4326 := replay_true τ ok4325 h4325
  have h4327 : TreeTrue τ start4327 := replay_true τ ok4326 h4326
  have h4328 : TreeTrue τ start4328 := replay_true τ ok4327 h4327
  have h4329 : TreeTrue τ start4329 := replay_true τ ok4328 h4328
  have h4330 : TreeTrue τ start4330 := replay_true τ ok4329 h4329
  have h4331 : TreeTrue τ start4331 := replay_true τ ok4330 h4330
  have h4332 : TreeTrue τ start4332 := replay_true τ ok4331 h4331
  have h4333 : TreeTrue τ start4333 := replay_true τ ok4332 h4332
  have h4334 : TreeTrue τ start4334 := replay_true τ ok4333 h4333
  have h4335 : TreeTrue τ start4335 := replay_true τ ok4334 h4334
  have h4336 : TreeTrue τ start4336 := replay_true τ ok4335 h4335
  have h4337 : TreeTrue τ start4337 := replay_true τ ok4336 h4336
  have h4338 : TreeTrue τ start4338 := replay_true τ ok4337 h4337
  have h4339 : TreeTrue τ start4339 := replay_true τ ok4338 h4338
  have h4340 : TreeTrue τ start4340 := replay_true τ ok4339 h4339
  have h4341 : TreeTrue τ start4341 := replay_true τ ok4340 h4340
  have h4342 : TreeTrue τ start4342 := replay_true τ ok4341 h4341
  have h4343 : TreeTrue τ start4343 := replay_true τ ok4342 h4342
  have h4344 : TreeTrue τ start4344 := replay_true τ ok4343 h4343
  have h4345 : TreeTrue τ start4345 := replay_true τ ok4344 h4344
  have h4346 : TreeTrue τ start4346 := replay_true τ ok4345 h4345
  have h4347 : TreeTrue τ start4347 := replay_true τ ok4346 h4346
  have h4348 : TreeTrue τ start4348 := replay_true τ ok4347 h4347
  have h4349 : TreeTrue τ start4349 := replay_true τ ok4348 h4348
  have h4350 : TreeTrue τ start4350 := replay_true τ ok4349 h4349
  have h4351 : TreeTrue τ start4351 := replay_true τ ok4350 h4350
  have h4352 : TreeTrue τ start4352 := cp_true τ ok4351 h4351
  exact h4352
#print axioms steps135
end Snake9.ReplayFull147
