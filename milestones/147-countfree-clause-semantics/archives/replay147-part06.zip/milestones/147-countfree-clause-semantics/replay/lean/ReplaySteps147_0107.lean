import ReplayCheck147_03424
import ReplayCheck147_03428
import ReplayCheck147_03432
import ReplayCheck147_03436
import ReplayCheck147_03440
import ReplayCheck147_03444
import ReplayCheck147_03448
import ReplayCheck147_03452
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps107 (τ : Nat → Bool) (h3424 : TreeTrue τ start3424) : TreeTrue τ start3456 := by
  have h3425 : TreeTrue τ start3425 := replay_true τ ok3424 h3424
  have h3426 : TreeTrue τ start3426 := replay_true τ ok3425 h3425
  have h3427 : TreeTrue τ start3427 := replay_true τ ok3426 h3426
  have h3428 : TreeTrue τ start3428 := replay_true τ ok3427 h3427
  have h3429 : TreeTrue τ start3429 := replay_true τ ok3428 h3428
  have h3430 : TreeTrue τ start3430 := replay_true τ ok3429 h3429
  have h3431 : TreeTrue τ start3431 := replay_true τ ok3430 h3430
  have h3432 : TreeTrue τ start3432 := replay_true τ ok3431 h3431
  have h3433 : TreeTrue τ start3433 := replay_true τ ok3432 h3432
  have h3434 : TreeTrue τ start3434 := replay_true τ ok3433 h3433
  have h3435 : TreeTrue τ start3435 := replay_true τ ok3434 h3434
  have h3436 : TreeTrue τ start3436 := replay_true τ ok3435 h3435
  have h3437 : TreeTrue τ start3437 := replay_true τ ok3436 h3436
  have h3438 : TreeTrue τ start3438 := replay_true τ ok3437 h3437
  have h3439 : TreeTrue τ start3439 := replay_true τ ok3438 h3438
  have h3440 : TreeTrue τ start3440 := replay_true τ ok3439 h3439
  have h3441 : TreeTrue τ start3441 := replay_true τ ok3440 h3440
  have h3442 : TreeTrue τ start3442 := replay_true τ ok3441 h3441
  have h3443 : TreeTrue τ start3443 := replay_true τ ok3442 h3442
  have h3444 : TreeTrue τ start3444 := replay_true τ ok3443 h3443
  have h3445 : TreeTrue τ start3445 := replay_true τ ok3444 h3444
  have h3446 : TreeTrue τ start3446 := replay_true τ ok3445 h3445
  have h3447 : TreeTrue τ start3447 := replay_true τ ok3446 h3446
  have h3448 : TreeTrue τ start3448 := replay_true τ ok3447 h3447
  have h3449 : TreeTrue τ start3449 := replay_true τ ok3448 h3448
  have h3450 : TreeTrue τ start3450 := replay_true τ ok3449 h3449
  have h3451 : TreeTrue τ start3451 := replay_true τ ok3450 h3450
  have h3452 : TreeTrue τ start3452 := replay_true τ ok3451 h3451
  have h3453 : TreeTrue τ start3453 := replay_true τ ok3452 h3452
  have h3454 : TreeTrue τ start3454 := replay_true τ ok3453 h3453
  have h3455 : TreeTrue τ start3455 := replay_true τ ok3454 h3454
  have h3456 : TreeTrue τ start3456 := cp_true τ ok3455 h3455
  exact h3456
#print axioms steps107
end Snake9.ReplayFull147
