import ReplayCheck147_03232
import ReplayCheck147_03236
import ReplayCheck147_03240
import ReplayCheck147_03244
import ReplayCheck147_03248
import ReplayCheck147_03252
import ReplayCheck147_03256
import ReplayCheck147_03260
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps101 (τ : Nat → Bool) (h3232 : TreeTrue τ start3232) : TreeTrue τ start3264 := by
  have h3233 : TreeTrue τ start3233 := replay_true τ ok3232 h3232
  have h3234 : TreeTrue τ start3234 := replay_true τ ok3233 h3233
  have h3235 : TreeTrue τ start3235 := replay_true τ ok3234 h3234
  have h3236 : TreeTrue τ start3236 := replay_true τ ok3235 h3235
  have h3237 : TreeTrue τ start3237 := replay_true τ ok3236 h3236
  have h3238 : TreeTrue τ start3238 := replay_true τ ok3237 h3237
  have h3239 : TreeTrue τ start3239 := replay_true τ ok3238 h3238
  have h3240 : TreeTrue τ start3240 := replay_true τ ok3239 h3239
  have h3241 : TreeTrue τ start3241 := replay_true τ ok3240 h3240
  have h3242 : TreeTrue τ start3242 := replay_true τ ok3241 h3241
  have h3243 : TreeTrue τ start3243 := replay_true τ ok3242 h3242
  have h3244 : TreeTrue τ start3244 := replay_true τ ok3243 h3243
  have h3245 : TreeTrue τ start3245 := replay_true τ ok3244 h3244
  have h3246 : TreeTrue τ start3246 := replay_true τ ok3245 h3245
  have h3247 : TreeTrue τ start3247 := replay_true τ ok3246 h3246
  have h3248 : TreeTrue τ start3248 := replay_true τ ok3247 h3247
  have h3249 : TreeTrue τ start3249 := replay_true τ ok3248 h3248
  have h3250 : TreeTrue τ start3250 := replay_true τ ok3249 h3249
  have h3251 : TreeTrue τ start3251 := replay_true τ ok3250 h3250
  have h3252 : TreeTrue τ start3252 := replay_true τ ok3251 h3251
  have h3253 : TreeTrue τ start3253 := replay_true τ ok3252 h3252
  have h3254 : TreeTrue τ start3254 := replay_true τ ok3253 h3253
  have h3255 : TreeTrue τ start3255 := replay_true τ ok3254 h3254
  have h3256 : TreeTrue τ start3256 := replay_true τ ok3255 h3255
  have h3257 : TreeTrue τ start3257 := replay_true τ ok3256 h3256
  have h3258 : TreeTrue τ start3258 := replay_true τ ok3257 h3257
  have h3259 : TreeTrue τ start3259 := replay_true τ ok3258 h3258
  have h3260 : TreeTrue τ start3260 := replay_true τ ok3259 h3259
  have h3261 : TreeTrue τ start3261 := replay_true τ ok3260 h3260
  have h3262 : TreeTrue τ start3262 := replay_true τ ok3261 h3261
  have h3263 : TreeTrue τ start3263 := replay_true τ ok3262 h3262
  have h3264 : TreeTrue τ start3264 := cp_true τ ok3263 h3263
  exact h3264
#print axioms steps101
end Snake9.ReplayFull147
