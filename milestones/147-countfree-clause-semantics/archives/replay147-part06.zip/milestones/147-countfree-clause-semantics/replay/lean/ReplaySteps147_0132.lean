import ReplayCheck147_04224
import ReplayCheck147_04228
import ReplayCheck147_04232
import ReplayCheck147_04236
import ReplayCheck147_04240
import ReplayCheck147_04244
import ReplayCheck147_04248
import ReplayCheck147_04252
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps132 (τ : Nat → Bool) (h4224 : TreeTrue τ start4224) : TreeTrue τ start4256 := by
  have h4225 : TreeTrue τ start4225 := replay_true τ ok4224 h4224
  have h4226 : TreeTrue τ start4226 := replay_true τ ok4225 h4225
  have h4227 : TreeTrue τ start4227 := replay_true τ ok4226 h4226
  have h4228 : TreeTrue τ start4228 := replay_true τ ok4227 h4227
  have h4229 : TreeTrue τ start4229 := replay_true τ ok4228 h4228
  have h4230 : TreeTrue τ start4230 := replay_true τ ok4229 h4229
  have h4231 : TreeTrue τ start4231 := replay_true τ ok4230 h4230
  have h4232 : TreeTrue τ start4232 := replay_true τ ok4231 h4231
  have h4233 : TreeTrue τ start4233 := replay_true τ ok4232 h4232
  have h4234 : TreeTrue τ start4234 := replay_true τ ok4233 h4233
  have h4235 : TreeTrue τ start4235 := replay_true τ ok4234 h4234
  have h4236 : TreeTrue τ start4236 := replay_true τ ok4235 h4235
  have h4237 : TreeTrue τ start4237 := replay_true τ ok4236 h4236
  have h4238 : TreeTrue τ start4238 := replay_true τ ok4237 h4237
  have h4239 : TreeTrue τ start4239 := replay_true τ ok4238 h4238
  have h4240 : TreeTrue τ start4240 := replay_true τ ok4239 h4239
  have h4241 : TreeTrue τ start4241 := replay_true τ ok4240 h4240
  have h4242 : TreeTrue τ start4242 := replay_true τ ok4241 h4241
  have h4243 : TreeTrue τ start4243 := replay_true τ ok4242 h4242
  have h4244 : TreeTrue τ start4244 := replay_true τ ok4243 h4243
  have h4245 : TreeTrue τ start4245 := replay_true τ ok4244 h4244
  have h4246 : TreeTrue τ start4246 := replay_true τ ok4245 h4245
  have h4247 : TreeTrue τ start4247 := replay_true τ ok4246 h4246
  have h4248 : TreeTrue τ start4248 := replay_true τ ok4247 h4247
  have h4249 : TreeTrue τ start4249 := replay_true τ ok4248 h4248
  have h4250 : TreeTrue τ start4250 := replay_true τ ok4249 h4249
  have h4251 : TreeTrue τ start4251 := replay_true τ ok4250 h4250
  have h4252 : TreeTrue τ start4252 := replay_true τ ok4251 h4251
  have h4253 : TreeTrue τ start4253 := replay_true τ ok4252 h4252
  have h4254 : TreeTrue τ start4254 := replay_true τ ok4253 h4253
  have h4255 : TreeTrue τ start4255 := replay_true τ ok4254 h4254
  have h4256 : TreeTrue τ start4256 := cp_true τ ok4255 h4255
  exact h4256
#print axioms steps132
end Snake9.ReplayFull147
