import ReplayCheck147_02784
import ReplayCheck147_02788
import ReplayCheck147_02792
import ReplayCheck147_02796
import ReplayCheck147_02800
import ReplayCheck147_02804
import ReplayCheck147_02808
import ReplayCheck147_02812
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps87 (τ : Nat → Bool) (h2784 : TreeTrue τ start2784) : TreeTrue τ start2816 := by
  have h2785 : TreeTrue τ start2785 := replay_true τ ok2784 h2784
  have h2786 : TreeTrue τ start2786 := replay_true τ ok2785 h2785
  have h2787 : TreeTrue τ start2787 := replay_true τ ok2786 h2786
  have h2788 : TreeTrue τ start2788 := replay_true τ ok2787 h2787
  have h2789 : TreeTrue τ start2789 := replay_true τ ok2788 h2788
  have h2790 : TreeTrue τ start2790 := replay_true τ ok2789 h2789
  have h2791 : TreeTrue τ start2791 := replay_true τ ok2790 h2790
  have h2792 : TreeTrue τ start2792 := replay_true τ ok2791 h2791
  have h2793 : TreeTrue τ start2793 := replay_true τ ok2792 h2792
  have h2794 : TreeTrue τ start2794 := replay_true τ ok2793 h2793
  have h2795 : TreeTrue τ start2795 := replay_true τ ok2794 h2794
  have h2796 : TreeTrue τ start2796 := replay_true τ ok2795 h2795
  have h2797 : TreeTrue τ start2797 := replay_true τ ok2796 h2796
  have h2798 : TreeTrue τ start2798 := replay_true τ ok2797 h2797
  have h2799 : TreeTrue τ start2799 := replay_true τ ok2798 h2798
  have h2800 : TreeTrue τ start2800 := replay_true τ ok2799 h2799
  have h2801 : TreeTrue τ start2801 := replay_true τ ok2800 h2800
  have h2802 : TreeTrue τ start2802 := replay_true τ ok2801 h2801
  have h2803 : TreeTrue τ start2803 := replay_true τ ok2802 h2802
  have h2804 : TreeTrue τ start2804 := replay_true τ ok2803 h2803
  have h2805 : TreeTrue τ start2805 := replay_true τ ok2804 h2804
  have h2806 : TreeTrue τ start2806 := replay_true τ ok2805 h2805
  have h2807 : TreeTrue τ start2807 := replay_true τ ok2806 h2806
  have h2808 : TreeTrue τ start2808 := replay_true τ ok2807 h2807
  have h2809 : TreeTrue τ start2809 := replay_true τ ok2808 h2808
  have h2810 : TreeTrue τ start2810 := replay_true τ ok2809 h2809
  have h2811 : TreeTrue τ start2811 := replay_true τ ok2810 h2810
  have h2812 : TreeTrue τ start2812 := replay_true τ ok2811 h2811
  have h2813 : TreeTrue τ start2813 := replay_true τ ok2812 h2812
  have h2814 : TreeTrue τ start2814 := replay_true τ ok2813 h2813
  have h2815 : TreeTrue τ start2815 := replay_true τ ok2814 h2814
  have h2816 : TreeTrue τ start2816 := cp_true τ ok2815 h2815
  exact h2816
#print axioms steps87
end Snake9.ReplayFull147
