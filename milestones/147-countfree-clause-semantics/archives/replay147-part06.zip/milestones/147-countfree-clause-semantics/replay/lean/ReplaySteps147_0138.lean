import ReplayCheck147_04416
import ReplayCheck147_04420
import ReplayCheck147_04424
import ReplayCheck147_04428
import ReplayCheck147_04432
import ReplayCheck147_04436
import ReplayCheck147_04440
import ReplayCheck147_04444
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps138 (τ : Nat → Bool) (h4416 : TreeTrue τ start4416) : TreeTrue τ start4448 := by
  have h4417 : TreeTrue τ start4417 := replay_true τ ok4416 h4416
  have h4418 : TreeTrue τ start4418 := replay_true τ ok4417 h4417
  have h4419 : TreeTrue τ start4419 := replay_true τ ok4418 h4418
  have h4420 : TreeTrue τ start4420 := replay_true τ ok4419 h4419
  have h4421 : TreeTrue τ start4421 := replay_true τ ok4420 h4420
  have h4422 : TreeTrue τ start4422 := replay_true τ ok4421 h4421
  have h4423 : TreeTrue τ start4423 := replay_true τ ok4422 h4422
  have h4424 : TreeTrue τ start4424 := replay_true τ ok4423 h4423
  have h4425 : TreeTrue τ start4425 := replay_true τ ok4424 h4424
  have h4426 : TreeTrue τ start4426 := replay_true τ ok4425 h4425
  have h4427 : TreeTrue τ start4427 := replay_true τ ok4426 h4426
  have h4428 : TreeTrue τ start4428 := replay_true τ ok4427 h4427
  have h4429 : TreeTrue τ start4429 := replay_true τ ok4428 h4428
  have h4430 : TreeTrue τ start4430 := replay_true τ ok4429 h4429
  have h4431 : TreeTrue τ start4431 := replay_true τ ok4430 h4430
  have h4432 : TreeTrue τ start4432 := replay_true τ ok4431 h4431
  have h4433 : TreeTrue τ start4433 := replay_true τ ok4432 h4432
  have h4434 : TreeTrue τ start4434 := replay_true τ ok4433 h4433
  have h4435 : TreeTrue τ start4435 := replay_true τ ok4434 h4434
  have h4436 : TreeTrue τ start4436 := replay_true τ ok4435 h4435
  have h4437 : TreeTrue τ start4437 := replay_true τ ok4436 h4436
  have h4438 : TreeTrue τ start4438 := replay_true τ ok4437 h4437
  have h4439 : TreeTrue τ start4439 := replay_true τ ok4438 h4438
  have h4440 : TreeTrue τ start4440 := replay_true τ ok4439 h4439
  have h4441 : TreeTrue τ start4441 := replay_true τ ok4440 h4440
  have h4442 : TreeTrue τ start4442 := replay_true τ ok4441 h4441
  have h4443 : TreeTrue τ start4443 := replay_true τ ok4442 h4442
  have h4444 : TreeTrue τ start4444 := replay_true τ ok4443 h4443
  have h4445 : TreeTrue τ start4445 := replay_true τ ok4444 h4444
  have h4446 : TreeTrue τ start4446 := replay_true τ ok4445 h4445
  have h4447 : TreeTrue τ start4447 := replay_true τ ok4446 h4446
  have h4448 : TreeTrue τ start4448 := cp_true τ ok4447 h4447
  exact h4448
#print axioms steps138
end Snake9.ReplayFull147
