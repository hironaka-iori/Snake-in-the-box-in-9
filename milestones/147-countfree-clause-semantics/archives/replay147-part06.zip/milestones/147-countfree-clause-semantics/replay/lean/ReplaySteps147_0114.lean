import ReplayCheck147_03648
import ReplayCheck147_03652
import ReplayCheck147_03656
import ReplayCheck147_03660
import ReplayCheck147_03664
import ReplayCheck147_03668
import ReplayCheck147_03672
import ReplayCheck147_03676
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps114 (τ : Nat → Bool) (h3648 : TreeTrue τ start3648) : TreeTrue τ start3680 := by
  have h3649 : TreeTrue τ start3649 := replay_true τ ok3648 h3648
  have h3650 : TreeTrue τ start3650 := replay_true τ ok3649 h3649
  have h3651 : TreeTrue τ start3651 := replay_true τ ok3650 h3650
  have h3652 : TreeTrue τ start3652 := replay_true τ ok3651 h3651
  have h3653 : TreeTrue τ start3653 := replay_true τ ok3652 h3652
  have h3654 : TreeTrue τ start3654 := replay_true τ ok3653 h3653
  have h3655 : TreeTrue τ start3655 := replay_true τ ok3654 h3654
  have h3656 : TreeTrue τ start3656 := replay_true τ ok3655 h3655
  have h3657 : TreeTrue τ start3657 := replay_true τ ok3656 h3656
  have h3658 : TreeTrue τ start3658 := replay_true τ ok3657 h3657
  have h3659 : TreeTrue τ start3659 := replay_true τ ok3658 h3658
  have h3660 : TreeTrue τ start3660 := replay_true τ ok3659 h3659
  have h3661 : TreeTrue τ start3661 := replay_true τ ok3660 h3660
  have h3662 : TreeTrue τ start3662 := replay_true τ ok3661 h3661
  have h3663 : TreeTrue τ start3663 := replay_true τ ok3662 h3662
  have h3664 : TreeTrue τ start3664 := replay_true τ ok3663 h3663
  have h3665 : TreeTrue τ start3665 := replay_true τ ok3664 h3664
  have h3666 : TreeTrue τ start3666 := replay_true τ ok3665 h3665
  have h3667 : TreeTrue τ start3667 := replay_true τ ok3666 h3666
  have h3668 : TreeTrue τ start3668 := replay_true τ ok3667 h3667
  have h3669 : TreeTrue τ start3669 := replay_true τ ok3668 h3668
  have h3670 : TreeTrue τ start3670 := replay_true τ ok3669 h3669
  have h3671 : TreeTrue τ start3671 := replay_true τ ok3670 h3670
  have h3672 : TreeTrue τ start3672 := replay_true τ ok3671 h3671
  have h3673 : TreeTrue τ start3673 := replay_true τ ok3672 h3672
  have h3674 : TreeTrue τ start3674 := replay_true τ ok3673 h3673
  have h3675 : TreeTrue τ start3675 := replay_true τ ok3674 h3674
  have h3676 : TreeTrue τ start3676 := replay_true τ ok3675 h3675
  have h3677 : TreeTrue τ start3677 := replay_true τ ok3676 h3676
  have h3678 : TreeTrue τ start3678 := replay_true τ ok3677 h3677
  have h3679 : TreeTrue τ start3679 := replay_true τ ok3678 h3678
  have h3680 : TreeTrue τ start3680 := cp_true τ ok3679 h3679
  exact h3680
#print axioms steps114
end Snake9.ReplayFull147
