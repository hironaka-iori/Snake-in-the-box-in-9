import ReplayCheck147_03968
import ReplayCheck147_03972
import ReplayCheck147_03976
import ReplayCheck147_03980
import ReplayCheck147_03984
import ReplayCheck147_03988
import ReplayCheck147_03992
import ReplayCheck147_03996
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps124 (τ : Nat → Bool) (h3968 : TreeTrue τ start3968) : TreeTrue τ start4000 := by
  have h3969 : TreeTrue τ start3969 := replay_true τ ok3968 h3968
  have h3970 : TreeTrue τ start3970 := replay_true τ ok3969 h3969
  have h3971 : TreeTrue τ start3971 := replay_true τ ok3970 h3970
  have h3972 : TreeTrue τ start3972 := replay_true τ ok3971 h3971
  have h3973 : TreeTrue τ start3973 := replay_true τ ok3972 h3972
  have h3974 : TreeTrue τ start3974 := replay_true τ ok3973 h3973
  have h3975 : TreeTrue τ start3975 := replay_true τ ok3974 h3974
  have h3976 : TreeTrue τ start3976 := replay_true τ ok3975 h3975
  have h3977 : TreeTrue τ start3977 := replay_true τ ok3976 h3976
  have h3978 : TreeTrue τ start3978 := replay_true τ ok3977 h3977
  have h3979 : TreeTrue τ start3979 := replay_true τ ok3978 h3978
  have h3980 : TreeTrue τ start3980 := replay_true τ ok3979 h3979
  have h3981 : TreeTrue τ start3981 := replay_true τ ok3980 h3980
  have h3982 : TreeTrue τ start3982 := replay_true τ ok3981 h3981
  have h3983 : TreeTrue τ start3983 := replay_true τ ok3982 h3982
  have h3984 : TreeTrue τ start3984 := replay_true τ ok3983 h3983
  have h3985 : TreeTrue τ start3985 := replay_true τ ok3984 h3984
  have h3986 : TreeTrue τ start3986 := replay_true τ ok3985 h3985
  have h3987 : TreeTrue τ start3987 := replay_true τ ok3986 h3986
  have h3988 : TreeTrue τ start3988 := replay_true τ ok3987 h3987
  have h3989 : TreeTrue τ start3989 := replay_true τ ok3988 h3988
  have h3990 : TreeTrue τ start3990 := replay_true τ ok3989 h3989
  have h3991 : TreeTrue τ start3991 := replay_true τ ok3990 h3990
  have h3992 : TreeTrue τ start3992 := replay_true τ ok3991 h3991
  have h3993 : TreeTrue τ start3993 := replay_true τ ok3992 h3992
  have h3994 : TreeTrue τ start3994 := replay_true τ ok3993 h3993
  have h3995 : TreeTrue τ start3995 := replay_true τ ok3994 h3994
  have h3996 : TreeTrue τ start3996 := replay_true τ ok3995 h3995
  have h3997 : TreeTrue τ start3997 := replay_true τ ok3996 h3996
  have h3998 : TreeTrue τ start3998 := replay_true τ ok3997 h3997
  have h3999 : TreeTrue τ start3999 := replay_true τ ok3998 h3998
  have h4000 : TreeTrue τ start4000 := cp_true τ ok3999 h3999
  exact h4000
#print axioms steps124
end Snake9.ReplayFull147
