import ReplayCheck147_04352
import ReplayCheck147_04356
import ReplayCheck147_04360
import ReplayCheck147_04364
import ReplayCheck147_04368
import ReplayCheck147_04372
import ReplayCheck147_04376
import ReplayCheck147_04380
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps136 (τ : Nat → Bool) (h4352 : TreeTrue τ start4352) : TreeTrue τ start4384 := by
  have h4353 : TreeTrue τ start4353 := replay_true τ ok4352 h4352
  have h4354 : TreeTrue τ start4354 := replay_true τ ok4353 h4353
  have h4355 : TreeTrue τ start4355 := replay_true τ ok4354 h4354
  have h4356 : TreeTrue τ start4356 := replay_true τ ok4355 h4355
  have h4357 : TreeTrue τ start4357 := replay_true τ ok4356 h4356
  have h4358 : TreeTrue τ start4358 := replay_true τ ok4357 h4357
  have h4359 : TreeTrue τ start4359 := replay_true τ ok4358 h4358
  have h4360 : TreeTrue τ start4360 := replay_true τ ok4359 h4359
  have h4361 : TreeTrue τ start4361 := replay_true τ ok4360 h4360
  have h4362 : TreeTrue τ start4362 := replay_true τ ok4361 h4361
  have h4363 : TreeTrue τ start4363 := replay_true τ ok4362 h4362
  have h4364 : TreeTrue τ start4364 := replay_true τ ok4363 h4363
  have h4365 : TreeTrue τ start4365 := replay_true τ ok4364 h4364
  have h4366 : TreeTrue τ start4366 := replay_true τ ok4365 h4365
  have h4367 : TreeTrue τ start4367 := replay_true τ ok4366 h4366
  have h4368 : TreeTrue τ start4368 := replay_true τ ok4367 h4367
  have h4369 : TreeTrue τ start4369 := replay_true τ ok4368 h4368
  have h4370 : TreeTrue τ start4370 := replay_true τ ok4369 h4369
  have h4371 : TreeTrue τ start4371 := replay_true τ ok4370 h4370
  have h4372 : TreeTrue τ start4372 := replay_true τ ok4371 h4371
  have h4373 : TreeTrue τ start4373 := replay_true τ ok4372 h4372
  have h4374 : TreeTrue τ start4374 := replay_true τ ok4373 h4373
  have h4375 : TreeTrue τ start4375 := replay_true τ ok4374 h4374
  have h4376 : TreeTrue τ start4376 := replay_true τ ok4375 h4375
  have h4377 : TreeTrue τ start4377 := replay_true τ ok4376 h4376
  have h4378 : TreeTrue τ start4378 := replay_true τ ok4377 h4377
  have h4379 : TreeTrue τ start4379 := replay_true τ ok4378 h4378
  have h4380 : TreeTrue τ start4380 := replay_true τ ok4379 h4379
  have h4381 : TreeTrue τ start4381 := replay_true τ ok4380 h4380
  have h4382 : TreeTrue τ start4382 := replay_true τ ok4381 h4381
  have h4383 : TreeTrue τ start4383 := replay_true τ ok4382 h4382
  have h4384 : TreeTrue τ start4384 := cp_true τ ok4383 h4383
  exact h4384
#print axioms steps136
end Snake9.ReplayFull147
