import ReplayCheck147_02560
import ReplayCheck147_02564
import ReplayCheck147_02568
import ReplayCheck147_02572
import ReplayCheck147_02576
import ReplayCheck147_02580
import ReplayCheck147_02584
import ReplayCheck147_02588
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps80 (τ : Nat → Bool) (h2560 : TreeTrue τ start2560) : TreeTrue τ start2592 := by
  have h2561 : TreeTrue τ start2561 := replay_true τ ok2560 h2560
  have h2562 : TreeTrue τ start2562 := replay_true τ ok2561 h2561
  have h2563 : TreeTrue τ start2563 := replay_true τ ok2562 h2562
  have h2564 : TreeTrue τ start2564 := replay_true τ ok2563 h2563
  have h2565 : TreeTrue τ start2565 := replay_true τ ok2564 h2564
  have h2566 : TreeTrue τ start2566 := replay_true τ ok2565 h2565
  have h2567 : TreeTrue τ start2567 := replay_true τ ok2566 h2566
  have h2568 : TreeTrue τ start2568 := replay_true τ ok2567 h2567
  have h2569 : TreeTrue τ start2569 := replay_true τ ok2568 h2568
  have h2570 : TreeTrue τ start2570 := replay_true τ ok2569 h2569
  have h2571 : TreeTrue τ start2571 := replay_true τ ok2570 h2570
  have h2572 : TreeTrue τ start2572 := replay_true τ ok2571 h2571
  have h2573 : TreeTrue τ start2573 := replay_true τ ok2572 h2572
  have h2574 : TreeTrue τ start2574 := replay_true τ ok2573 h2573
  have h2575 : TreeTrue τ start2575 := replay_true τ ok2574 h2574
  have h2576 : TreeTrue τ start2576 := replay_true τ ok2575 h2575
  have h2577 : TreeTrue τ start2577 := replay_true τ ok2576 h2576
  have h2578 : TreeTrue τ start2578 := replay_true τ ok2577 h2577
  have h2579 : TreeTrue τ start2579 := replay_true τ ok2578 h2578
  have h2580 : TreeTrue τ start2580 := replay_true τ ok2579 h2579
  have h2581 : TreeTrue τ start2581 := replay_true τ ok2580 h2580
  have h2582 : TreeTrue τ start2582 := replay_true τ ok2581 h2581
  have h2583 : TreeTrue τ start2583 := replay_true τ ok2582 h2582
  have h2584 : TreeTrue τ start2584 := replay_true τ ok2583 h2583
  have h2585 : TreeTrue τ start2585 := replay_true τ ok2584 h2584
  have h2586 : TreeTrue τ start2586 := replay_true τ ok2585 h2585
  have h2587 : TreeTrue τ start2587 := replay_true τ ok2586 h2586
  have h2588 : TreeTrue τ start2588 := replay_true τ ok2587 h2587
  have h2589 : TreeTrue τ start2589 := replay_true τ ok2588 h2588
  have h2590 : TreeTrue τ start2590 := replay_true τ ok2589 h2589
  have h2591 : TreeTrue τ start2591 := replay_true τ ok2590 h2590
  have h2592 : TreeTrue τ start2592 := cp_true τ ok2591 h2591
  exact h2592
#print axioms steps80
end Snake9.ReplayFull147
