import ReplayCheck147_03296
import ReplayCheck147_03300
import ReplayCheck147_03304
import ReplayCheck147_03308
import ReplayCheck147_03312
import ReplayCheck147_03316
import ReplayCheck147_03320
import ReplayCheck147_03324
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps103 (τ : Nat → Bool) (h3296 : TreeTrue τ start3296) : TreeTrue τ start3328 := by
  have h3297 : TreeTrue τ start3297 := replay_true τ ok3296 h3296
  have h3298 : TreeTrue τ start3298 := replay_true τ ok3297 h3297
  have h3299 : TreeTrue τ start3299 := replay_true τ ok3298 h3298
  have h3300 : TreeTrue τ start3300 := replay_true τ ok3299 h3299
  have h3301 : TreeTrue τ start3301 := replay_true τ ok3300 h3300
  have h3302 : TreeTrue τ start3302 := replay_true τ ok3301 h3301
  have h3303 : TreeTrue τ start3303 := replay_true τ ok3302 h3302
  have h3304 : TreeTrue τ start3304 := replay_true τ ok3303 h3303
  have h3305 : TreeTrue τ start3305 := replay_true τ ok3304 h3304
  have h3306 : TreeTrue τ start3306 := replay_true τ ok3305 h3305
  have h3307 : TreeTrue τ start3307 := replay_true τ ok3306 h3306
  have h3308 : TreeTrue τ start3308 := replay_true τ ok3307 h3307
  have h3309 : TreeTrue τ start3309 := replay_true τ ok3308 h3308
  have h3310 : TreeTrue τ start3310 := replay_true τ ok3309 h3309
  have h3311 : TreeTrue τ start3311 := replay_true τ ok3310 h3310
  have h3312 : TreeTrue τ start3312 := replay_true τ ok3311 h3311
  have h3313 : TreeTrue τ start3313 := replay_true τ ok3312 h3312
  have h3314 : TreeTrue τ start3314 := replay_true τ ok3313 h3313
  have h3315 : TreeTrue τ start3315 := replay_true τ ok3314 h3314
  have h3316 : TreeTrue τ start3316 := replay_true τ ok3315 h3315
  have h3317 : TreeTrue τ start3317 := replay_true τ ok3316 h3316
  have h3318 : TreeTrue τ start3318 := replay_true τ ok3317 h3317
  have h3319 : TreeTrue τ start3319 := replay_true τ ok3318 h3318
  have h3320 : TreeTrue τ start3320 := replay_true τ ok3319 h3319
  have h3321 : TreeTrue τ start3321 := replay_true τ ok3320 h3320
  have h3322 : TreeTrue τ start3322 := replay_true τ ok3321 h3321
  have h3323 : TreeTrue τ start3323 := replay_true τ ok3322 h3322
  have h3324 : TreeTrue τ start3324 := replay_true τ ok3323 h3323
  have h3325 : TreeTrue τ start3325 := replay_true τ ok3324 h3324
  have h3326 : TreeTrue τ start3326 := replay_true τ ok3325 h3325
  have h3327 : TreeTrue τ start3327 := replay_true τ ok3326 h3326
  have h3328 : TreeTrue τ start3328 := cp_true τ ok3327 h3327
  exact h3328
#print axioms steps103
end Snake9.ReplayFull147
