import ReplayCheck147_04896
import ReplayCheck147_04900
import ReplayCheck147_04904
import ReplayCheck147_04908
import ReplayCheck147_04912
import ReplayCheck147_04916
import ReplayCheck147_04920
import ReplayCheck147_04924
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps153 (τ : Nat → Bool) (h4896 : TreeTrue τ start4896) : TreeTrue τ start4928 := by
  have h4897 : TreeTrue τ start4897 := replay_true τ ok4896 h4896
  have h4898 : TreeTrue τ start4898 := replay_true τ ok4897 h4897
  have h4899 : TreeTrue τ start4899 := replay_true τ ok4898 h4898
  have h4900 : TreeTrue τ start4900 := replay_true τ ok4899 h4899
  have h4901 : TreeTrue τ start4901 := replay_true τ ok4900 h4900
  have h4902 : TreeTrue τ start4902 := replay_true τ ok4901 h4901
  have h4903 : TreeTrue τ start4903 := replay_true τ ok4902 h4902
  have h4904 : TreeTrue τ start4904 := replay_true τ ok4903 h4903
  have h4905 : TreeTrue τ start4905 := replay_true τ ok4904 h4904
  have h4906 : TreeTrue τ start4906 := replay_true τ ok4905 h4905
  have h4907 : TreeTrue τ start4907 := replay_true τ ok4906 h4906
  have h4908 : TreeTrue τ start4908 := replay_true τ ok4907 h4907
  have h4909 : TreeTrue τ start4909 := replay_true τ ok4908 h4908
  have h4910 : TreeTrue τ start4910 := replay_true τ ok4909 h4909
  have h4911 : TreeTrue τ start4911 := replay_true τ ok4910 h4910
  have h4912 : TreeTrue τ start4912 := replay_true τ ok4911 h4911
  have h4913 : TreeTrue τ start4913 := replay_true τ ok4912 h4912
  have h4914 : TreeTrue τ start4914 := replay_true τ ok4913 h4913
  have h4915 : TreeTrue τ start4915 := replay_true τ ok4914 h4914
  have h4916 : TreeTrue τ start4916 := replay_true τ ok4915 h4915
  have h4917 : TreeTrue τ start4917 := replay_true τ ok4916 h4916
  have h4918 : TreeTrue τ start4918 := replay_true τ ok4917 h4917
  have h4919 : TreeTrue τ start4919 := replay_true τ ok4918 h4918
  have h4920 : TreeTrue τ start4920 := replay_true τ ok4919 h4919
  have h4921 : TreeTrue τ start4921 := replay_true τ ok4920 h4920
  have h4922 : TreeTrue τ start4922 := replay_true τ ok4921 h4921
  have h4923 : TreeTrue τ start4923 := replay_true τ ok4922 h4922
  have h4924 : TreeTrue τ start4924 := replay_true τ ok4923 h4923
  have h4925 : TreeTrue τ start4925 := replay_true τ ok4924 h4924
  have h4926 : TreeTrue τ start4926 := replay_true τ ok4925 h4925
  have h4927 : TreeTrue τ start4927 := replay_true τ ok4926 h4926
  have h4928 : TreeTrue τ start4928 := cp_true τ ok4927 h4927
  exact h4928
#print axioms steps153
end Snake9.ReplayFull147
