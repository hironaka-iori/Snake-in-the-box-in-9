import ReplayParts14705
import ReplayTools147
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayData147
theorem part40_slice : input40.clauses = ((Snake9.LocalWindow.ShareWindow146.raw40 ++ Snake9.LocalWindow.ShareWindow146.raw41).drop 6).take 127 := by
  rw [part40_clauses]
  rfl
theorem part40_true (τ : Nat → Bool)
    (h40 : Snake9.LocalWindow.ShareWindow146.raw40.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h41 : Snake9.LocalWindow.ShareWindow146.raw41.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part40 := by
  rw [← part40_build]
  apply build_true_of_slice τ input40 (Snake9.LocalWindow.ShareWindow146.raw40 ++ Snake9.LocalWindow.ShareWindow146.raw41) 6 127 part40_slice
  rw [List.all_append]
  rw [h40, h41]
  rfl
#print axioms part40_true
theorem part41_slice : input41.clauses = ((Snake9.LocalWindow.ShareWindow146.raw41 ++ Snake9.LocalWindow.ShareWindow146.raw42).drop 5).take 127 := by
  rw [part41_clauses]
  rfl
theorem part41_true (τ : Nat → Bool)
    (h41 : Snake9.LocalWindow.ShareWindow146.raw41.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h42 : Snake9.LocalWindow.ShareWindow146.raw42.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part41 := by
  rw [← part41_build]
  apply build_true_of_slice τ input41 (Snake9.LocalWindow.ShareWindow146.raw41 ++ Snake9.LocalWindow.ShareWindow146.raw42) 5 127 part41_slice
  rw [List.all_append]
  rw [h41, h42]
  rfl
#print axioms part41_true
theorem part42_slice : input42.clauses = ((Snake9.LocalWindow.ShareWindow146.raw42 ++ Snake9.LocalWindow.ShareWindow146.raw43).drop 5).take 127 := by
  rw [part42_clauses]
  rfl
theorem part42_true (τ : Nat → Bool)
    (h42 : Snake9.LocalWindow.ShareWindow146.raw42.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h43 : Snake9.LocalWindow.ShareWindow146.raw43.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part42 := by
  rw [← part42_build]
  apply build_true_of_slice τ input42 (Snake9.LocalWindow.ShareWindow146.raw42 ++ Snake9.LocalWindow.ShareWindow146.raw43) 5 127 part42_slice
  rw [List.all_append]
  rw [h42, h43]
  rfl
#print axioms part42_true
theorem part43_slice : input43.clauses = ((Snake9.LocalWindow.ShareWindow146.raw43 ++ Snake9.LocalWindow.ShareWindow146.raw44).drop 4).take 127 := by
  rw [part43_clauses]
  rfl
theorem part43_true (τ : Nat → Bool)
    (h43 : Snake9.LocalWindow.ShareWindow146.raw43.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h44 : Snake9.LocalWindow.ShareWindow146.raw44.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part43 := by
  rw [← part43_build]
  apply build_true_of_slice τ input43 (Snake9.LocalWindow.ShareWindow146.raw43 ++ Snake9.LocalWindow.ShareWindow146.raw44) 4 127 part43_slice
  rw [List.all_append]
  rw [h43, h44]
  rfl
#print axioms part43_true
theorem part44_slice : input44.clauses = ((Snake9.LocalWindow.ShareWindow146.raw44 ++ Snake9.LocalWindow.ShareWindow146.raw45).drop 5).take 127 := by
  rw [part44_clauses]
  rfl
theorem part44_true (τ : Nat → Bool)
    (h44 : Snake9.LocalWindow.ShareWindow146.raw44.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h45 : Snake9.LocalWindow.ShareWindow146.raw45.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part44 := by
  rw [← part44_build]
  apply build_true_of_slice τ input44 (Snake9.LocalWindow.ShareWindow146.raw44 ++ Snake9.LocalWindow.ShareWindow146.raw45) 5 127 part44_slice
  rw [List.all_append]
  rw [h44, h45]
  rfl
#print axioms part44_true
theorem part45_slice : input45.clauses = ((Snake9.LocalWindow.ShareWindow146.raw45 ++ Snake9.LocalWindow.ShareWindow146.raw46).drop 4).take 127 := by
  rw [part45_clauses]
  rfl
theorem part45_true (τ : Nat → Bool)
    (h45 : Snake9.LocalWindow.ShareWindow146.raw45.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h46 : Snake9.LocalWindow.ShareWindow146.raw46.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part45 := by
  rw [← part45_build]
  apply build_true_of_slice τ input45 (Snake9.LocalWindow.ShareWindow146.raw45 ++ Snake9.LocalWindow.ShareWindow146.raw46) 4 127 part45_slice
  rw [List.all_append]
  rw [h45, h46]
  rfl
#print axioms part45_true
theorem part46_slice : input46.clauses = ((Snake9.LocalWindow.ShareWindow146.raw46 ++ Snake9.LocalWindow.ShareWindow146.raw47).drop 4).take 127 := by
  rw [part46_clauses]
  rfl
theorem part46_true (τ : Nat → Bool)
    (h46 : Snake9.LocalWindow.ShareWindow146.raw46.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h47 : Snake9.LocalWindow.ShareWindow146.raw47.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part46 := by
  rw [← part46_build]
  apply build_true_of_slice τ input46 (Snake9.LocalWindow.ShareWindow146.raw46 ++ Snake9.LocalWindow.ShareWindow146.raw47) 4 127 part46_slice
  rw [List.all_append]
  rw [h46, h47]
  rfl
#print axioms part46_true
theorem part47_slice : input47.clauses = ((Snake9.LocalWindow.ShareWindow146.raw47 ++ Snake9.LocalWindow.ShareWindow146.raw48).drop 3).take 127 := by
  rw [part47_clauses]
  rfl
theorem part47_true (τ : Nat → Bool)
    (h47 : Snake9.LocalWindow.ShareWindow146.raw47.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h48 : Snake9.LocalWindow.ShareWindow146.raw48.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat147Replay.TreeTrue τ part47 := by
  rw [← part47_build]
  apply build_true_of_slice τ input47 (Snake9.LocalWindow.ShareWindow146.raw47 ++ Snake9.LocalWindow.ShareWindow146.raw48) 3 127 part47_slice
  rw [List.all_append]
  rw [h47, h48]
  rfl
#print axioms part47_true
end Snake9.ReplayData147
