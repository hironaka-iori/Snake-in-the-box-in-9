import ReplayCheck147_03776
import ReplayCheck147_03780
import ReplayCheck147_03784
import ReplayCheck147_03788
import ReplayCheck147_03792
import ReplayCheck147_03796
import ReplayCheck147_03800
import ReplayCheck147_03804
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps118 (τ : Nat → Bool) (h3776 : TreeTrue τ start3776) : TreeTrue τ start3808 := by
  have h3777 : TreeTrue τ start3777 := replay_true τ ok3776 h3776
  have h3778 : TreeTrue τ start3778 := replay_true τ ok3777 h3777
  have h3779 : TreeTrue τ start3779 := replay_true τ ok3778 h3778
  have h3780 : TreeTrue τ start3780 := replay_true τ ok3779 h3779
  have h3781 : TreeTrue τ start3781 := replay_true τ ok3780 h3780
  have h3782 : TreeTrue τ start3782 := replay_true τ ok3781 h3781
  have h3783 : TreeTrue τ start3783 := replay_true τ ok3782 h3782
  have h3784 : TreeTrue τ start3784 := replay_true τ ok3783 h3783
  have h3785 : TreeTrue τ start3785 := replay_true τ ok3784 h3784
  have h3786 : TreeTrue τ start3786 := replay_true τ ok3785 h3785
  have h3787 : TreeTrue τ start3787 := replay_true τ ok3786 h3786
  have h3788 : TreeTrue τ start3788 := replay_true τ ok3787 h3787
  have h3789 : TreeTrue τ start3789 := replay_true τ ok3788 h3788
  have h3790 : TreeTrue τ start3790 := replay_true τ ok3789 h3789
  have h3791 : TreeTrue τ start3791 := replay_true τ ok3790 h3790
  have h3792 : TreeTrue τ start3792 := replay_true τ ok3791 h3791
  have h3793 : TreeTrue τ start3793 := replay_true τ ok3792 h3792
  have h3794 : TreeTrue τ start3794 := replay_true τ ok3793 h3793
  have h3795 : TreeTrue τ start3795 := replay_true τ ok3794 h3794
  have h3796 : TreeTrue τ start3796 := replay_true τ ok3795 h3795
  have h3797 : TreeTrue τ start3797 := replay_true τ ok3796 h3796
  have h3798 : TreeTrue τ start3798 := replay_true τ ok3797 h3797
  have h3799 : TreeTrue τ start3799 := replay_true τ ok3798 h3798
  have h3800 : TreeTrue τ start3800 := replay_true τ ok3799 h3799
  have h3801 : TreeTrue τ start3801 := replay_true τ ok3800 h3800
  have h3802 : TreeTrue τ start3802 := replay_true τ ok3801 h3801
  have h3803 : TreeTrue τ start3803 := replay_true τ ok3802 h3802
  have h3804 : TreeTrue τ start3804 := replay_true τ ok3803 h3803
  have h3805 : TreeTrue τ start3805 := replay_true τ ok3804 h3804
  have h3806 : TreeTrue τ start3806 := replay_true τ ok3805 h3805
  have h3807 : TreeTrue τ start3807 := replay_true τ ok3806 h3806
  have h3808 : TreeTrue τ start3808 := cp_true τ ok3807 h3807
  exact h3808
#print axioms steps118
end Snake9.ReplayFull147
