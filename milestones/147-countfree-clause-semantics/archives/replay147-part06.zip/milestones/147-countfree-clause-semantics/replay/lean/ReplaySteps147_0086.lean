import ReplayCheck147_02752
import ReplayCheck147_02756
import ReplayCheck147_02760
import ReplayCheck147_02764
import ReplayCheck147_02768
import ReplayCheck147_02772
import ReplayCheck147_02776
import ReplayCheck147_02780
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps86 (τ : Nat → Bool) (h2752 : TreeTrue τ start2752) : TreeTrue τ start2784 := by
  have h2753 : TreeTrue τ start2753 := replay_true τ ok2752 h2752
  have h2754 : TreeTrue τ start2754 := replay_true τ ok2753 h2753
  have h2755 : TreeTrue τ start2755 := replay_true τ ok2754 h2754
  have h2756 : TreeTrue τ start2756 := replay_true τ ok2755 h2755
  have h2757 : TreeTrue τ start2757 := replay_true τ ok2756 h2756
  have h2758 : TreeTrue τ start2758 := replay_true τ ok2757 h2757
  have h2759 : TreeTrue τ start2759 := replay_true τ ok2758 h2758
  have h2760 : TreeTrue τ start2760 := replay_true τ ok2759 h2759
  have h2761 : TreeTrue τ start2761 := replay_true τ ok2760 h2760
  have h2762 : TreeTrue τ start2762 := replay_true τ ok2761 h2761
  have h2763 : TreeTrue τ start2763 := replay_true τ ok2762 h2762
  have h2764 : TreeTrue τ start2764 := replay_true τ ok2763 h2763
  have h2765 : TreeTrue τ start2765 := replay_true τ ok2764 h2764
  have h2766 : TreeTrue τ start2766 := replay_true τ ok2765 h2765
  have h2767 : TreeTrue τ start2767 := replay_true τ ok2766 h2766
  have h2768 : TreeTrue τ start2768 := replay_true τ ok2767 h2767
  have h2769 : TreeTrue τ start2769 := replay_true τ ok2768 h2768
  have h2770 : TreeTrue τ start2770 := replay_true τ ok2769 h2769
  have h2771 : TreeTrue τ start2771 := replay_true τ ok2770 h2770
  have h2772 : TreeTrue τ start2772 := replay_true τ ok2771 h2771
  have h2773 : TreeTrue τ start2773 := replay_true τ ok2772 h2772
  have h2774 : TreeTrue τ start2774 := replay_true τ ok2773 h2773
  have h2775 : TreeTrue τ start2775 := replay_true τ ok2774 h2774
  have h2776 : TreeTrue τ start2776 := replay_true τ ok2775 h2775
  have h2777 : TreeTrue τ start2777 := replay_true τ ok2776 h2776
  have h2778 : TreeTrue τ start2778 := replay_true τ ok2777 h2777
  have h2779 : TreeTrue τ start2779 := replay_true τ ok2778 h2778
  have h2780 : TreeTrue τ start2780 := replay_true τ ok2779 h2779
  have h2781 : TreeTrue τ start2781 := replay_true τ ok2780 h2780
  have h2782 : TreeTrue τ start2782 := replay_true τ ok2781 h2781
  have h2783 : TreeTrue τ start2783 := replay_true τ ok2782 h2782
  have h2784 : TreeTrue τ start2784 := cp_true τ ok2783 h2783
  exact h2784
#print axioms steps86
end Snake9.ReplayFull147
