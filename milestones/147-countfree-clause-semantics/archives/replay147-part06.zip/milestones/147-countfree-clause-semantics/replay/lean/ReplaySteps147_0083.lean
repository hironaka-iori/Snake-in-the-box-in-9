import ReplayCheck147_02656
import ReplayCheck147_02660
import ReplayCheck147_02664
import ReplayCheck147_02668
import ReplayCheck147_02672
import ReplayCheck147_02676
import ReplayCheck147_02680
import ReplayCheck147_02684
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps83 (τ : Nat → Bool) (h2656 : TreeTrue τ start2656) : TreeTrue τ start2688 := by
  have h2657 : TreeTrue τ start2657 := replay_true τ ok2656 h2656
  have h2658 : TreeTrue τ start2658 := replay_true τ ok2657 h2657
  have h2659 : TreeTrue τ start2659 := replay_true τ ok2658 h2658
  have h2660 : TreeTrue τ start2660 := replay_true τ ok2659 h2659
  have h2661 : TreeTrue τ start2661 := replay_true τ ok2660 h2660
  have h2662 : TreeTrue τ start2662 := replay_true τ ok2661 h2661
  have h2663 : TreeTrue τ start2663 := replay_true τ ok2662 h2662
  have h2664 : TreeTrue τ start2664 := replay_true τ ok2663 h2663
  have h2665 : TreeTrue τ start2665 := replay_true τ ok2664 h2664
  have h2666 : TreeTrue τ start2666 := replay_true τ ok2665 h2665
  have h2667 : TreeTrue τ start2667 := replay_true τ ok2666 h2666
  have h2668 : TreeTrue τ start2668 := replay_true τ ok2667 h2667
  have h2669 : TreeTrue τ start2669 := replay_true τ ok2668 h2668
  have h2670 : TreeTrue τ start2670 := replay_true τ ok2669 h2669
  have h2671 : TreeTrue τ start2671 := replay_true τ ok2670 h2670
  have h2672 : TreeTrue τ start2672 := replay_true τ ok2671 h2671
  have h2673 : TreeTrue τ start2673 := replay_true τ ok2672 h2672
  have h2674 : TreeTrue τ start2674 := replay_true τ ok2673 h2673
  have h2675 : TreeTrue τ start2675 := replay_true τ ok2674 h2674
  have h2676 : TreeTrue τ start2676 := replay_true τ ok2675 h2675
  have h2677 : TreeTrue τ start2677 := replay_true τ ok2676 h2676
  have h2678 : TreeTrue τ start2678 := replay_true τ ok2677 h2677
  have h2679 : TreeTrue τ start2679 := replay_true τ ok2678 h2678
  have h2680 : TreeTrue τ start2680 := replay_true τ ok2679 h2679
  have h2681 : TreeTrue τ start2681 := replay_true τ ok2680 h2680
  have h2682 : TreeTrue τ start2682 := replay_true τ ok2681 h2681
  have h2683 : TreeTrue τ start2683 := replay_true τ ok2682 h2682
  have h2684 : TreeTrue τ start2684 := replay_true τ ok2683 h2683
  have h2685 : TreeTrue τ start2685 := replay_true τ ok2684 h2684
  have h2686 : TreeTrue τ start2686 := replay_true τ ok2685 h2685
  have h2687 : TreeTrue τ start2687 := replay_true τ ok2686 h2686
  have h2688 : TreeTrue τ start2688 := cp_true τ ok2687 h2687
  exact h2688
#print axioms steps83
end Snake9.ReplayFull147
