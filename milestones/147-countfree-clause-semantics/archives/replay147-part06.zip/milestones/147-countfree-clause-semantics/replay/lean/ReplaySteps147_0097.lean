import ReplayCheck147_03104
import ReplayCheck147_03108
import ReplayCheck147_03112
import ReplayCheck147_03116
import ReplayCheck147_03120
import ReplayCheck147_03124
import ReplayCheck147_03128
import ReplayCheck147_03132
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps97 (τ : Nat → Bool) (h3104 : TreeTrue τ start3104) : TreeTrue τ start3136 := by
  have h3105 : TreeTrue τ start3105 := replay_true τ ok3104 h3104
  have h3106 : TreeTrue τ start3106 := replay_true τ ok3105 h3105
  have h3107 : TreeTrue τ start3107 := replay_true τ ok3106 h3106
  have h3108 : TreeTrue τ start3108 := replay_true τ ok3107 h3107
  have h3109 : TreeTrue τ start3109 := replay_true τ ok3108 h3108
  have h3110 : TreeTrue τ start3110 := replay_true τ ok3109 h3109
  have h3111 : TreeTrue τ start3111 := replay_true τ ok3110 h3110
  have h3112 : TreeTrue τ start3112 := replay_true τ ok3111 h3111
  have h3113 : TreeTrue τ start3113 := replay_true τ ok3112 h3112
  have h3114 : TreeTrue τ start3114 := replay_true τ ok3113 h3113
  have h3115 : TreeTrue τ start3115 := replay_true τ ok3114 h3114
  have h3116 : TreeTrue τ start3116 := replay_true τ ok3115 h3115
  have h3117 : TreeTrue τ start3117 := replay_true τ ok3116 h3116
  have h3118 : TreeTrue τ start3118 := replay_true τ ok3117 h3117
  have h3119 : TreeTrue τ start3119 := replay_true τ ok3118 h3118
  have h3120 : TreeTrue τ start3120 := replay_true τ ok3119 h3119
  have h3121 : TreeTrue τ start3121 := replay_true τ ok3120 h3120
  have h3122 : TreeTrue τ start3122 := replay_true τ ok3121 h3121
  have h3123 : TreeTrue τ start3123 := replay_true τ ok3122 h3122
  have h3124 : TreeTrue τ start3124 := replay_true τ ok3123 h3123
  have h3125 : TreeTrue τ start3125 := replay_true τ ok3124 h3124
  have h3126 : TreeTrue τ start3126 := replay_true τ ok3125 h3125
  have h3127 : TreeTrue τ start3127 := replay_true τ ok3126 h3126
  have h3128 : TreeTrue τ start3128 := replay_true τ ok3127 h3127
  have h3129 : TreeTrue τ start3129 := replay_true τ ok3128 h3128
  have h3130 : TreeTrue τ start3130 := replay_true τ ok3129 h3129
  have h3131 : TreeTrue τ start3131 := replay_true τ ok3130 h3130
  have h3132 : TreeTrue τ start3132 := replay_true τ ok3131 h3131
  have h3133 : TreeTrue τ start3133 := replay_true τ ok3132 h3132
  have h3134 : TreeTrue τ start3134 := replay_true τ ok3133 h3133
  have h3135 : TreeTrue τ start3135 := replay_true τ ok3134 h3134
  have h3136 : TreeTrue τ start3136 := cp_true τ ok3135 h3135
  exact h3136
#print axioms steps97
end Snake9.ReplayFull147
