import ReplayCheck147_04544
import ReplayCheck147_04548
import ReplayCheck147_04552
import ReplayCheck147_04556
import ReplayCheck147_04560
import ReplayCheck147_04564
import ReplayCheck147_04568
import ReplayCheck147_04572
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps142 (τ : Nat → Bool) (h4544 : TreeTrue τ start4544) : TreeTrue τ start4576 := by
  have h4545 : TreeTrue τ start4545 := replay_true τ ok4544 h4544
  have h4546 : TreeTrue τ start4546 := replay_true τ ok4545 h4545
  have h4547 : TreeTrue τ start4547 := replay_true τ ok4546 h4546
  have h4548 : TreeTrue τ start4548 := replay_true τ ok4547 h4547
  have h4549 : TreeTrue τ start4549 := replay_true τ ok4548 h4548
  have h4550 : TreeTrue τ start4550 := replay_true τ ok4549 h4549
  have h4551 : TreeTrue τ start4551 := replay_true τ ok4550 h4550
  have h4552 : TreeTrue τ start4552 := replay_true τ ok4551 h4551
  have h4553 : TreeTrue τ start4553 := replay_true τ ok4552 h4552
  have h4554 : TreeTrue τ start4554 := replay_true τ ok4553 h4553
  have h4555 : TreeTrue τ start4555 := replay_true τ ok4554 h4554
  have h4556 : TreeTrue τ start4556 := replay_true τ ok4555 h4555
  have h4557 : TreeTrue τ start4557 := replay_true τ ok4556 h4556
  have h4558 : TreeTrue τ start4558 := replay_true τ ok4557 h4557
  have h4559 : TreeTrue τ start4559 := replay_true τ ok4558 h4558
  have h4560 : TreeTrue τ start4560 := replay_true τ ok4559 h4559
  have h4561 : TreeTrue τ start4561 := replay_true τ ok4560 h4560
  have h4562 : TreeTrue τ start4562 := replay_true τ ok4561 h4561
  have h4563 : TreeTrue τ start4563 := replay_true τ ok4562 h4562
  have h4564 : TreeTrue τ start4564 := replay_true τ ok4563 h4563
  have h4565 : TreeTrue τ start4565 := replay_true τ ok4564 h4564
  have h4566 : TreeTrue τ start4566 := replay_true τ ok4565 h4565
  have h4567 : TreeTrue τ start4567 := replay_true τ ok4566 h4566
  have h4568 : TreeTrue τ start4568 := replay_true τ ok4567 h4567
  have h4569 : TreeTrue τ start4569 := replay_true τ ok4568 h4568
  have h4570 : TreeTrue τ start4570 := replay_true τ ok4569 h4569
  have h4571 : TreeTrue τ start4571 := replay_true τ ok4570 h4570
  have h4572 : TreeTrue τ start4572 := replay_true τ ok4571 h4571
  have h4573 : TreeTrue τ start4573 := replay_true τ ok4572 h4572
  have h4574 : TreeTrue τ start4574 := replay_true τ ok4573 h4573
  have h4575 : TreeTrue τ start4575 := replay_true τ ok4574 h4574
  have h4576 : TreeTrue τ start4576 := cp_true τ ok4575 h4575
  exact h4576
#print axioms steps142
end Snake9.ReplayFull147
