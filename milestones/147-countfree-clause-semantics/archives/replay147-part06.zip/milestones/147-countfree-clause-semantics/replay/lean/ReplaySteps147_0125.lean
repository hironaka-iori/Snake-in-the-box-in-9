import ReplayCheck147_04000
import ReplayCheck147_04004
import ReplayCheck147_04008
import ReplayCheck147_04012
import ReplayCheck147_04016
import ReplayCheck147_04020
import ReplayCheck147_04024
import ReplayCheck147_04028
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps125 (τ : Nat → Bool) (h4000 : TreeTrue τ start4000) : TreeTrue τ start4032 := by
  have h4001 : TreeTrue τ start4001 := replay_true τ ok4000 h4000
  have h4002 : TreeTrue τ start4002 := replay_true τ ok4001 h4001
  have h4003 : TreeTrue τ start4003 := replay_true τ ok4002 h4002
  have h4004 : TreeTrue τ start4004 := replay_true τ ok4003 h4003
  have h4005 : TreeTrue τ start4005 := replay_true τ ok4004 h4004
  have h4006 : TreeTrue τ start4006 := replay_true τ ok4005 h4005
  have h4007 : TreeTrue τ start4007 := replay_true τ ok4006 h4006
  have h4008 : TreeTrue τ start4008 := replay_true τ ok4007 h4007
  have h4009 : TreeTrue τ start4009 := replay_true τ ok4008 h4008
  have h4010 : TreeTrue τ start4010 := replay_true τ ok4009 h4009
  have h4011 : TreeTrue τ start4011 := replay_true τ ok4010 h4010
  have h4012 : TreeTrue τ start4012 := replay_true τ ok4011 h4011
  have h4013 : TreeTrue τ start4013 := replay_true τ ok4012 h4012
  have h4014 : TreeTrue τ start4014 := replay_true τ ok4013 h4013
  have h4015 : TreeTrue τ start4015 := replay_true τ ok4014 h4014
  have h4016 : TreeTrue τ start4016 := replay_true τ ok4015 h4015
  have h4017 : TreeTrue τ start4017 := replay_true τ ok4016 h4016
  have h4018 : TreeTrue τ start4018 := replay_true τ ok4017 h4017
  have h4019 : TreeTrue τ start4019 := replay_true τ ok4018 h4018
  have h4020 : TreeTrue τ start4020 := replay_true τ ok4019 h4019
  have h4021 : TreeTrue τ start4021 := replay_true τ ok4020 h4020
  have h4022 : TreeTrue τ start4022 := replay_true τ ok4021 h4021
  have h4023 : TreeTrue τ start4023 := replay_true τ ok4022 h4022
  have h4024 : TreeTrue τ start4024 := replay_true τ ok4023 h4023
  have h4025 : TreeTrue τ start4025 := replay_true τ ok4024 h4024
  have h4026 : TreeTrue τ start4026 := replay_true τ ok4025 h4025
  have h4027 : TreeTrue τ start4027 := replay_true τ ok4026 h4026
  have h4028 : TreeTrue τ start4028 := replay_true τ ok4027 h4027
  have h4029 : TreeTrue τ start4029 := replay_true τ ok4028 h4028
  have h4030 : TreeTrue τ start4030 := replay_true τ ok4029 h4029
  have h4031 : TreeTrue τ start4031 := replay_true τ ok4030 h4030
  have h4032 : TreeTrue τ start4032 := cp_true τ ok4031 h4031
  exact h4032
#print axioms steps125
end Snake9.ReplayFull147
