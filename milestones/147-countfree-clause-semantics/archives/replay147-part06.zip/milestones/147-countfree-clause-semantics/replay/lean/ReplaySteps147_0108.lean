import ReplayCheck147_03456
import ReplayCheck147_03460
import ReplayCheck147_03464
import ReplayCheck147_03468
import ReplayCheck147_03472
import ReplayCheck147_03476
import ReplayCheck147_03480
import ReplayCheck147_03484
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps108 (τ : Nat → Bool) (h3456 : TreeTrue τ start3456) : TreeTrue τ start3488 := by
  have h3457 : TreeTrue τ start3457 := replay_true τ ok3456 h3456
  have h3458 : TreeTrue τ start3458 := replay_true τ ok3457 h3457
  have h3459 : TreeTrue τ start3459 := replay_true τ ok3458 h3458
  have h3460 : TreeTrue τ start3460 := replay_true τ ok3459 h3459
  have h3461 : TreeTrue τ start3461 := replay_true τ ok3460 h3460
  have h3462 : TreeTrue τ start3462 := replay_true τ ok3461 h3461
  have h3463 : TreeTrue τ start3463 := replay_true τ ok3462 h3462
  have h3464 : TreeTrue τ start3464 := replay_true τ ok3463 h3463
  have h3465 : TreeTrue τ start3465 := replay_true τ ok3464 h3464
  have h3466 : TreeTrue τ start3466 := replay_true τ ok3465 h3465
  have h3467 : TreeTrue τ start3467 := replay_true τ ok3466 h3466
  have h3468 : TreeTrue τ start3468 := replay_true τ ok3467 h3467
  have h3469 : TreeTrue τ start3469 := replay_true τ ok3468 h3468
  have h3470 : TreeTrue τ start3470 := replay_true τ ok3469 h3469
  have h3471 : TreeTrue τ start3471 := replay_true τ ok3470 h3470
  have h3472 : TreeTrue τ start3472 := replay_true τ ok3471 h3471
  have h3473 : TreeTrue τ start3473 := replay_true τ ok3472 h3472
  have h3474 : TreeTrue τ start3474 := replay_true τ ok3473 h3473
  have h3475 : TreeTrue τ start3475 := replay_true τ ok3474 h3474
  have h3476 : TreeTrue τ start3476 := replay_true τ ok3475 h3475
  have h3477 : TreeTrue τ start3477 := replay_true τ ok3476 h3476
  have h3478 : TreeTrue τ start3478 := replay_true τ ok3477 h3477
  have h3479 : TreeTrue τ start3479 := replay_true τ ok3478 h3478
  have h3480 : TreeTrue τ start3480 := replay_true τ ok3479 h3479
  have h3481 : TreeTrue τ start3481 := replay_true τ ok3480 h3480
  have h3482 : TreeTrue τ start3482 := replay_true τ ok3481 h3481
  have h3483 : TreeTrue τ start3483 := replay_true τ ok3482 h3482
  have h3484 : TreeTrue τ start3484 := replay_true τ ok3483 h3483
  have h3485 : TreeTrue τ start3485 := replay_true τ ok3484 h3484
  have h3486 : TreeTrue τ start3486 := replay_true τ ok3485 h3485
  have h3487 : TreeTrue τ start3487 := replay_true τ ok3486 h3486
  have h3488 : TreeTrue τ start3488 := cp_true τ ok3487 h3487
  exact h3488
#print axioms steps108
end Snake9.ReplayFull147
