import ReplayCheck147_03552
import ReplayCheck147_03556
import ReplayCheck147_03560
import ReplayCheck147_03564
import ReplayCheck147_03568
import ReplayCheck147_03572
import ReplayCheck147_03576
import ReplayCheck147_03580
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps111 (τ : Nat → Bool) (h3552 : TreeTrue τ start3552) : TreeTrue τ start3584 := by
  have h3553 : TreeTrue τ start3553 := replay_true τ ok3552 h3552
  have h3554 : TreeTrue τ start3554 := replay_true τ ok3553 h3553
  have h3555 : TreeTrue τ start3555 := replay_true τ ok3554 h3554
  have h3556 : TreeTrue τ start3556 := replay_true τ ok3555 h3555
  have h3557 : TreeTrue τ start3557 := replay_true τ ok3556 h3556
  have h3558 : TreeTrue τ start3558 := replay_true τ ok3557 h3557
  have h3559 : TreeTrue τ start3559 := replay_true τ ok3558 h3558
  have h3560 : TreeTrue τ start3560 := replay_true τ ok3559 h3559
  have h3561 : TreeTrue τ start3561 := replay_true τ ok3560 h3560
  have h3562 : TreeTrue τ start3562 := replay_true τ ok3561 h3561
  have h3563 : TreeTrue τ start3563 := replay_true τ ok3562 h3562
  have h3564 : TreeTrue τ start3564 := replay_true τ ok3563 h3563
  have h3565 : TreeTrue τ start3565 := replay_true τ ok3564 h3564
  have h3566 : TreeTrue τ start3566 := replay_true τ ok3565 h3565
  have h3567 : TreeTrue τ start3567 := replay_true τ ok3566 h3566
  have h3568 : TreeTrue τ start3568 := replay_true τ ok3567 h3567
  have h3569 : TreeTrue τ start3569 := replay_true τ ok3568 h3568
  have h3570 : TreeTrue τ start3570 := replay_true τ ok3569 h3569
  have h3571 : TreeTrue τ start3571 := replay_true τ ok3570 h3570
  have h3572 : TreeTrue τ start3572 := replay_true τ ok3571 h3571
  have h3573 : TreeTrue τ start3573 := replay_true τ ok3572 h3572
  have h3574 : TreeTrue τ start3574 := replay_true τ ok3573 h3573
  have h3575 : TreeTrue τ start3575 := replay_true τ ok3574 h3574
  have h3576 : TreeTrue τ start3576 := replay_true τ ok3575 h3575
  have h3577 : TreeTrue τ start3577 := replay_true τ ok3576 h3576
  have h3578 : TreeTrue τ start3578 := replay_true τ ok3577 h3577
  have h3579 : TreeTrue τ start3579 := replay_true τ ok3578 h3578
  have h3580 : TreeTrue τ start3580 := replay_true τ ok3579 h3579
  have h3581 : TreeTrue τ start3581 := replay_true τ ok3580 h3580
  have h3582 : TreeTrue τ start3582 := replay_true τ ok3581 h3581
  have h3583 : TreeTrue τ start3583 := replay_true τ ok3582 h3582
  have h3584 : TreeTrue τ start3584 := cp_true τ ok3583 h3583
  exact h3584
#print axioms steps111
end Snake9.ReplayFull147
