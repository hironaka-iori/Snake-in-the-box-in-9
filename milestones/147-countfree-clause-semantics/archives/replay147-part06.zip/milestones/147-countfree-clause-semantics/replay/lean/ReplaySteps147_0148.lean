import ReplayCheck147_04736
import ReplayCheck147_04740
import ReplayCheck147_04744
import ReplayCheck147_04748
import ReplayCheck147_04752
import ReplayCheck147_04756
import ReplayCheck147_04760
import ReplayCheck147_04764
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull147
open Snake9.Lrat147Replay (TreeTrue)
open Snake9.LratFast147Replay
theorem steps148 (τ : Nat → Bool) (h4736 : TreeTrue τ start4736) : TreeTrue τ start4768 := by
  have h4737 : TreeTrue τ start4737 := replay_true τ ok4736 h4736
  have h4738 : TreeTrue τ start4738 := replay_true τ ok4737 h4737
  have h4739 : TreeTrue τ start4739 := replay_true τ ok4738 h4738
  have h4740 : TreeTrue τ start4740 := replay_true τ ok4739 h4739
  have h4741 : TreeTrue τ start4741 := replay_true τ ok4740 h4740
  have h4742 : TreeTrue τ start4742 := replay_true τ ok4741 h4741
  have h4743 : TreeTrue τ start4743 := replay_true τ ok4742 h4742
  have h4744 : TreeTrue τ start4744 := replay_true τ ok4743 h4743
  have h4745 : TreeTrue τ start4745 := replay_true τ ok4744 h4744
  have h4746 : TreeTrue τ start4746 := replay_true τ ok4745 h4745
  have h4747 : TreeTrue τ start4747 := replay_true τ ok4746 h4746
  have h4748 : TreeTrue τ start4748 := replay_true τ ok4747 h4747
  have h4749 : TreeTrue τ start4749 := replay_true τ ok4748 h4748
  have h4750 : TreeTrue τ start4750 := replay_true τ ok4749 h4749
  have h4751 : TreeTrue τ start4751 := replay_true τ ok4750 h4750
  have h4752 : TreeTrue τ start4752 := replay_true τ ok4751 h4751
  have h4753 : TreeTrue τ start4753 := replay_true τ ok4752 h4752
  have h4754 : TreeTrue τ start4754 := replay_true τ ok4753 h4753
  have h4755 : TreeTrue τ start4755 := replay_true τ ok4754 h4754
  have h4756 : TreeTrue τ start4756 := replay_true τ ok4755 h4755
  have h4757 : TreeTrue τ start4757 := replay_true τ ok4756 h4756
  have h4758 : TreeTrue τ start4758 := replay_true τ ok4757 h4757
  have h4759 : TreeTrue τ start4759 := replay_true τ ok4758 h4758
  have h4760 : TreeTrue τ start4760 := replay_true τ ok4759 h4759
  have h4761 : TreeTrue τ start4761 := replay_true τ ok4760 h4760
  have h4762 : TreeTrue τ start4762 := replay_true τ ok4761 h4761
  have h4763 : TreeTrue τ start4763 := replay_true τ ok4762 h4762
  have h4764 : TreeTrue τ start4764 := replay_true τ ok4763 h4763
  have h4765 : TreeTrue τ start4765 := replay_true τ ok4764 h4764
  have h4766 : TreeTrue τ start4766 := replay_true τ ok4765 h4765
  have h4767 : TreeTrue τ start4767 := replay_true τ ok4766 h4766
  have h4768 : TreeTrue τ start4768 := cp_true τ ok4767 h4767
  exact h4768
#print axioms steps148
end Snake9.ReplayFull147
