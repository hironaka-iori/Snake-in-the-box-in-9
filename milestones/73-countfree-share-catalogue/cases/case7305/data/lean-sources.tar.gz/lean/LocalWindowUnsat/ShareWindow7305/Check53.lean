import LocalWindowUnsat.ShareWindow7305.Data312
import LocalWindowUnsat.ShareWindow7305.Data313

/-! Kernel checks of segments 313-313 of `share7305` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7305
open Snake9.LratFastOffset8192W15
open Snake9.LratOffset8192 (Tree TreeTrue andB)

theorem ok313 : andB (check start313 proof313) (hasEmpty (replay start313 proof313) 16384) = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7305
