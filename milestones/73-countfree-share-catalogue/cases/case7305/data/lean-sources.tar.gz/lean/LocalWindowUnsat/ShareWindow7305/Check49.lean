import LocalWindowUnsat.ShareWindow7305.Data288
import LocalWindowUnsat.ShareWindow7305.Data289
import LocalWindowUnsat.ShareWindow7305.Data290
import LocalWindowUnsat.ShareWindow7305.Data291
import LocalWindowUnsat.ShareWindow7305.Data292
import LocalWindowUnsat.ShareWindow7305.Data293
import LocalWindowUnsat.ShareWindow7305.Data294

/-! Kernel checks of segments 289-294 of `share7305` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7305
open Snake9.LratFastOffset8192W15
open Snake9.LratOffset8192 (Tree TreeTrue andB)

theorem ok289 : check start289 proof289 = true := by
  decide +kernel

theorem ok290 : check start290 proof290 = true := by
  decide +kernel

theorem ok291 : check start291 proof291 = true := by
  decide +kernel

theorem ok292 : andB (check start292 proof292) (cpOk (replay start292 proof292) start293) = true := by
  decide +kernel

theorem ok293 : check start293 proof293 = true := by
  decide +kernel

theorem ok294 : check start294 proof294 = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7305
