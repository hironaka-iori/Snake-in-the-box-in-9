import LocalWindowUnsat.ShareWindow7305.Data78
import LocalWindowUnsat.ShareWindow7305.Data79
import LocalWindowUnsat.ShareWindow7305.Data80
import LocalWindowUnsat.ShareWindow7305.Data81
import LocalWindowUnsat.ShareWindow7305.Data82
import LocalWindowUnsat.ShareWindow7305.Data83
import LocalWindowUnsat.ShareWindow7305.Data84

/-! Kernel checks of segments 79-84 of `share7305` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7305
open Snake9.LratFastOffset8192W15
open Snake9.LratOffset8192 (Tree TreeTrue andB)

theorem ok79 : check start79 proof79 = true := by
  decide +kernel

theorem ok80 : andB (check start80 proof80) (cpOk (replay start80 proof80) start81) = true := by
  decide +kernel

theorem ok81 : check start81 proof81 = true := by
  decide +kernel

theorem ok82 : check start82 proof82 = true := by
  decide +kernel

theorem ok83 : check start83 proof83 = true := by
  decide +kernel

theorem ok84 : andB (check start84 proof84) (cpOk (replay start84 proof84) start85) = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7305
