import LocalWindowUnsat.ShareWindow7305.Data282
import LocalWindowUnsat.ShareWindow7305.Data283
import LocalWindowUnsat.ShareWindow7305.Data284
import LocalWindowUnsat.ShareWindow7305.Data285
import LocalWindowUnsat.ShareWindow7305.Data286
import LocalWindowUnsat.ShareWindow7305.Data287
import LocalWindowUnsat.ShareWindow7305.Data288

/-! Kernel checks of segments 283-288 of `share7305` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7305
open Snake9.LratFastOffset8192W15
open Snake9.LratOffset8192 (Tree TreeTrue andB)

theorem ok283 : check start283 proof283 = true := by
  decide +kernel

theorem ok284 : andB (check start284 proof284) (cpOk (replay start284 proof284) start285) = true := by
  decide +kernel

theorem ok285 : check start285 proof285 = true := by
  decide +kernel

theorem ok286 : check start286 proof286 = true := by
  decide +kernel

theorem ok287 : check start287 proof287 = true := by
  decide +kernel

theorem ok288 : andB (check start288 proof288) (cpOk (replay start288 proof288) start289) = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7305
