import LocalWindowUnsat.ShareWindow7305.Data264
import LocalWindowUnsat.ShareWindow7305.Data265
import LocalWindowUnsat.ShareWindow7305.Data266
import LocalWindowUnsat.ShareWindow7305.Data267
import LocalWindowUnsat.ShareWindow7305.Data268
import LocalWindowUnsat.ShareWindow7305.Data269
import LocalWindowUnsat.ShareWindow7305.Data270

/-! Kernel checks of segments 265-270 of `share7305` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7305
open Snake9.LratFastOffset8192W15
open Snake9.LratOffset8192 (Tree TreeTrue andB)

theorem ok265 : check start265 proof265 = true := by
  decide +kernel

theorem ok266 : check start266 proof266 = true := by
  decide +kernel

theorem ok267 : check start267 proof267 = true := by
  decide +kernel

theorem ok268 : andB (check start268 proof268) (cpOk (replay start268 proof268) start269) = true := by
  decide +kernel

theorem ok269 : check start269 proof269 = true := by
  decide +kernel

theorem ok270 : check start270 proof270 = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7305
