import LocalWindowUnsat.ShareWindow7306.Data54
import LocalWindowUnsat.ShareWindow7306.Data55
import LocalWindowUnsat.ShareWindow7306.Data56
import LocalWindowUnsat.ShareWindow7306.Data57
import LocalWindowUnsat.ShareWindow7306.Data58
import LocalWindowUnsat.ShareWindow7306.Data59
import LocalWindowUnsat.ShareWindow7306.Data60

/-! Kernel checks of segments 55-60 of `share7306` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7306
open Snake9.LratFastOffset8192W14
open Snake9.LratOffset8192 (Tree TreeTrue andB)

theorem ok55 : check start55 proof55 = true := by
  decide +kernel

theorem ok56 : andB (check start56 proof56) (cpOk (replay start56 proof56) start57) = true := by
  decide +kernel

theorem ok57 : check start57 proof57 = true := by
  decide +kernel

theorem ok58 : check start58 proof58 = true := by
  decide +kernel

theorem ok59 : check start59 proof59 = true := by
  decide +kernel

theorem ok60 : andB (check start60 proof60) (cpOk (replay start60 proof60) start61) = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7306
