import LocalWindowUnsat.ShareWindow7306.Data78
import LocalWindowUnsat.ShareWindow7306.Data79
import LocalWindowUnsat.ShareWindow7306.Data80
import LocalWindowUnsat.ShareWindow7306.Data81

/-! Kernel checks of segments 79-81 of `share7306` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7306
open Snake9.LratFastOffset8192W14
open Snake9.LratOffset8192 (Tree TreeTrue andB)

theorem ok79 : check start79 proof79 = true := by
  decide +kernel

theorem ok80 : andB (check start80 proof80) (cpOk (replay start80 proof80) start81) = true := by
  decide +kernel

theorem ok81 : andB (check start81 proof81) (hasEmpty (replay start81 proof81) 8192) = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7306
