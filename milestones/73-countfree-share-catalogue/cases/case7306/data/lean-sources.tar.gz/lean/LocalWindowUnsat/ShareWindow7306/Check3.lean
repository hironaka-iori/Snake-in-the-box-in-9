import LocalWindowUnsat.ShareWindow7306.Data12
import LocalWindowUnsat.ShareWindow7306.Data13
import LocalWindowUnsat.ShareWindow7306.Data14
import LocalWindowUnsat.ShareWindow7306.Data15
import LocalWindowUnsat.ShareWindow7306.Data16
import LocalWindowUnsat.ShareWindow7306.Data17
import LocalWindowUnsat.ShareWindow7306.Data18

/-! Kernel checks of segments 13-18 of `share7306` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7306
open Snake9.LratFastOffset8192W14
open Snake9.LratOffset8192 (Tree TreeTrue andB)

theorem ok13 : check start13 proof13 = true := by
  decide +kernel

theorem ok14 : check start14 proof14 = true := by
  decide +kernel

theorem ok15 : check start15 proof15 = true := by
  decide +kernel

theorem ok16 : andB (check start16 proof16) (cpOk (replay start16 proof16) start17) = true := by
  decide +kernel

theorem ok17 : check start17 proof17 = true := by
  decide +kernel

theorem ok18 : check start18 proof18 = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7306
