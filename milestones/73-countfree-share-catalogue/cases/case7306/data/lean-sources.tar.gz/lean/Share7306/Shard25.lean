import Share7306.Data
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace Snake9.LocalWindow.ShareWindow7306
open Snake9.LocalWindow.Tags
theorem shard25 : ckAllS meaning smeaning resolution ctrs tots window cap tags25 raw25 = true := by decide +kernel
#print axioms shard25
end Snake9.LocalWindow.ShareWindow7306
