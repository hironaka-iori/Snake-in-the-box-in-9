import LocalWindowUnsat.ShareWindow7300.Data12
import LocalWindowUnsat.ShareWindow7300.Data13
import LocalWindowUnsat.ShareWindow7300.Data14

/-! Kernel checks of segments 13-14 of `share7300` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.ShareWindow7300
open Snake9.LratFastOffset4096W13
open Snake9.LratOffset4096 (Tree TreeTrue andB)

theorem ok13 : check start13 proof13 = true := by
  decide +kernel

theorem ok14 : andB (check start14 proof14) (hasEmpty (replay start14 proof14) 4096) = true := by
  decide +kernel

end Snake9.LocalWindow.ShareWindow7300
