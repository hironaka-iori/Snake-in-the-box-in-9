import ReplayData150_0026
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok832 : check start832 proof832 = true := by
  decide +kernel
#print axioms ok832
theorem ok833 : check start833 proof833 = true := by
  decide +kernel
#print axioms ok833
theorem ok834 : check start834 proof834 = true := by
  decide +kernel
#print axioms ok834
theorem ok835 : check start835 proof835 = true := by
  decide +kernel
#print axioms ok835
end Snake9.ReplayFull150
