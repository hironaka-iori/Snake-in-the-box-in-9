import ReplayData150_0027
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok876 : check start876 proof876 = true := by
  decide +kernel
#print axioms ok876
theorem ok877 : andB (check start877 proof877) (hasEmpty (replay start877 proof877) 12069) = true := by
  decide +kernel
#print axioms ok877
end Snake9.ReplayFull150
