import ReplayData150_0012
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok396 : check start396 proof396 = true := by
  decide +kernel
#print axioms ok396
theorem ok397 : check start397 proof397 = true := by
  decide +kernel
#print axioms ok397
theorem ok398 : check start398 proof398 = true := by
  decide +kernel
#print axioms ok398
theorem ok399 : check start399 proof399 = true := by
  decide +kernel
#print axioms ok399
end Snake9.ReplayFull150
