import ReplayData150_0021
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok680 : check start680 proof680 = true := by
  decide +kernel
#print axioms ok680
theorem ok681 : check start681 proof681 = true := by
  decide +kernel
#print axioms ok681
theorem ok682 : check start682 proof682 = true := by
  decide +kernel
#print axioms ok682
theorem ok683 : check start683 proof683 = true := by
  decide +kernel
#print axioms ok683
end Snake9.ReplayFull150
