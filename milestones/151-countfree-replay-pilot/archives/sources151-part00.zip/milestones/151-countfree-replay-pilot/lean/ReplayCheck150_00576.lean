import ReplayData150_0018
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok576 : check start576 proof576 = true := by
  decide +kernel
#print axioms ok576
theorem ok577 : check start577 proof577 = true := by
  decide +kernel
#print axioms ok577
theorem ok578 : check start578 proof578 = true := by
  decide +kernel
#print axioms ok578
theorem ok579 : check start579 proof579 = true := by
  decide +kernel
#print axioms ok579
end Snake9.ReplayFull150
