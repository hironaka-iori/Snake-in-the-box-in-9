import ReplayData150_0010
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok336 : check start336 proof336 = true := by
  decide +kernel
#print axioms ok336
theorem ok337 : check start337 proof337 = true := by
  decide +kernel
#print axioms ok337
theorem ok338 : check start338 proof338 = true := by
  decide +kernel
#print axioms ok338
theorem ok339 : check start339 proof339 = true := by
  decide +kernel
#print axioms ok339
end Snake9.ReplayFull150
