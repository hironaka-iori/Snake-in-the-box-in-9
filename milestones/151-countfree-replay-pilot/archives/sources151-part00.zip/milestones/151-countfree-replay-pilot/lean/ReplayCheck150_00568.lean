import ReplayData150_0017
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok568 : check start568 proof568 = true := by
  decide +kernel
#print axioms ok568
theorem ok569 : check start569 proof569 = true := by
  decide +kernel
#print axioms ok569
theorem ok570 : check start570 proof570 = true := by
  decide +kernel
#print axioms ok570
theorem ok571 : check start571 proof571 = true := by
  decide +kernel
#print axioms ok571
end Snake9.ReplayFull150
