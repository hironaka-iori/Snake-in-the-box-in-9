import ReplayData150_0024
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok788 : check start788 proof788 = true := by
  decide +kernel
#print axioms ok788
theorem ok789 : check start789 proof789 = true := by
  decide +kernel
#print axioms ok789
theorem ok790 : check start790 proof790 = true := by
  decide +kernel
#print axioms ok790
theorem ok791 : check start791 proof791 = true := by
  decide +kernel
#print axioms ok791
end Snake9.ReplayFull150
