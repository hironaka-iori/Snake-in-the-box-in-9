import ReplayData150_0015
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok500 : check start500 proof500 = true := by
  decide +kernel
#print axioms ok500
theorem ok501 : check start501 proof501 = true := by
  decide +kernel
#print axioms ok501
theorem ok502 : check start502 proof502 = true := by
  decide +kernel
#print axioms ok502
theorem ok503 : check start503 proof503 = true := by
  decide +kernel
#print axioms ok503
end Snake9.ReplayFull150
