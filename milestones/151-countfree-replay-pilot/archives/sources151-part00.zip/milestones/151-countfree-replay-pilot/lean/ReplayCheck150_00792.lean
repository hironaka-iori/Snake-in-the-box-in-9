import ReplayData150_0024
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok792 : check start792 proof792 = true := by
  decide +kernel
#print axioms ok792
theorem ok793 : check start793 proof793 = true := by
  decide +kernel
#print axioms ok793
theorem ok794 : check start794 proof794 = true := by
  decide +kernel
#print axioms ok794
theorem ok795 : check start795 proof795 = true := by
  decide +kernel
#print axioms ok795
end Snake9.ReplayFull150
