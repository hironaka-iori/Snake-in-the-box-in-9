import ReplayData150_0011
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok368 : check start368 proof368 = true := by
  decide +kernel
#print axioms ok368
theorem ok369 : check start369 proof369 = true := by
  decide +kernel
#print axioms ok369
theorem ok370 : check start370 proof370 = true := by
  decide +kernel
#print axioms ok370
theorem ok371 : check start371 proof371 = true := by
  decide +kernel
#print axioms ok371
end Snake9.ReplayFull150
