import ReplayData150_0004
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok144 : check start144 proof144 = true := by
  decide +kernel
#print axioms ok144
theorem ok145 : check start145 proof145 = true := by
  decide +kernel
#print axioms ok145
theorem ok146 : check start146 proof146 = true := by
  decide +kernel
#print axioms ok146
theorem ok147 : check start147 proof147 = true := by
  decide +kernel
#print axioms ok147
end Snake9.ReplayFull150
