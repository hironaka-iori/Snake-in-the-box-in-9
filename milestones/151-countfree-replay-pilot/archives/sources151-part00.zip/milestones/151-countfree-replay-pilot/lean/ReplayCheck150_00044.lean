import ReplayData150_0001
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok44 : check start44 proof44 = true := by
  decide +kernel
#print axioms ok44
theorem ok45 : check start45 proof45 = true := by
  decide +kernel
#print axioms ok45
theorem ok46 : check start46 proof46 = true := by
  decide +kernel
#print axioms ok46
theorem ok47 : check start47 proof47 = true := by
  decide +kernel
#print axioms ok47
end Snake9.ReplayFull150
