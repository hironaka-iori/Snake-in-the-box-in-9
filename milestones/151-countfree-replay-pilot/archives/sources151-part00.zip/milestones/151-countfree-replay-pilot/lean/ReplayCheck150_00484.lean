import ReplayData150_0015
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok484 : check start484 proof484 = true := by
  decide +kernel
#print axioms ok484
theorem ok485 : check start485 proof485 = true := by
  decide +kernel
#print axioms ok485
theorem ok486 : check start486 proof486 = true := by
  decide +kernel
#print axioms ok486
theorem ok487 : check start487 proof487 = true := by
  decide +kernel
#print axioms ok487
end Snake9.ReplayFull150
