import ReplayData150_0007
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok240 : check start240 proof240 = true := by
  decide +kernel
#print axioms ok240
theorem ok241 : check start241 proof241 = true := by
  decide +kernel
#print axioms ok241
theorem ok242 : check start242 proof242 = true := by
  decide +kernel
#print axioms ok242
theorem ok243 : check start243 proof243 = true := by
  decide +kernel
#print axioms ok243
end Snake9.ReplayFull150
