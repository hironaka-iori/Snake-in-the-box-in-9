import ReplayData150_0019
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok624 : check start624 proof624 = true := by
  decide +kernel
#print axioms ok624
theorem ok625 : check start625 proof625 = true := by
  decide +kernel
#print axioms ok625
theorem ok626 : check start626 proof626 = true := by
  decide +kernel
#print axioms ok626
theorem ok627 : check start627 proof627 = true := by
  decide +kernel
#print axioms ok627
end Snake9.ReplayFull150
