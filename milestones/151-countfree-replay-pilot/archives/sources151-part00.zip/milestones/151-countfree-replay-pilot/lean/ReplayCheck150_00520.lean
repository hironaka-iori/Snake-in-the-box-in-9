import ReplayData150_0016
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok520 : check start520 proof520 = true := by
  decide +kernel
#print axioms ok520
theorem ok521 : check start521 proof521 = true := by
  decide +kernel
#print axioms ok521
theorem ok522 : check start522 proof522 = true := by
  decide +kernel
#print axioms ok522
theorem ok523 : check start523 proof523 = true := by
  decide +kernel
#print axioms ok523
end Snake9.ReplayFull150
