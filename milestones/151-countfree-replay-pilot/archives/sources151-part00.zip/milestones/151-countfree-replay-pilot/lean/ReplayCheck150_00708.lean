import ReplayData150_0022
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok708 : check start708 proof708 = true := by
  decide +kernel
#print axioms ok708
theorem ok709 : check start709 proof709 = true := by
  decide +kernel
#print axioms ok709
theorem ok710 : check start710 proof710 = true := by
  decide +kernel
#print axioms ok710
theorem ok711 : check start711 proof711 = true := by
  decide +kernel
#print axioms ok711
end Snake9.ReplayFull150
