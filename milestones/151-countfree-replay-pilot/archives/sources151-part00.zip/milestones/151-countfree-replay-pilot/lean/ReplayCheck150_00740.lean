import ReplayData150_0023
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok740 : check start740 proof740 = true := by
  decide +kernel
#print axioms ok740
theorem ok741 : check start741 proof741 = true := by
  decide +kernel
#print axioms ok741
theorem ok742 : check start742 proof742 = true := by
  decide +kernel
#print axioms ok742
theorem ok743 : check start743 proof743 = true := by
  decide +kernel
#print axioms ok743
end Snake9.ReplayFull150
