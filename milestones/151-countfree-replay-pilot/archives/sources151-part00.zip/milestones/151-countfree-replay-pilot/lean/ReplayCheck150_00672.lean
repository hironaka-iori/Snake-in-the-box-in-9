import ReplayData150_0021
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok672 : check start672 proof672 = true := by
  decide +kernel
#print axioms ok672
theorem ok673 : check start673 proof673 = true := by
  decide +kernel
#print axioms ok673
theorem ok674 : check start674 proof674 = true := by
  decide +kernel
#print axioms ok674
theorem ok675 : check start675 proof675 = true := by
  decide +kernel
#print axioms ok675
end Snake9.ReplayFull150
