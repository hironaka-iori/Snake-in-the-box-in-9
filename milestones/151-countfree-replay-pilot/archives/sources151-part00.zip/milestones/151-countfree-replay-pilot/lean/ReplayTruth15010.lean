import ReplayParts15010
import ReplayTools150
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayData150
theorem part80_slice : input80.clauses = ((Snake9.LocalWindow.ShareWindow150.raw80 ++ Snake9.LocalWindow.ShareWindow150.raw81).drop 5).take 127 := by
  rw [part80_clauses]
  rfl
theorem part80_true (τ : Nat → Bool)
    (h80 : Snake9.LocalWindow.ShareWindow150.raw80.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h81 : Snake9.LocalWindow.ShareWindow150.raw81.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat150Replay.TreeTrue τ part80 := by
  rw [← part80_build]
  apply build_true_of_slice τ input80 (Snake9.LocalWindow.ShareWindow150.raw80 ++ Snake9.LocalWindow.ShareWindow150.raw81) 5 127 part80_slice
  rw [List.all_append]
  rw [h80, h81]
  rfl
#print axioms part80_true
theorem part81_slice : input81.clauses = ((Snake9.LocalWindow.ShareWindow150.raw81 ++ Snake9.LocalWindow.ShareWindow150.raw82).drop 4).take 127 := by
  rw [part81_clauses]
  rfl
theorem part81_true (τ : Nat → Bool)
    (h81 : Snake9.LocalWindow.ShareWindow150.raw81.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h82 : Snake9.LocalWindow.ShareWindow150.raw82.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat150Replay.TreeTrue τ part81 := by
  rw [← part81_build]
  apply build_true_of_slice τ input81 (Snake9.LocalWindow.ShareWindow150.raw81 ++ Snake9.LocalWindow.ShareWindow150.raw82) 4 127 part81_slice
  rw [List.all_append]
  rw [h81, h82]
  rfl
#print axioms part81_true
theorem part82_slice : input82.clauses = ((Snake9.LocalWindow.ShareWindow150.raw82 ++ Snake9.LocalWindow.ShareWindow150.raw83).drop 4).take 127 := by
  rw [part82_clauses]
  rfl
theorem part82_true (τ : Nat → Bool)
    (h82 : Snake9.LocalWindow.ShareWindow150.raw82.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h83 : Snake9.LocalWindow.ShareWindow150.raw83.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat150Replay.TreeTrue τ part82 := by
  rw [← part82_build]
  apply build_true_of_slice τ input82 (Snake9.LocalWindow.ShareWindow150.raw82 ++ Snake9.LocalWindow.ShareWindow150.raw83) 4 127 part82_slice
  rw [List.all_append]
  rw [h82, h83]
  rfl
#print axioms part82_true
theorem part83_slice : input83.clauses = ((Snake9.LocalWindow.ShareWindow150.raw83 ++ Snake9.LocalWindow.ShareWindow150.raw84).drop 3).take 127 := by
  rw [part83_clauses]
  rfl
theorem part83_true (τ : Nat → Bool)
    (h83 : Snake9.LocalWindow.ShareWindow150.raw83.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h84 : Snake9.LocalWindow.ShareWindow150.raw84.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat150Replay.TreeTrue τ part83 := by
  rw [← part83_build]
  apply build_true_of_slice τ input83 (Snake9.LocalWindow.ShareWindow150.raw83 ++ Snake9.LocalWindow.ShareWindow150.raw84) 3 127 part83_slice
  rw [List.all_append]
  rw [h83, h84]
  rfl
#print axioms part83_true
theorem part84_slice : input84.clauses = ((Snake9.LocalWindow.ShareWindow150.raw84 ++ Snake9.LocalWindow.ShareWindow150.raw85).drop 4).take 127 := by
  rw [part84_clauses]
  rfl
theorem part84_true (τ : Nat → Bool)
    (h84 : Snake9.LocalWindow.ShareWindow150.raw84.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h85 : Snake9.LocalWindow.ShareWindow150.raw85.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat150Replay.TreeTrue τ part84 := by
  rw [← part84_build]
  apply build_true_of_slice τ input84 (Snake9.LocalWindow.ShareWindow150.raw84 ++ Snake9.LocalWindow.ShareWindow150.raw85) 4 127 part84_slice
  rw [List.all_append]
  rw [h84, h85]
  rfl
#print axioms part84_true
theorem part85_slice : input85.clauses = ((Snake9.LocalWindow.ShareWindow150.raw85 ++ Snake9.LocalWindow.ShareWindow150.raw86).drop 3).take 127 := by
  rw [part85_clauses]
  rfl
theorem part85_true (τ : Nat → Bool)
    (h85 : Snake9.LocalWindow.ShareWindow150.raw85.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h86 : Snake9.LocalWindow.ShareWindow150.raw86.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat150Replay.TreeTrue τ part85 := by
  rw [← part85_build]
  apply build_true_of_slice τ input85 (Snake9.LocalWindow.ShareWindow150.raw85 ++ Snake9.LocalWindow.ShareWindow150.raw86) 3 127 part85_slice
  rw [List.all_append]
  rw [h85, h86]
  rfl
#print axioms part85_true
theorem part86_slice : input86.clauses = ((Snake9.LocalWindow.ShareWindow150.raw86 ++ Snake9.LocalWindow.ShareWindow150.raw87).drop 3).take 127 := by
  rw [part86_clauses]
  rfl
theorem part86_true (τ : Nat → Bool)
    (h86 : Snake9.LocalWindow.ShareWindow150.raw86.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h87 : Snake9.LocalWindow.ShareWindow150.raw87.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat150Replay.TreeTrue τ part86 := by
  rw [← part86_build]
  apply build_true_of_slice τ input86 (Snake9.LocalWindow.ShareWindow150.raw86 ++ Snake9.LocalWindow.ShareWindow150.raw87) 3 127 part86_slice
  rw [List.all_append]
  rw [h86, h87]
  rfl
#print axioms part86_true
theorem part87_slice : input87.clauses = ((Snake9.LocalWindow.ShareWindow150.raw87 ++ Snake9.LocalWindow.ShareWindow150.raw88).drop 2).take 127 := by
  rw [part87_clauses]
  rfl
theorem part87_true (τ : Nat → Bool)
    (h87 : Snake9.LocalWindow.ShareWindow150.raw87.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    (h88 : Snake9.LocalWindow.ShareWindow150.raw88.all (fun c => Snake9.LocalWindow.clauseTrue τ (c.map Snake9.LocalWindow.decodeLit)) = true)
    : Snake9.Lrat150Replay.TreeTrue τ part87 := by
  rw [← part87_build]
  apply build_true_of_slice τ input87 (Snake9.LocalWindow.ShareWindow150.raw87 ++ Snake9.LocalWindow.ShareWindow150.raw88) 2 127 part87_slice
  rw [List.all_append]
  rw [h87, h88]
  rfl
#print axioms part87_true
end Snake9.ReplayData150
