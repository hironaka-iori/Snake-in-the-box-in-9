import ReplayData150_0018
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok588 : check start588 proof588 = true := by
  decide +kernel
#print axioms ok588
theorem ok589 : check start589 proof589 = true := by
  decide +kernel
#print axioms ok589
theorem ok590 : check start590 proof590 = true := by
  decide +kernel
#print axioms ok590
theorem ok591 : check start591 proof591 = true := by
  decide +kernel
#print axioms ok591
end Snake9.ReplayFull150
