import ReplayData150_0011
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok356 : check start356 proof356 = true := by
  decide +kernel
#print axioms ok356
theorem ok357 : check start357 proof357 = true := by
  decide +kernel
#print axioms ok357
theorem ok358 : check start358 proof358 = true := by
  decide +kernel
#print axioms ok358
theorem ok359 : check start359 proof359 = true := by
  decide +kernel
#print axioms ok359
end Snake9.ReplayFull150
