import ReplayData150_0016
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok536 : check start536 proof536 = true := by
  decide +kernel
#print axioms ok536
theorem ok537 : check start537 proof537 = true := by
  decide +kernel
#print axioms ok537
theorem ok538 : check start538 proof538 = true := by
  decide +kernel
#print axioms ok538
theorem ok539 : check start539 proof539 = true := by
  decide +kernel
#print axioms ok539
end Snake9.ReplayFull150
