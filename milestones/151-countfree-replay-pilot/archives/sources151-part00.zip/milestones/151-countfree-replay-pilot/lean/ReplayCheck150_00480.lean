import ReplayData150_0015
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok480 : check start480 proof480 = true := by
  decide +kernel
#print axioms ok480
theorem ok481 : check start481 proof481 = true := by
  decide +kernel
#print axioms ok481
theorem ok482 : check start482 proof482 = true := by
  decide +kernel
#print axioms ok482
theorem ok483 : check start483 proof483 = true := by
  decide +kernel
#print axioms ok483
end Snake9.ReplayFull150
