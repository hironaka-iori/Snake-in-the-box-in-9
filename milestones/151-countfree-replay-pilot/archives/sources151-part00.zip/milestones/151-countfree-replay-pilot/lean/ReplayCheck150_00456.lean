import ReplayData150_0014
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok456 : check start456 proof456 = true := by
  decide +kernel
#print axioms ok456
theorem ok457 : check start457 proof457 = true := by
  decide +kernel
#print axioms ok457
theorem ok458 : check start458 proof458 = true := by
  decide +kernel
#print axioms ok458
theorem ok459 : check start459 proof459 = true := by
  decide +kernel
#print axioms ok459
end Snake9.ReplayFull150
