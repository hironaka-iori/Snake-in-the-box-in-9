import ReplayData150_0008
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok276 : check start276 proof276 = true := by
  decide +kernel
#print axioms ok276
theorem ok277 : check start277 proof277 = true := by
  decide +kernel
#print axioms ok277
theorem ok278 : check start278 proof278 = true := by
  decide +kernel
#print axioms ok278
theorem ok279 : check start279 proof279 = true := by
  decide +kernel
#print axioms ok279
end Snake9.ReplayFull150
