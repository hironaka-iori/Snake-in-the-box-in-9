import ReplayData150_0009
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok304 : check start304 proof304 = true := by
  decide +kernel
#print axioms ok304
theorem ok305 : check start305 proof305 = true := by
  decide +kernel
#print axioms ok305
theorem ok306 : check start306 proof306 = true := by
  decide +kernel
#print axioms ok306
theorem ok307 : check start307 proof307 = true := by
  decide +kernel
#print axioms ok307
end Snake9.ReplayFull150
