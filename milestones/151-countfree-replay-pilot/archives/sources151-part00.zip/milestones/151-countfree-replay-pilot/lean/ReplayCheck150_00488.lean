import ReplayData150_0015
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok488 : check start488 proof488 = true := by
  decide +kernel
#print axioms ok488
theorem ok489 : check start489 proof489 = true := by
  decide +kernel
#print axioms ok489
theorem ok490 : check start490 proof490 = true := by
  decide +kernel
#print axioms ok490
theorem ok491 : check start491 proof491 = true := by
  decide +kernel
#print axioms ok491
end Snake9.ReplayFull150
