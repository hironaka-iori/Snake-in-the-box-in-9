import ReplayData150_0008
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok272 : check start272 proof272 = true := by
  decide +kernel
#print axioms ok272
theorem ok273 : check start273 proof273 = true := by
  decide +kernel
#print axioms ok273
theorem ok274 : check start274 proof274 = true := by
  decide +kernel
#print axioms ok274
theorem ok275 : check start275 proof275 = true := by
  decide +kernel
#print axioms ok275
end Snake9.ReplayFull150
