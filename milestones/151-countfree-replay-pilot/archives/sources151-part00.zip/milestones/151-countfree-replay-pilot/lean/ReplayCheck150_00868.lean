import ReplayData150_0027
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok868 : check start868 proof868 = true := by
  decide +kernel
#print axioms ok868
theorem ok869 : check start869 proof869 = true := by
  decide +kernel
#print axioms ok869
theorem ok870 : check start870 proof870 = true := by
  decide +kernel
#print axioms ok870
theorem ok871 : check start871 proof871 = true := by
  decide +kernel
#print axioms ok871
end Snake9.ReplayFull150
