import ReplayData150_0020
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok656 : check start656 proof656 = true := by
  decide +kernel
#print axioms ok656
theorem ok657 : check start657 proof657 = true := by
  decide +kernel
#print axioms ok657
theorem ok658 : check start658 proof658 = true := by
  decide +kernel
#print axioms ok658
theorem ok659 : check start659 proof659 = true := by
  decide +kernel
#print axioms ok659
end Snake9.ReplayFull150
