import ReplayData150_0014
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok464 : check start464 proof464 = true := by
  decide +kernel
#print axioms ok464
theorem ok465 : check start465 proof465 = true := by
  decide +kernel
#print axioms ok465
theorem ok466 : check start466 proof466 = true := by
  decide +kernel
#print axioms ok466
theorem ok467 : check start467 proof467 = true := by
  decide +kernel
#print axioms ok467
end Snake9.ReplayFull150
