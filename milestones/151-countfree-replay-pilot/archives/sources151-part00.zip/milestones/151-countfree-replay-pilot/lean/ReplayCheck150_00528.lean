import ReplayData150_0016
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok528 : check start528 proof528 = true := by
  decide +kernel
#print axioms ok528
theorem ok529 : check start529 proof529 = true := by
  decide +kernel
#print axioms ok529
theorem ok530 : check start530 proof530 = true := by
  decide +kernel
#print axioms ok530
theorem ok531 : check start531 proof531 = true := by
  decide +kernel
#print axioms ok531
end Snake9.ReplayFull150
