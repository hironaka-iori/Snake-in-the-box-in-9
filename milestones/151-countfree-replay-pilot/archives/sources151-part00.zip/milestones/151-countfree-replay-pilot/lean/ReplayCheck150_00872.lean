import ReplayData150_0027
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok872 : check start872 proof872 = true := by
  decide +kernel
#print axioms ok872
theorem ok873 : check start873 proof873 = true := by
  decide +kernel
#print axioms ok873
theorem ok874 : check start874 proof874 = true := by
  decide +kernel
#print axioms ok874
theorem ok875 : check start875 proof875 = true := by
  decide +kernel
#print axioms ok875
end Snake9.ReplayFull150
