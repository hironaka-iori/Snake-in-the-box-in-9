import ReplayData150_0009
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok288 : check start288 proof288 = true := by
  decide +kernel
#print axioms ok288
theorem ok289 : check start289 proof289 = true := by
  decide +kernel
#print axioms ok289
theorem ok290 : check start290 proof290 = true := by
  decide +kernel
#print axioms ok290
theorem ok291 : check start291 proof291 = true := by
  decide +kernel
#print axioms ok291
end Snake9.ReplayFull150
