import ReplayData150_0013
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok420 : check start420 proof420 = true := by
  decide +kernel
#print axioms ok420
theorem ok421 : check start421 proof421 = true := by
  decide +kernel
#print axioms ok421
theorem ok422 : check start422 proof422 = true := by
  decide +kernel
#print axioms ok422
theorem ok423 : check start423 proof423 = true := by
  decide +kernel
#print axioms ok423
end Snake9.ReplayFull150
