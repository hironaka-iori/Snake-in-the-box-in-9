import ReplayData150_0014
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok452 : check start452 proof452 = true := by
  decide +kernel
#print axioms ok452
theorem ok453 : check start453 proof453 = true := by
  decide +kernel
#print axioms ok453
theorem ok454 : check start454 proof454 = true := by
  decide +kernel
#print axioms ok454
theorem ok455 : check start455 proof455 = true := by
  decide +kernel
#print axioms ok455
end Snake9.ReplayFull150
