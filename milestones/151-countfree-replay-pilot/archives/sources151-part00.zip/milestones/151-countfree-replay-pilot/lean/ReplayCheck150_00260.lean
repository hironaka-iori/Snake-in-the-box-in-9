import ReplayData150_0008
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.ReplayFull150
open Snake9.Lrat150Replay (andB)
open Snake9.LratFast150Replay
theorem ok260 : check start260 proof260 = true := by
  decide +kernel
#print axioms ok260
theorem ok261 : check start261 proof261 = true := by
  decide +kernel
#print axioms ok261
theorem ok262 : check start262 proof262 = true := by
  decide +kernel
#print axioms ok262
theorem ok263 : check start263 proof263 = true := by
  decide +kernel
#print axioms ok263
end Snake9.ReplayFull150
