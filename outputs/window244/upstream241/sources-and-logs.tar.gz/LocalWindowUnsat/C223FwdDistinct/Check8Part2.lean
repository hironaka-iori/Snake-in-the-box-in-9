import LocalWindowUnsat.C223FwdDistinct.Check8Part2Check
import LocalWindowUnsat.C223FwdDistinct.Check8Part2Checkpoint

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok30 : andB (check start30 proof30) (cpOk (replay start30 proof30) cp31) = true := by
  exact combineChecks ok30_Check ok30_Checkpoint
end Snake9.LocalWindow.C223FwdDistinct
