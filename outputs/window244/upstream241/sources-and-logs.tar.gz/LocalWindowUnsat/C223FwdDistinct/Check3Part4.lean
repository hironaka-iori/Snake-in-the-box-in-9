import LocalWindowUnsat.C223FwdDistinct.Check3Part4Check
import LocalWindowUnsat.C223FwdDistinct.Check3Part4Checkpoint

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok12 : andB (check start12 proof12) (cpOk (replay start12 proof12) cp13) = true := by
  exact combineChecks ok12_Check ok12_Checkpoint
end Snake9.LocalWindow.C223FwdDistinct
