import LocalWindowUnsat.C223FwdDistinct.Check7Part3Check
import LocalWindowUnsat.C223FwdDistinct.Check7Part3Checkpoint

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok27 : andB (check start27 proof27) (cpOk (replay start27 proof27) cp28) = true := by
  exact combineChecks ok27_Check ok27_Checkpoint
end Snake9.LocalWindow.C223FwdDistinct
