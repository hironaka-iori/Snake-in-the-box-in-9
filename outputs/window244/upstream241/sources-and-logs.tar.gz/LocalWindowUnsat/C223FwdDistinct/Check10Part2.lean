import LocalWindowUnsat.C223FwdDistinct.Check10Part2Check
import LocalWindowUnsat.C223FwdDistinct.Check10Part2Checkpoint

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok38 : andB (check start38 proof38) (hasEmpty (replay start38 proof38) 1244) = true := by
  exact combineChecks ok38_Check ok38_Checkpoint
end Snake9.LocalWindow.C223FwdDistinct
