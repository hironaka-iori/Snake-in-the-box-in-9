import LocalWindowUnsat.C223FwdDistinct.Data24

/-! Kernel checks of segments 21-24 of `223_fwd_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat

theorem ok21_Checkpoint : cpOk (replay start21 proof21) cp22 = true := by
  decide +kernel

end Snake9.LocalWindow.C223FwdDistinct
