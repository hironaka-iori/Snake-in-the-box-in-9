import LocalWindowUnsat.C223FwdDistinct.Check9Part4Check
import LocalWindowUnsat.C223FwdDistinct.Check9Part4Checkpoint

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok36 : andB (check start36 proof36) (cpOk (replay start36 proof36) cp37) = true := by
  exact combineChecks ok36_Check ok36_Checkpoint
end Snake9.LocalWindow.C223FwdDistinct
