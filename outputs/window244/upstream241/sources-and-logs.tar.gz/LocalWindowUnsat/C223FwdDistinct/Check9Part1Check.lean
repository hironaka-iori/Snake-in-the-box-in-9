import LocalWindowUnsat.C223FwdDistinct.Data36

/-! Kernel checks of segments 33-36 of `223_fwd_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat

theorem ok33_Check : check start33 proof33 = true := by
  decide +kernel

end Snake9.LocalWindow.C223FwdDistinct
