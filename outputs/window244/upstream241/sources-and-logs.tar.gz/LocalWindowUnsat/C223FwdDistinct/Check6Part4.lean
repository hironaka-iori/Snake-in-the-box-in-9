import LocalWindowUnsat.C223FwdDistinct.Check6Part4Check
import LocalWindowUnsat.C223FwdDistinct.Check6Part4Checkpoint

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok24 : andB (check start24 proof24) (cpOk (replay start24 proof24) cp25) = true := by
  exact combineChecks ok24_Check ok24_Checkpoint
end Snake9.LocalWindow.C223FwdDistinct
