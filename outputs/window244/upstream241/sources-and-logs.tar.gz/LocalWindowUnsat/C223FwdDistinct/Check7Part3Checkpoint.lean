import LocalWindowUnsat.C223FwdDistinct.Data28

/-! Kernel checks of segments 25-28 of `223_fwd_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat

theorem ok27_Checkpoint : cpOk (replay start27 proof27) cp28 = true := by
  decide +kernel

end Snake9.LocalWindow.C223FwdDistinct
