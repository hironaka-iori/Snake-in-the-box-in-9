import LocalWindowUnsat.C223FwdDistinct.Data20

/-! Kernel checks of segments 17-20 of `223_fwd_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat

theorem ok20 : check start20 proof20 = true := by
  decide +kernel


end Snake9.LocalWindow.C223FwdDistinct
