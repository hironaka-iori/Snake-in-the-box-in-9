import LocalWindowUnsat.C223FwdDistinct.Check9Part1Check
import LocalWindowUnsat.C223FwdDistinct.Check9Part1Checkpoint

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok33 : andB (check start33 proof33) (cpOk (replay start33 proof33) cp34) = true := by
  exact combineChecks ok33_Check ok33_Checkpoint
end Snake9.LocalWindow.C223FwdDistinct
