import LocalWindowUnsat.C223FwdDistinct.Data32

/-! Kernel checks of segments 29-32 of `223_fwd_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223FwdDistinct
open Snake9.Lrat

theorem ok32 : check start32 proof32 = true := by
  decide +kernel


end Snake9.LocalWindow.C223FwdDistinct
