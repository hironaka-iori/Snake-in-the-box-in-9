import LocalWindowUnsat.C223RevRepeated.Check3Part1Check
import LocalWindowUnsat.C223RevRepeated.Check3Part1Checkpoint

namespace Snake9.LocalWindow.C223RevRepeated
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok9 : andB (check start9 proof9) (cpOk (replay start9 proof9) cp10) = true := by
  exact combineChecks ok9_Check ok9_Checkpoint
end Snake9.LocalWindow.C223RevRepeated
