import LocalWindowUnsat.C223RevRepeated.Check2Part2Check
import LocalWindowUnsat.C223RevRepeated.Check2Part2Checkpoint

namespace Snake9.LocalWindow.C223RevRepeated
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok6 : andB (check start6 proof6) (cpOk (replay start6 proof6) cp7) = true := by
  exact combineChecks ok6_Check ok6_Checkpoint
end Snake9.LocalWindow.C223RevRepeated
