import LocalWindowUnsat.C223RevRepeated.Check3Part2Check
import LocalWindowUnsat.C223RevRepeated.Check3Part2Checkpoint

namespace Snake9.LocalWindow.C223RevRepeated
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok10 : andB (check start10 proof10) (hasEmpty (replay start10 proof10) 994) = true := by
  exact combineChecks ok10_Check ok10_Checkpoint
end Snake9.LocalWindow.C223RevRepeated
