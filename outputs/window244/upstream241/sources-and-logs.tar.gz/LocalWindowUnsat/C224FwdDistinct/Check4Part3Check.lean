import LocalWindowUnsat.C224FwdDistinct.Data16

/-! Kernel checks of segments 13-16 of `224_fwd_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C224FwdDistinct
open Snake9.Lrat

theorem ok15_Check : check start15 proof15 = true := by
  decide +kernel

end Snake9.LocalWindow.C224FwdDistinct
