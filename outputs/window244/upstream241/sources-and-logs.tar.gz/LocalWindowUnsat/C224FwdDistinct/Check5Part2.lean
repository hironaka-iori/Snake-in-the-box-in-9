import LocalWindowUnsat.C224FwdDistinct.Check5Part2Check
import LocalWindowUnsat.C224FwdDistinct.Check5Part2Checkpoint

namespace Snake9.LocalWindow.C224FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok18 : andB (check start18 proof18) (cpOk (replay start18 proof18) cp19) = true := by
  exact combineChecks ok18_Check ok18_Checkpoint
end Snake9.LocalWindow.C224FwdDistinct
