import LocalWindowUnsat.C224FwdDistinct.Data8

/-! Kernel checks of segments 5-8 of `224_fwd_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C224FwdDistinct
open Snake9.Lrat

theorem ok7 : check start7 proof7 = true := by
  decide +kernel


end Snake9.LocalWindow.C224FwdDistinct
