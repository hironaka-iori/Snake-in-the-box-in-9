import LocalWindowUnsat.C224FwdDistinct.Check6Part1Check
import LocalWindowUnsat.C224FwdDistinct.Check6Part1Checkpoint

namespace Snake9.LocalWindow.C224FwdDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok21 : andB (check start21 proof21) (cpOk (replay start21 proof21) cp22) = true := by
  exact combineChecks ok21_Check ok21_Checkpoint
end Snake9.LocalWindow.C224FwdDistinct
