import LocalWindowUnsat.C224FwdDistinct.Check5Part2CheckHalf1
import LocalWindowUnsat.C224FwdDistinct.Check5Part2CheckHalf2
namespace Snake9.LocalWindow.C224FwdDistinct
open Snake9.Lrat
set_option Elab.async false
theorem ok18_Check : check start18 proof18 = true := by
  have h := check_append_true start18 (proof18.take 214) (proof18.drop 214) ok18_Check_half1 ok18_Check_half2
  rw [List.take_append_drop] at h
  exact h
end Snake9.LocalWindow.C224FwdDistinct
