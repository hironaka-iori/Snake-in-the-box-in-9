import LocalWindowUnsat.C223RevDistinct.Data8

/-! Kernel checks of segments 5-8 of `223_rev_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223RevDistinct
open Snake9.Lrat

theorem ok8 : check start8 proof8 = true := by
  decide +kernel


end Snake9.LocalWindow.C223RevDistinct
