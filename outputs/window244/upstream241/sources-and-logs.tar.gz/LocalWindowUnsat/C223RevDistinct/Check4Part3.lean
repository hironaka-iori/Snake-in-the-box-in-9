import LocalWindowUnsat.C223RevDistinct.Check4Part3Check
import LocalWindowUnsat.C223RevDistinct.Check4Part3Checkpoint

namespace Snake9.LocalWindow.C223RevDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok15 : andB (check start15 proof15) (cpOk (replay start15 proof15) cp16) = true := by
  exact combineChecks ok15_Check ok15_Checkpoint
end Snake9.LocalWindow.C223RevDistinct
