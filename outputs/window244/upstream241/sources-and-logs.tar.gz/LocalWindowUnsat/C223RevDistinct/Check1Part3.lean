import LocalWindowUnsat.C223RevDistinct.Check1Part3Check
import LocalWindowUnsat.C223RevDistinct.Check1Part3Checkpoint

namespace Snake9.LocalWindow.C223RevDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok3 : andB (check start3 proof3) (cpOk (replay start3 proof3) cp4) = true := by
  exact combineChecks ok3_Check ok3_Checkpoint
end Snake9.LocalWindow.C223RevDistinct
