import LocalWindowUnsat.C223RevDistinct.Data4

/-! Kernel checks of segments 1-4 of `223_rev_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223RevDistinct
open Snake9.Lrat

theorem ok3_Check : check start3 proof3 = true := by
  decide +kernel

end Snake9.LocalWindow.C223RevDistinct
