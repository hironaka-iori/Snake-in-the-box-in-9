import LocalWindowUnsat.C223RevDistinct.Data20

/-! Kernel checks of segments 17-20 of `223_rev_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223RevDistinct
open Snake9.Lrat

theorem ok17 : check start17 proof17 = true := by
  decide +kernel


end Snake9.LocalWindow.C223RevDistinct
