import LocalWindowUnsat.C223RevDistinct.Check8Part3Check
import LocalWindowUnsat.C223RevDistinct.Check8Part3Checkpoint

namespace Snake9.LocalWindow.C223RevDistinct
open Snake9.Lrat
set_option Elab.async false
private theorem combineChecks {a b : Bool} (ha : a = true) (hb : b = true) : andB a b = true := by
  rw [ha, hb]
  rfl
theorem ok31 : andB (check start31 proof31) (hasEmpty (replay start31 proof31) 1118) = true := by
  exact combineChecks ok31_Check ok31_Checkpoint
end Snake9.LocalWindow.C223RevDistinct
