import LocalWindowUnsat.C223RevDistinct.Data12

/-! Kernel checks of segments 9-12 of `223_rev_distinct` (generated). -/

set_option maxRecDepth 100000
set_option maxHeartbeats 0

set_option Elab.async false

namespace Snake9.LocalWindow.C223RevDistinct
open Snake9.Lrat

theorem ok10 : check start10 proof10 = true := by
  decide +kernel


end Snake9.LocalWindow.C223RevDistinct
