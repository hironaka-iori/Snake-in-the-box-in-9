import Std

/- A snake's length is its number of edges. No optimality axiom is declared. -/
namespace Snake9

abbrev Vertex := Fin 512

def Adj (u v : Vertex) : Prop :=
  (List.range 9).any (fun k => v.val == Nat.xor u.val (2 ^ k)) = true

instance (u v : Vertex) : Decidable (Adj u v) :=
  inferInstanceAs (Decidable (_ = true))

theorem adj_iff_coordinate_flip (u v : Vertex) :
    Adj u v ↔ ∃ k : Nat, k < 9 ∧ v.val = Nat.xor u.val (2 ^ k) := by
  simp [Adj, List.any_eq_true]

structure Snake (m : Nat) where
  vertex : Fin (m + 1) → Vertex
  distinct : ∀ i j, vertex i = vertex j → i = j
  induced : ∀ i j, i.val < j.val → (Adj (vertex i) (vertex j) ↔ i.val + 1 = j.val)

def takePrefix {m k : Nat} (p : Snake m) (h : k ≤ m) : Snake k where
  vertex i := p.vertex ⟨i.val, by omega⟩
  distinct i j eq := by
    have e := p.distinct ⟨i.val, by omega⟩ ⟨j.val, by omega⟩ eq
    apply Fin.ext
    exact congrArg (fun x : Fin (m + 1) => x.val) e
  induced i j hij := p.induced ⟨i.val, by omega⟩ ⟨j.val, by omega⟩ hij

theorem no192_iff_upperBound :
    (¬ Nonempty (Snake 192)) ↔ (∀ m, Nonempty (Snake m) → m ≤ 191) := by
  constructor
  · intro h m hp
    cases Nat.lt_or_ge m 192 with
    | inl hm => omega
    | inr hm =>
      obtain ⟨p⟩ := hp
      exact False.elim (h ⟨takePrefix p hm⟩)
  · intro h hp
    have := h 192 hp
    omega

/- An exact finite target: 193 distinct cube vertices in induced-path order. -/
def Target192 : Prop :=
  ∃ f : Fin 193 → Vertex,
    (∀ i j, f i = f j → i = j) ∧
    (∀ i j, i.val < j.val → (Adj (f i) (f j) ↔ i.val + 1 = j.val))

theorem target192_iff : Target192 ↔ Nonempty (Snake 192) := by
  constructor
  · rintro ⟨f, hd, hi⟩
    exact ⟨⟨f, hd, hi⟩⟩
  · rintro ⟨p⟩
    exact ⟨p.vertex, p.distinct, p.induced⟩

theorem target192_impossible_iff_upperBound :
    (¬ Target192) ↔ (∀ m, Nonempty (Snake m) → m ≤ 191) := by
  rw [target192_iff, no192_iff_upperBound]

#print axioms no192_iff_upperBound
#print axioms target192_impossible_iff_upperBound

-- BEGIN WITNESS
set_option Elab.async false
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def witnessValues : Array Nat := #[0, 1, 3, 7, 6, 14, 12, 28, 60, 61, 125, 121, 123, 122, 58, 26, 27, 31, 95, 87, 85, 69, 77, 73, 75, 74, 66, 98, 99, 103, 111, 47, 43, 41, 40, 104, 108, 100, 36, 37, 165, 181, 180, 244, 252, 248, 184, 185, 187, 191, 255, 247, 243, 242, 178, 162, 418, 426, 427, 431, 495, 487, 485, 453, 461, 457, 393, 385, 387, 391, 390, 398, 462, 458, 450, 466, 467, 471, 479, 415, 411, 410, 408, 472, 476, 468, 404, 405, 277, 309, 308, 372, 380, 376, 312, 313, 315, 319, 383, 375, 371, 370, 306, 274, 278, 286, 350, 346, 347, 345, 337, 321, 323, 327, 326, 324, 332, 328, 264, 266, 267, 271, 269, 301, 365, 361, 363, 362, 366, 302, 294, 295, 291, 289, 288, 352, 480, 496, 432, 433, 435, 439, 438, 502, 510, 506, 507, 505, 509, 445, 444, 428, 172, 174, 238, 234, 235, 233, 225, 193, 195, 199, 198, 196, 204, 200, 136, 138, 139, 143, 141, 157, 221, 217, 219, 218, 222, 158, 150, 151, 147, 145, 144, 208, 80, 112, 48, 49, 51, 55, 54, 118]

def witnessVertex (i : Fin 192) : Vertex :=
  ⟨witnessValues[i.val]! % 512, Nat.mod_lt _ (by decide)⟩

theorem witness_distinct_row_0 : ∀ j : Fin 192, witnessVertex (0 : Fin 192) = witnessVertex j → (0 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_1 : ∀ j : Fin 192, witnessVertex (1 : Fin 192) = witnessVertex j → (1 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_2 : ∀ j : Fin 192, witnessVertex (2 : Fin 192) = witnessVertex j → (2 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_3 : ∀ j : Fin 192, witnessVertex (3 : Fin 192) = witnessVertex j → (3 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_4 : ∀ j : Fin 192, witnessVertex (4 : Fin 192) = witnessVertex j → (4 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_5 : ∀ j : Fin 192, witnessVertex (5 : Fin 192) = witnessVertex j → (5 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_6 : ∀ j : Fin 192, witnessVertex (6 : Fin 192) = witnessVertex j → (6 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_7 : ∀ j : Fin 192, witnessVertex (7 : Fin 192) = witnessVertex j → (7 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_8 : ∀ j : Fin 192, witnessVertex (8 : Fin 192) = witnessVertex j → (8 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_9 : ∀ j : Fin 192, witnessVertex (9 : Fin 192) = witnessVertex j → (9 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_10 : ∀ j : Fin 192, witnessVertex (10 : Fin 192) = witnessVertex j → (10 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_11 : ∀ j : Fin 192, witnessVertex (11 : Fin 192) = witnessVertex j → (11 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_12 : ∀ j : Fin 192, witnessVertex (12 : Fin 192) = witnessVertex j → (12 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_13 : ∀ j : Fin 192, witnessVertex (13 : Fin 192) = witnessVertex j → (13 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_14 : ∀ j : Fin 192, witnessVertex (14 : Fin 192) = witnessVertex j → (14 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_15 : ∀ j : Fin 192, witnessVertex (15 : Fin 192) = witnessVertex j → (15 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_16 : ∀ j : Fin 192, witnessVertex (16 : Fin 192) = witnessVertex j → (16 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_17 : ∀ j : Fin 192, witnessVertex (17 : Fin 192) = witnessVertex j → (17 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_18 : ∀ j : Fin 192, witnessVertex (18 : Fin 192) = witnessVertex j → (18 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_19 : ∀ j : Fin 192, witnessVertex (19 : Fin 192) = witnessVertex j → (19 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_20 : ∀ j : Fin 192, witnessVertex (20 : Fin 192) = witnessVertex j → (20 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_21 : ∀ j : Fin 192, witnessVertex (21 : Fin 192) = witnessVertex j → (21 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_22 : ∀ j : Fin 192, witnessVertex (22 : Fin 192) = witnessVertex j → (22 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_23 : ∀ j : Fin 192, witnessVertex (23 : Fin 192) = witnessVertex j → (23 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_24 : ∀ j : Fin 192, witnessVertex (24 : Fin 192) = witnessVertex j → (24 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_25 : ∀ j : Fin 192, witnessVertex (25 : Fin 192) = witnessVertex j → (25 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_26 : ∀ j : Fin 192, witnessVertex (26 : Fin 192) = witnessVertex j → (26 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_27 : ∀ j : Fin 192, witnessVertex (27 : Fin 192) = witnessVertex j → (27 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_28 : ∀ j : Fin 192, witnessVertex (28 : Fin 192) = witnessVertex j → (28 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_29 : ∀ j : Fin 192, witnessVertex (29 : Fin 192) = witnessVertex j → (29 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_30 : ∀ j : Fin 192, witnessVertex (30 : Fin 192) = witnessVertex j → (30 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_31 : ∀ j : Fin 192, witnessVertex (31 : Fin 192) = witnessVertex j → (31 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_32 : ∀ j : Fin 192, witnessVertex (32 : Fin 192) = witnessVertex j → (32 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_33 : ∀ j : Fin 192, witnessVertex (33 : Fin 192) = witnessVertex j → (33 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_34 : ∀ j : Fin 192, witnessVertex (34 : Fin 192) = witnessVertex j → (34 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_35 : ∀ j : Fin 192, witnessVertex (35 : Fin 192) = witnessVertex j → (35 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_36 : ∀ j : Fin 192, witnessVertex (36 : Fin 192) = witnessVertex j → (36 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_37 : ∀ j : Fin 192, witnessVertex (37 : Fin 192) = witnessVertex j → (37 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_38 : ∀ j : Fin 192, witnessVertex (38 : Fin 192) = witnessVertex j → (38 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_39 : ∀ j : Fin 192, witnessVertex (39 : Fin 192) = witnessVertex j → (39 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_40 : ∀ j : Fin 192, witnessVertex (40 : Fin 192) = witnessVertex j → (40 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_41 : ∀ j : Fin 192, witnessVertex (41 : Fin 192) = witnessVertex j → (41 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_42 : ∀ j : Fin 192, witnessVertex (42 : Fin 192) = witnessVertex j → (42 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_43 : ∀ j : Fin 192, witnessVertex (43 : Fin 192) = witnessVertex j → (43 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_44 : ∀ j : Fin 192, witnessVertex (44 : Fin 192) = witnessVertex j → (44 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_45 : ∀ j : Fin 192, witnessVertex (45 : Fin 192) = witnessVertex j → (45 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_46 : ∀ j : Fin 192, witnessVertex (46 : Fin 192) = witnessVertex j → (46 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_47 : ∀ j : Fin 192, witnessVertex (47 : Fin 192) = witnessVertex j → (47 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_48 : ∀ j : Fin 192, witnessVertex (48 : Fin 192) = witnessVertex j → (48 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_49 : ∀ j : Fin 192, witnessVertex (49 : Fin 192) = witnessVertex j → (49 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_50 : ∀ j : Fin 192, witnessVertex (50 : Fin 192) = witnessVertex j → (50 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_51 : ∀ j : Fin 192, witnessVertex (51 : Fin 192) = witnessVertex j → (51 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_52 : ∀ j : Fin 192, witnessVertex (52 : Fin 192) = witnessVertex j → (52 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_53 : ∀ j : Fin 192, witnessVertex (53 : Fin 192) = witnessVertex j → (53 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_54 : ∀ j : Fin 192, witnessVertex (54 : Fin 192) = witnessVertex j → (54 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_55 : ∀ j : Fin 192, witnessVertex (55 : Fin 192) = witnessVertex j → (55 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_56 : ∀ j : Fin 192, witnessVertex (56 : Fin 192) = witnessVertex j → (56 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_57 : ∀ j : Fin 192, witnessVertex (57 : Fin 192) = witnessVertex j → (57 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_58 : ∀ j : Fin 192, witnessVertex (58 : Fin 192) = witnessVertex j → (58 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_59 : ∀ j : Fin 192, witnessVertex (59 : Fin 192) = witnessVertex j → (59 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_60 : ∀ j : Fin 192, witnessVertex (60 : Fin 192) = witnessVertex j → (60 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_61 : ∀ j : Fin 192, witnessVertex (61 : Fin 192) = witnessVertex j → (61 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_62 : ∀ j : Fin 192, witnessVertex (62 : Fin 192) = witnessVertex j → (62 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_63 : ∀ j : Fin 192, witnessVertex (63 : Fin 192) = witnessVertex j → (63 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_64 : ∀ j : Fin 192, witnessVertex (64 : Fin 192) = witnessVertex j → (64 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_65 : ∀ j : Fin 192, witnessVertex (65 : Fin 192) = witnessVertex j → (65 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_66 : ∀ j : Fin 192, witnessVertex (66 : Fin 192) = witnessVertex j → (66 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_67 : ∀ j : Fin 192, witnessVertex (67 : Fin 192) = witnessVertex j → (67 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_68 : ∀ j : Fin 192, witnessVertex (68 : Fin 192) = witnessVertex j → (68 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_69 : ∀ j : Fin 192, witnessVertex (69 : Fin 192) = witnessVertex j → (69 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_70 : ∀ j : Fin 192, witnessVertex (70 : Fin 192) = witnessVertex j → (70 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_71 : ∀ j : Fin 192, witnessVertex (71 : Fin 192) = witnessVertex j → (71 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_72 : ∀ j : Fin 192, witnessVertex (72 : Fin 192) = witnessVertex j → (72 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_73 : ∀ j : Fin 192, witnessVertex (73 : Fin 192) = witnessVertex j → (73 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_74 : ∀ j : Fin 192, witnessVertex (74 : Fin 192) = witnessVertex j → (74 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_75 : ∀ j : Fin 192, witnessVertex (75 : Fin 192) = witnessVertex j → (75 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_76 : ∀ j : Fin 192, witnessVertex (76 : Fin 192) = witnessVertex j → (76 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_77 : ∀ j : Fin 192, witnessVertex (77 : Fin 192) = witnessVertex j → (77 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_78 : ∀ j : Fin 192, witnessVertex (78 : Fin 192) = witnessVertex j → (78 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_79 : ∀ j : Fin 192, witnessVertex (79 : Fin 192) = witnessVertex j → (79 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_80 : ∀ j : Fin 192, witnessVertex (80 : Fin 192) = witnessVertex j → (80 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_81 : ∀ j : Fin 192, witnessVertex (81 : Fin 192) = witnessVertex j → (81 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_82 : ∀ j : Fin 192, witnessVertex (82 : Fin 192) = witnessVertex j → (82 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_83 : ∀ j : Fin 192, witnessVertex (83 : Fin 192) = witnessVertex j → (83 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_84 : ∀ j : Fin 192, witnessVertex (84 : Fin 192) = witnessVertex j → (84 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_85 : ∀ j : Fin 192, witnessVertex (85 : Fin 192) = witnessVertex j → (85 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_86 : ∀ j : Fin 192, witnessVertex (86 : Fin 192) = witnessVertex j → (86 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_87 : ∀ j : Fin 192, witnessVertex (87 : Fin 192) = witnessVertex j → (87 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_88 : ∀ j : Fin 192, witnessVertex (88 : Fin 192) = witnessVertex j → (88 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_89 : ∀ j : Fin 192, witnessVertex (89 : Fin 192) = witnessVertex j → (89 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_90 : ∀ j : Fin 192, witnessVertex (90 : Fin 192) = witnessVertex j → (90 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_91 : ∀ j : Fin 192, witnessVertex (91 : Fin 192) = witnessVertex j → (91 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_92 : ∀ j : Fin 192, witnessVertex (92 : Fin 192) = witnessVertex j → (92 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_93 : ∀ j : Fin 192, witnessVertex (93 : Fin 192) = witnessVertex j → (93 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_94 : ∀ j : Fin 192, witnessVertex (94 : Fin 192) = witnessVertex j → (94 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_95 : ∀ j : Fin 192, witnessVertex (95 : Fin 192) = witnessVertex j → (95 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_96 : ∀ j : Fin 192, witnessVertex (96 : Fin 192) = witnessVertex j → (96 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_97 : ∀ j : Fin 192, witnessVertex (97 : Fin 192) = witnessVertex j → (97 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_98 : ∀ j : Fin 192, witnessVertex (98 : Fin 192) = witnessVertex j → (98 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_99 : ∀ j : Fin 192, witnessVertex (99 : Fin 192) = witnessVertex j → (99 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_100 : ∀ j : Fin 192, witnessVertex (100 : Fin 192) = witnessVertex j → (100 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_101 : ∀ j : Fin 192, witnessVertex (101 : Fin 192) = witnessVertex j → (101 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_102 : ∀ j : Fin 192, witnessVertex (102 : Fin 192) = witnessVertex j → (102 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_103 : ∀ j : Fin 192, witnessVertex (103 : Fin 192) = witnessVertex j → (103 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_104 : ∀ j : Fin 192, witnessVertex (104 : Fin 192) = witnessVertex j → (104 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_105 : ∀ j : Fin 192, witnessVertex (105 : Fin 192) = witnessVertex j → (105 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_106 : ∀ j : Fin 192, witnessVertex (106 : Fin 192) = witnessVertex j → (106 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_107 : ∀ j : Fin 192, witnessVertex (107 : Fin 192) = witnessVertex j → (107 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_108 : ∀ j : Fin 192, witnessVertex (108 : Fin 192) = witnessVertex j → (108 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_109 : ∀ j : Fin 192, witnessVertex (109 : Fin 192) = witnessVertex j → (109 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_110 : ∀ j : Fin 192, witnessVertex (110 : Fin 192) = witnessVertex j → (110 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_111 : ∀ j : Fin 192, witnessVertex (111 : Fin 192) = witnessVertex j → (111 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_112 : ∀ j : Fin 192, witnessVertex (112 : Fin 192) = witnessVertex j → (112 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_113 : ∀ j : Fin 192, witnessVertex (113 : Fin 192) = witnessVertex j → (113 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_114 : ∀ j : Fin 192, witnessVertex (114 : Fin 192) = witnessVertex j → (114 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_115 : ∀ j : Fin 192, witnessVertex (115 : Fin 192) = witnessVertex j → (115 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_116 : ∀ j : Fin 192, witnessVertex (116 : Fin 192) = witnessVertex j → (116 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_117 : ∀ j : Fin 192, witnessVertex (117 : Fin 192) = witnessVertex j → (117 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_118 : ∀ j : Fin 192, witnessVertex (118 : Fin 192) = witnessVertex j → (118 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_119 : ∀ j : Fin 192, witnessVertex (119 : Fin 192) = witnessVertex j → (119 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_120 : ∀ j : Fin 192, witnessVertex (120 : Fin 192) = witnessVertex j → (120 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_121 : ∀ j : Fin 192, witnessVertex (121 : Fin 192) = witnessVertex j → (121 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_122 : ∀ j : Fin 192, witnessVertex (122 : Fin 192) = witnessVertex j → (122 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_123 : ∀ j : Fin 192, witnessVertex (123 : Fin 192) = witnessVertex j → (123 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_124 : ∀ j : Fin 192, witnessVertex (124 : Fin 192) = witnessVertex j → (124 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_125 : ∀ j : Fin 192, witnessVertex (125 : Fin 192) = witnessVertex j → (125 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_126 : ∀ j : Fin 192, witnessVertex (126 : Fin 192) = witnessVertex j → (126 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_127 : ∀ j : Fin 192, witnessVertex (127 : Fin 192) = witnessVertex j → (127 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_128 : ∀ j : Fin 192, witnessVertex (128 : Fin 192) = witnessVertex j → (128 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_129 : ∀ j : Fin 192, witnessVertex (129 : Fin 192) = witnessVertex j → (129 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_130 : ∀ j : Fin 192, witnessVertex (130 : Fin 192) = witnessVertex j → (130 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_131 : ∀ j : Fin 192, witnessVertex (131 : Fin 192) = witnessVertex j → (131 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_132 : ∀ j : Fin 192, witnessVertex (132 : Fin 192) = witnessVertex j → (132 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_133 : ∀ j : Fin 192, witnessVertex (133 : Fin 192) = witnessVertex j → (133 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_134 : ∀ j : Fin 192, witnessVertex (134 : Fin 192) = witnessVertex j → (134 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_135 : ∀ j : Fin 192, witnessVertex (135 : Fin 192) = witnessVertex j → (135 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_136 : ∀ j : Fin 192, witnessVertex (136 : Fin 192) = witnessVertex j → (136 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_137 : ∀ j : Fin 192, witnessVertex (137 : Fin 192) = witnessVertex j → (137 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_138 : ∀ j : Fin 192, witnessVertex (138 : Fin 192) = witnessVertex j → (138 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_139 : ∀ j : Fin 192, witnessVertex (139 : Fin 192) = witnessVertex j → (139 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_140 : ∀ j : Fin 192, witnessVertex (140 : Fin 192) = witnessVertex j → (140 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_141 : ∀ j : Fin 192, witnessVertex (141 : Fin 192) = witnessVertex j → (141 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_142 : ∀ j : Fin 192, witnessVertex (142 : Fin 192) = witnessVertex j → (142 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_143 : ∀ j : Fin 192, witnessVertex (143 : Fin 192) = witnessVertex j → (143 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_144 : ∀ j : Fin 192, witnessVertex (144 : Fin 192) = witnessVertex j → (144 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_145 : ∀ j : Fin 192, witnessVertex (145 : Fin 192) = witnessVertex j → (145 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_146 : ∀ j : Fin 192, witnessVertex (146 : Fin 192) = witnessVertex j → (146 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_147 : ∀ j : Fin 192, witnessVertex (147 : Fin 192) = witnessVertex j → (147 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_148 : ∀ j : Fin 192, witnessVertex (148 : Fin 192) = witnessVertex j → (148 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_149 : ∀ j : Fin 192, witnessVertex (149 : Fin 192) = witnessVertex j → (149 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_150 : ∀ j : Fin 192, witnessVertex (150 : Fin 192) = witnessVertex j → (150 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_151 : ∀ j : Fin 192, witnessVertex (151 : Fin 192) = witnessVertex j → (151 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_152 : ∀ j : Fin 192, witnessVertex (152 : Fin 192) = witnessVertex j → (152 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_153 : ∀ j : Fin 192, witnessVertex (153 : Fin 192) = witnessVertex j → (153 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_154 : ∀ j : Fin 192, witnessVertex (154 : Fin 192) = witnessVertex j → (154 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_155 : ∀ j : Fin 192, witnessVertex (155 : Fin 192) = witnessVertex j → (155 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_156 : ∀ j : Fin 192, witnessVertex (156 : Fin 192) = witnessVertex j → (156 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_157 : ∀ j : Fin 192, witnessVertex (157 : Fin 192) = witnessVertex j → (157 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_158 : ∀ j : Fin 192, witnessVertex (158 : Fin 192) = witnessVertex j → (158 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_159 : ∀ j : Fin 192, witnessVertex (159 : Fin 192) = witnessVertex j → (159 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_160 : ∀ j : Fin 192, witnessVertex (160 : Fin 192) = witnessVertex j → (160 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_161 : ∀ j : Fin 192, witnessVertex (161 : Fin 192) = witnessVertex j → (161 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_162 : ∀ j : Fin 192, witnessVertex (162 : Fin 192) = witnessVertex j → (162 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_163 : ∀ j : Fin 192, witnessVertex (163 : Fin 192) = witnessVertex j → (163 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_164 : ∀ j : Fin 192, witnessVertex (164 : Fin 192) = witnessVertex j → (164 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_165 : ∀ j : Fin 192, witnessVertex (165 : Fin 192) = witnessVertex j → (165 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_166 : ∀ j : Fin 192, witnessVertex (166 : Fin 192) = witnessVertex j → (166 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_167 : ∀ j : Fin 192, witnessVertex (167 : Fin 192) = witnessVertex j → (167 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_168 : ∀ j : Fin 192, witnessVertex (168 : Fin 192) = witnessVertex j → (168 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_169 : ∀ j : Fin 192, witnessVertex (169 : Fin 192) = witnessVertex j → (169 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_170 : ∀ j : Fin 192, witnessVertex (170 : Fin 192) = witnessVertex j → (170 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_171 : ∀ j : Fin 192, witnessVertex (171 : Fin 192) = witnessVertex j → (171 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_172 : ∀ j : Fin 192, witnessVertex (172 : Fin 192) = witnessVertex j → (172 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_173 : ∀ j : Fin 192, witnessVertex (173 : Fin 192) = witnessVertex j → (173 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_174 : ∀ j : Fin 192, witnessVertex (174 : Fin 192) = witnessVertex j → (174 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_175 : ∀ j : Fin 192, witnessVertex (175 : Fin 192) = witnessVertex j → (175 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_176 : ∀ j : Fin 192, witnessVertex (176 : Fin 192) = witnessVertex j → (176 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_177 : ∀ j : Fin 192, witnessVertex (177 : Fin 192) = witnessVertex j → (177 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_178 : ∀ j : Fin 192, witnessVertex (178 : Fin 192) = witnessVertex j → (178 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_179 : ∀ j : Fin 192, witnessVertex (179 : Fin 192) = witnessVertex j → (179 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_180 : ∀ j : Fin 192, witnessVertex (180 : Fin 192) = witnessVertex j → (180 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_181 : ∀ j : Fin 192, witnessVertex (181 : Fin 192) = witnessVertex j → (181 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_182 : ∀ j : Fin 192, witnessVertex (182 : Fin 192) = witnessVertex j → (182 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_183 : ∀ j : Fin 192, witnessVertex (183 : Fin 192) = witnessVertex j → (183 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_184 : ∀ j : Fin 192, witnessVertex (184 : Fin 192) = witnessVertex j → (184 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_185 : ∀ j : Fin 192, witnessVertex (185 : Fin 192) = witnessVertex j → (185 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_186 : ∀ j : Fin 192, witnessVertex (186 : Fin 192) = witnessVertex j → (186 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_187 : ∀ j : Fin 192, witnessVertex (187 : Fin 192) = witnessVertex j → (187 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_188 : ∀ j : Fin 192, witnessVertex (188 : Fin 192) = witnessVertex j → (188 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_189 : ∀ j : Fin 192, witnessVertex (189 : Fin 192) = witnessVertex j → (189 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_190 : ∀ j : Fin 192, witnessVertex (190 : Fin 192) = witnessVertex j → (190 : Fin 192) = j := by decide +kernel

theorem witness_distinct_row_191 : ∀ j : Fin 192, witnessVertex (191 : Fin 192) = witnessVertex j → (191 : Fin 192) = j := by decide +kernel

theorem witness_distinct :
    ∀ i j : Fin 192, witnessVertex i = witnessVertex j → i = j := by
  exact (Fin.cases witness_distinct_row_0 (Fin.cases witness_distinct_row_1 (Fin.cases witness_distinct_row_2 (Fin.cases witness_distinct_row_3 (Fin.cases witness_distinct_row_4 (Fin.cases witness_distinct_row_5 (Fin.cases witness_distinct_row_6 (Fin.cases witness_distinct_row_7 (Fin.cases witness_distinct_row_8 (Fin.cases witness_distinct_row_9 (Fin.cases witness_distinct_row_10 (Fin.cases witness_distinct_row_11 (Fin.cases witness_distinct_row_12 (Fin.cases witness_distinct_row_13 (Fin.cases witness_distinct_row_14 (Fin.cases witness_distinct_row_15 (Fin.cases witness_distinct_row_16 (Fin.cases witness_distinct_row_17 (Fin.cases witness_distinct_row_18 (Fin.cases witness_distinct_row_19 (Fin.cases witness_distinct_row_20 (Fin.cases witness_distinct_row_21 (Fin.cases witness_distinct_row_22 (Fin.cases witness_distinct_row_23 (Fin.cases witness_distinct_row_24 (Fin.cases witness_distinct_row_25 (Fin.cases witness_distinct_row_26 (Fin.cases witness_distinct_row_27 (Fin.cases witness_distinct_row_28 (Fin.cases witness_distinct_row_29 (Fin.cases witness_distinct_row_30 (Fin.cases witness_distinct_row_31 (Fin.cases witness_distinct_row_32 (Fin.cases witness_distinct_row_33 (Fin.cases witness_distinct_row_34 (Fin.cases witness_distinct_row_35 (Fin.cases witness_distinct_row_36 (Fin.cases witness_distinct_row_37 (Fin.cases witness_distinct_row_38 (Fin.cases witness_distinct_row_39 (Fin.cases witness_distinct_row_40 (Fin.cases witness_distinct_row_41 (Fin.cases witness_distinct_row_42 (Fin.cases witness_distinct_row_43 (Fin.cases witness_distinct_row_44 (Fin.cases witness_distinct_row_45 (Fin.cases witness_distinct_row_46 (Fin.cases witness_distinct_row_47 (Fin.cases witness_distinct_row_48 (Fin.cases witness_distinct_row_49 (Fin.cases witness_distinct_row_50 (Fin.cases witness_distinct_row_51 (Fin.cases witness_distinct_row_52 (Fin.cases witness_distinct_row_53 (Fin.cases witness_distinct_row_54 (Fin.cases witness_distinct_row_55 (Fin.cases witness_distinct_row_56 (Fin.cases witness_distinct_row_57 (Fin.cases witness_distinct_row_58 (Fin.cases witness_distinct_row_59 (Fin.cases witness_distinct_row_60 (Fin.cases witness_distinct_row_61 (Fin.cases witness_distinct_row_62 (Fin.cases witness_distinct_row_63 (Fin.cases witness_distinct_row_64 (Fin.cases witness_distinct_row_65 (Fin.cases witness_distinct_row_66 (Fin.cases witness_distinct_row_67 (Fin.cases witness_distinct_row_68 (Fin.cases witness_distinct_row_69 (Fin.cases witness_distinct_row_70 (Fin.cases witness_distinct_row_71 (Fin.cases witness_distinct_row_72 (Fin.cases witness_distinct_row_73 (Fin.cases witness_distinct_row_74 (Fin.cases witness_distinct_row_75 (Fin.cases witness_distinct_row_76 (Fin.cases witness_distinct_row_77 (Fin.cases witness_distinct_row_78 (Fin.cases witness_distinct_row_79 (Fin.cases witness_distinct_row_80 (Fin.cases witness_distinct_row_81 (Fin.cases witness_distinct_row_82 (Fin.cases witness_distinct_row_83 (Fin.cases witness_distinct_row_84 (Fin.cases witness_distinct_row_85 (Fin.cases witness_distinct_row_86 (Fin.cases witness_distinct_row_87 (Fin.cases witness_distinct_row_88 (Fin.cases witness_distinct_row_89 (Fin.cases witness_distinct_row_90 (Fin.cases witness_distinct_row_91 (Fin.cases witness_distinct_row_92 (Fin.cases witness_distinct_row_93 (Fin.cases witness_distinct_row_94 (Fin.cases witness_distinct_row_95 (Fin.cases witness_distinct_row_96 (Fin.cases witness_distinct_row_97 (Fin.cases witness_distinct_row_98 (Fin.cases witness_distinct_row_99 (Fin.cases witness_distinct_row_100 (Fin.cases witness_distinct_row_101 (Fin.cases witness_distinct_row_102 (Fin.cases witness_distinct_row_103 (Fin.cases witness_distinct_row_104 (Fin.cases witness_distinct_row_105 (Fin.cases witness_distinct_row_106 (Fin.cases witness_distinct_row_107 (Fin.cases witness_distinct_row_108 (Fin.cases witness_distinct_row_109 (Fin.cases witness_distinct_row_110 (Fin.cases witness_distinct_row_111 (Fin.cases witness_distinct_row_112 (Fin.cases witness_distinct_row_113 (Fin.cases witness_distinct_row_114 (Fin.cases witness_distinct_row_115 (Fin.cases witness_distinct_row_116 (Fin.cases witness_distinct_row_117 (Fin.cases witness_distinct_row_118 (Fin.cases witness_distinct_row_119 (Fin.cases witness_distinct_row_120 (Fin.cases witness_distinct_row_121 (Fin.cases witness_distinct_row_122 (Fin.cases witness_distinct_row_123 (Fin.cases witness_distinct_row_124 (Fin.cases witness_distinct_row_125 (Fin.cases witness_distinct_row_126 (Fin.cases witness_distinct_row_127 (Fin.cases witness_distinct_row_128 (Fin.cases witness_distinct_row_129 (Fin.cases witness_distinct_row_130 (Fin.cases witness_distinct_row_131 (Fin.cases witness_distinct_row_132 (Fin.cases witness_distinct_row_133 (Fin.cases witness_distinct_row_134 (Fin.cases witness_distinct_row_135 (Fin.cases witness_distinct_row_136 (Fin.cases witness_distinct_row_137 (Fin.cases witness_distinct_row_138 (Fin.cases witness_distinct_row_139 (Fin.cases witness_distinct_row_140 (Fin.cases witness_distinct_row_141 (Fin.cases witness_distinct_row_142 (Fin.cases witness_distinct_row_143 (Fin.cases witness_distinct_row_144 (Fin.cases witness_distinct_row_145 (Fin.cases witness_distinct_row_146 (Fin.cases witness_distinct_row_147 (Fin.cases witness_distinct_row_148 (Fin.cases witness_distinct_row_149 (Fin.cases witness_distinct_row_150 (Fin.cases witness_distinct_row_151 (Fin.cases witness_distinct_row_152 (Fin.cases witness_distinct_row_153 (Fin.cases witness_distinct_row_154 (Fin.cases witness_distinct_row_155 (Fin.cases witness_distinct_row_156 (Fin.cases witness_distinct_row_157 (Fin.cases witness_distinct_row_158 (Fin.cases witness_distinct_row_159 (Fin.cases witness_distinct_row_160 (Fin.cases witness_distinct_row_161 (Fin.cases witness_distinct_row_162 (Fin.cases witness_distinct_row_163 (Fin.cases witness_distinct_row_164 (Fin.cases witness_distinct_row_165 (Fin.cases witness_distinct_row_166 (Fin.cases witness_distinct_row_167 (Fin.cases witness_distinct_row_168 (Fin.cases witness_distinct_row_169 (Fin.cases witness_distinct_row_170 (Fin.cases witness_distinct_row_171 (Fin.cases witness_distinct_row_172 (Fin.cases witness_distinct_row_173 (Fin.cases witness_distinct_row_174 (Fin.cases witness_distinct_row_175 (Fin.cases witness_distinct_row_176 (Fin.cases witness_distinct_row_177 (Fin.cases witness_distinct_row_178 (Fin.cases witness_distinct_row_179 (Fin.cases witness_distinct_row_180 (Fin.cases witness_distinct_row_181 (Fin.cases witness_distinct_row_182 (Fin.cases witness_distinct_row_183 (Fin.cases witness_distinct_row_184 (Fin.cases witness_distinct_row_185 (Fin.cases witness_distinct_row_186 (Fin.cases witness_distinct_row_187 (Fin.cases witness_distinct_row_188 (Fin.cases witness_distinct_row_189 (Fin.cases witness_distinct_row_190 (Fin.cases witness_distinct_row_191 (fun i => Fin.elim0 i)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

theorem witness_induced_row_0 : ∀ j : Fin 192, (0 : Fin 192).val < j.val → (Adj (witnessVertex (0 : Fin 192)) (witnessVertex j) ↔ (0 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_1 : ∀ j : Fin 192, (1 : Fin 192).val < j.val → (Adj (witnessVertex (1 : Fin 192)) (witnessVertex j) ↔ (1 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_2 : ∀ j : Fin 192, (2 : Fin 192).val < j.val → (Adj (witnessVertex (2 : Fin 192)) (witnessVertex j) ↔ (2 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_3 : ∀ j : Fin 192, (3 : Fin 192).val < j.val → (Adj (witnessVertex (3 : Fin 192)) (witnessVertex j) ↔ (3 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_4 : ∀ j : Fin 192, (4 : Fin 192).val < j.val → (Adj (witnessVertex (4 : Fin 192)) (witnessVertex j) ↔ (4 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_5 : ∀ j : Fin 192, (5 : Fin 192).val < j.val → (Adj (witnessVertex (5 : Fin 192)) (witnessVertex j) ↔ (5 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_6 : ∀ j : Fin 192, (6 : Fin 192).val < j.val → (Adj (witnessVertex (6 : Fin 192)) (witnessVertex j) ↔ (6 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_7 : ∀ j : Fin 192, (7 : Fin 192).val < j.val → (Adj (witnessVertex (7 : Fin 192)) (witnessVertex j) ↔ (7 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_8 : ∀ j : Fin 192, (8 : Fin 192).val < j.val → (Adj (witnessVertex (8 : Fin 192)) (witnessVertex j) ↔ (8 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_9 : ∀ j : Fin 192, (9 : Fin 192).val < j.val → (Adj (witnessVertex (9 : Fin 192)) (witnessVertex j) ↔ (9 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_10 : ∀ j : Fin 192, (10 : Fin 192).val < j.val → (Adj (witnessVertex (10 : Fin 192)) (witnessVertex j) ↔ (10 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_11 : ∀ j : Fin 192, (11 : Fin 192).val < j.val → (Adj (witnessVertex (11 : Fin 192)) (witnessVertex j) ↔ (11 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_12 : ∀ j : Fin 192, (12 : Fin 192).val < j.val → (Adj (witnessVertex (12 : Fin 192)) (witnessVertex j) ↔ (12 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_13 : ∀ j : Fin 192, (13 : Fin 192).val < j.val → (Adj (witnessVertex (13 : Fin 192)) (witnessVertex j) ↔ (13 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_14 : ∀ j : Fin 192, (14 : Fin 192).val < j.val → (Adj (witnessVertex (14 : Fin 192)) (witnessVertex j) ↔ (14 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_15 : ∀ j : Fin 192, (15 : Fin 192).val < j.val → (Adj (witnessVertex (15 : Fin 192)) (witnessVertex j) ↔ (15 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_16 : ∀ j : Fin 192, (16 : Fin 192).val < j.val → (Adj (witnessVertex (16 : Fin 192)) (witnessVertex j) ↔ (16 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_17 : ∀ j : Fin 192, (17 : Fin 192).val < j.val → (Adj (witnessVertex (17 : Fin 192)) (witnessVertex j) ↔ (17 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_18 : ∀ j : Fin 192, (18 : Fin 192).val < j.val → (Adj (witnessVertex (18 : Fin 192)) (witnessVertex j) ↔ (18 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_19 : ∀ j : Fin 192, (19 : Fin 192).val < j.val → (Adj (witnessVertex (19 : Fin 192)) (witnessVertex j) ↔ (19 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_20 : ∀ j : Fin 192, (20 : Fin 192).val < j.val → (Adj (witnessVertex (20 : Fin 192)) (witnessVertex j) ↔ (20 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_21 : ∀ j : Fin 192, (21 : Fin 192).val < j.val → (Adj (witnessVertex (21 : Fin 192)) (witnessVertex j) ↔ (21 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_22 : ∀ j : Fin 192, (22 : Fin 192).val < j.val → (Adj (witnessVertex (22 : Fin 192)) (witnessVertex j) ↔ (22 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_23 : ∀ j : Fin 192, (23 : Fin 192).val < j.val → (Adj (witnessVertex (23 : Fin 192)) (witnessVertex j) ↔ (23 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_24 : ∀ j : Fin 192, (24 : Fin 192).val < j.val → (Adj (witnessVertex (24 : Fin 192)) (witnessVertex j) ↔ (24 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_25 : ∀ j : Fin 192, (25 : Fin 192).val < j.val → (Adj (witnessVertex (25 : Fin 192)) (witnessVertex j) ↔ (25 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_26 : ∀ j : Fin 192, (26 : Fin 192).val < j.val → (Adj (witnessVertex (26 : Fin 192)) (witnessVertex j) ↔ (26 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_27 : ∀ j : Fin 192, (27 : Fin 192).val < j.val → (Adj (witnessVertex (27 : Fin 192)) (witnessVertex j) ↔ (27 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_28 : ∀ j : Fin 192, (28 : Fin 192).val < j.val → (Adj (witnessVertex (28 : Fin 192)) (witnessVertex j) ↔ (28 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_29 : ∀ j : Fin 192, (29 : Fin 192).val < j.val → (Adj (witnessVertex (29 : Fin 192)) (witnessVertex j) ↔ (29 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_30 : ∀ j : Fin 192, (30 : Fin 192).val < j.val → (Adj (witnessVertex (30 : Fin 192)) (witnessVertex j) ↔ (30 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_31 : ∀ j : Fin 192, (31 : Fin 192).val < j.val → (Adj (witnessVertex (31 : Fin 192)) (witnessVertex j) ↔ (31 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_32 : ∀ j : Fin 192, (32 : Fin 192).val < j.val → (Adj (witnessVertex (32 : Fin 192)) (witnessVertex j) ↔ (32 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_33 : ∀ j : Fin 192, (33 : Fin 192).val < j.val → (Adj (witnessVertex (33 : Fin 192)) (witnessVertex j) ↔ (33 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_34 : ∀ j : Fin 192, (34 : Fin 192).val < j.val → (Adj (witnessVertex (34 : Fin 192)) (witnessVertex j) ↔ (34 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_35 : ∀ j : Fin 192, (35 : Fin 192).val < j.val → (Adj (witnessVertex (35 : Fin 192)) (witnessVertex j) ↔ (35 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_36 : ∀ j : Fin 192, (36 : Fin 192).val < j.val → (Adj (witnessVertex (36 : Fin 192)) (witnessVertex j) ↔ (36 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_37 : ∀ j : Fin 192, (37 : Fin 192).val < j.val → (Adj (witnessVertex (37 : Fin 192)) (witnessVertex j) ↔ (37 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_38 : ∀ j : Fin 192, (38 : Fin 192).val < j.val → (Adj (witnessVertex (38 : Fin 192)) (witnessVertex j) ↔ (38 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_39 : ∀ j : Fin 192, (39 : Fin 192).val < j.val → (Adj (witnessVertex (39 : Fin 192)) (witnessVertex j) ↔ (39 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_40 : ∀ j : Fin 192, (40 : Fin 192).val < j.val → (Adj (witnessVertex (40 : Fin 192)) (witnessVertex j) ↔ (40 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_41 : ∀ j : Fin 192, (41 : Fin 192).val < j.val → (Adj (witnessVertex (41 : Fin 192)) (witnessVertex j) ↔ (41 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_42 : ∀ j : Fin 192, (42 : Fin 192).val < j.val → (Adj (witnessVertex (42 : Fin 192)) (witnessVertex j) ↔ (42 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_43 : ∀ j : Fin 192, (43 : Fin 192).val < j.val → (Adj (witnessVertex (43 : Fin 192)) (witnessVertex j) ↔ (43 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_44 : ∀ j : Fin 192, (44 : Fin 192).val < j.val → (Adj (witnessVertex (44 : Fin 192)) (witnessVertex j) ↔ (44 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_45 : ∀ j : Fin 192, (45 : Fin 192).val < j.val → (Adj (witnessVertex (45 : Fin 192)) (witnessVertex j) ↔ (45 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_46 : ∀ j : Fin 192, (46 : Fin 192).val < j.val → (Adj (witnessVertex (46 : Fin 192)) (witnessVertex j) ↔ (46 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_47 : ∀ j : Fin 192, (47 : Fin 192).val < j.val → (Adj (witnessVertex (47 : Fin 192)) (witnessVertex j) ↔ (47 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_48 : ∀ j : Fin 192, (48 : Fin 192).val < j.val → (Adj (witnessVertex (48 : Fin 192)) (witnessVertex j) ↔ (48 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_49 : ∀ j : Fin 192, (49 : Fin 192).val < j.val → (Adj (witnessVertex (49 : Fin 192)) (witnessVertex j) ↔ (49 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_50 : ∀ j : Fin 192, (50 : Fin 192).val < j.val → (Adj (witnessVertex (50 : Fin 192)) (witnessVertex j) ↔ (50 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_51 : ∀ j : Fin 192, (51 : Fin 192).val < j.val → (Adj (witnessVertex (51 : Fin 192)) (witnessVertex j) ↔ (51 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_52 : ∀ j : Fin 192, (52 : Fin 192).val < j.val → (Adj (witnessVertex (52 : Fin 192)) (witnessVertex j) ↔ (52 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_53 : ∀ j : Fin 192, (53 : Fin 192).val < j.val → (Adj (witnessVertex (53 : Fin 192)) (witnessVertex j) ↔ (53 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_54 : ∀ j : Fin 192, (54 : Fin 192).val < j.val → (Adj (witnessVertex (54 : Fin 192)) (witnessVertex j) ↔ (54 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_55 : ∀ j : Fin 192, (55 : Fin 192).val < j.val → (Adj (witnessVertex (55 : Fin 192)) (witnessVertex j) ↔ (55 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_56 : ∀ j : Fin 192, (56 : Fin 192).val < j.val → (Adj (witnessVertex (56 : Fin 192)) (witnessVertex j) ↔ (56 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_57 : ∀ j : Fin 192, (57 : Fin 192).val < j.val → (Adj (witnessVertex (57 : Fin 192)) (witnessVertex j) ↔ (57 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_58 : ∀ j : Fin 192, (58 : Fin 192).val < j.val → (Adj (witnessVertex (58 : Fin 192)) (witnessVertex j) ↔ (58 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_59 : ∀ j : Fin 192, (59 : Fin 192).val < j.val → (Adj (witnessVertex (59 : Fin 192)) (witnessVertex j) ↔ (59 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_60 : ∀ j : Fin 192, (60 : Fin 192).val < j.val → (Adj (witnessVertex (60 : Fin 192)) (witnessVertex j) ↔ (60 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_61 : ∀ j : Fin 192, (61 : Fin 192).val < j.val → (Adj (witnessVertex (61 : Fin 192)) (witnessVertex j) ↔ (61 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_62 : ∀ j : Fin 192, (62 : Fin 192).val < j.val → (Adj (witnessVertex (62 : Fin 192)) (witnessVertex j) ↔ (62 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_63 : ∀ j : Fin 192, (63 : Fin 192).val < j.val → (Adj (witnessVertex (63 : Fin 192)) (witnessVertex j) ↔ (63 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_64 : ∀ j : Fin 192, (64 : Fin 192).val < j.val → (Adj (witnessVertex (64 : Fin 192)) (witnessVertex j) ↔ (64 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_65 : ∀ j : Fin 192, (65 : Fin 192).val < j.val → (Adj (witnessVertex (65 : Fin 192)) (witnessVertex j) ↔ (65 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_66 : ∀ j : Fin 192, (66 : Fin 192).val < j.val → (Adj (witnessVertex (66 : Fin 192)) (witnessVertex j) ↔ (66 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_67 : ∀ j : Fin 192, (67 : Fin 192).val < j.val → (Adj (witnessVertex (67 : Fin 192)) (witnessVertex j) ↔ (67 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_68 : ∀ j : Fin 192, (68 : Fin 192).val < j.val → (Adj (witnessVertex (68 : Fin 192)) (witnessVertex j) ↔ (68 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_69 : ∀ j : Fin 192, (69 : Fin 192).val < j.val → (Adj (witnessVertex (69 : Fin 192)) (witnessVertex j) ↔ (69 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_70 : ∀ j : Fin 192, (70 : Fin 192).val < j.val → (Adj (witnessVertex (70 : Fin 192)) (witnessVertex j) ↔ (70 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_71 : ∀ j : Fin 192, (71 : Fin 192).val < j.val → (Adj (witnessVertex (71 : Fin 192)) (witnessVertex j) ↔ (71 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_72 : ∀ j : Fin 192, (72 : Fin 192).val < j.val → (Adj (witnessVertex (72 : Fin 192)) (witnessVertex j) ↔ (72 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_73 : ∀ j : Fin 192, (73 : Fin 192).val < j.val → (Adj (witnessVertex (73 : Fin 192)) (witnessVertex j) ↔ (73 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_74 : ∀ j : Fin 192, (74 : Fin 192).val < j.val → (Adj (witnessVertex (74 : Fin 192)) (witnessVertex j) ↔ (74 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_75 : ∀ j : Fin 192, (75 : Fin 192).val < j.val → (Adj (witnessVertex (75 : Fin 192)) (witnessVertex j) ↔ (75 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_76 : ∀ j : Fin 192, (76 : Fin 192).val < j.val → (Adj (witnessVertex (76 : Fin 192)) (witnessVertex j) ↔ (76 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_77 : ∀ j : Fin 192, (77 : Fin 192).val < j.val → (Adj (witnessVertex (77 : Fin 192)) (witnessVertex j) ↔ (77 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_78 : ∀ j : Fin 192, (78 : Fin 192).val < j.val → (Adj (witnessVertex (78 : Fin 192)) (witnessVertex j) ↔ (78 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_79 : ∀ j : Fin 192, (79 : Fin 192).val < j.val → (Adj (witnessVertex (79 : Fin 192)) (witnessVertex j) ↔ (79 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_80 : ∀ j : Fin 192, (80 : Fin 192).val < j.val → (Adj (witnessVertex (80 : Fin 192)) (witnessVertex j) ↔ (80 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_81 : ∀ j : Fin 192, (81 : Fin 192).val < j.val → (Adj (witnessVertex (81 : Fin 192)) (witnessVertex j) ↔ (81 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_82 : ∀ j : Fin 192, (82 : Fin 192).val < j.val → (Adj (witnessVertex (82 : Fin 192)) (witnessVertex j) ↔ (82 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_83 : ∀ j : Fin 192, (83 : Fin 192).val < j.val → (Adj (witnessVertex (83 : Fin 192)) (witnessVertex j) ↔ (83 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_84 : ∀ j : Fin 192, (84 : Fin 192).val < j.val → (Adj (witnessVertex (84 : Fin 192)) (witnessVertex j) ↔ (84 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_85 : ∀ j : Fin 192, (85 : Fin 192).val < j.val → (Adj (witnessVertex (85 : Fin 192)) (witnessVertex j) ↔ (85 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_86 : ∀ j : Fin 192, (86 : Fin 192).val < j.val → (Adj (witnessVertex (86 : Fin 192)) (witnessVertex j) ↔ (86 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_87 : ∀ j : Fin 192, (87 : Fin 192).val < j.val → (Adj (witnessVertex (87 : Fin 192)) (witnessVertex j) ↔ (87 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_88 : ∀ j : Fin 192, (88 : Fin 192).val < j.val → (Adj (witnessVertex (88 : Fin 192)) (witnessVertex j) ↔ (88 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_89 : ∀ j : Fin 192, (89 : Fin 192).val < j.val → (Adj (witnessVertex (89 : Fin 192)) (witnessVertex j) ↔ (89 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_90 : ∀ j : Fin 192, (90 : Fin 192).val < j.val → (Adj (witnessVertex (90 : Fin 192)) (witnessVertex j) ↔ (90 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_91 : ∀ j : Fin 192, (91 : Fin 192).val < j.val → (Adj (witnessVertex (91 : Fin 192)) (witnessVertex j) ↔ (91 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_92 : ∀ j : Fin 192, (92 : Fin 192).val < j.val → (Adj (witnessVertex (92 : Fin 192)) (witnessVertex j) ↔ (92 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_93 : ∀ j : Fin 192, (93 : Fin 192).val < j.val → (Adj (witnessVertex (93 : Fin 192)) (witnessVertex j) ↔ (93 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_94 : ∀ j : Fin 192, (94 : Fin 192).val < j.val → (Adj (witnessVertex (94 : Fin 192)) (witnessVertex j) ↔ (94 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_95 : ∀ j : Fin 192, (95 : Fin 192).val < j.val → (Adj (witnessVertex (95 : Fin 192)) (witnessVertex j) ↔ (95 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_96 : ∀ j : Fin 192, (96 : Fin 192).val < j.val → (Adj (witnessVertex (96 : Fin 192)) (witnessVertex j) ↔ (96 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_97 : ∀ j : Fin 192, (97 : Fin 192).val < j.val → (Adj (witnessVertex (97 : Fin 192)) (witnessVertex j) ↔ (97 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_98 : ∀ j : Fin 192, (98 : Fin 192).val < j.val → (Adj (witnessVertex (98 : Fin 192)) (witnessVertex j) ↔ (98 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_99 : ∀ j : Fin 192, (99 : Fin 192).val < j.val → (Adj (witnessVertex (99 : Fin 192)) (witnessVertex j) ↔ (99 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_100 : ∀ j : Fin 192, (100 : Fin 192).val < j.val → (Adj (witnessVertex (100 : Fin 192)) (witnessVertex j) ↔ (100 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_101 : ∀ j : Fin 192, (101 : Fin 192).val < j.val → (Adj (witnessVertex (101 : Fin 192)) (witnessVertex j) ↔ (101 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_102 : ∀ j : Fin 192, (102 : Fin 192).val < j.val → (Adj (witnessVertex (102 : Fin 192)) (witnessVertex j) ↔ (102 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_103 : ∀ j : Fin 192, (103 : Fin 192).val < j.val → (Adj (witnessVertex (103 : Fin 192)) (witnessVertex j) ↔ (103 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_104 : ∀ j : Fin 192, (104 : Fin 192).val < j.val → (Adj (witnessVertex (104 : Fin 192)) (witnessVertex j) ↔ (104 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_105 : ∀ j : Fin 192, (105 : Fin 192).val < j.val → (Adj (witnessVertex (105 : Fin 192)) (witnessVertex j) ↔ (105 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_106 : ∀ j : Fin 192, (106 : Fin 192).val < j.val → (Adj (witnessVertex (106 : Fin 192)) (witnessVertex j) ↔ (106 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_107 : ∀ j : Fin 192, (107 : Fin 192).val < j.val → (Adj (witnessVertex (107 : Fin 192)) (witnessVertex j) ↔ (107 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_108 : ∀ j : Fin 192, (108 : Fin 192).val < j.val → (Adj (witnessVertex (108 : Fin 192)) (witnessVertex j) ↔ (108 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_109 : ∀ j : Fin 192, (109 : Fin 192).val < j.val → (Adj (witnessVertex (109 : Fin 192)) (witnessVertex j) ↔ (109 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_110 : ∀ j : Fin 192, (110 : Fin 192).val < j.val → (Adj (witnessVertex (110 : Fin 192)) (witnessVertex j) ↔ (110 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_111 : ∀ j : Fin 192, (111 : Fin 192).val < j.val → (Adj (witnessVertex (111 : Fin 192)) (witnessVertex j) ↔ (111 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_112 : ∀ j : Fin 192, (112 : Fin 192).val < j.val → (Adj (witnessVertex (112 : Fin 192)) (witnessVertex j) ↔ (112 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_113 : ∀ j : Fin 192, (113 : Fin 192).val < j.val → (Adj (witnessVertex (113 : Fin 192)) (witnessVertex j) ↔ (113 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_114 : ∀ j : Fin 192, (114 : Fin 192).val < j.val → (Adj (witnessVertex (114 : Fin 192)) (witnessVertex j) ↔ (114 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_115 : ∀ j : Fin 192, (115 : Fin 192).val < j.val → (Adj (witnessVertex (115 : Fin 192)) (witnessVertex j) ↔ (115 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_116 : ∀ j : Fin 192, (116 : Fin 192).val < j.val → (Adj (witnessVertex (116 : Fin 192)) (witnessVertex j) ↔ (116 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_117 : ∀ j : Fin 192, (117 : Fin 192).val < j.val → (Adj (witnessVertex (117 : Fin 192)) (witnessVertex j) ↔ (117 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_118 : ∀ j : Fin 192, (118 : Fin 192).val < j.val → (Adj (witnessVertex (118 : Fin 192)) (witnessVertex j) ↔ (118 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_119 : ∀ j : Fin 192, (119 : Fin 192).val < j.val → (Adj (witnessVertex (119 : Fin 192)) (witnessVertex j) ↔ (119 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_120 : ∀ j : Fin 192, (120 : Fin 192).val < j.val → (Adj (witnessVertex (120 : Fin 192)) (witnessVertex j) ↔ (120 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_121 : ∀ j : Fin 192, (121 : Fin 192).val < j.val → (Adj (witnessVertex (121 : Fin 192)) (witnessVertex j) ↔ (121 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_122 : ∀ j : Fin 192, (122 : Fin 192).val < j.val → (Adj (witnessVertex (122 : Fin 192)) (witnessVertex j) ↔ (122 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_123 : ∀ j : Fin 192, (123 : Fin 192).val < j.val → (Adj (witnessVertex (123 : Fin 192)) (witnessVertex j) ↔ (123 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_124 : ∀ j : Fin 192, (124 : Fin 192).val < j.val → (Adj (witnessVertex (124 : Fin 192)) (witnessVertex j) ↔ (124 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_125 : ∀ j : Fin 192, (125 : Fin 192).val < j.val → (Adj (witnessVertex (125 : Fin 192)) (witnessVertex j) ↔ (125 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_126 : ∀ j : Fin 192, (126 : Fin 192).val < j.val → (Adj (witnessVertex (126 : Fin 192)) (witnessVertex j) ↔ (126 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_127 : ∀ j : Fin 192, (127 : Fin 192).val < j.val → (Adj (witnessVertex (127 : Fin 192)) (witnessVertex j) ↔ (127 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_128 : ∀ j : Fin 192, (128 : Fin 192).val < j.val → (Adj (witnessVertex (128 : Fin 192)) (witnessVertex j) ↔ (128 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_129 : ∀ j : Fin 192, (129 : Fin 192).val < j.val → (Adj (witnessVertex (129 : Fin 192)) (witnessVertex j) ↔ (129 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_130 : ∀ j : Fin 192, (130 : Fin 192).val < j.val → (Adj (witnessVertex (130 : Fin 192)) (witnessVertex j) ↔ (130 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_131 : ∀ j : Fin 192, (131 : Fin 192).val < j.val → (Adj (witnessVertex (131 : Fin 192)) (witnessVertex j) ↔ (131 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_132 : ∀ j : Fin 192, (132 : Fin 192).val < j.val → (Adj (witnessVertex (132 : Fin 192)) (witnessVertex j) ↔ (132 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_133 : ∀ j : Fin 192, (133 : Fin 192).val < j.val → (Adj (witnessVertex (133 : Fin 192)) (witnessVertex j) ↔ (133 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_134 : ∀ j : Fin 192, (134 : Fin 192).val < j.val → (Adj (witnessVertex (134 : Fin 192)) (witnessVertex j) ↔ (134 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_135 : ∀ j : Fin 192, (135 : Fin 192).val < j.val → (Adj (witnessVertex (135 : Fin 192)) (witnessVertex j) ↔ (135 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_136 : ∀ j : Fin 192, (136 : Fin 192).val < j.val → (Adj (witnessVertex (136 : Fin 192)) (witnessVertex j) ↔ (136 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_137 : ∀ j : Fin 192, (137 : Fin 192).val < j.val → (Adj (witnessVertex (137 : Fin 192)) (witnessVertex j) ↔ (137 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_138 : ∀ j : Fin 192, (138 : Fin 192).val < j.val → (Adj (witnessVertex (138 : Fin 192)) (witnessVertex j) ↔ (138 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_139 : ∀ j : Fin 192, (139 : Fin 192).val < j.val → (Adj (witnessVertex (139 : Fin 192)) (witnessVertex j) ↔ (139 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_140 : ∀ j : Fin 192, (140 : Fin 192).val < j.val → (Adj (witnessVertex (140 : Fin 192)) (witnessVertex j) ↔ (140 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_141 : ∀ j : Fin 192, (141 : Fin 192).val < j.val → (Adj (witnessVertex (141 : Fin 192)) (witnessVertex j) ↔ (141 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_142 : ∀ j : Fin 192, (142 : Fin 192).val < j.val → (Adj (witnessVertex (142 : Fin 192)) (witnessVertex j) ↔ (142 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_143 : ∀ j : Fin 192, (143 : Fin 192).val < j.val → (Adj (witnessVertex (143 : Fin 192)) (witnessVertex j) ↔ (143 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_144 : ∀ j : Fin 192, (144 : Fin 192).val < j.val → (Adj (witnessVertex (144 : Fin 192)) (witnessVertex j) ↔ (144 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_145 : ∀ j : Fin 192, (145 : Fin 192).val < j.val → (Adj (witnessVertex (145 : Fin 192)) (witnessVertex j) ↔ (145 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_146 : ∀ j : Fin 192, (146 : Fin 192).val < j.val → (Adj (witnessVertex (146 : Fin 192)) (witnessVertex j) ↔ (146 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_147 : ∀ j : Fin 192, (147 : Fin 192).val < j.val → (Adj (witnessVertex (147 : Fin 192)) (witnessVertex j) ↔ (147 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_148 : ∀ j : Fin 192, (148 : Fin 192).val < j.val → (Adj (witnessVertex (148 : Fin 192)) (witnessVertex j) ↔ (148 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_149 : ∀ j : Fin 192, (149 : Fin 192).val < j.val → (Adj (witnessVertex (149 : Fin 192)) (witnessVertex j) ↔ (149 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_150 : ∀ j : Fin 192, (150 : Fin 192).val < j.val → (Adj (witnessVertex (150 : Fin 192)) (witnessVertex j) ↔ (150 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_151 : ∀ j : Fin 192, (151 : Fin 192).val < j.val → (Adj (witnessVertex (151 : Fin 192)) (witnessVertex j) ↔ (151 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_152 : ∀ j : Fin 192, (152 : Fin 192).val < j.val → (Adj (witnessVertex (152 : Fin 192)) (witnessVertex j) ↔ (152 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_153 : ∀ j : Fin 192, (153 : Fin 192).val < j.val → (Adj (witnessVertex (153 : Fin 192)) (witnessVertex j) ↔ (153 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_154 : ∀ j : Fin 192, (154 : Fin 192).val < j.val → (Adj (witnessVertex (154 : Fin 192)) (witnessVertex j) ↔ (154 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_155 : ∀ j : Fin 192, (155 : Fin 192).val < j.val → (Adj (witnessVertex (155 : Fin 192)) (witnessVertex j) ↔ (155 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_156 : ∀ j : Fin 192, (156 : Fin 192).val < j.val → (Adj (witnessVertex (156 : Fin 192)) (witnessVertex j) ↔ (156 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_157 : ∀ j : Fin 192, (157 : Fin 192).val < j.val → (Adj (witnessVertex (157 : Fin 192)) (witnessVertex j) ↔ (157 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_158 : ∀ j : Fin 192, (158 : Fin 192).val < j.val → (Adj (witnessVertex (158 : Fin 192)) (witnessVertex j) ↔ (158 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_159 : ∀ j : Fin 192, (159 : Fin 192).val < j.val → (Adj (witnessVertex (159 : Fin 192)) (witnessVertex j) ↔ (159 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_160 : ∀ j : Fin 192, (160 : Fin 192).val < j.val → (Adj (witnessVertex (160 : Fin 192)) (witnessVertex j) ↔ (160 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_161 : ∀ j : Fin 192, (161 : Fin 192).val < j.val → (Adj (witnessVertex (161 : Fin 192)) (witnessVertex j) ↔ (161 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_162 : ∀ j : Fin 192, (162 : Fin 192).val < j.val → (Adj (witnessVertex (162 : Fin 192)) (witnessVertex j) ↔ (162 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_163 : ∀ j : Fin 192, (163 : Fin 192).val < j.val → (Adj (witnessVertex (163 : Fin 192)) (witnessVertex j) ↔ (163 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_164 : ∀ j : Fin 192, (164 : Fin 192).val < j.val → (Adj (witnessVertex (164 : Fin 192)) (witnessVertex j) ↔ (164 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_165 : ∀ j : Fin 192, (165 : Fin 192).val < j.val → (Adj (witnessVertex (165 : Fin 192)) (witnessVertex j) ↔ (165 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_166 : ∀ j : Fin 192, (166 : Fin 192).val < j.val → (Adj (witnessVertex (166 : Fin 192)) (witnessVertex j) ↔ (166 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_167 : ∀ j : Fin 192, (167 : Fin 192).val < j.val → (Adj (witnessVertex (167 : Fin 192)) (witnessVertex j) ↔ (167 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_168 : ∀ j : Fin 192, (168 : Fin 192).val < j.val → (Adj (witnessVertex (168 : Fin 192)) (witnessVertex j) ↔ (168 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_169 : ∀ j : Fin 192, (169 : Fin 192).val < j.val → (Adj (witnessVertex (169 : Fin 192)) (witnessVertex j) ↔ (169 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_170 : ∀ j : Fin 192, (170 : Fin 192).val < j.val → (Adj (witnessVertex (170 : Fin 192)) (witnessVertex j) ↔ (170 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_171 : ∀ j : Fin 192, (171 : Fin 192).val < j.val → (Adj (witnessVertex (171 : Fin 192)) (witnessVertex j) ↔ (171 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_172 : ∀ j : Fin 192, (172 : Fin 192).val < j.val → (Adj (witnessVertex (172 : Fin 192)) (witnessVertex j) ↔ (172 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_173 : ∀ j : Fin 192, (173 : Fin 192).val < j.val → (Adj (witnessVertex (173 : Fin 192)) (witnessVertex j) ↔ (173 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_174 : ∀ j : Fin 192, (174 : Fin 192).val < j.val → (Adj (witnessVertex (174 : Fin 192)) (witnessVertex j) ↔ (174 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_175 : ∀ j : Fin 192, (175 : Fin 192).val < j.val → (Adj (witnessVertex (175 : Fin 192)) (witnessVertex j) ↔ (175 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_176 : ∀ j : Fin 192, (176 : Fin 192).val < j.val → (Adj (witnessVertex (176 : Fin 192)) (witnessVertex j) ↔ (176 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_177 : ∀ j : Fin 192, (177 : Fin 192).val < j.val → (Adj (witnessVertex (177 : Fin 192)) (witnessVertex j) ↔ (177 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_178 : ∀ j : Fin 192, (178 : Fin 192).val < j.val → (Adj (witnessVertex (178 : Fin 192)) (witnessVertex j) ↔ (178 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_179 : ∀ j : Fin 192, (179 : Fin 192).val < j.val → (Adj (witnessVertex (179 : Fin 192)) (witnessVertex j) ↔ (179 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_180 : ∀ j : Fin 192, (180 : Fin 192).val < j.val → (Adj (witnessVertex (180 : Fin 192)) (witnessVertex j) ↔ (180 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_181 : ∀ j : Fin 192, (181 : Fin 192).val < j.val → (Adj (witnessVertex (181 : Fin 192)) (witnessVertex j) ↔ (181 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_182 : ∀ j : Fin 192, (182 : Fin 192).val < j.val → (Adj (witnessVertex (182 : Fin 192)) (witnessVertex j) ↔ (182 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_183 : ∀ j : Fin 192, (183 : Fin 192).val < j.val → (Adj (witnessVertex (183 : Fin 192)) (witnessVertex j) ↔ (183 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_184 : ∀ j : Fin 192, (184 : Fin 192).val < j.val → (Adj (witnessVertex (184 : Fin 192)) (witnessVertex j) ↔ (184 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_185 : ∀ j : Fin 192, (185 : Fin 192).val < j.val → (Adj (witnessVertex (185 : Fin 192)) (witnessVertex j) ↔ (185 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_186 : ∀ j : Fin 192, (186 : Fin 192).val < j.val → (Adj (witnessVertex (186 : Fin 192)) (witnessVertex j) ↔ (186 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_187 : ∀ j : Fin 192, (187 : Fin 192).val < j.val → (Adj (witnessVertex (187 : Fin 192)) (witnessVertex j) ↔ (187 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_188 : ∀ j : Fin 192, (188 : Fin 192).val < j.val → (Adj (witnessVertex (188 : Fin 192)) (witnessVertex j) ↔ (188 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_189 : ∀ j : Fin 192, (189 : Fin 192).val < j.val → (Adj (witnessVertex (189 : Fin 192)) (witnessVertex j) ↔ (189 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_190 : ∀ j : Fin 192, (190 : Fin 192).val < j.val → (Adj (witnessVertex (190 : Fin 192)) (witnessVertex j) ↔ (190 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_191 : ∀ j : Fin 192, (191 : Fin 192).val < j.val → (Adj (witnessVertex (191 : Fin 192)) (witnessVertex j) ↔ (191 : Fin 192).val + 1 = j.val) := by decide +kernel

theorem witness_induced :
    ∀ i j : Fin 192, i.val < j.val →
      (Adj (witnessVertex i) (witnessVertex j) ↔ i.val + 1 = j.val) := by
  exact (Fin.cases witness_induced_row_0 (Fin.cases witness_induced_row_1 (Fin.cases witness_induced_row_2 (Fin.cases witness_induced_row_3 (Fin.cases witness_induced_row_4 (Fin.cases witness_induced_row_5 (Fin.cases witness_induced_row_6 (Fin.cases witness_induced_row_7 (Fin.cases witness_induced_row_8 (Fin.cases witness_induced_row_9 (Fin.cases witness_induced_row_10 (Fin.cases witness_induced_row_11 (Fin.cases witness_induced_row_12 (Fin.cases witness_induced_row_13 (Fin.cases witness_induced_row_14 (Fin.cases witness_induced_row_15 (Fin.cases witness_induced_row_16 (Fin.cases witness_induced_row_17 (Fin.cases witness_induced_row_18 (Fin.cases witness_induced_row_19 (Fin.cases witness_induced_row_20 (Fin.cases witness_induced_row_21 (Fin.cases witness_induced_row_22 (Fin.cases witness_induced_row_23 (Fin.cases witness_induced_row_24 (Fin.cases witness_induced_row_25 (Fin.cases witness_induced_row_26 (Fin.cases witness_induced_row_27 (Fin.cases witness_induced_row_28 (Fin.cases witness_induced_row_29 (Fin.cases witness_induced_row_30 (Fin.cases witness_induced_row_31 (Fin.cases witness_induced_row_32 (Fin.cases witness_induced_row_33 (Fin.cases witness_induced_row_34 (Fin.cases witness_induced_row_35 (Fin.cases witness_induced_row_36 (Fin.cases witness_induced_row_37 (Fin.cases witness_induced_row_38 (Fin.cases witness_induced_row_39 (Fin.cases witness_induced_row_40 (Fin.cases witness_induced_row_41 (Fin.cases witness_induced_row_42 (Fin.cases witness_induced_row_43 (Fin.cases witness_induced_row_44 (Fin.cases witness_induced_row_45 (Fin.cases witness_induced_row_46 (Fin.cases witness_induced_row_47 (Fin.cases witness_induced_row_48 (Fin.cases witness_induced_row_49 (Fin.cases witness_induced_row_50 (Fin.cases witness_induced_row_51 (Fin.cases witness_induced_row_52 (Fin.cases witness_induced_row_53 (Fin.cases witness_induced_row_54 (Fin.cases witness_induced_row_55 (Fin.cases witness_induced_row_56 (Fin.cases witness_induced_row_57 (Fin.cases witness_induced_row_58 (Fin.cases witness_induced_row_59 (Fin.cases witness_induced_row_60 (Fin.cases witness_induced_row_61 (Fin.cases witness_induced_row_62 (Fin.cases witness_induced_row_63 (Fin.cases witness_induced_row_64 (Fin.cases witness_induced_row_65 (Fin.cases witness_induced_row_66 (Fin.cases witness_induced_row_67 (Fin.cases witness_induced_row_68 (Fin.cases witness_induced_row_69 (Fin.cases witness_induced_row_70 (Fin.cases witness_induced_row_71 (Fin.cases witness_induced_row_72 (Fin.cases witness_induced_row_73 (Fin.cases witness_induced_row_74 (Fin.cases witness_induced_row_75 (Fin.cases witness_induced_row_76 (Fin.cases witness_induced_row_77 (Fin.cases witness_induced_row_78 (Fin.cases witness_induced_row_79 (Fin.cases witness_induced_row_80 (Fin.cases witness_induced_row_81 (Fin.cases witness_induced_row_82 (Fin.cases witness_induced_row_83 (Fin.cases witness_induced_row_84 (Fin.cases witness_induced_row_85 (Fin.cases witness_induced_row_86 (Fin.cases witness_induced_row_87 (Fin.cases witness_induced_row_88 (Fin.cases witness_induced_row_89 (Fin.cases witness_induced_row_90 (Fin.cases witness_induced_row_91 (Fin.cases witness_induced_row_92 (Fin.cases witness_induced_row_93 (Fin.cases witness_induced_row_94 (Fin.cases witness_induced_row_95 (Fin.cases witness_induced_row_96 (Fin.cases witness_induced_row_97 (Fin.cases witness_induced_row_98 (Fin.cases witness_induced_row_99 (Fin.cases witness_induced_row_100 (Fin.cases witness_induced_row_101 (Fin.cases witness_induced_row_102 (Fin.cases witness_induced_row_103 (Fin.cases witness_induced_row_104 (Fin.cases witness_induced_row_105 (Fin.cases witness_induced_row_106 (Fin.cases witness_induced_row_107 (Fin.cases witness_induced_row_108 (Fin.cases witness_induced_row_109 (Fin.cases witness_induced_row_110 (Fin.cases witness_induced_row_111 (Fin.cases witness_induced_row_112 (Fin.cases witness_induced_row_113 (Fin.cases witness_induced_row_114 (Fin.cases witness_induced_row_115 (Fin.cases witness_induced_row_116 (Fin.cases witness_induced_row_117 (Fin.cases witness_induced_row_118 (Fin.cases witness_induced_row_119 (Fin.cases witness_induced_row_120 (Fin.cases witness_induced_row_121 (Fin.cases witness_induced_row_122 (Fin.cases witness_induced_row_123 (Fin.cases witness_induced_row_124 (Fin.cases witness_induced_row_125 (Fin.cases witness_induced_row_126 (Fin.cases witness_induced_row_127 (Fin.cases witness_induced_row_128 (Fin.cases witness_induced_row_129 (Fin.cases witness_induced_row_130 (Fin.cases witness_induced_row_131 (Fin.cases witness_induced_row_132 (Fin.cases witness_induced_row_133 (Fin.cases witness_induced_row_134 (Fin.cases witness_induced_row_135 (Fin.cases witness_induced_row_136 (Fin.cases witness_induced_row_137 (Fin.cases witness_induced_row_138 (Fin.cases witness_induced_row_139 (Fin.cases witness_induced_row_140 (Fin.cases witness_induced_row_141 (Fin.cases witness_induced_row_142 (Fin.cases witness_induced_row_143 (Fin.cases witness_induced_row_144 (Fin.cases witness_induced_row_145 (Fin.cases witness_induced_row_146 (Fin.cases witness_induced_row_147 (Fin.cases witness_induced_row_148 (Fin.cases witness_induced_row_149 (Fin.cases witness_induced_row_150 (Fin.cases witness_induced_row_151 (Fin.cases witness_induced_row_152 (Fin.cases witness_induced_row_153 (Fin.cases witness_induced_row_154 (Fin.cases witness_induced_row_155 (Fin.cases witness_induced_row_156 (Fin.cases witness_induced_row_157 (Fin.cases witness_induced_row_158 (Fin.cases witness_induced_row_159 (Fin.cases witness_induced_row_160 (Fin.cases witness_induced_row_161 (Fin.cases witness_induced_row_162 (Fin.cases witness_induced_row_163 (Fin.cases witness_induced_row_164 (Fin.cases witness_induced_row_165 (Fin.cases witness_induced_row_166 (Fin.cases witness_induced_row_167 (Fin.cases witness_induced_row_168 (Fin.cases witness_induced_row_169 (Fin.cases witness_induced_row_170 (Fin.cases witness_induced_row_171 (Fin.cases witness_induced_row_172 (Fin.cases witness_induced_row_173 (Fin.cases witness_induced_row_174 (Fin.cases witness_induced_row_175 (Fin.cases witness_induced_row_176 (Fin.cases witness_induced_row_177 (Fin.cases witness_induced_row_178 (Fin.cases witness_induced_row_179 (Fin.cases witness_induced_row_180 (Fin.cases witness_induced_row_181 (Fin.cases witness_induced_row_182 (Fin.cases witness_induced_row_183 (Fin.cases witness_induced_row_184 (Fin.cases witness_induced_row_185 (Fin.cases witness_induced_row_186 (Fin.cases witness_induced_row_187 (Fin.cases witness_induced_row_188 (Fin.cases witness_induced_row_189 (Fin.cases witness_induced_row_190 (Fin.cases witness_induced_row_191 (fun i => Fin.elim0 i)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

def witness : Snake 191 := ⟨witnessVertex, witness_distinct, witness_induced⟩

theorem lower_bound : Nonempty (Snake 191) := ⟨witness⟩

theorem optimality_of_no192 (h : ¬ Target192) :
    Nonempty (Snake 191) ∧ (∀ m, Nonempty (Snake m) → m ≤ 191) :=
  ⟨lower_bound, target192_impossible_iff_upperBound.mp h⟩

#print axioms witness_distinct
#print axioms witness_induced
#print axioms lower_bound
#print axioms optimality_of_no192
end Snake9
