import Snake9

namespace SquareCounterexample
open Snake9
set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

/-- The three other vertices of the coordinate square are outside the path. -/
def SingletonSquare {m : Nat} (p : Snake m) (i : Fin (m+1)) (a b : Nat) : Prop :=
  a < 9 ∧ b < 9 ∧ a < b ∧
  ∀ j, (p.vertex j).val ≠ Nat.xor (p.vertex i).val (2^a) ∧
    (p.vertex j).val ≠ Nat.xor (p.vertex i).val (2^b) ∧
    (p.vertex j).val ≠ Nat.xor (Nat.xor (p.vertex i).val (2^a)) (2^b)

instance {m : Nat} (p : Snake m) (i : Fin (m+1)) (a b : Nat) :
    Decidable (SingletonSquare p i a b) := by unfold SingletonSquare; infer_instance

def coordinatePairs : List (Nat × Nat) :=
  (List.range 9).flatMap (fun a => (List.range 9).map (fun b => (a,b)))

def singletonPairs {m : Nat} (p : Snake m) (i : Fin (m+1)) : List (Nat × Nat) :=
  coordinatePairs.filter (fun ab => decide (SingletonSquare p i ab.1 ab.2))

theorem mem_singletonPairs_iff {m : Nat} (p : Snake m) (i : Fin (m+1)) (a b : Nat) :
    (a,b) ∈ singletonPairs p i ↔ SingletonSquare p i a b := by
  have hp : (a,b) ∈ coordinatePairs ↔ a < 9 ∧ b < 9 := by
    simp [coordinatePairs, List.mem_flatMap, List.mem_map]
  simp only [singletonPairs, List.mem_filter, decide_eq_true_eq]
  rw [hp]
  constructor
  · exact fun h => h.2
  · exact fun h => ⟨⟨h.1,h.2.1⟩,h⟩

def witnessValues : Array Nat := #[145, 144, 146, 154, 158, 190, 188, 444, 508, 509, 511, 479, 223, 219, 211, 243, 179, 187, 59, 27, 25, 24, 28, 20, 22, 23, 55, 53, 49, 48, 50, 306, 274, 272, 273, 277, 285, 287, 286, 350, 348, 344, 472, 474, 458, 202, 194, 192, 193, 197, 213, 85, 81, 80, 82, 90, 122, 126, 110, 238, 236, 228, 484, 486, 502, 438, 439, 437, 433, 441, 425, 489, 491, 235, 107, 75, 73, 72, 76, 68, 70, 71, 103, 101, 97, 96, 98, 354, 322, 320, 321, 325, 333, 461, 397, 389, 385, 384, 386, 418, 162, 160, 161, 165, 167, 135, 134, 132, 140, 136, 137, 139, 395, 267, 265, 264, 268, 260, 262, 294, 38, 36, 44, 40, 42, 10, 2, 0, 1, 5, 13, 15, 47, 303, 301, 293, 289, 288]
def witnessVertex (i : Fin 138) : Vertex :=
  ⟨witnessValues[i.val]! % 512, Nat.mod_lt _ (by decide)⟩

theorem witness_distinct_row_0 : ∀ j : Fin 138, witnessVertex (0 : Fin 138) = witnessVertex j → (0 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_1 : ∀ j : Fin 138, witnessVertex (1 : Fin 138) = witnessVertex j → (1 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_2 : ∀ j : Fin 138, witnessVertex (2 : Fin 138) = witnessVertex j → (2 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_3 : ∀ j : Fin 138, witnessVertex (3 : Fin 138) = witnessVertex j → (3 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_4 : ∀ j : Fin 138, witnessVertex (4 : Fin 138) = witnessVertex j → (4 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_5 : ∀ j : Fin 138, witnessVertex (5 : Fin 138) = witnessVertex j → (5 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_6 : ∀ j : Fin 138, witnessVertex (6 : Fin 138) = witnessVertex j → (6 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_7 : ∀ j : Fin 138, witnessVertex (7 : Fin 138) = witnessVertex j → (7 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_8 : ∀ j : Fin 138, witnessVertex (8 : Fin 138) = witnessVertex j → (8 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_9 : ∀ j : Fin 138, witnessVertex (9 : Fin 138) = witnessVertex j → (9 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_10 : ∀ j : Fin 138, witnessVertex (10 : Fin 138) = witnessVertex j → (10 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_11 : ∀ j : Fin 138, witnessVertex (11 : Fin 138) = witnessVertex j → (11 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_12 : ∀ j : Fin 138, witnessVertex (12 : Fin 138) = witnessVertex j → (12 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_13 : ∀ j : Fin 138, witnessVertex (13 : Fin 138) = witnessVertex j → (13 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_14 : ∀ j : Fin 138, witnessVertex (14 : Fin 138) = witnessVertex j → (14 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_15 : ∀ j : Fin 138, witnessVertex (15 : Fin 138) = witnessVertex j → (15 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_16 : ∀ j : Fin 138, witnessVertex (16 : Fin 138) = witnessVertex j → (16 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_17 : ∀ j : Fin 138, witnessVertex (17 : Fin 138) = witnessVertex j → (17 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_18 : ∀ j : Fin 138, witnessVertex (18 : Fin 138) = witnessVertex j → (18 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_19 : ∀ j : Fin 138, witnessVertex (19 : Fin 138) = witnessVertex j → (19 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_20 : ∀ j : Fin 138, witnessVertex (20 : Fin 138) = witnessVertex j → (20 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_21 : ∀ j : Fin 138, witnessVertex (21 : Fin 138) = witnessVertex j → (21 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_22 : ∀ j : Fin 138, witnessVertex (22 : Fin 138) = witnessVertex j → (22 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_23 : ∀ j : Fin 138, witnessVertex (23 : Fin 138) = witnessVertex j → (23 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_24 : ∀ j : Fin 138, witnessVertex (24 : Fin 138) = witnessVertex j → (24 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_25 : ∀ j : Fin 138, witnessVertex (25 : Fin 138) = witnessVertex j → (25 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_26 : ∀ j : Fin 138, witnessVertex (26 : Fin 138) = witnessVertex j → (26 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_27 : ∀ j : Fin 138, witnessVertex (27 : Fin 138) = witnessVertex j → (27 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_28 : ∀ j : Fin 138, witnessVertex (28 : Fin 138) = witnessVertex j → (28 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_29 : ∀ j : Fin 138, witnessVertex (29 : Fin 138) = witnessVertex j → (29 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_30 : ∀ j : Fin 138, witnessVertex (30 : Fin 138) = witnessVertex j → (30 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_31 : ∀ j : Fin 138, witnessVertex (31 : Fin 138) = witnessVertex j → (31 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_32 : ∀ j : Fin 138, witnessVertex (32 : Fin 138) = witnessVertex j → (32 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_33 : ∀ j : Fin 138, witnessVertex (33 : Fin 138) = witnessVertex j → (33 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_34 : ∀ j : Fin 138, witnessVertex (34 : Fin 138) = witnessVertex j → (34 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_35 : ∀ j : Fin 138, witnessVertex (35 : Fin 138) = witnessVertex j → (35 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_36 : ∀ j : Fin 138, witnessVertex (36 : Fin 138) = witnessVertex j → (36 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_37 : ∀ j : Fin 138, witnessVertex (37 : Fin 138) = witnessVertex j → (37 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_38 : ∀ j : Fin 138, witnessVertex (38 : Fin 138) = witnessVertex j → (38 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_39 : ∀ j : Fin 138, witnessVertex (39 : Fin 138) = witnessVertex j → (39 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_40 : ∀ j : Fin 138, witnessVertex (40 : Fin 138) = witnessVertex j → (40 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_41 : ∀ j : Fin 138, witnessVertex (41 : Fin 138) = witnessVertex j → (41 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_42 : ∀ j : Fin 138, witnessVertex (42 : Fin 138) = witnessVertex j → (42 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_43 : ∀ j : Fin 138, witnessVertex (43 : Fin 138) = witnessVertex j → (43 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_44 : ∀ j : Fin 138, witnessVertex (44 : Fin 138) = witnessVertex j → (44 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_45 : ∀ j : Fin 138, witnessVertex (45 : Fin 138) = witnessVertex j → (45 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_46 : ∀ j : Fin 138, witnessVertex (46 : Fin 138) = witnessVertex j → (46 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_47 : ∀ j : Fin 138, witnessVertex (47 : Fin 138) = witnessVertex j → (47 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_48 : ∀ j : Fin 138, witnessVertex (48 : Fin 138) = witnessVertex j → (48 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_49 : ∀ j : Fin 138, witnessVertex (49 : Fin 138) = witnessVertex j → (49 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_50 : ∀ j : Fin 138, witnessVertex (50 : Fin 138) = witnessVertex j → (50 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_51 : ∀ j : Fin 138, witnessVertex (51 : Fin 138) = witnessVertex j → (51 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_52 : ∀ j : Fin 138, witnessVertex (52 : Fin 138) = witnessVertex j → (52 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_53 : ∀ j : Fin 138, witnessVertex (53 : Fin 138) = witnessVertex j → (53 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_54 : ∀ j : Fin 138, witnessVertex (54 : Fin 138) = witnessVertex j → (54 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_55 : ∀ j : Fin 138, witnessVertex (55 : Fin 138) = witnessVertex j → (55 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_56 : ∀ j : Fin 138, witnessVertex (56 : Fin 138) = witnessVertex j → (56 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_57 : ∀ j : Fin 138, witnessVertex (57 : Fin 138) = witnessVertex j → (57 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_58 : ∀ j : Fin 138, witnessVertex (58 : Fin 138) = witnessVertex j → (58 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_59 : ∀ j : Fin 138, witnessVertex (59 : Fin 138) = witnessVertex j → (59 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_60 : ∀ j : Fin 138, witnessVertex (60 : Fin 138) = witnessVertex j → (60 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_61 : ∀ j : Fin 138, witnessVertex (61 : Fin 138) = witnessVertex j → (61 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_62 : ∀ j : Fin 138, witnessVertex (62 : Fin 138) = witnessVertex j → (62 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_63 : ∀ j : Fin 138, witnessVertex (63 : Fin 138) = witnessVertex j → (63 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_64 : ∀ j : Fin 138, witnessVertex (64 : Fin 138) = witnessVertex j → (64 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_65 : ∀ j : Fin 138, witnessVertex (65 : Fin 138) = witnessVertex j → (65 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_66 : ∀ j : Fin 138, witnessVertex (66 : Fin 138) = witnessVertex j → (66 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_67 : ∀ j : Fin 138, witnessVertex (67 : Fin 138) = witnessVertex j → (67 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_68 : ∀ j : Fin 138, witnessVertex (68 : Fin 138) = witnessVertex j → (68 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_69 : ∀ j : Fin 138, witnessVertex (69 : Fin 138) = witnessVertex j → (69 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_70 : ∀ j : Fin 138, witnessVertex (70 : Fin 138) = witnessVertex j → (70 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_71 : ∀ j : Fin 138, witnessVertex (71 : Fin 138) = witnessVertex j → (71 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_72 : ∀ j : Fin 138, witnessVertex (72 : Fin 138) = witnessVertex j → (72 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_73 : ∀ j : Fin 138, witnessVertex (73 : Fin 138) = witnessVertex j → (73 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_74 : ∀ j : Fin 138, witnessVertex (74 : Fin 138) = witnessVertex j → (74 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_75 : ∀ j : Fin 138, witnessVertex (75 : Fin 138) = witnessVertex j → (75 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_76 : ∀ j : Fin 138, witnessVertex (76 : Fin 138) = witnessVertex j → (76 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_77 : ∀ j : Fin 138, witnessVertex (77 : Fin 138) = witnessVertex j → (77 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_78 : ∀ j : Fin 138, witnessVertex (78 : Fin 138) = witnessVertex j → (78 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_79 : ∀ j : Fin 138, witnessVertex (79 : Fin 138) = witnessVertex j → (79 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_80 : ∀ j : Fin 138, witnessVertex (80 : Fin 138) = witnessVertex j → (80 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_81 : ∀ j : Fin 138, witnessVertex (81 : Fin 138) = witnessVertex j → (81 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_82 : ∀ j : Fin 138, witnessVertex (82 : Fin 138) = witnessVertex j → (82 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_83 : ∀ j : Fin 138, witnessVertex (83 : Fin 138) = witnessVertex j → (83 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_84 : ∀ j : Fin 138, witnessVertex (84 : Fin 138) = witnessVertex j → (84 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_85 : ∀ j : Fin 138, witnessVertex (85 : Fin 138) = witnessVertex j → (85 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_86 : ∀ j : Fin 138, witnessVertex (86 : Fin 138) = witnessVertex j → (86 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_87 : ∀ j : Fin 138, witnessVertex (87 : Fin 138) = witnessVertex j → (87 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_88 : ∀ j : Fin 138, witnessVertex (88 : Fin 138) = witnessVertex j → (88 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_89 : ∀ j : Fin 138, witnessVertex (89 : Fin 138) = witnessVertex j → (89 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_90 : ∀ j : Fin 138, witnessVertex (90 : Fin 138) = witnessVertex j → (90 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_91 : ∀ j : Fin 138, witnessVertex (91 : Fin 138) = witnessVertex j → (91 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_92 : ∀ j : Fin 138, witnessVertex (92 : Fin 138) = witnessVertex j → (92 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_93 : ∀ j : Fin 138, witnessVertex (93 : Fin 138) = witnessVertex j → (93 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_94 : ∀ j : Fin 138, witnessVertex (94 : Fin 138) = witnessVertex j → (94 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_95 : ∀ j : Fin 138, witnessVertex (95 : Fin 138) = witnessVertex j → (95 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_96 : ∀ j : Fin 138, witnessVertex (96 : Fin 138) = witnessVertex j → (96 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_97 : ∀ j : Fin 138, witnessVertex (97 : Fin 138) = witnessVertex j → (97 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_98 : ∀ j : Fin 138, witnessVertex (98 : Fin 138) = witnessVertex j → (98 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_99 : ∀ j : Fin 138, witnessVertex (99 : Fin 138) = witnessVertex j → (99 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_100 : ∀ j : Fin 138, witnessVertex (100 : Fin 138) = witnessVertex j → (100 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_101 : ∀ j : Fin 138, witnessVertex (101 : Fin 138) = witnessVertex j → (101 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_102 : ∀ j : Fin 138, witnessVertex (102 : Fin 138) = witnessVertex j → (102 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_103 : ∀ j : Fin 138, witnessVertex (103 : Fin 138) = witnessVertex j → (103 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_104 : ∀ j : Fin 138, witnessVertex (104 : Fin 138) = witnessVertex j → (104 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_105 : ∀ j : Fin 138, witnessVertex (105 : Fin 138) = witnessVertex j → (105 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_106 : ∀ j : Fin 138, witnessVertex (106 : Fin 138) = witnessVertex j → (106 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_107 : ∀ j : Fin 138, witnessVertex (107 : Fin 138) = witnessVertex j → (107 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_108 : ∀ j : Fin 138, witnessVertex (108 : Fin 138) = witnessVertex j → (108 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_109 : ∀ j : Fin 138, witnessVertex (109 : Fin 138) = witnessVertex j → (109 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_110 : ∀ j : Fin 138, witnessVertex (110 : Fin 138) = witnessVertex j → (110 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_111 : ∀ j : Fin 138, witnessVertex (111 : Fin 138) = witnessVertex j → (111 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_112 : ∀ j : Fin 138, witnessVertex (112 : Fin 138) = witnessVertex j → (112 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_113 : ∀ j : Fin 138, witnessVertex (113 : Fin 138) = witnessVertex j → (113 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_114 : ∀ j : Fin 138, witnessVertex (114 : Fin 138) = witnessVertex j → (114 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_115 : ∀ j : Fin 138, witnessVertex (115 : Fin 138) = witnessVertex j → (115 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_116 : ∀ j : Fin 138, witnessVertex (116 : Fin 138) = witnessVertex j → (116 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_117 : ∀ j : Fin 138, witnessVertex (117 : Fin 138) = witnessVertex j → (117 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_118 : ∀ j : Fin 138, witnessVertex (118 : Fin 138) = witnessVertex j → (118 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_119 : ∀ j : Fin 138, witnessVertex (119 : Fin 138) = witnessVertex j → (119 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_120 : ∀ j : Fin 138, witnessVertex (120 : Fin 138) = witnessVertex j → (120 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_121 : ∀ j : Fin 138, witnessVertex (121 : Fin 138) = witnessVertex j → (121 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_122 : ∀ j : Fin 138, witnessVertex (122 : Fin 138) = witnessVertex j → (122 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_123 : ∀ j : Fin 138, witnessVertex (123 : Fin 138) = witnessVertex j → (123 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_124 : ∀ j : Fin 138, witnessVertex (124 : Fin 138) = witnessVertex j → (124 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_125 : ∀ j : Fin 138, witnessVertex (125 : Fin 138) = witnessVertex j → (125 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_126 : ∀ j : Fin 138, witnessVertex (126 : Fin 138) = witnessVertex j → (126 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_127 : ∀ j : Fin 138, witnessVertex (127 : Fin 138) = witnessVertex j → (127 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_128 : ∀ j : Fin 138, witnessVertex (128 : Fin 138) = witnessVertex j → (128 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_129 : ∀ j : Fin 138, witnessVertex (129 : Fin 138) = witnessVertex j → (129 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_130 : ∀ j : Fin 138, witnessVertex (130 : Fin 138) = witnessVertex j → (130 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_131 : ∀ j : Fin 138, witnessVertex (131 : Fin 138) = witnessVertex j → (131 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_132 : ∀ j : Fin 138, witnessVertex (132 : Fin 138) = witnessVertex j → (132 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_133 : ∀ j : Fin 138, witnessVertex (133 : Fin 138) = witnessVertex j → (133 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_134 : ∀ j : Fin 138, witnessVertex (134 : Fin 138) = witnessVertex j → (134 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_135 : ∀ j : Fin 138, witnessVertex (135 : Fin 138) = witnessVertex j → (135 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_136 : ∀ j : Fin 138, witnessVertex (136 : Fin 138) = witnessVertex j → (136 : Fin 138) = j := by decide +kernel

theorem witness_distinct_row_137 : ∀ j : Fin 138, witnessVertex (137 : Fin 138) = witnessVertex j → (137 : Fin 138) = j := by decide +kernel

theorem witness_distinct :
    ∀ i j : Fin 138, witnessVertex i = witnessVertex j → i = j := by
  exact (Fin.cases witness_distinct_row_0 (Fin.cases witness_distinct_row_1 (Fin.cases witness_distinct_row_2 (Fin.cases witness_distinct_row_3 (Fin.cases witness_distinct_row_4 (Fin.cases witness_distinct_row_5 (Fin.cases witness_distinct_row_6 (Fin.cases witness_distinct_row_7 (Fin.cases witness_distinct_row_8 (Fin.cases witness_distinct_row_9 (Fin.cases witness_distinct_row_10 (Fin.cases witness_distinct_row_11 (Fin.cases witness_distinct_row_12 (Fin.cases witness_distinct_row_13 (Fin.cases witness_distinct_row_14 (Fin.cases witness_distinct_row_15 (Fin.cases witness_distinct_row_16 (Fin.cases witness_distinct_row_17 (Fin.cases witness_distinct_row_18 (Fin.cases witness_distinct_row_19 (Fin.cases witness_distinct_row_20 (Fin.cases witness_distinct_row_21 (Fin.cases witness_distinct_row_22 (Fin.cases witness_distinct_row_23 (Fin.cases witness_distinct_row_24 (Fin.cases witness_distinct_row_25 (Fin.cases witness_distinct_row_26 (Fin.cases witness_distinct_row_27 (Fin.cases witness_distinct_row_28 (Fin.cases witness_distinct_row_29 (Fin.cases witness_distinct_row_30 (Fin.cases witness_distinct_row_31 (Fin.cases witness_distinct_row_32 (Fin.cases witness_distinct_row_33 (Fin.cases witness_distinct_row_34 (Fin.cases witness_distinct_row_35 (Fin.cases witness_distinct_row_36 (Fin.cases witness_distinct_row_37 (Fin.cases witness_distinct_row_38 (Fin.cases witness_distinct_row_39 (Fin.cases witness_distinct_row_40 (Fin.cases witness_distinct_row_41 (Fin.cases witness_distinct_row_42 (Fin.cases witness_distinct_row_43 (Fin.cases witness_distinct_row_44 (Fin.cases witness_distinct_row_45 (Fin.cases witness_distinct_row_46 (Fin.cases witness_distinct_row_47 (Fin.cases witness_distinct_row_48 (Fin.cases witness_distinct_row_49 (Fin.cases witness_distinct_row_50 (Fin.cases witness_distinct_row_51 (Fin.cases witness_distinct_row_52 (Fin.cases witness_distinct_row_53 (Fin.cases witness_distinct_row_54 (Fin.cases witness_distinct_row_55 (Fin.cases witness_distinct_row_56 (Fin.cases witness_distinct_row_57 (Fin.cases witness_distinct_row_58 (Fin.cases witness_distinct_row_59 (Fin.cases witness_distinct_row_60 (Fin.cases witness_distinct_row_61 (Fin.cases witness_distinct_row_62 (Fin.cases witness_distinct_row_63 (Fin.cases witness_distinct_row_64 (Fin.cases witness_distinct_row_65 (Fin.cases witness_distinct_row_66 (Fin.cases witness_distinct_row_67 (Fin.cases witness_distinct_row_68 (Fin.cases witness_distinct_row_69 (Fin.cases witness_distinct_row_70 (Fin.cases witness_distinct_row_71 (Fin.cases witness_distinct_row_72 (Fin.cases witness_distinct_row_73 (Fin.cases witness_distinct_row_74 (Fin.cases witness_distinct_row_75 (Fin.cases witness_distinct_row_76 (Fin.cases witness_distinct_row_77 (Fin.cases witness_distinct_row_78 (Fin.cases witness_distinct_row_79 (Fin.cases witness_distinct_row_80 (Fin.cases witness_distinct_row_81 (Fin.cases witness_distinct_row_82 (Fin.cases witness_distinct_row_83 (Fin.cases witness_distinct_row_84 (Fin.cases witness_distinct_row_85 (Fin.cases witness_distinct_row_86 (Fin.cases witness_distinct_row_87 (Fin.cases witness_distinct_row_88 (Fin.cases witness_distinct_row_89 (Fin.cases witness_distinct_row_90 (Fin.cases witness_distinct_row_91 (Fin.cases witness_distinct_row_92 (Fin.cases witness_distinct_row_93 (Fin.cases witness_distinct_row_94 (Fin.cases witness_distinct_row_95 (Fin.cases witness_distinct_row_96 (Fin.cases witness_distinct_row_97 (Fin.cases witness_distinct_row_98 (Fin.cases witness_distinct_row_99 (Fin.cases witness_distinct_row_100 (Fin.cases witness_distinct_row_101 (Fin.cases witness_distinct_row_102 (Fin.cases witness_distinct_row_103 (Fin.cases witness_distinct_row_104 (Fin.cases witness_distinct_row_105 (Fin.cases witness_distinct_row_106 (Fin.cases witness_distinct_row_107 (Fin.cases witness_distinct_row_108 (Fin.cases witness_distinct_row_109 (Fin.cases witness_distinct_row_110 (Fin.cases witness_distinct_row_111 (Fin.cases witness_distinct_row_112 (Fin.cases witness_distinct_row_113 (Fin.cases witness_distinct_row_114 (Fin.cases witness_distinct_row_115 (Fin.cases witness_distinct_row_116 (Fin.cases witness_distinct_row_117 (Fin.cases witness_distinct_row_118 (Fin.cases witness_distinct_row_119 (Fin.cases witness_distinct_row_120 (Fin.cases witness_distinct_row_121 (Fin.cases witness_distinct_row_122 (Fin.cases witness_distinct_row_123 (Fin.cases witness_distinct_row_124 (Fin.cases witness_distinct_row_125 (Fin.cases witness_distinct_row_126 (Fin.cases witness_distinct_row_127 (Fin.cases witness_distinct_row_128 (Fin.cases witness_distinct_row_129 (Fin.cases witness_distinct_row_130 (Fin.cases witness_distinct_row_131 (Fin.cases witness_distinct_row_132 (Fin.cases witness_distinct_row_133 (Fin.cases witness_distinct_row_134 (Fin.cases witness_distinct_row_135 (Fin.cases witness_distinct_row_136 (Fin.cases witness_distinct_row_137 (fun i => Fin.elim0 i)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
theorem witness_induced_row_0 : ∀ j : Fin 138, (0 : Fin 138).val < j.val → (Adj (witnessVertex (0 : Fin 138)) (witnessVertex j) ↔ (0 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_1 : ∀ j : Fin 138, (1 : Fin 138).val < j.val → (Adj (witnessVertex (1 : Fin 138)) (witnessVertex j) ↔ (1 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_2 : ∀ j : Fin 138, (2 : Fin 138).val < j.val → (Adj (witnessVertex (2 : Fin 138)) (witnessVertex j) ↔ (2 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_3 : ∀ j : Fin 138, (3 : Fin 138).val < j.val → (Adj (witnessVertex (3 : Fin 138)) (witnessVertex j) ↔ (3 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_4 : ∀ j : Fin 138, (4 : Fin 138).val < j.val → (Adj (witnessVertex (4 : Fin 138)) (witnessVertex j) ↔ (4 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_5 : ∀ j : Fin 138, (5 : Fin 138).val < j.val → (Adj (witnessVertex (5 : Fin 138)) (witnessVertex j) ↔ (5 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_6 : ∀ j : Fin 138, (6 : Fin 138).val < j.val → (Adj (witnessVertex (6 : Fin 138)) (witnessVertex j) ↔ (6 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_7 : ∀ j : Fin 138, (7 : Fin 138).val < j.val → (Adj (witnessVertex (7 : Fin 138)) (witnessVertex j) ↔ (7 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_8 : ∀ j : Fin 138, (8 : Fin 138).val < j.val → (Adj (witnessVertex (8 : Fin 138)) (witnessVertex j) ↔ (8 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_9 : ∀ j : Fin 138, (9 : Fin 138).val < j.val → (Adj (witnessVertex (9 : Fin 138)) (witnessVertex j) ↔ (9 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_10 : ∀ j : Fin 138, (10 : Fin 138).val < j.val → (Adj (witnessVertex (10 : Fin 138)) (witnessVertex j) ↔ (10 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_11 : ∀ j : Fin 138, (11 : Fin 138).val < j.val → (Adj (witnessVertex (11 : Fin 138)) (witnessVertex j) ↔ (11 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_12 : ∀ j : Fin 138, (12 : Fin 138).val < j.val → (Adj (witnessVertex (12 : Fin 138)) (witnessVertex j) ↔ (12 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_13 : ∀ j : Fin 138, (13 : Fin 138).val < j.val → (Adj (witnessVertex (13 : Fin 138)) (witnessVertex j) ↔ (13 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_14 : ∀ j : Fin 138, (14 : Fin 138).val < j.val → (Adj (witnessVertex (14 : Fin 138)) (witnessVertex j) ↔ (14 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_15 : ∀ j : Fin 138, (15 : Fin 138).val < j.val → (Adj (witnessVertex (15 : Fin 138)) (witnessVertex j) ↔ (15 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_16 : ∀ j : Fin 138, (16 : Fin 138).val < j.val → (Adj (witnessVertex (16 : Fin 138)) (witnessVertex j) ↔ (16 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_17 : ∀ j : Fin 138, (17 : Fin 138).val < j.val → (Adj (witnessVertex (17 : Fin 138)) (witnessVertex j) ↔ (17 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_18 : ∀ j : Fin 138, (18 : Fin 138).val < j.val → (Adj (witnessVertex (18 : Fin 138)) (witnessVertex j) ↔ (18 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_19 : ∀ j : Fin 138, (19 : Fin 138).val < j.val → (Adj (witnessVertex (19 : Fin 138)) (witnessVertex j) ↔ (19 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_20 : ∀ j : Fin 138, (20 : Fin 138).val < j.val → (Adj (witnessVertex (20 : Fin 138)) (witnessVertex j) ↔ (20 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_21 : ∀ j : Fin 138, (21 : Fin 138).val < j.val → (Adj (witnessVertex (21 : Fin 138)) (witnessVertex j) ↔ (21 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_22 : ∀ j : Fin 138, (22 : Fin 138).val < j.val → (Adj (witnessVertex (22 : Fin 138)) (witnessVertex j) ↔ (22 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_23 : ∀ j : Fin 138, (23 : Fin 138).val < j.val → (Adj (witnessVertex (23 : Fin 138)) (witnessVertex j) ↔ (23 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_24 : ∀ j : Fin 138, (24 : Fin 138).val < j.val → (Adj (witnessVertex (24 : Fin 138)) (witnessVertex j) ↔ (24 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_25 : ∀ j : Fin 138, (25 : Fin 138).val < j.val → (Adj (witnessVertex (25 : Fin 138)) (witnessVertex j) ↔ (25 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_26 : ∀ j : Fin 138, (26 : Fin 138).val < j.val → (Adj (witnessVertex (26 : Fin 138)) (witnessVertex j) ↔ (26 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_27 : ∀ j : Fin 138, (27 : Fin 138).val < j.val → (Adj (witnessVertex (27 : Fin 138)) (witnessVertex j) ↔ (27 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_28 : ∀ j : Fin 138, (28 : Fin 138).val < j.val → (Adj (witnessVertex (28 : Fin 138)) (witnessVertex j) ↔ (28 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_29 : ∀ j : Fin 138, (29 : Fin 138).val < j.val → (Adj (witnessVertex (29 : Fin 138)) (witnessVertex j) ↔ (29 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_30 : ∀ j : Fin 138, (30 : Fin 138).val < j.val → (Adj (witnessVertex (30 : Fin 138)) (witnessVertex j) ↔ (30 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_31 : ∀ j : Fin 138, (31 : Fin 138).val < j.val → (Adj (witnessVertex (31 : Fin 138)) (witnessVertex j) ↔ (31 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_32 : ∀ j : Fin 138, (32 : Fin 138).val < j.val → (Adj (witnessVertex (32 : Fin 138)) (witnessVertex j) ↔ (32 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_33 : ∀ j : Fin 138, (33 : Fin 138).val < j.val → (Adj (witnessVertex (33 : Fin 138)) (witnessVertex j) ↔ (33 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_34 : ∀ j : Fin 138, (34 : Fin 138).val < j.val → (Adj (witnessVertex (34 : Fin 138)) (witnessVertex j) ↔ (34 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_35 : ∀ j : Fin 138, (35 : Fin 138).val < j.val → (Adj (witnessVertex (35 : Fin 138)) (witnessVertex j) ↔ (35 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_36 : ∀ j : Fin 138, (36 : Fin 138).val < j.val → (Adj (witnessVertex (36 : Fin 138)) (witnessVertex j) ↔ (36 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_37 : ∀ j : Fin 138, (37 : Fin 138).val < j.val → (Adj (witnessVertex (37 : Fin 138)) (witnessVertex j) ↔ (37 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_38 : ∀ j : Fin 138, (38 : Fin 138).val < j.val → (Adj (witnessVertex (38 : Fin 138)) (witnessVertex j) ↔ (38 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_39 : ∀ j : Fin 138, (39 : Fin 138).val < j.val → (Adj (witnessVertex (39 : Fin 138)) (witnessVertex j) ↔ (39 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_40 : ∀ j : Fin 138, (40 : Fin 138).val < j.val → (Adj (witnessVertex (40 : Fin 138)) (witnessVertex j) ↔ (40 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_41 : ∀ j : Fin 138, (41 : Fin 138).val < j.val → (Adj (witnessVertex (41 : Fin 138)) (witnessVertex j) ↔ (41 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_42 : ∀ j : Fin 138, (42 : Fin 138).val < j.val → (Adj (witnessVertex (42 : Fin 138)) (witnessVertex j) ↔ (42 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_43 : ∀ j : Fin 138, (43 : Fin 138).val < j.val → (Adj (witnessVertex (43 : Fin 138)) (witnessVertex j) ↔ (43 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_44 : ∀ j : Fin 138, (44 : Fin 138).val < j.val → (Adj (witnessVertex (44 : Fin 138)) (witnessVertex j) ↔ (44 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_45 : ∀ j : Fin 138, (45 : Fin 138).val < j.val → (Adj (witnessVertex (45 : Fin 138)) (witnessVertex j) ↔ (45 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_46 : ∀ j : Fin 138, (46 : Fin 138).val < j.val → (Adj (witnessVertex (46 : Fin 138)) (witnessVertex j) ↔ (46 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_47 : ∀ j : Fin 138, (47 : Fin 138).val < j.val → (Adj (witnessVertex (47 : Fin 138)) (witnessVertex j) ↔ (47 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_48 : ∀ j : Fin 138, (48 : Fin 138).val < j.val → (Adj (witnessVertex (48 : Fin 138)) (witnessVertex j) ↔ (48 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_49 : ∀ j : Fin 138, (49 : Fin 138).val < j.val → (Adj (witnessVertex (49 : Fin 138)) (witnessVertex j) ↔ (49 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_50 : ∀ j : Fin 138, (50 : Fin 138).val < j.val → (Adj (witnessVertex (50 : Fin 138)) (witnessVertex j) ↔ (50 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_51 : ∀ j : Fin 138, (51 : Fin 138).val < j.val → (Adj (witnessVertex (51 : Fin 138)) (witnessVertex j) ↔ (51 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_52 : ∀ j : Fin 138, (52 : Fin 138).val < j.val → (Adj (witnessVertex (52 : Fin 138)) (witnessVertex j) ↔ (52 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_53 : ∀ j : Fin 138, (53 : Fin 138).val < j.val → (Adj (witnessVertex (53 : Fin 138)) (witnessVertex j) ↔ (53 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_54 : ∀ j : Fin 138, (54 : Fin 138).val < j.val → (Adj (witnessVertex (54 : Fin 138)) (witnessVertex j) ↔ (54 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_55 : ∀ j : Fin 138, (55 : Fin 138).val < j.val → (Adj (witnessVertex (55 : Fin 138)) (witnessVertex j) ↔ (55 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_56 : ∀ j : Fin 138, (56 : Fin 138).val < j.val → (Adj (witnessVertex (56 : Fin 138)) (witnessVertex j) ↔ (56 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_57 : ∀ j : Fin 138, (57 : Fin 138).val < j.val → (Adj (witnessVertex (57 : Fin 138)) (witnessVertex j) ↔ (57 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_58 : ∀ j : Fin 138, (58 : Fin 138).val < j.val → (Adj (witnessVertex (58 : Fin 138)) (witnessVertex j) ↔ (58 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_59 : ∀ j : Fin 138, (59 : Fin 138).val < j.val → (Adj (witnessVertex (59 : Fin 138)) (witnessVertex j) ↔ (59 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_60 : ∀ j : Fin 138, (60 : Fin 138).val < j.val → (Adj (witnessVertex (60 : Fin 138)) (witnessVertex j) ↔ (60 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_61 : ∀ j : Fin 138, (61 : Fin 138).val < j.val → (Adj (witnessVertex (61 : Fin 138)) (witnessVertex j) ↔ (61 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_62 : ∀ j : Fin 138, (62 : Fin 138).val < j.val → (Adj (witnessVertex (62 : Fin 138)) (witnessVertex j) ↔ (62 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_63 : ∀ j : Fin 138, (63 : Fin 138).val < j.val → (Adj (witnessVertex (63 : Fin 138)) (witnessVertex j) ↔ (63 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_64 : ∀ j : Fin 138, (64 : Fin 138).val < j.val → (Adj (witnessVertex (64 : Fin 138)) (witnessVertex j) ↔ (64 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_65 : ∀ j : Fin 138, (65 : Fin 138).val < j.val → (Adj (witnessVertex (65 : Fin 138)) (witnessVertex j) ↔ (65 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_66 : ∀ j : Fin 138, (66 : Fin 138).val < j.val → (Adj (witnessVertex (66 : Fin 138)) (witnessVertex j) ↔ (66 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_67 : ∀ j : Fin 138, (67 : Fin 138).val < j.val → (Adj (witnessVertex (67 : Fin 138)) (witnessVertex j) ↔ (67 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_68 : ∀ j : Fin 138, (68 : Fin 138).val < j.val → (Adj (witnessVertex (68 : Fin 138)) (witnessVertex j) ↔ (68 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_69 : ∀ j : Fin 138, (69 : Fin 138).val < j.val → (Adj (witnessVertex (69 : Fin 138)) (witnessVertex j) ↔ (69 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_70 : ∀ j : Fin 138, (70 : Fin 138).val < j.val → (Adj (witnessVertex (70 : Fin 138)) (witnessVertex j) ↔ (70 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_71 : ∀ j : Fin 138, (71 : Fin 138).val < j.val → (Adj (witnessVertex (71 : Fin 138)) (witnessVertex j) ↔ (71 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_72 : ∀ j : Fin 138, (72 : Fin 138).val < j.val → (Adj (witnessVertex (72 : Fin 138)) (witnessVertex j) ↔ (72 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_73 : ∀ j : Fin 138, (73 : Fin 138).val < j.val → (Adj (witnessVertex (73 : Fin 138)) (witnessVertex j) ↔ (73 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_74 : ∀ j : Fin 138, (74 : Fin 138).val < j.val → (Adj (witnessVertex (74 : Fin 138)) (witnessVertex j) ↔ (74 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_75 : ∀ j : Fin 138, (75 : Fin 138).val < j.val → (Adj (witnessVertex (75 : Fin 138)) (witnessVertex j) ↔ (75 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_76 : ∀ j : Fin 138, (76 : Fin 138).val < j.val → (Adj (witnessVertex (76 : Fin 138)) (witnessVertex j) ↔ (76 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_77 : ∀ j : Fin 138, (77 : Fin 138).val < j.val → (Adj (witnessVertex (77 : Fin 138)) (witnessVertex j) ↔ (77 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_78 : ∀ j : Fin 138, (78 : Fin 138).val < j.val → (Adj (witnessVertex (78 : Fin 138)) (witnessVertex j) ↔ (78 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_79 : ∀ j : Fin 138, (79 : Fin 138).val < j.val → (Adj (witnessVertex (79 : Fin 138)) (witnessVertex j) ↔ (79 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_80 : ∀ j : Fin 138, (80 : Fin 138).val < j.val → (Adj (witnessVertex (80 : Fin 138)) (witnessVertex j) ↔ (80 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_81 : ∀ j : Fin 138, (81 : Fin 138).val < j.val → (Adj (witnessVertex (81 : Fin 138)) (witnessVertex j) ↔ (81 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_82 : ∀ j : Fin 138, (82 : Fin 138).val < j.val → (Adj (witnessVertex (82 : Fin 138)) (witnessVertex j) ↔ (82 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_83 : ∀ j : Fin 138, (83 : Fin 138).val < j.val → (Adj (witnessVertex (83 : Fin 138)) (witnessVertex j) ↔ (83 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_84 : ∀ j : Fin 138, (84 : Fin 138).val < j.val → (Adj (witnessVertex (84 : Fin 138)) (witnessVertex j) ↔ (84 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_85 : ∀ j : Fin 138, (85 : Fin 138).val < j.val → (Adj (witnessVertex (85 : Fin 138)) (witnessVertex j) ↔ (85 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_86 : ∀ j : Fin 138, (86 : Fin 138).val < j.val → (Adj (witnessVertex (86 : Fin 138)) (witnessVertex j) ↔ (86 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_87 : ∀ j : Fin 138, (87 : Fin 138).val < j.val → (Adj (witnessVertex (87 : Fin 138)) (witnessVertex j) ↔ (87 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_88 : ∀ j : Fin 138, (88 : Fin 138).val < j.val → (Adj (witnessVertex (88 : Fin 138)) (witnessVertex j) ↔ (88 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_89 : ∀ j : Fin 138, (89 : Fin 138).val < j.val → (Adj (witnessVertex (89 : Fin 138)) (witnessVertex j) ↔ (89 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_90 : ∀ j : Fin 138, (90 : Fin 138).val < j.val → (Adj (witnessVertex (90 : Fin 138)) (witnessVertex j) ↔ (90 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_91 : ∀ j : Fin 138, (91 : Fin 138).val < j.val → (Adj (witnessVertex (91 : Fin 138)) (witnessVertex j) ↔ (91 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_92 : ∀ j : Fin 138, (92 : Fin 138).val < j.val → (Adj (witnessVertex (92 : Fin 138)) (witnessVertex j) ↔ (92 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_93 : ∀ j : Fin 138, (93 : Fin 138).val < j.val → (Adj (witnessVertex (93 : Fin 138)) (witnessVertex j) ↔ (93 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_94 : ∀ j : Fin 138, (94 : Fin 138).val < j.val → (Adj (witnessVertex (94 : Fin 138)) (witnessVertex j) ↔ (94 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_95 : ∀ j : Fin 138, (95 : Fin 138).val < j.val → (Adj (witnessVertex (95 : Fin 138)) (witnessVertex j) ↔ (95 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_96 : ∀ j : Fin 138, (96 : Fin 138).val < j.val → (Adj (witnessVertex (96 : Fin 138)) (witnessVertex j) ↔ (96 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_97 : ∀ j : Fin 138, (97 : Fin 138).val < j.val → (Adj (witnessVertex (97 : Fin 138)) (witnessVertex j) ↔ (97 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_98 : ∀ j : Fin 138, (98 : Fin 138).val < j.val → (Adj (witnessVertex (98 : Fin 138)) (witnessVertex j) ↔ (98 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_99 : ∀ j : Fin 138, (99 : Fin 138).val < j.val → (Adj (witnessVertex (99 : Fin 138)) (witnessVertex j) ↔ (99 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_100 : ∀ j : Fin 138, (100 : Fin 138).val < j.val → (Adj (witnessVertex (100 : Fin 138)) (witnessVertex j) ↔ (100 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_101 : ∀ j : Fin 138, (101 : Fin 138).val < j.val → (Adj (witnessVertex (101 : Fin 138)) (witnessVertex j) ↔ (101 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_102 : ∀ j : Fin 138, (102 : Fin 138).val < j.val → (Adj (witnessVertex (102 : Fin 138)) (witnessVertex j) ↔ (102 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_103 : ∀ j : Fin 138, (103 : Fin 138).val < j.val → (Adj (witnessVertex (103 : Fin 138)) (witnessVertex j) ↔ (103 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_104 : ∀ j : Fin 138, (104 : Fin 138).val < j.val → (Adj (witnessVertex (104 : Fin 138)) (witnessVertex j) ↔ (104 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_105 : ∀ j : Fin 138, (105 : Fin 138).val < j.val → (Adj (witnessVertex (105 : Fin 138)) (witnessVertex j) ↔ (105 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_106 : ∀ j : Fin 138, (106 : Fin 138).val < j.val → (Adj (witnessVertex (106 : Fin 138)) (witnessVertex j) ↔ (106 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_107 : ∀ j : Fin 138, (107 : Fin 138).val < j.val → (Adj (witnessVertex (107 : Fin 138)) (witnessVertex j) ↔ (107 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_108 : ∀ j : Fin 138, (108 : Fin 138).val < j.val → (Adj (witnessVertex (108 : Fin 138)) (witnessVertex j) ↔ (108 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_109 : ∀ j : Fin 138, (109 : Fin 138).val < j.val → (Adj (witnessVertex (109 : Fin 138)) (witnessVertex j) ↔ (109 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_110 : ∀ j : Fin 138, (110 : Fin 138).val < j.val → (Adj (witnessVertex (110 : Fin 138)) (witnessVertex j) ↔ (110 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_111 : ∀ j : Fin 138, (111 : Fin 138).val < j.val → (Adj (witnessVertex (111 : Fin 138)) (witnessVertex j) ↔ (111 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_112 : ∀ j : Fin 138, (112 : Fin 138).val < j.val → (Adj (witnessVertex (112 : Fin 138)) (witnessVertex j) ↔ (112 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_113 : ∀ j : Fin 138, (113 : Fin 138).val < j.val → (Adj (witnessVertex (113 : Fin 138)) (witnessVertex j) ↔ (113 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_114 : ∀ j : Fin 138, (114 : Fin 138).val < j.val → (Adj (witnessVertex (114 : Fin 138)) (witnessVertex j) ↔ (114 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_115 : ∀ j : Fin 138, (115 : Fin 138).val < j.val → (Adj (witnessVertex (115 : Fin 138)) (witnessVertex j) ↔ (115 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_116 : ∀ j : Fin 138, (116 : Fin 138).val < j.val → (Adj (witnessVertex (116 : Fin 138)) (witnessVertex j) ↔ (116 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_117 : ∀ j : Fin 138, (117 : Fin 138).val < j.val → (Adj (witnessVertex (117 : Fin 138)) (witnessVertex j) ↔ (117 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_118 : ∀ j : Fin 138, (118 : Fin 138).val < j.val → (Adj (witnessVertex (118 : Fin 138)) (witnessVertex j) ↔ (118 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_119 : ∀ j : Fin 138, (119 : Fin 138).val < j.val → (Adj (witnessVertex (119 : Fin 138)) (witnessVertex j) ↔ (119 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_120 : ∀ j : Fin 138, (120 : Fin 138).val < j.val → (Adj (witnessVertex (120 : Fin 138)) (witnessVertex j) ↔ (120 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_121 : ∀ j : Fin 138, (121 : Fin 138).val < j.val → (Adj (witnessVertex (121 : Fin 138)) (witnessVertex j) ↔ (121 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_122 : ∀ j : Fin 138, (122 : Fin 138).val < j.val → (Adj (witnessVertex (122 : Fin 138)) (witnessVertex j) ↔ (122 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_123 : ∀ j : Fin 138, (123 : Fin 138).val < j.val → (Adj (witnessVertex (123 : Fin 138)) (witnessVertex j) ↔ (123 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_124 : ∀ j : Fin 138, (124 : Fin 138).val < j.val → (Adj (witnessVertex (124 : Fin 138)) (witnessVertex j) ↔ (124 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_125 : ∀ j : Fin 138, (125 : Fin 138).val < j.val → (Adj (witnessVertex (125 : Fin 138)) (witnessVertex j) ↔ (125 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_126 : ∀ j : Fin 138, (126 : Fin 138).val < j.val → (Adj (witnessVertex (126 : Fin 138)) (witnessVertex j) ↔ (126 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_127 : ∀ j : Fin 138, (127 : Fin 138).val < j.val → (Adj (witnessVertex (127 : Fin 138)) (witnessVertex j) ↔ (127 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_128 : ∀ j : Fin 138, (128 : Fin 138).val < j.val → (Adj (witnessVertex (128 : Fin 138)) (witnessVertex j) ↔ (128 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_129 : ∀ j : Fin 138, (129 : Fin 138).val < j.val → (Adj (witnessVertex (129 : Fin 138)) (witnessVertex j) ↔ (129 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_130 : ∀ j : Fin 138, (130 : Fin 138).val < j.val → (Adj (witnessVertex (130 : Fin 138)) (witnessVertex j) ↔ (130 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_131 : ∀ j : Fin 138, (131 : Fin 138).val < j.val → (Adj (witnessVertex (131 : Fin 138)) (witnessVertex j) ↔ (131 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_132 : ∀ j : Fin 138, (132 : Fin 138).val < j.val → (Adj (witnessVertex (132 : Fin 138)) (witnessVertex j) ↔ (132 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_133 : ∀ j : Fin 138, (133 : Fin 138).val < j.val → (Adj (witnessVertex (133 : Fin 138)) (witnessVertex j) ↔ (133 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_134 : ∀ j : Fin 138, (134 : Fin 138).val < j.val → (Adj (witnessVertex (134 : Fin 138)) (witnessVertex j) ↔ (134 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_135 : ∀ j : Fin 138, (135 : Fin 138).val < j.val → (Adj (witnessVertex (135 : Fin 138)) (witnessVertex j) ↔ (135 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_136 : ∀ j : Fin 138, (136 : Fin 138).val < j.val → (Adj (witnessVertex (136 : Fin 138)) (witnessVertex j) ↔ (136 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced_row_137 : ∀ j : Fin 138, (137 : Fin 138).val < j.val → (Adj (witnessVertex (137 : Fin 138)) (witnessVertex j) ↔ (137 : Fin 138).val + 1 = j.val) := by decide +kernel

theorem witness_induced :
    ∀ i j : Fin 138, i.val < j.val →
      (Adj (witnessVertex i) (witnessVertex j) ↔ i.val+1=j.val) := by
  exact (Fin.cases witness_induced_row_0 (Fin.cases witness_induced_row_1 (Fin.cases witness_induced_row_2 (Fin.cases witness_induced_row_3 (Fin.cases witness_induced_row_4 (Fin.cases witness_induced_row_5 (Fin.cases witness_induced_row_6 (Fin.cases witness_induced_row_7 (Fin.cases witness_induced_row_8 (Fin.cases witness_induced_row_9 (Fin.cases witness_induced_row_10 (Fin.cases witness_induced_row_11 (Fin.cases witness_induced_row_12 (Fin.cases witness_induced_row_13 (Fin.cases witness_induced_row_14 (Fin.cases witness_induced_row_15 (Fin.cases witness_induced_row_16 (Fin.cases witness_induced_row_17 (Fin.cases witness_induced_row_18 (Fin.cases witness_induced_row_19 (Fin.cases witness_induced_row_20 (Fin.cases witness_induced_row_21 (Fin.cases witness_induced_row_22 (Fin.cases witness_induced_row_23 (Fin.cases witness_induced_row_24 (Fin.cases witness_induced_row_25 (Fin.cases witness_induced_row_26 (Fin.cases witness_induced_row_27 (Fin.cases witness_induced_row_28 (Fin.cases witness_induced_row_29 (Fin.cases witness_induced_row_30 (Fin.cases witness_induced_row_31 (Fin.cases witness_induced_row_32 (Fin.cases witness_induced_row_33 (Fin.cases witness_induced_row_34 (Fin.cases witness_induced_row_35 (Fin.cases witness_induced_row_36 (Fin.cases witness_induced_row_37 (Fin.cases witness_induced_row_38 (Fin.cases witness_induced_row_39 (Fin.cases witness_induced_row_40 (Fin.cases witness_induced_row_41 (Fin.cases witness_induced_row_42 (Fin.cases witness_induced_row_43 (Fin.cases witness_induced_row_44 (Fin.cases witness_induced_row_45 (Fin.cases witness_induced_row_46 (Fin.cases witness_induced_row_47 (Fin.cases witness_induced_row_48 (Fin.cases witness_induced_row_49 (Fin.cases witness_induced_row_50 (Fin.cases witness_induced_row_51 (Fin.cases witness_induced_row_52 (Fin.cases witness_induced_row_53 (Fin.cases witness_induced_row_54 (Fin.cases witness_induced_row_55 (Fin.cases witness_induced_row_56 (Fin.cases witness_induced_row_57 (Fin.cases witness_induced_row_58 (Fin.cases witness_induced_row_59 (Fin.cases witness_induced_row_60 (Fin.cases witness_induced_row_61 (Fin.cases witness_induced_row_62 (Fin.cases witness_induced_row_63 (Fin.cases witness_induced_row_64 (Fin.cases witness_induced_row_65 (Fin.cases witness_induced_row_66 (Fin.cases witness_induced_row_67 (Fin.cases witness_induced_row_68 (Fin.cases witness_induced_row_69 (Fin.cases witness_induced_row_70 (Fin.cases witness_induced_row_71 (Fin.cases witness_induced_row_72 (Fin.cases witness_induced_row_73 (Fin.cases witness_induced_row_74 (Fin.cases witness_induced_row_75 (Fin.cases witness_induced_row_76 (Fin.cases witness_induced_row_77 (Fin.cases witness_induced_row_78 (Fin.cases witness_induced_row_79 (Fin.cases witness_induced_row_80 (Fin.cases witness_induced_row_81 (Fin.cases witness_induced_row_82 (Fin.cases witness_induced_row_83 (Fin.cases witness_induced_row_84 (Fin.cases witness_induced_row_85 (Fin.cases witness_induced_row_86 (Fin.cases witness_induced_row_87 (Fin.cases witness_induced_row_88 (Fin.cases witness_induced_row_89 (Fin.cases witness_induced_row_90 (Fin.cases witness_induced_row_91 (Fin.cases witness_induced_row_92 (Fin.cases witness_induced_row_93 (Fin.cases witness_induced_row_94 (Fin.cases witness_induced_row_95 (Fin.cases witness_induced_row_96 (Fin.cases witness_induced_row_97 (Fin.cases witness_induced_row_98 (Fin.cases witness_induced_row_99 (Fin.cases witness_induced_row_100 (Fin.cases witness_induced_row_101 (Fin.cases witness_induced_row_102 (Fin.cases witness_induced_row_103 (Fin.cases witness_induced_row_104 (Fin.cases witness_induced_row_105 (Fin.cases witness_induced_row_106 (Fin.cases witness_induced_row_107 (Fin.cases witness_induced_row_108 (Fin.cases witness_induced_row_109 (Fin.cases witness_induced_row_110 (Fin.cases witness_induced_row_111 (Fin.cases witness_induced_row_112 (Fin.cases witness_induced_row_113 (Fin.cases witness_induced_row_114 (Fin.cases witness_induced_row_115 (Fin.cases witness_induced_row_116 (Fin.cases witness_induced_row_117 (Fin.cases witness_induced_row_118 (Fin.cases witness_induced_row_119 (Fin.cases witness_induced_row_120 (Fin.cases witness_induced_row_121 (Fin.cases witness_induced_row_122 (Fin.cases witness_induced_row_123 (Fin.cases witness_induced_row_124 (Fin.cases witness_induced_row_125 (Fin.cases witness_induced_row_126 (Fin.cases witness_induced_row_127 (Fin.cases witness_induced_row_128 (Fin.cases witness_induced_row_129 (Fin.cases witness_induced_row_130 (Fin.cases witness_induced_row_131 (Fin.cases witness_induced_row_132 (Fin.cases witness_induced_row_133 (Fin.cases witness_induced_row_134 (Fin.cases witness_induced_row_135 (Fin.cases witness_induced_row_136 (Fin.cases witness_induced_row_137 (fun i => Fin.elim0 i)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))

def witness : Snake 137 := ⟨witnessVertex,witness_distinct,witness_induced⟩
def centerIndex : Fin 138 := ⟨127,by decide⟩

theorem center_and_endpoints :
    (witness.vertex centerIndex).val = 0 ∧
    (witness.vertex ⟨0,by decide⟩).val = 145 ∧
    (witness.vertex ⟨137,by decide⟩).val = 288 := by decide +kernel

theorem center_is_internal : 0 < centerIndex.val ∧ centerIndex.val < 137 := by decide +kernel
theorem center_ten_edges_from_ends : 10 ≤ centerIndex.val ∧ centerIndex.val+10 ≤ 137 := by decide +kernel

theorem exactly_one_singleton_square : singletonPairs witness centerIndex = [(2,3)] := by decide +kernel

theorem unique_square_characterization (a b : Nat) :
    SingletonSquare witness centerIndex a b ↔ a=2 ∧ b=3 := by
  rw [← mem_singletonPairs_iff, exactly_one_singleton_square]
  simp

theorem universal_internal_two_square_claim_false :
    ¬ (∀ m (p : Snake m) (i : Fin (m+1)),
      0 < i.val → i.val < m → 2 ≤ (singletonPairs p i).length) := by
  intro h
  have hc := h 137 witness centerIndex center_is_internal.1 center_is_internal.2
  rw [exactly_one_singleton_square] at hc
  contradiction

#print axioms witness_distinct
#print axioms witness_induced
#print axioms exactly_one_singleton_square
#print axioms unique_square_characterization
#print axioms universal_internal_two_square_claim_false
end SquareCounterexample
