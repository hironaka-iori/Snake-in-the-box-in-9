module

-- LocalWindowCertSplit.T012301A36264K45: kernel checks of segments 1447..1544 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.T012301A36264K45.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.T012301A36264K45

theorem warm1447 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1447 1447) = true := by
  decide +kernel

theorem ok1447 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1447 1447 = true := (Snake9.LratV3.andB_eq_true warm1447).2

theorem warm1448 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1448 1448) = true := by
  decide +kernel

theorem ok1448 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1448 1448 = true := (Snake9.LratV3.andB_eq_true warm1448).2

theorem warm1449 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1449 1449) = true := by
  decide +kernel

theorem ok1449 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1449 1449 = true := (Snake9.LratV3.andB_eq_true warm1449).2

theorem warm1450 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1450 1450) = true := by
  decide +kernel

theorem ok1450 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1450 1450 = true := (Snake9.LratV3.andB_eq_true warm1450).2

theorem warm1451 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1451 1451) = true := by
  decide +kernel

theorem ok1451 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1451 1451 = true := (Snake9.LratV3.andB_eq_true warm1451).2

theorem warm1452 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 57) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1452 1452) = true := by
  decide +kernel

theorem ok1452 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1452 1452 = true := (Snake9.LratV3.andB_eq_true warm1452).2

theorem warm1453 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1453 1453) = true := by
  decide +kernel

theorem ok1453 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1453 1453 = true := (Snake9.LratV3.andB_eq_true warm1453).2

theorem warm1454 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1454 1454) = true := by
  decide +kernel

theorem ok1454 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1454 1454 = true := (Snake9.LratV3.andB_eq_true warm1454).2

theorem warm1455 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1455 1455) = true := by
  decide +kernel

theorem ok1455 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1455 1455 = true := (Snake9.LratV3.andB_eq_true warm1455).2

theorem warm1456 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1456 1456) = true := by
  decide +kernel

theorem ok1456 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1456 1456 = true := (Snake9.LratV3.andB_eq_true warm1456).2

theorem warm1457 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1457 1457) = true := by
  decide +kernel

theorem ok1457 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1457 1457 = true := (Snake9.LratV3.andB_eq_true warm1457).2

theorem warm1458 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1458 1458) = true := by
  decide +kernel

theorem ok1458 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1458 1458 = true := (Snake9.LratV3.andB_eq_true warm1458).2

theorem warm1459 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1459 1459) = true := by
  decide +kernel

theorem ok1459 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1459 1459 = true := (Snake9.LratV3.andB_eq_true warm1459).2

theorem warm1460 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1460 1460) = true := by
  decide +kernel

theorem ok1460 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1460 1460 = true := (Snake9.LratV3.andB_eq_true warm1460).2

theorem warm1461 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1461 1461) = true := by
  decide +kernel

theorem ok1461 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1461 1461 = true := (Snake9.LratV3.andB_eq_true warm1461).2

theorem warm1462 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1462 1462) = true := by
  decide +kernel

theorem ok1462 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1462 1462 = true := (Snake9.LratV3.andB_eq_true warm1462).2

theorem warm1463 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1463 1463) = true := by
  decide +kernel

theorem ok1463 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1463 1463 = true := (Snake9.LratV3.andB_eq_true warm1463).2

theorem warm1464 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1464 1464) = true := by
  decide +kernel

theorem ok1464 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1464 1464 = true := (Snake9.LratV3.andB_eq_true warm1464).2

theorem warm1465 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1465 1465) = true := by
  decide +kernel

theorem ok1465 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1465 1465 = true := (Snake9.LratV3.andB_eq_true warm1465).2

theorem warm1466 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1466 1466) = true := by
  decide +kernel

theorem ok1466 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1466 1466 = true := (Snake9.LratV3.andB_eq_true warm1466).2

theorem warm1467 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1467 1467) = true := by
  decide +kernel

theorem ok1467 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1467 1467 = true := (Snake9.LratV3.andB_eq_true warm1467).2

theorem warm1468 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1468 1468) = true := by
  decide +kernel

theorem ok1468 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1468 1468 = true := (Snake9.LratV3.andB_eq_true warm1468).2

theorem warm1469 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1469 1469) = true := by
  decide +kernel

theorem ok1469 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1469 1469 = true := (Snake9.LratV3.andB_eq_true warm1469).2

theorem warm1470 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1470 1470) = true := by
  decide +kernel

theorem ok1470 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1470 1470 = true := (Snake9.LratV3.andB_eq_true warm1470).2

theorem warm1471 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1471 1471) = true := by
  decide +kernel

theorem ok1471 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1471 1471 = true := (Snake9.LratV3.andB_eq_true warm1471).2

theorem warm1472 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1472 1472) = true := by
  decide +kernel

theorem ok1472 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1472 1472 = true := (Snake9.LratV3.andB_eq_true warm1472).2

theorem warm1473 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1473 1473) = true := by
  decide +kernel

theorem ok1473 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1473 1473 = true := (Snake9.LratV3.andB_eq_true warm1473).2

theorem warm1474 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1474 1474) = true := by
  decide +kernel

theorem ok1474 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1474 1474 = true := (Snake9.LratV3.andB_eq_true warm1474).2

theorem warm1475 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1475 1475) = true := by
  decide +kernel

theorem ok1475 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1475 1475 = true := (Snake9.LratV3.andB_eq_true warm1475).2

theorem warm1476 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1476 1476) = true := by
  decide +kernel

theorem ok1476 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1476 1476 = true := (Snake9.LratV3.andB_eq_true warm1476).2

theorem warm1477 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1477 1477) = true := by
  decide +kernel

theorem ok1477 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1477 1477 = true := (Snake9.LratV3.andB_eq_true warm1477).2

theorem warm1478 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1478 1478) = true := by
  decide +kernel

theorem ok1478 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1478 1478 = true := (Snake9.LratV3.andB_eq_true warm1478).2

theorem warm1479 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1479 1479) = true := by
  decide +kernel

theorem ok1479 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1479 1479 = true := (Snake9.LratV3.andB_eq_true warm1479).2

theorem warm1480 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1480 1480) = true := by
  decide +kernel

theorem ok1480 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1480 1480 = true := (Snake9.LratV3.andB_eq_true warm1480).2

theorem warm1481 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1481 1481) = true := by
  decide +kernel

theorem ok1481 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1481 1481 = true := (Snake9.LratV3.andB_eq_true warm1481).2

theorem warm1482 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1482 1482) = true := by
  decide +kernel

theorem ok1482 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1482 1482 = true := (Snake9.LratV3.andB_eq_true warm1482).2

theorem warm1483 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1483 1483) = true := by
  decide +kernel

theorem ok1483 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1483 1483 = true := (Snake9.LratV3.andB_eq_true warm1483).2

theorem warm1484 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1484 1484) = true := by
  decide +kernel

theorem ok1484 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1484 1484 = true := (Snake9.LratV3.andB_eq_true warm1484).2

theorem warm1485 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1485 1485) = true := by
  decide +kernel

theorem ok1485 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1485 1485 = true := (Snake9.LratV3.andB_eq_true warm1485).2

theorem warm1486 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1486 1486) = true := by
  decide +kernel

theorem ok1486 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1486 1486 = true := (Snake9.LratV3.andB_eq_true warm1486).2

theorem warm1487 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1487 1487) = true := by
  decide +kernel

theorem ok1487 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1487 1487 = true := (Snake9.LratV3.andB_eq_true warm1487).2

theorem warm1488 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1488 1488) = true := by
  decide +kernel

theorem ok1488 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1488 1488 = true := (Snake9.LratV3.andB_eq_true warm1488).2

theorem warm1489 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1489 1489) = true := by
  decide +kernel

theorem ok1489 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1489 1489 = true := (Snake9.LratV3.andB_eq_true warm1489).2

theorem warm1490 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1490 1490) = true := by
  decide +kernel

theorem ok1490 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1490 1490 = true := (Snake9.LratV3.andB_eq_true warm1490).2

theorem warm1491 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1491 1491) = true := by
  decide +kernel

theorem ok1491 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1491 1491 = true := (Snake9.LratV3.andB_eq_true warm1491).2

theorem warm1492 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1492 1492) = true := by
  decide +kernel

theorem ok1492 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1492 1492 = true := (Snake9.LratV3.andB_eq_true warm1492).2

theorem warm1493 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1493 1493) = true := by
  decide +kernel

theorem ok1493 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1493 1493 = true := (Snake9.LratV3.andB_eq_true warm1493).2

theorem warm1494 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1494 1494) = true := by
  decide +kernel

theorem ok1494 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1494 1494 = true := (Snake9.LratV3.andB_eq_true warm1494).2

theorem warm1495 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1495 1495) = true := by
  decide +kernel

theorem ok1495 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1495 1495 = true := (Snake9.LratV3.andB_eq_true warm1495).2

theorem warm1496 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1496 1496) = true := by
  decide +kernel

theorem ok1496 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1496 1496 = true := (Snake9.LratV3.andB_eq_true warm1496).2

theorem warm1497 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1497 1497) = true := by
  decide +kernel

theorem ok1497 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1497 1497 = true := (Snake9.LratV3.andB_eq_true warm1497).2

theorem warm1498 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1498 1498) = true := by
  decide +kernel

theorem ok1498 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1498 1498 = true := (Snake9.LratV3.andB_eq_true warm1498).2

theorem warm1499 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1499 1499) = true := by
  decide +kernel

theorem ok1499 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1499 1499 = true := (Snake9.LratV3.andB_eq_true warm1499).2

theorem warm1500 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1500 1500) = true := by
  decide +kernel

theorem ok1500 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1500 1500 = true := (Snake9.LratV3.andB_eq_true warm1500).2

theorem warm1501 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1501 1501) = true := by
  decide +kernel

theorem ok1501 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1501 1501 = true := (Snake9.LratV3.andB_eq_true warm1501).2

theorem warm1502 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1502 1502) = true := by
  decide +kernel

theorem ok1502 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1502 1502 = true := (Snake9.LratV3.andB_eq_true warm1502).2

theorem warm1503 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1503 1503) = true := by
  decide +kernel

theorem ok1503 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1503 1503 = true := (Snake9.LratV3.andB_eq_true warm1503).2

theorem warm1504 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1504 1504) = true := by
  decide +kernel

theorem ok1504 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1504 1504 = true := (Snake9.LratV3.andB_eq_true warm1504).2

theorem warm1505 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1505 1505) = true := by
  decide +kernel

theorem ok1505 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1505 1505 = true := (Snake9.LratV3.andB_eq_true warm1505).2

theorem warm1506 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1506 1506) = true := by
  decide +kernel

theorem ok1506 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1506 1506 = true := (Snake9.LratV3.andB_eq_true warm1506).2

theorem warm1507 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1506) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1507 1507) = true := by
  decide +kernel

theorem ok1507 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1507 1507 = true := (Snake9.LratV3.andB_eq_true warm1507).2

theorem warm1508 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1506) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1508 1508) = true := by
  decide +kernel

theorem ok1508 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1508 1508 = true := (Snake9.LratV3.andB_eq_true warm1508).2

theorem warm1509 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1506) 2048)) true)
    (true)))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1509 1509) = true := by
  decide +kernel

theorem ok1509 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1509 1509 = true := (Snake9.LratV3.andB_eq_true warm1509).2

theorem warm1510 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 882) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1506) 2048)) true)
    (true)))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1510 1510) = true := by
  decide +kernel

theorem ok1510 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1510 1510 = true := (Snake9.LratV3.andB_eq_true warm1510).2

theorem warm1511 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 57) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1511 1511) = true := by
  decide +kernel

theorem ok1511 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1511 1511 = true := (Snake9.LratV3.andB_eq_true warm1511).2

theorem warm1512 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1512 1512) = true := by
  decide +kernel

theorem ok1512 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1512 1512 = true := (Snake9.LratV3.andB_eq_true warm1512).2

theorem warm1513 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 57) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1513 1513) = true := by
  decide +kernel

theorem ok1513 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1513 1513 = true := (Snake9.LratV3.andB_eq_true warm1513).2

theorem warm1514 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1514 1514) = true := by
  decide +kernel

theorem ok1514 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1514 1514 = true := (Snake9.LratV3.andB_eq_true warm1514).2

theorem warm1515 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1515 1515) = true := by
  decide +kernel

theorem ok1515 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1515 1515 = true := (Snake9.LratV3.andB_eq_true warm1515).2

theorem warm1516 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1516 1516) = true := by
  decide +kernel

theorem ok1516 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1516 1516 = true := (Snake9.LratV3.andB_eq_true warm1516).2

theorem warm1517 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1517 1517) = true := by
  decide +kernel

theorem ok1517 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1517 1517 = true := (Snake9.LratV3.andB_eq_true warm1517).2

theorem warm1518 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 57) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1518 1518) = true := by
  decide +kernel

theorem ok1518 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1518 1518 = true := (Snake9.LratV3.andB_eq_true warm1518).2

theorem warm1519 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1519 1519) = true := by
  decide +kernel

theorem ok1519 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1519 1519 = true := (Snake9.LratV3.andB_eq_true warm1519).2

theorem warm1520 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1520 1520) = true := by
  decide +kernel

theorem ok1520 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1520 1520 = true := (Snake9.LratV3.andB_eq_true warm1520).2

theorem warm1521 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1521 1521) = true := by
  decide +kernel

theorem ok1521 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1521 1521 = true := (Snake9.LratV3.andB_eq_true warm1521).2

theorem warm1522 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 57) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1522 1522) = true := by
  decide +kernel

theorem ok1522 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1522 1522 = true := (Snake9.LratV3.andB_eq_true warm1522).2

theorem warm1523 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1523 1523) = true := by
  decide +kernel

theorem ok1523 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1523 1523 = true := (Snake9.LratV3.andB_eq_true warm1523).2

theorem warm1524 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1524 1524) = true := by
  decide +kernel

theorem ok1524 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1524 1524 = true := (Snake9.LratV3.andB_eq_true warm1524).2

theorem warm1525 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1525 1525) = true := by
  decide +kernel

theorem ok1525 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1525 1525 = true := (Snake9.LratV3.andB_eq_true warm1525).2

theorem warm1526 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1526 1526) = true := by
  decide +kernel

theorem ok1526 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1526 1526 = true := (Snake9.LratV3.andB_eq_true warm1526).2

theorem warm1527 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 57) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1527 1527) = true := by
  decide +kernel

theorem ok1527 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1527 1527 = true := (Snake9.LratV3.andB_eq_true warm1527).2

theorem warm1528 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1528 1528) = true := by
  decide +kernel

theorem ok1528 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1528 1528 = true := (Snake9.LratV3.andB_eq_true warm1528).2

theorem warm1529 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1529 1529) = true := by
  decide +kernel

theorem ok1529 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1529 1529 = true := (Snake9.LratV3.andB_eq_true warm1529).2

theorem warm1530 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1530 1530) = true := by
  decide +kernel

theorem ok1530 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1530 1530 = true := (Snake9.LratV3.andB_eq_true warm1530).2

theorem warm1531 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1531 1531) = true := by
  decide +kernel

theorem ok1531 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1531 1531 = true := (Snake9.LratV3.andB_eq_true warm1531).2

theorem warm1532 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1532 1532) = true := by
  decide +kernel

theorem ok1532 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1532 1532 = true := (Snake9.LratV3.andB_eq_true warm1532).2

theorem warm1533 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1533 1533) = true := by
  decide +kernel

theorem ok1533 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1533 1533 = true := (Snake9.LratV3.andB_eq_true warm1533).2

theorem warm1534 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1534 1534) = true := by
  decide +kernel

theorem ok1534 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1534 1534 = true := (Snake9.LratV3.andB_eq_true warm1534).2

theorem warm1535 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1535 1535) = true := by
  decide +kernel

theorem ok1535 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1535 1535 = true := (Snake9.LratV3.andB_eq_true warm1535).2

theorem warm1536 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 733) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1049) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1536 1536) = true := by
  decide +kernel

theorem ok1536 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1536 1536 = true := (Snake9.LratV3.andB_eq_true warm1536).2

theorem warm1537 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 733) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1537 1537) = true := by
  decide +kernel

theorem ok1537 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1537 1537 = true := (Snake9.LratV3.andB_eq_true warm1537).2

theorem warm1538 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 57) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1538 1538) = true := by
  decide +kernel

theorem ok1538 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1538 1538 = true := (Snake9.LratV3.andB_eq_true warm1538).2

theorem warm1539 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 57) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1539 1539) = true := by
  decide +kernel

theorem ok1539 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1539 1539 = true := (Snake9.LratV3.andB_eq_true warm1539).2

theorem warm1540 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1540 1540) = true := by
  decide +kernel

theorem ok1540 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1540 1540 = true := (Snake9.LratV3.andB_eq_true warm1540).2

theorem warm1541 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1541 1541) = true := by
  decide +kernel

theorem ok1541 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1541 1541 = true := (Snake9.LratV3.andB_eq_true warm1541).2

theorem warm1542 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 82) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1542 1542) = true := by
  decide +kernel

theorem ok1542 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1542 1542 = true := (Snake9.LratV3.andB_eq_true warm1542).2

theorem warm1543 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1543 1543) = true := by
  decide +kernel

theorem ok1543 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1543 1543 = true := (Snake9.LratV3.andB_eq_true warm1543).2

theorem warm1544 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 26624)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 28672)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.andB (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1544 1544) (Snake9.LratV3.hasEmpty 15 32767 (Snake9.LratV3.segP Ps 1544))) = true := by
  decide +kernel

theorem ok1544 : Snake9.LratV3.andB (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t1544 1544) (Snake9.LratV3.hasEmpty 15 32767 (Snake9.LratV3.segP Ps 1544)) = true := (Snake9.LratV3.andB_eq_true warm1544).2

end Snake9.LocalWindow.T012301A36264K45
