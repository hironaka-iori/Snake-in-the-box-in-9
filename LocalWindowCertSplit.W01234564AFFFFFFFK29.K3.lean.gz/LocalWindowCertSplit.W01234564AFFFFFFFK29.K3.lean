module

-- LocalWindowCertSplit.W01234564AFFFFFFFK29: kernel checks of segments 94..125 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.W01234564AFFFFFFFK29.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.W01234564AFFFFFFFK29

theorem warm94 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t94 94) = true := by
  decide +kernel

theorem ok94 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t94 94 = true := (Snake9.LratV3.andB_eq_true warm94).2

theorem warm95 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 23) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t95 95) = true := by
  decide +kernel

theorem ok95 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t95 95 = true := (Snake9.LratV3.andB_eq_true warm95).2

theorem warm96 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t96 96) = true := by
  decide +kernel

theorem ok96 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t96 96 = true := (Snake9.LratV3.andB_eq_true warm96).2

theorem warm97 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t97 97) = true := by
  decide +kernel

theorem ok97 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t97 97 = true := (Snake9.LratV3.andB_eq_true warm97).2

theorem warm98 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t98 98) = true := by
  decide +kernel

theorem ok98 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t98 98 = true := (Snake9.LratV3.andB_eq_true warm98).2

theorem warm99 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 23) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t99 99) = true := by
  decide +kernel

theorem ok99 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t99 99 = true := (Snake9.LratV3.andB_eq_true warm99).2

theorem warm100 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t100 100) = true := by
  decide +kernel

theorem ok100 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t100 100 = true := (Snake9.LratV3.andB_eq_true warm100).2

theorem warm101 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t101 101) = true := by
  decide +kernel

theorem ok101 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t101 101 = true := (Snake9.LratV3.andB_eq_true warm101).2

theorem warm102 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t102 102) = true := by
  decide +kernel

theorem ok102 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t102 102 = true := (Snake9.LratV3.andB_eq_true warm102).2

theorem warm103 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t103 103) = true := by
  decide +kernel

theorem ok103 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t103 103 = true := (Snake9.LratV3.andB_eq_true warm103).2

theorem warm104 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t104 104) = true := by
  decide +kernel

theorem ok104 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t104 104 = true := (Snake9.LratV3.andB_eq_true warm104).2

theorem warm105 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t105 105) = true := by
  decide +kernel

theorem ok105 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t105 105 = true := (Snake9.LratV3.andB_eq_true warm105).2

theorem warm106 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t106 106) = true := by
  decide +kernel

theorem ok106 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t106 106 = true := (Snake9.LratV3.andB_eq_true warm106).2

theorem warm107 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t107 107) = true := by
  decide +kernel

theorem ok107 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t107 107 = true := (Snake9.LratV3.andB_eq_true warm107).2

theorem warm108 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t108 108) = true := by
  decide +kernel

theorem ok108 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t108 108 = true := (Snake9.LratV3.andB_eq_true warm108).2

theorem warm109 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t109 109) = true := by
  decide +kernel

theorem ok109 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t109 109 = true := (Snake9.LratV3.andB_eq_true warm109).2

theorem warm110 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t110 110) = true := by
  decide +kernel

theorem ok110 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t110 110 = true := (Snake9.LratV3.andB_eq_true warm110).2

theorem warm111 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t111 111) = true := by
  decide +kernel

theorem ok111 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t111 111 = true := (Snake9.LratV3.andB_eq_true warm111).2

theorem warm112 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t112 112) = true := by
  decide +kernel

theorem ok112 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t112 112 = true := (Snake9.LratV3.andB_eq_true warm112).2

theorem warm113 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t113 113) = true := by
  decide +kernel

theorem ok113 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t113 113 = true := (Snake9.LratV3.andB_eq_true warm113).2

theorem warm114 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t114 114) = true := by
  decide +kernel

theorem ok114 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t114 114 = true := (Snake9.LratV3.andB_eq_true warm114).2

theorem warm115 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t115 115) = true := by
  decide +kernel

theorem ok115 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t115 115 = true := (Snake9.LratV3.andB_eq_true warm115).2

theorem warm116 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t116 116) = true := by
  decide +kernel

theorem ok116 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t116 116 = true := (Snake9.LratV3.andB_eq_true warm116).2

theorem warm117 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t117 117) = true := by
  decide +kernel

theorem ok117 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t117 117 = true := (Snake9.LratV3.andB_eq_true warm117).2

theorem warm118 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t118 118) = true := by
  decide +kernel

theorem ok118 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t118 118 = true := (Snake9.LratV3.andB_eq_true warm118).2

theorem warm119 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t119 119) = true := by
  decide +kernel

theorem ok119 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t119 119 = true := (Snake9.LratV3.andB_eq_true warm119).2

theorem warm120 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t120 120) = true := by
  decide +kernel

theorem ok120 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t120 120 = true := (Snake9.LratV3.andB_eq_true warm120).2

theorem warm121 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t121 121) = true := by
  decide +kernel

theorem ok121 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t121 121 = true := (Snake9.LratV3.andB_eq_true warm121).2

theorem warm122 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t122 122) = true := by
  decide +kernel

theorem ok122 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t122 122 = true := (Snake9.LratV3.andB_eq_true warm122).2

theorem warm123 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t123 123) = true := by
  decide +kernel

theorem ok123 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t123 123 = true := (Snake9.LratV3.andB_eq_true warm123).2

theorem warm124 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t124 124) = true := by
  decide +kernel

theorem ok124 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t124 124 = true := (Snake9.LratV3.andB_eq_true warm124).2

theorem warm125 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t125 125) = true := by
  decide +kernel

theorem ok125 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t125 125 = true := (Snake9.LratV3.andB_eq_true warm125).2

end Snake9.LocalWindow.W01234564AFFFFFFFK29
