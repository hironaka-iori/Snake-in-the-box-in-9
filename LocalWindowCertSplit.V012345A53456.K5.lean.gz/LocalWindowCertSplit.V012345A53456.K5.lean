module

-- LocalWindowCertSplit.V012345A53456: kernel checks of segments 298..354 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012345A53456.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012345A53456

theorem warm298 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t298 298) = true := by
  decide +kernel

theorem ok298 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t298 298 = true := (Snake9.LratV3.andB_eq_true warm298).2

theorem warm299 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t299 299) = true := by
  decide +kernel

theorem ok299 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t299 299 = true := (Snake9.LratV3.andB_eq_true warm299).2

theorem warm300 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t300 300) = true := by
  decide +kernel

theorem ok300 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t300 300 = true := (Snake9.LratV3.andB_eq_true warm300).2

theorem warm301 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t301 301) = true := by
  decide +kernel

theorem ok301 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t301 301 = true := (Snake9.LratV3.andB_eq_true warm301).2

theorem warm302 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t302 302) = true := by
  decide +kernel

theorem ok302 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t302 302 = true := (Snake9.LratV3.andB_eq_true warm302).2

theorem warm303 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t303 303) = true := by
  decide +kernel

theorem ok303 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t303 303 = true := (Snake9.LratV3.andB_eq_true warm303).2

theorem warm304 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t304 304) = true := by
  decide +kernel

theorem ok304 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t304 304 = true := (Snake9.LratV3.andB_eq_true warm304).2

theorem warm305 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t305 305) = true := by
  decide +kernel

theorem ok305 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t305 305 = true := (Snake9.LratV3.andB_eq_true warm305).2

theorem warm306 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t306 306) = true := by
  decide +kernel

theorem ok306 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t306 306 = true := (Snake9.LratV3.andB_eq_true warm306).2

theorem warm307 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t307 307) = true := by
  decide +kernel

theorem ok307 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t307 307 = true := (Snake9.LratV3.andB_eq_true warm307).2

theorem warm308 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t308 308) = true := by
  decide +kernel

theorem ok308 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t308 308 = true := (Snake9.LratV3.andB_eq_true warm308).2

theorem warm309 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t309 309) = true := by
  decide +kernel

theorem ok309 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t309 309 = true := (Snake9.LratV3.andB_eq_true warm309).2

theorem warm310 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t310 310) = true := by
  decide +kernel

theorem ok310 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t310 310 = true := (Snake9.LratV3.andB_eq_true warm310).2

theorem warm311 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t311 311) = true := by
  decide +kernel

theorem ok311 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t311 311 = true := (Snake9.LratV3.andB_eq_true warm311).2

theorem warm312 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t312 312) = true := by
  decide +kernel

theorem ok312 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t312 312 = true := (Snake9.LratV3.andB_eq_true warm312).2

theorem warm313 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t313 313) = true := by
  decide +kernel

theorem ok313 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t313 313 = true := (Snake9.LratV3.andB_eq_true warm313).2

theorem warm314 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t314 314) = true := by
  decide +kernel

theorem ok314 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t314 314 = true := (Snake9.LratV3.andB_eq_true warm314).2

theorem warm315 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t315 315) = true := by
  decide +kernel

theorem ok315 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t315 315 = true := (Snake9.LratV3.andB_eq_true warm315).2

theorem warm316 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t316 316) = true := by
  decide +kernel

theorem ok316 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t316 316 = true := (Snake9.LratV3.andB_eq_true warm316).2

theorem warm317 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t317 317) = true := by
  decide +kernel

theorem ok317 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t317 317 = true := (Snake9.LratV3.andB_eq_true warm317).2

theorem warm318 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t318 318) = true := by
  decide +kernel

theorem ok318 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t318 318 = true := (Snake9.LratV3.andB_eq_true warm318).2

theorem warm319 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t319 319) = true := by
  decide +kernel

theorem ok319 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t319 319 = true := (Snake9.LratV3.andB_eq_true warm319).2

theorem warm320 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t320 320) = true := by
  decide +kernel

theorem ok320 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t320 320 = true := (Snake9.LratV3.andB_eq_true warm320).2

theorem warm321 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t321 321) = true := by
  decide +kernel

theorem ok321 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t321 321 = true := (Snake9.LratV3.andB_eq_true warm321).2

theorem warm322 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t322 322) = true := by
  decide +kernel

theorem ok322 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t322 322 = true := (Snake9.LratV3.andB_eq_true warm322).2

theorem warm323 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t323 323) = true := by
  decide +kernel

theorem ok323 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t323 323 = true := (Snake9.LratV3.andB_eq_true warm323).2

theorem warm324 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t324 324) = true := by
  decide +kernel

theorem ok324 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t324 324 = true := (Snake9.LratV3.andB_eq_true warm324).2

theorem warm325 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t325 325) = true := by
  decide +kernel

theorem ok325 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t325 325 = true := (Snake9.LratV3.andB_eq_true warm325).2

theorem warm326 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t326 326) = true := by
  decide +kernel

theorem ok326 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t326 326 = true := (Snake9.LratV3.andB_eq_true warm326).2

theorem warm327 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t327 327) = true := by
  decide +kernel

theorem ok327 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t327 327 = true := (Snake9.LratV3.andB_eq_true warm327).2

theorem warm328 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t328 328) = true := by
  decide +kernel

theorem ok328 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t328 328 = true := (Snake9.LratV3.andB_eq_true warm328).2

theorem warm329 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t329 329) = true := by
  decide +kernel

theorem ok329 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t329 329 = true := (Snake9.LratV3.andB_eq_true warm329).2

theorem warm330 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 294) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t330 330) = true := by
  decide +kernel

theorem ok330 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t330 330 = true := (Snake9.LratV3.andB_eq_true warm330).2

theorem warm331 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t331 331) = true := by
  decide +kernel

theorem ok331 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t331 331 = true := (Snake9.LratV3.andB_eq_true warm331).2

theorem warm332 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t332 332) = true := by
  decide +kernel

theorem ok332 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t332 332 = true := (Snake9.LratV3.andB_eq_true warm332).2

theorem warm333 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t333 333) = true := by
  decide +kernel

theorem ok333 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t333 333 = true := (Snake9.LratV3.andB_eq_true warm333).2

theorem warm334 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t334 334) = true := by
  decide +kernel

theorem ok334 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t334 334 = true := (Snake9.LratV3.andB_eq_true warm334).2

theorem warm335 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t335 335) = true := by
  decide +kernel

theorem ok335 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t335 335 = true := (Snake9.LratV3.andB_eq_true warm335).2

theorem warm336 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t336 336) = true := by
  decide +kernel

theorem ok336 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t336 336 = true := (Snake9.LratV3.andB_eq_true warm336).2

theorem warm337 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t337 337) = true := by
  decide +kernel

theorem ok337 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t337 337 = true := (Snake9.LratV3.andB_eq_true warm337).2

theorem warm338 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t338 338) = true := by
  decide +kernel

theorem ok338 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t338 338 = true := (Snake9.LratV3.andB_eq_true warm338).2

theorem warm339 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t339 339) = true := by
  decide +kernel

theorem ok339 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t339 339 = true := (Snake9.LratV3.andB_eq_true warm339).2

theorem warm340 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 294) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t340 340) = true := by
  decide +kernel

theorem ok340 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t340 340 = true := (Snake9.LratV3.andB_eq_true warm340).2

theorem warm341 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t341 341) = true := by
  decide +kernel

theorem ok341 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t341 341 = true := (Snake9.LratV3.andB_eq_true warm341).2

theorem warm342 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t342 342) = true := by
  decide +kernel

theorem ok342 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t342 342 = true := (Snake9.LratV3.andB_eq_true warm342).2

theorem warm343 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t343 343) = true := by
  decide +kernel

theorem ok343 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t343 343 = true := (Snake9.LratV3.andB_eq_true warm343).2

theorem warm344 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t344 344) = true := by
  decide +kernel

theorem ok344 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t344 344 = true := (Snake9.LratV3.andB_eq_true warm344).2

theorem warm345 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t345 345) = true := by
  decide +kernel

theorem ok345 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t345 345 = true := (Snake9.LratV3.andB_eq_true warm345).2

theorem warm346 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t346 346) = true := by
  decide +kernel

theorem ok346 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t346 346 = true := (Snake9.LratV3.andB_eq_true warm346).2

theorem warm347 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t347 347) = true := by
  decide +kernel

theorem ok347 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t347 347 = true := (Snake9.LratV3.andB_eq_true warm347).2

theorem warm348 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t348 348) = true := by
  decide +kernel

theorem ok348 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t348 348 = true := (Snake9.LratV3.andB_eq_true warm348).2

theorem warm349 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t349 349) = true := by
  decide +kernel

theorem ok349 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t349 349 = true := (Snake9.LratV3.andB_eq_true warm349).2

theorem warm350 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t350 350) = true := by
  decide +kernel

theorem ok350 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t350 350 = true := (Snake9.LratV3.andB_eq_true warm350).2

theorem warm351 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t351 351) = true := by
  decide +kernel

theorem ok351 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t351 351 = true := (Snake9.LratV3.andB_eq_true warm351).2

theorem warm352 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 351) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t352 352) = true := by
  decide +kernel

theorem ok352 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t352 352 = true := (Snake9.LratV3.andB_eq_true warm352).2

theorem warm353 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t353 353) = true := by
  decide +kernel

theorem ok353 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t353 353 = true := (Snake9.LratV3.andB_eq_true warm353).2

theorem warm354 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 265) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 311) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 351) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t354 354) = true := by
  decide +kernel

theorem ok354 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t354 354 = true := (Snake9.LratV3.andB_eq_true warm354).2

end Snake9.LocalWindow.V012345A53456
