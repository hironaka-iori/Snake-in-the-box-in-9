module

-- LocalWindowCertSplit.V012310A43455: kernel checks of segments 90..183 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012310A43455.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012310A43455

theorem warm90 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t90 90) = true := by
  decide +kernel

theorem ok90 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t90 90 = true := (Snake9.LratV3.andB_eq_true warm90).2

theorem warm91 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t91 91) = true := by
  decide +kernel

theorem ok91 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t91 91 = true := (Snake9.LratV3.andB_eq_true warm91).2

theorem warm92 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t92 92) = true := by
  decide +kernel

theorem ok92 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t92 92 = true := (Snake9.LratV3.andB_eq_true warm92).2

theorem warm93 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t93 93) = true := by
  decide +kernel

theorem ok93 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t93 93 = true := (Snake9.LratV3.andB_eq_true warm93).2

theorem warm94 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t94 94) = true := by
  decide +kernel

theorem ok94 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t94 94 = true := (Snake9.LratV3.andB_eq_true warm94).2

theorem warm95 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t95 95) = true := by
  decide +kernel

theorem ok95 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t95 95 = true := (Snake9.LratV3.andB_eq_true warm95).2

theorem warm96 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t96 96) = true := by
  decide +kernel

theorem ok96 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t96 96 = true := (Snake9.LratV3.andB_eq_true warm96).2

theorem warm97 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t97 97) = true := by
  decide +kernel

theorem ok97 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t97 97 = true := (Snake9.LratV3.andB_eq_true warm97).2

theorem warm98 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t98 98) = true := by
  decide +kernel

theorem ok98 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t98 98 = true := (Snake9.LratV3.andB_eq_true warm98).2

theorem warm99 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t99 99) = true := by
  decide +kernel

theorem ok99 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t99 99 = true := (Snake9.LratV3.andB_eq_true warm99).2

theorem warm100 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t100 100) = true := by
  decide +kernel

theorem ok100 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t100 100 = true := (Snake9.LratV3.andB_eq_true warm100).2

theorem warm101 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t101 101) = true := by
  decide +kernel

theorem ok101 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t101 101 = true := (Snake9.LratV3.andB_eq_true warm101).2

theorem warm102 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t102 102) = true := by
  decide +kernel

theorem ok102 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t102 102 = true := (Snake9.LratV3.andB_eq_true warm102).2

theorem warm103 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t103 103) = true := by
  decide +kernel

theorem ok103 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t103 103 = true := (Snake9.LratV3.andB_eq_true warm103).2

theorem warm104 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t104 104) = true := by
  decide +kernel

theorem ok104 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t104 104 = true := (Snake9.LratV3.andB_eq_true warm104).2

theorem warm105 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t105 105) = true := by
  decide +kernel

theorem ok105 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t105 105 = true := (Snake9.LratV3.andB_eq_true warm105).2

theorem warm106 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t106 106) = true := by
  decide +kernel

theorem ok106 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t106 106 = true := (Snake9.LratV3.andB_eq_true warm106).2

theorem warm107 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t107 107) = true := by
  decide +kernel

theorem ok107 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t107 107 = true := (Snake9.LratV3.andB_eq_true warm107).2

theorem warm108 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t108 108) = true := by
  decide +kernel

theorem ok108 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t108 108 = true := (Snake9.LratV3.andB_eq_true warm108).2

theorem warm109 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t109 109) = true := by
  decide +kernel

theorem ok109 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t109 109 = true := (Snake9.LratV3.andB_eq_true warm109).2

theorem warm110 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t110 110) = true := by
  decide +kernel

theorem ok110 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t110 110 = true := (Snake9.LratV3.andB_eq_true warm110).2

theorem warm111 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t111 111) = true := by
  decide +kernel

theorem ok111 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t111 111 = true := (Snake9.LratV3.andB_eq_true warm111).2

theorem warm112 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t112 112) = true := by
  decide +kernel

theorem ok112 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t112 112 = true := (Snake9.LratV3.andB_eq_true warm112).2

theorem warm113 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t113 113) = true := by
  decide +kernel

theorem ok113 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t113 113 = true := (Snake9.LratV3.andB_eq_true warm113).2

theorem warm114 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t114 114) = true := by
  decide +kernel

theorem ok114 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t114 114 = true := (Snake9.LratV3.andB_eq_true warm114).2

theorem warm115 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t115 115) = true := by
  decide +kernel

theorem ok115 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t115 115 = true := (Snake9.LratV3.andB_eq_true warm115).2

theorem warm116 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t116 116) = true := by
  decide +kernel

theorem ok116 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t116 116 = true := (Snake9.LratV3.andB_eq_true warm116).2

theorem warm117 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t117 117) = true := by
  decide +kernel

theorem ok117 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t117 117 = true := (Snake9.LratV3.andB_eq_true warm117).2

theorem warm118 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t118 118) = true := by
  decide +kernel

theorem ok118 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t118 118 = true := (Snake9.LratV3.andB_eq_true warm118).2

theorem warm119 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t119 119) = true := by
  decide +kernel

theorem ok119 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t119 119 = true := (Snake9.LratV3.andB_eq_true warm119).2

theorem warm120 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t120 120) = true := by
  decide +kernel

theorem ok120 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t120 120 = true := (Snake9.LratV3.andB_eq_true warm120).2

theorem warm121 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t121 121) = true := by
  decide +kernel

theorem ok121 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t121 121 = true := (Snake9.LratV3.andB_eq_true warm121).2

theorem warm122 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t122 122) = true := by
  decide +kernel

theorem ok122 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t122 122 = true := (Snake9.LratV3.andB_eq_true warm122).2

theorem warm123 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t123 123) = true := by
  decide +kernel

theorem ok123 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t123 123 = true := (Snake9.LratV3.andB_eq_true warm123).2

theorem warm124 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t124 124) = true := by
  decide +kernel

theorem ok124 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t124 124 = true := (Snake9.LratV3.andB_eq_true warm124).2

theorem warm125 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t125 125) = true := by
  decide +kernel

theorem ok125 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t125 125 = true := (Snake9.LratV3.andB_eq_true warm125).2

theorem warm126 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t126 126) = true := by
  decide +kernel

theorem ok126 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t126 126 = true := (Snake9.LratV3.andB_eq_true warm126).2

theorem warm127 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t127 127) = true := by
  decide +kernel

theorem ok127 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t127 127 = true := (Snake9.LratV3.andB_eq_true warm127).2

theorem warm128 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t128 128) = true := by
  decide +kernel

theorem ok128 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t128 128 = true := (Snake9.LratV3.andB_eq_true warm128).2

theorem warm129 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t129 129) = true := by
  decide +kernel

theorem ok129 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t129 129 = true := (Snake9.LratV3.andB_eq_true warm129).2

theorem ok130 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t130 130 = true := by
  decide +kernel

theorem warm131 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t131 131) = true := by
  decide +kernel

theorem ok131 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t131 131 = true := (Snake9.LratV3.andB_eq_true warm131).2

theorem warm132 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t132 132) = true := by
  decide +kernel

theorem ok132 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t132 132 = true := (Snake9.LratV3.andB_eq_true warm132).2

theorem warm133 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t133 133) = true := by
  decide +kernel

theorem ok133 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t133 133 = true := (Snake9.LratV3.andB_eq_true warm133).2

theorem warm134 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t134 134) = true := by
  decide +kernel

theorem ok134 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t134 134 = true := (Snake9.LratV3.andB_eq_true warm134).2

theorem warm135 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t135 135) = true := by
  decide +kernel

theorem ok135 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t135 135 = true := (Snake9.LratV3.andB_eq_true warm135).2

theorem warm136 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t136 136) = true := by
  decide +kernel

theorem ok136 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t136 136 = true := (Snake9.LratV3.andB_eq_true warm136).2

theorem ok137 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t137 137 = true := by
  decide +kernel

theorem warm138 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t138 138) = true := by
  decide +kernel

theorem ok138 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t138 138 = true := (Snake9.LratV3.andB_eq_true warm138).2

theorem warm139 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t139 139) = true := by
  decide +kernel

theorem ok139 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t139 139 = true := (Snake9.LratV3.andB_eq_true warm139).2

theorem warm140 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t140 140) = true := by
  decide +kernel

theorem ok140 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t140 140 = true := (Snake9.LratV3.andB_eq_true warm140).2

theorem warm141 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t141 141) = true := by
  decide +kernel

theorem ok141 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t141 141 = true := (Snake9.LratV3.andB_eq_true warm141).2

theorem warm142 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t142 142) = true := by
  decide +kernel

theorem ok142 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t142 142 = true := (Snake9.LratV3.andB_eq_true warm142).2

theorem warm143 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t143 143) = true := by
  decide +kernel

theorem ok143 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t143 143 = true := (Snake9.LratV3.andB_eq_true warm143).2

theorem warm144 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t144 144) = true := by
  decide +kernel

theorem ok144 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t144 144 = true := (Snake9.LratV3.andB_eq_true warm144).2

theorem warm145 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t145 145) = true := by
  decide +kernel

theorem ok145 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t145 145 = true := (Snake9.LratV3.andB_eq_true warm145).2

theorem warm146 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t146 146) = true := by
  decide +kernel

theorem ok146 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t146 146 = true := (Snake9.LratV3.andB_eq_true warm146).2

theorem warm147 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t147 147) = true := by
  decide +kernel

theorem ok147 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t147 147 = true := (Snake9.LratV3.andB_eq_true warm147).2

theorem warm148 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t148 148) = true := by
  decide +kernel

theorem ok148 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t148 148 = true := (Snake9.LratV3.andB_eq_true warm148).2

theorem warm149 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t149 149) = true := by
  decide +kernel

theorem ok149 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t149 149 = true := (Snake9.LratV3.andB_eq_true warm149).2

theorem warm150 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t150 150) = true := by
  decide +kernel

theorem ok150 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t150 150 = true := (Snake9.LratV3.andB_eq_true warm150).2

theorem warm151 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t151 151) = true := by
  decide +kernel

theorem ok151 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t151 151 = true := (Snake9.LratV3.andB_eq_true warm151).2

theorem warm152 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t152 152) = true := by
  decide +kernel

theorem ok152 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t152 152 = true := (Snake9.LratV3.andB_eq_true warm152).2

theorem warm153 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t153 153) = true := by
  decide +kernel

theorem ok153 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t153 153 = true := (Snake9.LratV3.andB_eq_true warm153).2

theorem warm154 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t154 154) = true := by
  decide +kernel

theorem ok154 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t154 154 = true := (Snake9.LratV3.andB_eq_true warm154).2

theorem warm155 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t155 155) = true := by
  decide +kernel

theorem ok155 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t155 155 = true := (Snake9.LratV3.andB_eq_true warm155).2

theorem warm156 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t156 156) = true := by
  decide +kernel

theorem ok156 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t156 156 = true := (Snake9.LratV3.andB_eq_true warm156).2

theorem warm157 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t157 157) = true := by
  decide +kernel

theorem ok157 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t157 157 = true := (Snake9.LratV3.andB_eq_true warm157).2

theorem warm158 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t158 158) = true := by
  decide +kernel

theorem ok158 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t158 158 = true := (Snake9.LratV3.andB_eq_true warm158).2

theorem warm159 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t159 159) = true := by
  decide +kernel

theorem ok159 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t159 159 = true := (Snake9.LratV3.andB_eq_true warm159).2

theorem warm160 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t160 160) = true := by
  decide +kernel

theorem ok160 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t160 160 = true := (Snake9.LratV3.andB_eq_true warm160).2

theorem warm161 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t161 161) = true := by
  decide +kernel

theorem ok161 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t161 161 = true := (Snake9.LratV3.andB_eq_true warm161).2

theorem warm162 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 112) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t162 162) = true := by
  decide +kernel

theorem ok162 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t162 162 = true := (Snake9.LratV3.andB_eq_true warm162).2

theorem warm163 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t163 163) = true := by
  decide +kernel

theorem ok163 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t163 163 = true := (Snake9.LratV3.andB_eq_true warm163).2

theorem warm164 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t164 164) = true := by
  decide +kernel

theorem ok164 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t164 164 = true := (Snake9.LratV3.andB_eq_true warm164).2

theorem warm165 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 164) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t165 165) = true := by
  decide +kernel

theorem ok165 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t165 165 = true := (Snake9.LratV3.andB_eq_true warm165).2

theorem warm166 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t166 166) = true := by
  decide +kernel

theorem ok166 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t166 166 = true := (Snake9.LratV3.andB_eq_true warm166).2

theorem warm167 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t167 167) = true := by
  decide +kernel

theorem ok167 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t167 167 = true := (Snake9.LratV3.andB_eq_true warm167).2

theorem warm168 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t168 168) = true := by
  decide +kernel

theorem ok168 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t168 168 = true := (Snake9.LratV3.andB_eq_true warm168).2

theorem warm169 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t169 169) = true := by
  decide +kernel

theorem ok169 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t169 169 = true := (Snake9.LratV3.andB_eq_true warm169).2

theorem warm170 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t170 170) = true := by
  decide +kernel

theorem ok170 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t170 170 = true := (Snake9.LratV3.andB_eq_true warm170).2

theorem warm171 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t171 171) = true := by
  decide +kernel

theorem ok171 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t171 171 = true := (Snake9.LratV3.andB_eq_true warm171).2

theorem warm172 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t172 172) = true := by
  decide +kernel

theorem ok172 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t172 172 = true := (Snake9.LratV3.andB_eq_true warm172).2

theorem warm173 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t173 173) = true := by
  decide +kernel

theorem ok173 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t173 173 = true := (Snake9.LratV3.andB_eq_true warm173).2

theorem warm174 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t174 174) = true := by
  decide +kernel

theorem ok174 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t174 174 = true := (Snake9.LratV3.andB_eq_true warm174).2

theorem warm175 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t175 175) = true := by
  decide +kernel

theorem ok175 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t175 175 = true := (Snake9.LratV3.andB_eq_true warm175).2

theorem warm176 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 112) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t176 176) = true := by
  decide +kernel

theorem ok176 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t176 176 = true := (Snake9.LratV3.andB_eq_true warm176).2

theorem warm177 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t177 177) = true := by
  decide +kernel

theorem ok177 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t177 177 = true := (Snake9.LratV3.andB_eq_true warm177).2

theorem warm178 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t178 178) = true := by
  decide +kernel

theorem ok178 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t178 178 = true := (Snake9.LratV3.andB_eq_true warm178).2

theorem warm179 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t179 179) = true := by
  decide +kernel

theorem ok179 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t179 179 = true := (Snake9.LratV3.andB_eq_true warm179).2

theorem warm180 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t180 180) = true := by
  decide +kernel

theorem ok180 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t180 180 = true := (Snake9.LratV3.andB_eq_true warm180).2

theorem warm181 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t181 181) = true := by
  decide +kernel

theorem ok181 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t181 181 = true := (Snake9.LratV3.andB_eq_true warm181).2

theorem warm182 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t182 182) = true := by
  decide +kernel

theorem ok182 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t182 182 = true := (Snake9.LratV3.andB_eq_true warm182).2

theorem warm183 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 148) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t183 183) = true := by
  decide +kernel

theorem ok183 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t183 183 = true := (Snake9.LratV3.andB_eq_true warm183).2

end Snake9.LocalWindow.V012310A43455
