module

-- LocalWindowCertSplit.V012031A54643: kernel checks of segments 834..893 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012031A54643.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012031A54643

theorem warm834 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t834 834) = true := by
  decide +kernel

theorem ok834 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t834 834 = true := (Snake9.LratV3.andB_eq_true warm834).2

theorem warm835 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t835 835) = true := by
  decide +kernel

theorem ok835 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t835 835 = true := (Snake9.LratV3.andB_eq_true warm835).2

theorem warm836 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t836 836) = true := by
  decide +kernel

theorem ok836 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t836 836 = true := (Snake9.LratV3.andB_eq_true warm836).2

theorem warm837 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t837 837) = true := by
  decide +kernel

theorem ok837 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t837 837 = true := (Snake9.LratV3.andB_eq_true warm837).2

theorem warm838 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 704) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 820) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t838 838) = true := by
  decide +kernel

theorem ok838 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t838 838 = true := (Snake9.LratV3.andB_eq_true warm838).2

theorem warm839 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t839 839) = true := by
  decide +kernel

theorem ok839 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t839 839 = true := (Snake9.LratV3.andB_eq_true warm839).2

theorem warm840 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t840 840) = true := by
  decide +kernel

theorem ok840 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t840 840 = true := (Snake9.LratV3.andB_eq_true warm840).2

theorem warm841 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t841 841) = true := by
  decide +kernel

theorem ok841 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t841 841 = true := (Snake9.LratV3.andB_eq_true warm841).2

theorem warm842 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t842 842) = true := by
  decide +kernel

theorem ok842 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t842 842 = true := (Snake9.LratV3.andB_eq_true warm842).2

theorem warm843 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t843 843) = true := by
  decide +kernel

theorem ok843 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t843 843 = true := (Snake9.LratV3.andB_eq_true warm843).2

theorem warm844 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t844 844) = true := by
  decide +kernel

theorem ok844 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t844 844 = true := (Snake9.LratV3.andB_eq_true warm844).2

theorem warm845 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 820) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t845 845) = true := by
  decide +kernel

theorem ok845 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t845 845 = true := (Snake9.LratV3.andB_eq_true warm845).2

theorem warm846 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 780) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t846 846) = true := by
  decide +kernel

theorem ok846 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t846 846 = true := (Snake9.LratV3.andB_eq_true warm846).2

theorem warm847 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t847 847) = true := by
  decide +kernel

theorem ok847 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t847 847 = true := (Snake9.LratV3.andB_eq_true warm847).2

theorem warm848 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t848 848) = true := by
  decide +kernel

theorem ok848 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t848 848 = true := (Snake9.LratV3.andB_eq_true warm848).2

theorem warm849 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t849 849) = true := by
  decide +kernel

theorem ok849 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t849 849 = true := (Snake9.LratV3.andB_eq_true warm849).2

theorem warm850 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t850 850) = true := by
  decide +kernel

theorem ok850 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t850 850 = true := (Snake9.LratV3.andB_eq_true warm850).2

theorem warm851 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t851 851) = true := by
  decide +kernel

theorem ok851 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t851 851 = true := (Snake9.LratV3.andB_eq_true warm851).2

theorem warm852 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t852 852) = true := by
  decide +kernel

theorem ok852 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t852 852 = true := (Snake9.LratV3.andB_eq_true warm852).2

theorem warm853 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t853 853) = true := by
  decide +kernel

theorem ok853 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t853 853 = true := (Snake9.LratV3.andB_eq_true warm853).2

theorem warm854 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t854 854) = true := by
  decide +kernel

theorem ok854 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t854 854 = true := (Snake9.LratV3.andB_eq_true warm854).2

theorem warm855 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t855 855) = true := by
  decide +kernel

theorem ok855 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t855 855 = true := (Snake9.LratV3.andB_eq_true warm855).2

theorem warm856 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 820) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t856 856) = true := by
  decide +kernel

theorem ok856 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t856 856 = true := (Snake9.LratV3.andB_eq_true warm856).2

theorem warm857 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t857 857) = true := by
  decide +kernel

theorem ok857 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t857 857 = true := (Snake9.LratV3.andB_eq_true warm857).2

theorem warm858 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 820) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t858 858) = true := by
  decide +kernel

theorem ok858 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t858 858 = true := (Snake9.LratV3.andB_eq_true warm858).2

theorem warm859 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t859 859) = true := by
  decide +kernel

theorem ok859 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t859 859 = true := (Snake9.LratV3.andB_eq_true warm859).2

theorem warm860 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t860 860) = true := by
  decide +kernel

theorem ok860 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t860 860 = true := (Snake9.LratV3.andB_eq_true warm860).2

theorem warm861 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t861 861) = true := by
  decide +kernel

theorem ok861 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t861 861 = true := (Snake9.LratV3.andB_eq_true warm861).2

theorem warm862 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t862 862) = true := by
  decide +kernel

theorem ok862 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t862 862 = true := (Snake9.LratV3.andB_eq_true warm862).2

theorem warm863 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 862) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t863 863) = true := by
  decide +kernel

theorem ok863 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t863 863 = true := (Snake9.LratV3.andB_eq_true warm863).2

theorem warm864 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t864 864) = true := by
  decide +kernel

theorem ok864 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t864 864 = true := (Snake9.LratV3.andB_eq_true warm864).2

theorem warm865 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t865 865) = true := by
  decide +kernel

theorem ok865 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t865 865 = true := (Snake9.LratV3.andB_eq_true warm865).2

theorem warm866 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t866 866) = true := by
  decide +kernel

theorem ok866 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t866 866 = true := (Snake9.LratV3.andB_eq_true warm866).2

theorem warm867 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t867 867) = true := by
  decide +kernel

theorem ok867 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t867 867 = true := (Snake9.LratV3.andB_eq_true warm867).2

theorem warm868 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t868 868) = true := by
  decide +kernel

theorem ok868 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t868 868 = true := (Snake9.LratV3.andB_eq_true warm868).2

theorem warm869 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t869 869) = true := by
  decide +kernel

theorem ok869 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t869 869 = true := (Snake9.LratV3.andB_eq_true warm869).2

theorem warm870 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t870 870) = true := by
  decide +kernel

theorem ok870 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t870 870 = true := (Snake9.LratV3.andB_eq_true warm870).2

theorem warm871 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t871 871) = true := by
  decide +kernel

theorem ok871 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t871 871 = true := (Snake9.LratV3.andB_eq_true warm871).2

theorem warm872 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t872 872) = true := by
  decide +kernel

theorem ok872 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t872 872 = true := (Snake9.LratV3.andB_eq_true warm872).2

theorem warm873 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t873 873) = true := by
  decide +kernel

theorem ok873 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t873 873 = true := (Snake9.LratV3.andB_eq_true warm873).2

theorem warm874 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 780) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t874 874) = true := by
  decide +kernel

theorem ok874 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t874 874 = true := (Snake9.LratV3.andB_eq_true warm874).2

theorem warm875 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t875 875) = true := by
  decide +kernel

theorem ok875 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t875 875 = true := (Snake9.LratV3.andB_eq_true warm875).2

theorem warm876 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t876 876) = true := by
  decide +kernel

theorem ok876 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t876 876 = true := (Snake9.LratV3.andB_eq_true warm876).2

theorem warm877 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t877 877) = true := by
  decide +kernel

theorem ok877 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t877 877 = true := (Snake9.LratV3.andB_eq_true warm877).2

theorem warm878 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t878 878) = true := by
  decide +kernel

theorem ok878 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t878 878 = true := (Snake9.LratV3.andB_eq_true warm878).2

theorem warm879 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t879 879) = true := by
  decide +kernel

theorem ok879 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t879 879 = true := (Snake9.LratV3.andB_eq_true warm879).2

theorem warm880 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t880 880) = true := by
  decide +kernel

theorem ok880 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t880 880 = true := (Snake9.LratV3.andB_eq_true warm880).2

theorem warm881 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t881 881) = true := by
  decide +kernel

theorem ok881 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t881 881 = true := (Snake9.LratV3.andB_eq_true warm881).2

theorem warm882 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t882 882) = true := by
  decide +kernel

theorem ok882 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t882 882 = true := (Snake9.LratV3.andB_eq_true warm882).2

theorem warm883 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t883 883) = true := by
  decide +kernel

theorem ok883 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t883 883 = true := (Snake9.LratV3.andB_eq_true warm883).2

theorem warm884 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t884 884) = true := by
  decide +kernel

theorem ok884 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t884 884 = true := (Snake9.LratV3.andB_eq_true warm884).2

theorem warm885 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t885 885) = true := by
  decide +kernel

theorem ok885 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t885 885 = true := (Snake9.LratV3.andB_eq_true warm885).2

theorem warm886 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 820) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t886 886) = true := by
  decide +kernel

theorem ok886 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t886 886 = true := (Snake9.LratV3.andB_eq_true warm886).2

theorem warm887 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 820) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t887 887) = true := by
  decide +kernel

theorem ok887 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t887 887 = true := (Snake9.LratV3.andB_eq_true warm887).2

theorem warm888 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t888 888) = true := by
  decide +kernel

theorem ok888 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t888 888 = true := (Snake9.LratV3.andB_eq_true warm888).2

theorem warm889 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t889 889) = true := by
  decide +kernel

theorem ok889 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t889 889 = true := (Snake9.LratV3.andB_eq_true warm889).2

theorem warm890 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 820) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t890 890) = true := by
  decide +kernel

theorem ok890 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t890 890 = true := (Snake9.LratV3.andB_eq_true warm890).2

theorem warm891 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t891 891) = true := by
  decide +kernel

theorem ok891 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t891 891 = true := (Snake9.LratV3.andB_eq_true warm891).2

theorem warm892 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t892 892) = true := by
  decide +kernel

theorem ok892 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t892 892 = true := (Snake9.LratV3.andB_eq_true warm892).2

theorem warm893 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t893 893) = true := by
  decide +kernel

theorem ok893 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t893 893 = true := (Snake9.LratV3.andB_eq_true warm893).2

end Snake9.LocalWindow.V012031A54643
