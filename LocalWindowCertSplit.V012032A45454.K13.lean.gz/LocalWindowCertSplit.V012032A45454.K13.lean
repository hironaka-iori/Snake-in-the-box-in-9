module

-- LocalWindowCertSplit.V012032A45454: kernel checks of segments 1189..1286 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012032A45454.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012032A45454

theorem warm1189 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1189 1189) = true := by
  decide +kernel

theorem ok1189 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1189 1189 = true := (Snake9.LratV3.andB_eq_true warm1189).2

theorem warm1190 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1000) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1190 1190) = true := by
  decide +kernel

theorem ok1190 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1190 1190 = true := (Snake9.LratV3.andB_eq_true warm1190).2

theorem warm1191 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1000) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1191 1191) = true := by
  decide +kernel

theorem ok1191 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1191 1191 = true := (Snake9.LratV3.andB_eq_true warm1191).2

theorem warm1192 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1192 1192) = true := by
  decide +kernel

theorem ok1192 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1192 1192 = true := (Snake9.LratV3.andB_eq_true warm1192).2

theorem warm1193 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1193 1193) = true := by
  decide +kernel

theorem ok1193 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1193 1193 = true := (Snake9.LratV3.andB_eq_true warm1193).2

theorem warm1194 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1194 1194) = true := by
  decide +kernel

theorem ok1194 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1194 1194 = true := (Snake9.LratV3.andB_eq_true warm1194).2

theorem warm1195 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1195 1195) = true := by
  decide +kernel

theorem ok1195 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1195 1195 = true := (Snake9.LratV3.andB_eq_true warm1195).2

theorem warm1196 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1196 1196) = true := by
  decide +kernel

theorem ok1196 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1196 1196 = true := (Snake9.LratV3.andB_eq_true warm1196).2

theorem warm1197 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1197 1197) = true := by
  decide +kernel

theorem ok1197 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1197 1197 = true := (Snake9.LratV3.andB_eq_true warm1197).2

theorem warm1198 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1198 1198) = true := by
  decide +kernel

theorem ok1198 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1198 1198 = true := (Snake9.LratV3.andB_eq_true warm1198).2

theorem warm1199 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1199 1199) = true := by
  decide +kernel

theorem ok1199 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1199 1199 = true := (Snake9.LratV3.andB_eq_true warm1199).2

theorem warm1200 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1200 1200) = true := by
  decide +kernel

theorem ok1200 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1200 1200 = true := (Snake9.LratV3.andB_eq_true warm1200).2

theorem warm1201 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1201 1201) = true := by
  decide +kernel

theorem ok1201 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1201 1201 = true := (Snake9.LratV3.andB_eq_true warm1201).2

theorem warm1202 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1202 1202) = true := by
  decide +kernel

theorem ok1202 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1202 1202 = true := (Snake9.LratV3.andB_eq_true warm1202).2

theorem warm1203 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1203 1203) = true := by
  decide +kernel

theorem ok1203 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1203 1203 = true := (Snake9.LratV3.andB_eq_true warm1203).2

theorem warm1204 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1204 1204) = true := by
  decide +kernel

theorem ok1204 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1204 1204 = true := (Snake9.LratV3.andB_eq_true warm1204).2

theorem warm1205 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1205 1205) = true := by
  decide +kernel

theorem ok1205 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1205 1205 = true := (Snake9.LratV3.andB_eq_true warm1205).2

theorem warm1206 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1206 1206) = true := by
  decide +kernel

theorem ok1206 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1206 1206 = true := (Snake9.LratV3.andB_eq_true warm1206).2

theorem warm1207 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1207 1207) = true := by
  decide +kernel

theorem ok1207 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1207 1207 = true := (Snake9.LratV3.andB_eq_true warm1207).2

theorem warm1208 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1208 1208) = true := by
  decide +kernel

theorem ok1208 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1208 1208 = true := (Snake9.LratV3.andB_eq_true warm1208).2

theorem warm1209 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1209 1209) = true := by
  decide +kernel

theorem ok1209 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1209 1209 = true := (Snake9.LratV3.andB_eq_true warm1209).2

theorem warm1210 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1210 1210) = true := by
  decide +kernel

theorem ok1210 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1210 1210 = true := (Snake9.LratV3.andB_eq_true warm1210).2

theorem warm1211 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1211 1211) = true := by
  decide +kernel

theorem ok1211 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1211 1211 = true := (Snake9.LratV3.andB_eq_true warm1211).2

theorem warm1212 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1212 1212) = true := by
  decide +kernel

theorem ok1212 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1212 1212 = true := (Snake9.LratV3.andB_eq_true warm1212).2

theorem warm1213 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1213 1213) = true := by
  decide +kernel

theorem ok1213 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1213 1213 = true := (Snake9.LratV3.andB_eq_true warm1213).2

theorem warm1214 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 84) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1214 1214) = true := by
  decide +kernel

theorem ok1214 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1214 1214 = true := (Snake9.LratV3.andB_eq_true warm1214).2

theorem warm1215 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1215 1215) = true := by
  decide +kernel

theorem ok1215 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1215 1215 = true := (Snake9.LratV3.andB_eq_true warm1215).2

theorem warm1216 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1216 1216) = true := by
  decide +kernel

theorem ok1216 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1216 1216 = true := (Snake9.LratV3.andB_eq_true warm1216).2

theorem warm1217 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1217 1217) = true := by
  decide +kernel

theorem ok1217 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1217 1217 = true := (Snake9.LratV3.andB_eq_true warm1217).2

theorem warm1218 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1218 1218) = true := by
  decide +kernel

theorem ok1218 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1218 1218 = true := (Snake9.LratV3.andB_eq_true warm1218).2

theorem warm1219 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1219 1219) = true := by
  decide +kernel

theorem ok1219 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1219 1219 = true := (Snake9.LratV3.andB_eq_true warm1219).2

theorem warm1220 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1220 1220) = true := by
  decide +kernel

theorem ok1220 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1220 1220 = true := (Snake9.LratV3.andB_eq_true warm1220).2

theorem warm1221 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1221 1221) = true := by
  decide +kernel

theorem ok1221 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1221 1221 = true := (Snake9.LratV3.andB_eq_true warm1221).2

theorem warm1222 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1222 1222) = true := by
  decide +kernel

theorem ok1222 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1222 1222 = true := (Snake9.LratV3.andB_eq_true warm1222).2

theorem warm1223 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1223 1223) = true := by
  decide +kernel

theorem ok1223 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1223 1223 = true := (Snake9.LratV3.andB_eq_true warm1223).2

theorem warm1224 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1224 1224) = true := by
  decide +kernel

theorem ok1224 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1224 1224 = true := (Snake9.LratV3.andB_eq_true warm1224).2

theorem warm1225 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1225 1225) = true := by
  decide +kernel

theorem ok1225 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1225 1225 = true := (Snake9.LratV3.andB_eq_true warm1225).2

theorem warm1226 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1226 1226) = true := by
  decide +kernel

theorem ok1226 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1226 1226 = true := (Snake9.LratV3.andB_eq_true warm1226).2

theorem warm1227 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1227 1227) = true := by
  decide +kernel

theorem ok1227 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1227 1227 = true := (Snake9.LratV3.andB_eq_true warm1227).2

theorem warm1228 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1228 1228) = true := by
  decide +kernel

theorem ok1228 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1228 1228 = true := (Snake9.LratV3.andB_eq_true warm1228).2

theorem warm1229 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1229 1229) = true := by
  decide +kernel

theorem ok1229 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1229 1229 = true := (Snake9.LratV3.andB_eq_true warm1229).2

theorem warm1230 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1230 1230) = true := by
  decide +kernel

theorem ok1230 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1230 1230 = true := (Snake9.LratV3.andB_eq_true warm1230).2

theorem warm1231 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1231 1231) = true := by
  decide +kernel

theorem ok1231 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1231 1231 = true := (Snake9.LratV3.andB_eq_true warm1231).2

theorem warm1232 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1232 1232) = true := by
  decide +kernel

theorem ok1232 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1232 1232 = true := (Snake9.LratV3.andB_eq_true warm1232).2

theorem warm1233 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1233 1233) = true := by
  decide +kernel

theorem ok1233 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1233 1233 = true := (Snake9.LratV3.andB_eq_true warm1233).2

theorem warm1234 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1234 1234) = true := by
  decide +kernel

theorem ok1234 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1234 1234 = true := (Snake9.LratV3.andB_eq_true warm1234).2

theorem warm1235 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1235 1235) = true := by
  decide +kernel

theorem ok1235 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1235 1235 = true := (Snake9.LratV3.andB_eq_true warm1235).2

theorem warm1236 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1236 1236) = true := by
  decide +kernel

theorem ok1236 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1236 1236 = true := (Snake9.LratV3.andB_eq_true warm1236).2

theorem warm1237 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1237 1237) = true := by
  decide +kernel

theorem ok1237 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1237 1237 = true := (Snake9.LratV3.andB_eq_true warm1237).2

theorem warm1238 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1238 1238) = true := by
  decide +kernel

theorem ok1238 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1238 1238 = true := (Snake9.LratV3.andB_eq_true warm1238).2

theorem warm1239 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1239 1239) = true := by
  decide +kernel

theorem ok1239 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1239 1239 = true := (Snake9.LratV3.andB_eq_true warm1239).2

theorem warm1240 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1240 1240) = true := by
  decide +kernel

theorem ok1240 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1240 1240 = true := (Snake9.LratV3.andB_eq_true warm1240).2

theorem warm1241 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1241 1241) = true := by
  decide +kernel

theorem ok1241 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1241 1241 = true := (Snake9.LratV3.andB_eq_true warm1241).2

theorem warm1242 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1242 1242) = true := by
  decide +kernel

theorem ok1242 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1242 1242 = true := (Snake9.LratV3.andB_eq_true warm1242).2

theorem warm1243 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1243 1243) = true := by
  decide +kernel

theorem ok1243 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1243 1243 = true := (Snake9.LratV3.andB_eq_true warm1243).2

theorem warm1244 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1244 1244) = true := by
  decide +kernel

theorem ok1244 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1244 1244 = true := (Snake9.LratV3.andB_eq_true warm1244).2

theorem warm1245 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1245 1245) = true := by
  decide +kernel

theorem ok1245 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1245 1245 = true := (Snake9.LratV3.andB_eq_true warm1245).2

theorem warm1246 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1246 1246) = true := by
  decide +kernel

theorem ok1246 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1246 1246 = true := (Snake9.LratV3.andB_eq_true warm1246).2

theorem warm1247 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 64) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1247 1247) = true := by
  decide +kernel

theorem ok1247 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1247 1247 = true := (Snake9.LratV3.andB_eq_true warm1247).2

theorem warm1248 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1248 1248) = true := by
  decide +kernel

theorem ok1248 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1248 1248 = true := (Snake9.LratV3.andB_eq_true warm1248).2

theorem warm1249 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1249 1249) = true := by
  decide +kernel

theorem ok1249 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1249 1249 = true := (Snake9.LratV3.andB_eq_true warm1249).2

theorem warm1250 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1250 1250) = true := by
  decide +kernel

theorem ok1250 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1250 1250 = true := (Snake9.LratV3.andB_eq_true warm1250).2

theorem warm1251 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1251 1251) = true := by
  decide +kernel

theorem ok1251 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1251 1251 = true := (Snake9.LratV3.andB_eq_true warm1251).2

theorem warm1252 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1252 1252) = true := by
  decide +kernel

theorem ok1252 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1252 1252 = true := (Snake9.LratV3.andB_eq_true warm1252).2

theorem warm1253 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1253 1253) = true := by
  decide +kernel

theorem ok1253 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1253 1253 = true := (Snake9.LratV3.andB_eq_true warm1253).2

theorem warm1254 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1254 1254) = true := by
  decide +kernel

theorem ok1254 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1254 1254 = true := (Snake9.LratV3.andB_eq_true warm1254).2

theorem warm1255 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1255 1255) = true := by
  decide +kernel

theorem ok1255 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1255 1255 = true := (Snake9.LratV3.andB_eq_true warm1255).2

theorem warm1256 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1256 1256) = true := by
  decide +kernel

theorem ok1256 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1256 1256 = true := (Snake9.LratV3.andB_eq_true warm1256).2

theorem warm1257 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1257 1257) = true := by
  decide +kernel

theorem ok1257 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1257 1257 = true := (Snake9.LratV3.andB_eq_true warm1257).2

theorem warm1258 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1258 1258) = true := by
  decide +kernel

theorem ok1258 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1258 1258 = true := (Snake9.LratV3.andB_eq_true warm1258).2

theorem warm1259 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1259 1259) = true := by
  decide +kernel

theorem ok1259 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1259 1259 = true := (Snake9.LratV3.andB_eq_true warm1259).2

theorem warm1260 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1260 1260) = true := by
  decide +kernel

theorem ok1260 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1260 1260 = true := (Snake9.LratV3.andB_eq_true warm1260).2

theorem warm1261 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1261 1261) = true := by
  decide +kernel

theorem ok1261 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1261 1261 = true := (Snake9.LratV3.andB_eq_true warm1261).2

theorem warm1262 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1262 1262) = true := by
  decide +kernel

theorem ok1262 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1262 1262 = true := (Snake9.LratV3.andB_eq_true warm1262).2

theorem warm1263 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1263 1263) = true := by
  decide +kernel

theorem ok1263 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1263 1263 = true := (Snake9.LratV3.andB_eq_true warm1263).2

theorem warm1264 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1264 1264) = true := by
  decide +kernel

theorem ok1264 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1264 1264 = true := (Snake9.LratV3.andB_eq_true warm1264).2

theorem warm1265 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1265 1265) = true := by
  decide +kernel

theorem ok1265 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1265 1265 = true := (Snake9.LratV3.andB_eq_true warm1265).2

theorem warm1266 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1266 1266) = true := by
  decide +kernel

theorem ok1266 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1266 1266 = true := (Snake9.LratV3.andB_eq_true warm1266).2

theorem warm1267 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1267 1267) = true := by
  decide +kernel

theorem ok1267 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1267 1267 = true := (Snake9.LratV3.andB_eq_true warm1267).2

theorem warm1268 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1268 1268) = true := by
  decide +kernel

theorem ok1268 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1268 1268 = true := (Snake9.LratV3.andB_eq_true warm1268).2

theorem warm1269 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1000) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1269 1269) = true := by
  decide +kernel

theorem ok1269 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1269 1269 = true := (Snake9.LratV3.andB_eq_true warm1269).2

theorem warm1270 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 170) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1270 1270) = true := by
  decide +kernel

theorem ok1270 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1270 1270 = true := (Snake9.LratV3.andB_eq_true warm1270).2

theorem warm1271 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 170) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1271 1271) = true := by
  decide +kernel

theorem ok1271 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1271 1271 = true := (Snake9.LratV3.andB_eq_true warm1271).2

theorem warm1272 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1272 1272) = true := by
  decide +kernel

theorem ok1272 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1272 1272 = true := (Snake9.LratV3.andB_eq_true warm1272).2

theorem warm1273 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1273 1273) = true := by
  decide +kernel

theorem ok1273 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1273 1273 = true := (Snake9.LratV3.andB_eq_true warm1273).2

theorem warm1274 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1274 1274) = true := by
  decide +kernel

theorem ok1274 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1274 1274 = true := (Snake9.LratV3.andB_eq_true warm1274).2

theorem warm1275 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 84) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1275 1275) = true := by
  decide +kernel

theorem ok1275 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1275 1275 = true := (Snake9.LratV3.andB_eq_true warm1275).2

theorem warm1276 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1276 1276) = true := by
  decide +kernel

theorem ok1276 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1276 1276 = true := (Snake9.LratV3.andB_eq_true warm1276).2

theorem warm1277 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1277 1277) = true := by
  decide +kernel

theorem ok1277 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1277 1277 = true := (Snake9.LratV3.andB_eq_true warm1277).2

theorem warm1278 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 140) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1278 1278) = true := by
  decide +kernel

theorem ok1278 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1278 1278 = true := (Snake9.LratV3.andB_eq_true warm1278).2

theorem warm1279 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1279 1279) = true := by
  decide +kernel

theorem ok1279 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1279 1279 = true := (Snake9.LratV3.andB_eq_true warm1279).2

theorem warm1280 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1280 1280) = true := by
  decide +kernel

theorem ok1280 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1280 1280 = true := (Snake9.LratV3.andB_eq_true warm1280).2

theorem warm1281 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1281 1281) = true := by
  decide +kernel

theorem ok1281 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1281 1281 = true := (Snake9.LratV3.andB_eq_true warm1281).2

theorem warm1282 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 64) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1282 1282) = true := by
  decide +kernel

theorem ok1282 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1282 1282 = true := (Snake9.LratV3.andB_eq_true warm1282).2

theorem warm1283 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1283 1283) = true := by
  decide +kernel

theorem ok1283 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1283 1283 = true := (Snake9.LratV3.andB_eq_true warm1283).2

theorem warm1284 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1284 1284) = true := by
  decide +kernel

theorem ok1284 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1284 1284 = true := (Snake9.LratV3.andB_eq_true warm1284).2

theorem warm1285 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1285 1285) = true := by
  decide +kernel

theorem ok1285 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1285 1285 = true := (Snake9.LratV3.andB_eq_true warm1285).2

theorem warm1286 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1286 1286) = true := by
  decide +kernel

theorem ok1286 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1286 1286 = true := (Snake9.LratV3.andB_eq_true warm1286).2

end Snake9.LocalWindow.V012032A45454
