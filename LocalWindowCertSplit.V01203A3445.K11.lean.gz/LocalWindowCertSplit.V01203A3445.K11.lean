module

-- LocalWindowCertSplit.V01203A3445: kernel checks of segments 679..742 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V01203A3445.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V01203A3445

theorem warm679 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t679 679) = true := by
  decide +kernel

theorem ok679 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t679 679 = true := (Snake9.LratV3.andB_eq_true warm679).2

theorem warm680 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t680 680) = true := by
  decide +kernel

theorem ok680 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t680 680 = true := (Snake9.LratV3.andB_eq_true warm680).2

theorem warm681 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t681 681) = true := by
  decide +kernel

theorem ok681 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t681 681 = true := (Snake9.LratV3.andB_eq_true warm681).2

theorem warm682 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t682 682) = true := by
  decide +kernel

theorem ok682 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t682 682 = true := (Snake9.LratV3.andB_eq_true warm682).2

theorem warm683 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t683 683) = true := by
  decide +kernel

theorem ok683 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t683 683 = true := (Snake9.LratV3.andB_eq_true warm683).2

theorem warm684 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t684 684) = true := by
  decide +kernel

theorem ok684 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t684 684 = true := (Snake9.LratV3.andB_eq_true warm684).2

theorem warm685 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t685 685) = true := by
  decide +kernel

theorem ok685 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t685 685 = true := (Snake9.LratV3.andB_eq_true warm685).2

theorem warm686 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t686 686) = true := by
  decide +kernel

theorem ok686 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t686 686 = true := (Snake9.LratV3.andB_eq_true warm686).2

theorem warm687 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t687 687) = true := by
  decide +kernel

theorem ok687 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t687 687 = true := (Snake9.LratV3.andB_eq_true warm687).2

theorem warm688 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t688 688) = true := by
  decide +kernel

theorem ok688 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t688 688 = true := (Snake9.LratV3.andB_eq_true warm688).2

theorem warm689 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t689 689) = true := by
  decide +kernel

theorem ok689 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t689 689 = true := (Snake9.LratV3.andB_eq_true warm689).2

theorem warm690 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t690 690) = true := by
  decide +kernel

theorem ok690 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t690 690 = true := (Snake9.LratV3.andB_eq_true warm690).2

theorem warm691 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t691 691) = true := by
  decide +kernel

theorem ok691 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t691 691 = true := (Snake9.LratV3.andB_eq_true warm691).2

theorem warm692 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t692 692) = true := by
  decide +kernel

theorem ok692 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t692 692 = true := (Snake9.LratV3.andB_eq_true warm692).2

theorem warm693 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t693 693) = true := by
  decide +kernel

theorem ok693 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t693 693 = true := (Snake9.LratV3.andB_eq_true warm693).2

theorem warm694 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t694 694) = true := by
  decide +kernel

theorem ok694 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t694 694 = true := (Snake9.LratV3.andB_eq_true warm694).2

theorem warm695 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t695 695) = true := by
  decide +kernel

theorem ok695 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t695 695 = true := (Snake9.LratV3.andB_eq_true warm695).2

theorem warm696 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t696 696) = true := by
  decide +kernel

theorem ok696 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t696 696 = true := (Snake9.LratV3.andB_eq_true warm696).2

theorem warm697 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t697 697) = true := by
  decide +kernel

theorem ok697 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t697 697 = true := (Snake9.LratV3.andB_eq_true warm697).2

theorem warm698 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t698 698) = true := by
  decide +kernel

theorem ok698 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t698 698 = true := (Snake9.LratV3.andB_eq_true warm698).2

theorem warm699 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t699 699) = true := by
  decide +kernel

theorem ok699 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t699 699 = true := (Snake9.LratV3.andB_eq_true warm699).2

theorem warm700 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t700 700) = true := by
  decide +kernel

theorem ok700 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t700 700 = true := (Snake9.LratV3.andB_eq_true warm700).2

theorem warm701 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t701 701) = true := by
  decide +kernel

theorem ok701 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t701 701 = true := (Snake9.LratV3.andB_eq_true warm701).2

theorem warm702 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t702 702) = true := by
  decide +kernel

theorem ok702 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t702 702 = true := (Snake9.LratV3.andB_eq_true warm702).2

theorem warm703 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 9) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t703 703) = true := by
  decide +kernel

theorem ok703 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t703 703 = true := (Snake9.LratV3.andB_eq_true warm703).2

theorem warm704 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t704 704) = true := by
  decide +kernel

theorem ok704 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t704 704 = true := (Snake9.LratV3.andB_eq_true warm704).2

theorem warm705 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t705 705) = true := by
  decide +kernel

theorem ok705 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t705 705 = true := (Snake9.LratV3.andB_eq_true warm705).2

theorem warm706 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t706 706) = true := by
  decide +kernel

theorem ok706 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t706 706 = true := (Snake9.LratV3.andB_eq_true warm706).2

theorem ok707 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t707 707 = true := by
  decide +kernel

theorem warm708 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t708 708) = true := by
  decide +kernel

theorem ok708 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t708 708 = true := (Snake9.LratV3.andB_eq_true warm708).2

theorem ok709 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t709 709 = true := by
  decide +kernel

theorem warm710 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 709) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t710 710) = true := by
  decide +kernel

theorem ok710 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t710 710 = true := (Snake9.LratV3.andB_eq_true warm710).2

theorem warm711 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t711 711) = true := by
  decide +kernel

theorem ok711 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t711 711 = true := (Snake9.LratV3.andB_eq_true warm711).2

theorem warm712 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t712 712) = true := by
  decide +kernel

theorem ok712 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t712 712 = true := (Snake9.LratV3.andB_eq_true warm712).2

theorem warm713 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t713 713) = true := by
  decide +kernel

theorem ok713 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t713 713 = true := (Snake9.LratV3.andB_eq_true warm713).2

theorem warm714 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t714 714) = true := by
  decide +kernel

theorem ok714 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t714 714 = true := (Snake9.LratV3.andB_eq_true warm714).2

theorem warm715 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t715 715) = true := by
  decide +kernel

theorem ok715 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t715 715 = true := (Snake9.LratV3.andB_eq_true warm715).2

theorem warm716 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t716 716) = true := by
  decide +kernel

theorem ok716 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t716 716 = true := (Snake9.LratV3.andB_eq_true warm716).2

theorem warm717 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t717 717) = true := by
  decide +kernel

theorem ok717 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t717 717 = true := (Snake9.LratV3.andB_eq_true warm717).2

theorem warm718 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t718 718) = true := by
  decide +kernel

theorem ok718 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t718 718 = true := (Snake9.LratV3.andB_eq_true warm718).2

theorem warm719 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t719 719) = true := by
  decide +kernel

theorem ok719 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t719 719 = true := (Snake9.LratV3.andB_eq_true warm719).2

theorem warm720 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t720 720) = true := by
  decide +kernel

theorem ok720 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t720 720 = true := (Snake9.LratV3.andB_eq_true warm720).2

theorem warm721 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t721 721) = true := by
  decide +kernel

theorem ok721 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t721 721 = true := (Snake9.LratV3.andB_eq_true warm721).2

theorem warm722 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t722 722) = true := by
  decide +kernel

theorem ok722 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t722 722 = true := (Snake9.LratV3.andB_eq_true warm722).2

theorem warm723 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t723 723) = true := by
  decide +kernel

theorem ok723 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t723 723 = true := (Snake9.LratV3.andB_eq_true warm723).2

theorem warm724 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t724 724) = true := by
  decide +kernel

theorem ok724 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t724 724 = true := (Snake9.LratV3.andB_eq_true warm724).2

theorem warm725 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t725 725) = true := by
  decide +kernel

theorem ok725 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t725 725 = true := (Snake9.LratV3.andB_eq_true warm725).2

theorem warm726 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t726 726) = true := by
  decide +kernel

theorem ok726 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t726 726 = true := (Snake9.LratV3.andB_eq_true warm726).2

theorem warm727 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t727 727) = true := by
  decide +kernel

theorem ok727 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t727 727 = true := (Snake9.LratV3.andB_eq_true warm727).2

theorem warm728 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t728 728) = true := by
  decide +kernel

theorem ok728 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t728 728 = true := (Snake9.LratV3.andB_eq_true warm728).2

theorem warm729 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t729 729) = true := by
  decide +kernel

theorem ok729 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t729 729 = true := (Snake9.LratV3.andB_eq_true warm729).2

theorem warm730 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t730 730) = true := by
  decide +kernel

theorem ok730 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t730 730 = true := (Snake9.LratV3.andB_eq_true warm730).2

theorem warm731 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t731 731) = true := by
  decide +kernel

theorem ok731 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t731 731 = true := (Snake9.LratV3.andB_eq_true warm731).2

theorem warm732 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t732 732) = true := by
  decide +kernel

theorem ok732 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t732 732 = true := (Snake9.LratV3.andB_eq_true warm732).2

theorem warm733 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t733 733) = true := by
  decide +kernel

theorem ok733 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t733 733 = true := (Snake9.LratV3.andB_eq_true warm733).2

theorem warm734 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t734 734) = true := by
  decide +kernel

theorem ok734 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t734 734 = true := (Snake9.LratV3.andB_eq_true warm734).2

theorem warm735 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t735 735) = true := by
  decide +kernel

theorem ok735 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t735 735 = true := (Snake9.LratV3.andB_eq_true warm735).2

theorem warm736 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t736 736) = true := by
  decide +kernel

theorem ok736 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t736 736 = true := (Snake9.LratV3.andB_eq_true warm736).2

theorem warm737 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t737 737) = true := by
  decide +kernel

theorem ok737 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t737 737 = true := (Snake9.LratV3.andB_eq_true warm737).2

theorem warm738 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t738 738) = true := by
  decide +kernel

theorem ok738 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t738 738 = true := (Snake9.LratV3.andB_eq_true warm738).2

theorem warm739 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t739 739) = true := by
  decide +kernel

theorem ok739 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t739 739 = true := (Snake9.LratV3.andB_eq_true warm739).2

theorem warm740 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t740 740) = true := by
  decide +kernel

theorem ok740 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t740 740 = true := (Snake9.LratV3.andB_eq_true warm740).2

theorem warm741 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 438) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t741 741) = true := by
  decide +kernel

theorem ok741 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t741 741 = true := (Snake9.LratV3.andB_eq_true warm741).2

theorem warm742 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 480) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t742 742) = true := by
  decide +kernel

theorem ok742 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t742 742 = true := (Snake9.LratV3.andB_eq_true warm742).2

end Snake9.LocalWindow.V01203A3445
