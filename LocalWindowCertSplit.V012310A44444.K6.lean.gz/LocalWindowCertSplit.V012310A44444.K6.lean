module

-- LocalWindowCertSplit.V012310A44444: kernel checks of segments 413..478 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012310A44444.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012310A44444

theorem warm413 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t413 413) = true := by
  decide +kernel

theorem ok413 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t413 413 = true := (Snake9.LratV3.andB_eq_true warm413).2

theorem warm414 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t414 414) = true := by
  decide +kernel

theorem ok414 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t414 414 = true := (Snake9.LratV3.andB_eq_true warm414).2

theorem warm415 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 96) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t415 415) = true := by
  decide +kernel

theorem ok415 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t415 415 = true := (Snake9.LratV3.andB_eq_true warm415).2

theorem warm416 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t416 416) = true := by
  decide +kernel

theorem ok416 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t416 416 = true := (Snake9.LratV3.andB_eq_true warm416).2

theorem warm417 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t417 417) = true := by
  decide +kernel

theorem ok417 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t417 417 = true := (Snake9.LratV3.andB_eq_true warm417).2

theorem warm418 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t418 418) = true := by
  decide +kernel

theorem ok418 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t418 418 = true := (Snake9.LratV3.andB_eq_true warm418).2

theorem warm419 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t419 419) = true := by
  decide +kernel

theorem ok419 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t419 419 = true := (Snake9.LratV3.andB_eq_true warm419).2

theorem warm420 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t420 420) = true := by
  decide +kernel

theorem ok420 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t420 420 = true := (Snake9.LratV3.andB_eq_true warm420).2

theorem warm421 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t421 421) = true := by
  decide +kernel

theorem ok421 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t421 421 = true := (Snake9.LratV3.andB_eq_true warm421).2

theorem warm422 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t422 422) = true := by
  decide +kernel

theorem ok422 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t422 422 = true := (Snake9.LratV3.andB_eq_true warm422).2

theorem warm423 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t423 423) = true := by
  decide +kernel

theorem ok423 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t423 423 = true := (Snake9.LratV3.andB_eq_true warm423).2

theorem warm424 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t424 424) = true := by
  decide +kernel

theorem ok424 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t424 424 = true := (Snake9.LratV3.andB_eq_true warm424).2

theorem warm425 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 96) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t425 425) = true := by
  decide +kernel

theorem ok425 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t425 425 = true := (Snake9.LratV3.andB_eq_true warm425).2

theorem warm426 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 79) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 300) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t426 426) = true := by
  decide +kernel

theorem ok426 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t426 426 = true := (Snake9.LratV3.andB_eq_true warm426).2

theorem warm427 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 96) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t427 427) = true := by
  decide +kernel

theorem ok427 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t427 427 = true := (Snake9.LratV3.andB_eq_true warm427).2

theorem warm428 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t428 428) = true := by
  decide +kernel

theorem ok428 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t428 428 = true := (Snake9.LratV3.andB_eq_true warm428).2

theorem warm429 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t429 429) = true := by
  decide +kernel

theorem ok429 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t429 429 = true := (Snake9.LratV3.andB_eq_true warm429).2

theorem warm430 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t430 430) = true := by
  decide +kernel

theorem ok430 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t430 430 = true := (Snake9.LratV3.andB_eq_true warm430).2

theorem warm431 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 96) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t431 431) = true := by
  decide +kernel

theorem ok431 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t431 431 = true := (Snake9.LratV3.andB_eq_true warm431).2

theorem warm432 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t432 432) = true := by
  decide +kernel

theorem ok432 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t432 432 = true := (Snake9.LratV3.andB_eq_true warm432).2

theorem warm433 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 96) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 300) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t433 433) = true := by
  decide +kernel

theorem ok433 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t433 433 = true := (Snake9.LratV3.andB_eq_true warm433).2

theorem warm434 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 300) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t434 434) = true := by
  decide +kernel

theorem ok434 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t434 434 = true := (Snake9.LratV3.andB_eq_true warm434).2

theorem warm435 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 300) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t435 435) = true := by
  decide +kernel

theorem ok435 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t435 435 = true := (Snake9.LratV3.andB_eq_true warm435).2

theorem warm436 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t436 436) = true := by
  decide +kernel

theorem ok436 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t436 436 = true := (Snake9.LratV3.andB_eq_true warm436).2

theorem warm437 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t437 437) = true := by
  decide +kernel

theorem ok437 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t437 437 = true := (Snake9.LratV3.andB_eq_true warm437).2

theorem warm438 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t438 438) = true := by
  decide +kernel

theorem ok438 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t438 438 = true := (Snake9.LratV3.andB_eq_true warm438).2

theorem warm439 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t439 439) = true := by
  decide +kernel

theorem ok439 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t439 439 = true := (Snake9.LratV3.andB_eq_true warm439).2

theorem warm440 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t440 440) = true := by
  decide +kernel

theorem ok440 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t440 440 = true := (Snake9.LratV3.andB_eq_true warm440).2

theorem warm441 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 156) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t441 441) = true := by
  decide +kernel

theorem ok441 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t441 441 = true := (Snake9.LratV3.andB_eq_true warm441).2

theorem warm442 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t442 442) = true := by
  decide +kernel

theorem ok442 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t442 442 = true := (Snake9.LratV3.andB_eq_true warm442).2

theorem warm443 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t443 443) = true := by
  decide +kernel

theorem ok443 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t443 443 = true := (Snake9.LratV3.andB_eq_true warm443).2

theorem warm444 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t444 444) = true := by
  decide +kernel

theorem ok444 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t444 444 = true := (Snake9.LratV3.andB_eq_true warm444).2

theorem warm445 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t445 445) = true := by
  decide +kernel

theorem ok445 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t445 445 = true := (Snake9.LratV3.andB_eq_true warm445).2

theorem warm446 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t446 446) = true := by
  decide +kernel

theorem ok446 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t446 446 = true := (Snake9.LratV3.andB_eq_true warm446).2

theorem warm447 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t447 447) = true := by
  decide +kernel

theorem ok447 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t447 447 = true := (Snake9.LratV3.andB_eq_true warm447).2

theorem warm448 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t448 448) = true := by
  decide +kernel

theorem ok448 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t448 448 = true := (Snake9.LratV3.andB_eq_true warm448).2

theorem warm449 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t449 449) = true := by
  decide +kernel

theorem ok449 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t449 449 = true := (Snake9.LratV3.andB_eq_true warm449).2

theorem warm450 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t450 450) = true := by
  decide +kernel

theorem ok450 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t450 450 = true := (Snake9.LratV3.andB_eq_true warm450).2

theorem warm451 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t451 451) = true := by
  decide +kernel

theorem ok451 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t451 451 = true := (Snake9.LratV3.andB_eq_true warm451).2

theorem warm452 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t452 452) = true := by
  decide +kernel

theorem ok452 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t452 452 = true := (Snake9.LratV3.andB_eq_true warm452).2

theorem warm453 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t453 453) = true := by
  decide +kernel

theorem ok453 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t453 453 = true := (Snake9.LratV3.andB_eq_true warm453).2

theorem warm454 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 300) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t454 454) = true := by
  decide +kernel

theorem ok454 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t454 454 = true := (Snake9.LratV3.andB_eq_true warm454).2

theorem warm455 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t455 455) = true := by
  decide +kernel

theorem ok455 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t455 455 = true := (Snake9.LratV3.andB_eq_true warm455).2

theorem warm456 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t456 456) = true := by
  decide +kernel

theorem ok456 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t456 456 = true := (Snake9.LratV3.andB_eq_true warm456).2

theorem warm457 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t457 457) = true := by
  decide +kernel

theorem ok457 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t457 457 = true := (Snake9.LratV3.andB_eq_true warm457).2

theorem warm458 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t458 458) = true := by
  decide +kernel

theorem ok458 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t458 458 = true := (Snake9.LratV3.andB_eq_true warm458).2

theorem warm459 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 300) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t459 459) = true := by
  decide +kernel

theorem ok459 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t459 459 = true := (Snake9.LratV3.andB_eq_true warm459).2

theorem warm460 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t460 460) = true := by
  decide +kernel

theorem ok460 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t460 460 = true := (Snake9.LratV3.andB_eq_true warm460).2

theorem warm461 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 125) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t461 461) = true := by
  decide +kernel

theorem ok461 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t461 461 = true := (Snake9.LratV3.andB_eq_true warm461).2

theorem warm462 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t462 462) = true := by
  decide +kernel

theorem ok462 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t462 462 = true := (Snake9.LratV3.andB_eq_true warm462).2

theorem warm463 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t463 463) = true := by
  decide +kernel

theorem ok463 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t463 463 = true := (Snake9.LratV3.andB_eq_true warm463).2

theorem warm464 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t464 464) = true := by
  decide +kernel

theorem ok464 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t464 464 = true := (Snake9.LratV3.andB_eq_true warm464).2

theorem warm465 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 300) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t465 465) = true := by
  decide +kernel

theorem ok465 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t465 465 = true := (Snake9.LratV3.andB_eq_true warm465).2

theorem warm466 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t466 466) = true := by
  decide +kernel

theorem ok466 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t466 466 = true := (Snake9.LratV3.andB_eq_true warm466).2

theorem warm467 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t467 467) = true := by
  decide +kernel

theorem ok467 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t467 467 = true := (Snake9.LratV3.andB_eq_true warm467).2

theorem warm468 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t468 468) = true := by
  decide +kernel

theorem ok468 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t468 468 = true := (Snake9.LratV3.andB_eq_true warm468).2

theorem warm469 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t469 469) = true := by
  decide +kernel

theorem ok469 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t469 469 = true := (Snake9.LratV3.andB_eq_true warm469).2

theorem warm470 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t470 470) = true := by
  decide +kernel

theorem ok470 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t470 470 = true := (Snake9.LratV3.andB_eq_true warm470).2

theorem warm471 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 96) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t471 471) = true := by
  decide +kernel

theorem ok471 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t471 471 = true := (Snake9.LratV3.andB_eq_true warm471).2

theorem warm472 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 96) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t472 472) = true := by
  decide +kernel

theorem ok472 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t472 472 = true := (Snake9.LratV3.andB_eq_true warm472).2

theorem warm473 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t473 473) = true := by
  decide +kernel

theorem ok473 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t473 473 = true := (Snake9.LratV3.andB_eq_true warm473).2

theorem warm474 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 156) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t474 474) = true := by
  decide +kernel

theorem ok474 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t474 474 = true := (Snake9.LratV3.andB_eq_true warm474).2

theorem warm475 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 32) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t475 475) = true := by
  decide +kernel

theorem ok475 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t475 475 = true := (Snake9.LratV3.andB_eq_true warm475).2

theorem warm476 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 156) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (true))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t476 476) = true := by
  decide +kernel

theorem ok476 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t476 476 = true := (Snake9.LratV3.andB_eq_true warm476).2

theorem warm477 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 252) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 300) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t477 477) = true := by
  decide +kernel

theorem ok477 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t477 477 = true := (Snake9.LratV3.andB_eq_true warm477).2

theorem warm478 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))
    (Snake9.LratV3.check 3000 14 16383 8192 raw Ps t478 478) = true := by
  decide +kernel

theorem ok478 : Snake9.LratV3.check 3000 14 16383 8192 raw Ps t478 478 = true := (Snake9.LratV3.andB_eq_true warm478).2

end Snake9.LocalWindow.V012310A44444
