module

-- LocalWindowCertSplit.V01230243A6445456: kernel checks of segments 124..165 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V01230243A6445456.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V01230243A6445456

theorem warm124 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t124 124) = true := by
  decide +kernel

theorem ok124 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t124 124 = true := (Snake9.LratV3.andB_eq_true warm124).2

theorem warm125 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t125 125) = true := by
  decide +kernel

theorem ok125 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t125 125 = true := (Snake9.LratV3.andB_eq_true warm125).2

theorem warm126 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t126 126) = true := by
  decide +kernel

theorem ok126 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t126 126 = true := (Snake9.LratV3.andB_eq_true warm126).2

theorem warm127 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t127 127) = true := by
  decide +kernel

theorem ok127 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t127 127 = true := (Snake9.LratV3.andB_eq_true warm127).2

theorem warm128 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t128 128) = true := by
  decide +kernel

theorem ok128 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t128 128 = true := (Snake9.LratV3.andB_eq_true warm128).2

theorem warm129 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t129 129) = true := by
  decide +kernel

theorem ok129 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t129 129 = true := (Snake9.LratV3.andB_eq_true warm129).2

theorem warm130 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t130 130) = true := by
  decide +kernel

theorem ok130 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t130 130 = true := (Snake9.LratV3.andB_eq_true warm130).2

theorem warm131 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t131 131) = true := by
  decide +kernel

theorem ok131 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t131 131 = true := (Snake9.LratV3.andB_eq_true warm131).2

theorem warm132 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t132 132) = true := by
  decide +kernel

theorem ok132 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t132 132 = true := (Snake9.LratV3.andB_eq_true warm132).2

theorem warm133 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t133 133) = true := by
  decide +kernel

theorem ok133 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t133 133 = true := (Snake9.LratV3.andB_eq_true warm133).2

theorem warm134 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t134 134) = true := by
  decide +kernel

theorem ok134 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t134 134 = true := (Snake9.LratV3.andB_eq_true warm134).2

theorem warm135 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t135 135) = true := by
  decide +kernel

theorem ok135 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t135 135 = true := (Snake9.LratV3.andB_eq_true warm135).2

theorem warm136 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t136 136) = true := by
  decide +kernel

theorem ok136 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t136 136 = true := (Snake9.LratV3.andB_eq_true warm136).2

theorem warm137 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t137 137) = true := by
  decide +kernel

theorem ok137 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t137 137 = true := (Snake9.LratV3.andB_eq_true warm137).2

theorem warm138 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t138 138) = true := by
  decide +kernel

theorem ok138 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t138 138 = true := (Snake9.LratV3.andB_eq_true warm138).2

theorem warm139 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t139 139) = true := by
  decide +kernel

theorem ok139 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t139 139 = true := (Snake9.LratV3.andB_eq_true warm139).2

theorem warm140 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t140 140) = true := by
  decide +kernel

theorem ok140 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t140 140 = true := (Snake9.LratV3.andB_eq_true warm140).2

theorem warm141 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t141 141) = true := by
  decide +kernel

theorem ok141 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t141 141 = true := (Snake9.LratV3.andB_eq_true warm141).2

theorem warm142 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t142 142) = true := by
  decide +kernel

theorem ok142 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t142 142 = true := (Snake9.LratV3.andB_eq_true warm142).2

theorem warm143 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t143 143) = true := by
  decide +kernel

theorem ok143 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t143 143 = true := (Snake9.LratV3.andB_eq_true warm143).2

theorem warm144 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t144 144) = true := by
  decide +kernel

theorem ok144 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t144 144 = true := (Snake9.LratV3.andB_eq_true warm144).2

theorem warm145 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t145 145) = true := by
  decide +kernel

theorem ok145 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t145 145 = true := (Snake9.LratV3.andB_eq_true warm145).2

theorem warm146 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t146 146) = true := by
  decide +kernel

theorem ok146 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t146 146 = true := (Snake9.LratV3.andB_eq_true warm146).2

theorem warm147 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t147 147) = true := by
  decide +kernel

theorem ok147 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t147 147 = true := (Snake9.LratV3.andB_eq_true warm147).2

theorem warm148 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t148 148) = true := by
  decide +kernel

theorem ok148 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t148 148 = true := (Snake9.LratV3.andB_eq_true warm148).2

theorem warm149 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t149 149) = true := by
  decide +kernel

theorem ok149 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t149 149 = true := (Snake9.LratV3.andB_eq_true warm149).2

theorem warm150 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t150 150) = true := by
  decide +kernel

theorem ok150 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t150 150 = true := (Snake9.LratV3.andB_eq_true warm150).2

theorem warm151 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t151 151) = true := by
  decide +kernel

theorem ok151 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t151 151 = true := (Snake9.LratV3.andB_eq_true warm151).2

theorem warm152 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t152 152) = true := by
  decide +kernel

theorem ok152 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t152 152 = true := (Snake9.LratV3.andB_eq_true warm152).2

theorem warm153 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t153 153) = true := by
  decide +kernel

theorem ok153 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t153 153 = true := (Snake9.LratV3.andB_eq_true warm153).2

theorem warm154 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t154 154) = true := by
  decide +kernel

theorem ok154 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t154 154 = true := (Snake9.LratV3.andB_eq_true warm154).2

theorem warm155 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t155 155) = true := by
  decide +kernel

theorem ok155 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t155 155 = true := (Snake9.LratV3.andB_eq_true warm155).2

theorem warm156 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t156 156) = true := by
  decide +kernel

theorem ok156 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t156 156 = true := (Snake9.LratV3.andB_eq_true warm156).2

theorem warm157 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t157 157) = true := by
  decide +kernel

theorem ok157 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t157 157 = true := (Snake9.LratV3.andB_eq_true warm157).2

theorem warm158 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t158 158) = true := by
  decide +kernel

theorem ok158 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t158 158 = true := (Snake9.LratV3.andB_eq_true warm158).2

theorem warm159 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t159 159) = true := by
  decide +kernel

theorem ok159 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t159 159 = true := (Snake9.LratV3.andB_eq_true warm159).2

theorem warm160 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t160 160) = true := by
  decide +kernel

theorem ok160 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t160 160 = true := (Snake9.LratV3.andB_eq_true warm160).2

theorem warm161 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t161 161) = true := by
  decide +kernel

theorem ok161 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t161 161 = true := (Snake9.LratV3.andB_eq_true warm161).2

theorem warm162 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t162 162) = true := by
  decide +kernel

theorem ok162 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t162 162 = true := (Snake9.LratV3.andB_eq_true warm162).2

theorem warm163 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t163 163) = true := by
  decide +kernel

theorem ok163 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t163 163 = true := (Snake9.LratV3.andB_eq_true warm163).2

theorem warm164 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t164 164) = true := by
  decide +kernel

theorem ok164 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t164 164 = true := (Snake9.LratV3.andB_eq_true warm164).2

theorem warm165 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t165 165) = true := by
  decide +kernel

theorem ok165 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t165 165 = true := (Snake9.LratV3.andB_eq_true warm165).2

end Snake9.LocalWindow.V01230243A6445456
