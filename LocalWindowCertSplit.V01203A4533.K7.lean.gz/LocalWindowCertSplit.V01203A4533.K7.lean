module

-- LocalWindowCertSplit.V01203A4533: kernel checks of segments 609..706 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V01203A4533.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V01203A4533

theorem warm609 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 105) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t609 609) = true := by
  decide +kernel

theorem ok609 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t609 609 = true := (Snake9.LratV3.andB_eq_true warm609).2

theorem warm610 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t610 610) = true := by
  decide +kernel

theorem ok610 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t610 610 = true := (Snake9.LratV3.andB_eq_true warm610).2

theorem warm611 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t611 611) = true := by
  decide +kernel

theorem ok611 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t611 611 = true := (Snake9.LratV3.andB_eq_true warm611).2

theorem warm612 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t612 612) = true := by
  decide +kernel

theorem ok612 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t612 612 = true := (Snake9.LratV3.andB_eq_true warm612).2

theorem warm613 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t613 613) = true := by
  decide +kernel

theorem ok613 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t613 613 = true := (Snake9.LratV3.andB_eq_true warm613).2

theorem warm614 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t614 614) = true := by
  decide +kernel

theorem ok614 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t614 614 = true := (Snake9.LratV3.andB_eq_true warm614).2

theorem warm615 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t615 615) = true := by
  decide +kernel

theorem ok615 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t615 615 = true := (Snake9.LratV3.andB_eq_true warm615).2

theorem warm616 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 105) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t616 616) = true := by
  decide +kernel

theorem ok616 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t616 616 = true := (Snake9.LratV3.andB_eq_true warm616).2

theorem warm617 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t617 617) = true := by
  decide +kernel

theorem ok617 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t617 617 = true := (Snake9.LratV3.andB_eq_true warm617).2

theorem warm618 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t618 618) = true := by
  decide +kernel

theorem ok618 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t618 618 = true := (Snake9.LratV3.andB_eq_true warm618).2

theorem warm619 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t619 619) = true := by
  decide +kernel

theorem ok619 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t619 619 = true := (Snake9.LratV3.andB_eq_true warm619).2

theorem warm620 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t620 620) = true := by
  decide +kernel

theorem ok620 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t620 620 = true := (Snake9.LratV3.andB_eq_true warm620).2

theorem warm621 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t621 621) = true := by
  decide +kernel

theorem ok621 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t621 621 = true := (Snake9.LratV3.andB_eq_true warm621).2

theorem warm622 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t622 622) = true := by
  decide +kernel

theorem ok622 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t622 622 = true := (Snake9.LratV3.andB_eq_true warm622).2

theorem warm623 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t623 623) = true := by
  decide +kernel

theorem ok623 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t623 623 = true := (Snake9.LratV3.andB_eq_true warm623).2

theorem warm624 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t624 624) = true := by
  decide +kernel

theorem ok624 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t624 624 = true := (Snake9.LratV3.andB_eq_true warm624).2

theorem warm625 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t625 625) = true := by
  decide +kernel

theorem ok625 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t625 625 = true := (Snake9.LratV3.andB_eq_true warm625).2

theorem warm626 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 105) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t626 626) = true := by
  decide +kernel

theorem ok626 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t626 626 = true := (Snake9.LratV3.andB_eq_true warm626).2

theorem warm627 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t627 627) = true := by
  decide +kernel

theorem ok627 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t627 627 = true := (Snake9.LratV3.andB_eq_true warm627).2

theorem warm628 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t628 628) = true := by
  decide +kernel

theorem ok628 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t628 628 = true := (Snake9.LratV3.andB_eq_true warm628).2

theorem warm629 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 627) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t629 629) = true := by
  decide +kernel

theorem ok629 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t629 629 = true := (Snake9.LratV3.andB_eq_true warm629).2

theorem warm630 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t630 630) = true := by
  decide +kernel

theorem ok630 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t630 630 = true := (Snake9.LratV3.andB_eq_true warm630).2

theorem warm631 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 105) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t631 631) = true := by
  decide +kernel

theorem ok631 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t631 631 = true := (Snake9.LratV3.andB_eq_true warm631).2

theorem warm632 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 105) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t632 632) = true := by
  decide +kernel

theorem ok632 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t632 632 = true := (Snake9.LratV3.andB_eq_true warm632).2

theorem warm633 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 627) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t633 633) = true := by
  decide +kernel

theorem ok633 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t633 633 = true := (Snake9.LratV3.andB_eq_true warm633).2

theorem warm634 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t634 634) = true := by
  decide +kernel

theorem ok634 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t634 634 = true := (Snake9.LratV3.andB_eq_true warm634).2

theorem warm635 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t635 635) = true := by
  decide +kernel

theorem ok635 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t635 635 = true := (Snake9.LratV3.andB_eq_true warm635).2

theorem warm636 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t636 636) = true := by
  decide +kernel

theorem ok636 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t636 636 = true := (Snake9.LratV3.andB_eq_true warm636).2

theorem warm637 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 105) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t637 637) = true := by
  decide +kernel

theorem ok637 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t637 637 = true := (Snake9.LratV3.andB_eq_true warm637).2

theorem warm638 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t638 638) = true := by
  decide +kernel

theorem ok638 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t638 638 = true := (Snake9.LratV3.andB_eq_true warm638).2

theorem warm639 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 627) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t639 639) = true := by
  decide +kernel

theorem ok639 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t639 639 = true := (Snake9.LratV3.andB_eq_true warm639).2

theorem warm640 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 105) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t640 640) = true := by
  decide +kernel

theorem ok640 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t640 640 = true := (Snake9.LratV3.andB_eq_true warm640).2

theorem warm641 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t641 641) = true := by
  decide +kernel

theorem ok641 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t641 641 = true := (Snake9.LratV3.andB_eq_true warm641).2

theorem warm642 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t642 642) = true := by
  decide +kernel

theorem ok642 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t642 642 = true := (Snake9.LratV3.andB_eq_true warm642).2

theorem warm643 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t643 643) = true := by
  decide +kernel

theorem ok643 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t643 643 = true := (Snake9.LratV3.andB_eq_true warm643).2

theorem warm644 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t644 644) = true := by
  decide +kernel

theorem ok644 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t644 644 = true := (Snake9.LratV3.andB_eq_true warm644).2

theorem warm645 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t645 645) = true := by
  decide +kernel

theorem ok645 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t645 645 = true := (Snake9.LratV3.andB_eq_true warm645).2

theorem warm646 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t646 646) = true := by
  decide +kernel

theorem ok646 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t646 646 = true := (Snake9.LratV3.andB_eq_true warm646).2

theorem warm647 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t647 647) = true := by
  decide +kernel

theorem ok647 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t647 647 = true := (Snake9.LratV3.andB_eq_true warm647).2

theorem warm648 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t648 648) = true := by
  decide +kernel

theorem ok648 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t648 648 = true := (Snake9.LratV3.andB_eq_true warm648).2

theorem warm649 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 648) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t649 649) = true := by
  decide +kernel

theorem ok649 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t649 649 = true := (Snake9.LratV3.andB_eq_true warm649).2

theorem warm650 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 627) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 648) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t650 650) = true := by
  decide +kernel

theorem ok650 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t650 650 = true := (Snake9.LratV3.andB_eq_true warm650).2

theorem warm651 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t651 651) = true := by
  decide +kernel

theorem ok651 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t651 651 = true := (Snake9.LratV3.andB_eq_true warm651).2

theorem warm652 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 307) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t652 652) = true := by
  decide +kernel

theorem ok652 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t652 652 = true := (Snake9.LratV3.andB_eq_true warm652).2

theorem warm653 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t653 653) = true := by
  decide +kernel

theorem ok653 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t653 653 = true := (Snake9.LratV3.andB_eq_true warm653).2

theorem warm654 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t654 654) = true := by
  decide +kernel

theorem ok654 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t654 654 = true := (Snake9.LratV3.andB_eq_true warm654).2

theorem warm655 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t655 655) = true := by
  decide +kernel

theorem ok655 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t655 655 = true := (Snake9.LratV3.andB_eq_true warm655).2

theorem warm656 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t656 656) = true := by
  decide +kernel

theorem ok656 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t656 656 = true := (Snake9.LratV3.andB_eq_true warm656).2

theorem warm657 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t657 657) = true := by
  decide +kernel

theorem ok657 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t657 657 = true := (Snake9.LratV3.andB_eq_true warm657).2

theorem warm658 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t658 658) = true := by
  decide +kernel

theorem ok658 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t658 658 = true := (Snake9.LratV3.andB_eq_true warm658).2

theorem warm659 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t659 659) = true := by
  decide +kernel

theorem ok659 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t659 659 = true := (Snake9.LratV3.andB_eq_true warm659).2

theorem warm660 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t660 660) = true := by
  decide +kernel

theorem ok660 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t660 660 = true := (Snake9.LratV3.andB_eq_true warm660).2

theorem warm661 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t661 661) = true := by
  decide +kernel

theorem ok661 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t661 661 = true := (Snake9.LratV3.andB_eq_true warm661).2

theorem warm662 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t662 662) = true := by
  decide +kernel

theorem ok662 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t662 662 = true := (Snake9.LratV3.andB_eq_true warm662).2

theorem warm663 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t663 663) = true := by
  decide +kernel

theorem ok663 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t663 663 = true := (Snake9.LratV3.andB_eq_true warm663).2

theorem warm664 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t664 664) = true := by
  decide +kernel

theorem ok664 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t664 664 = true := (Snake9.LratV3.andB_eq_true warm664).2

theorem warm665 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 627) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t665 665) = true := by
  decide +kernel

theorem ok665 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t665 665 = true := (Snake9.LratV3.andB_eq_true warm665).2

theorem warm666 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t666 666) = true := by
  decide +kernel

theorem ok666 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t666 666 = true := (Snake9.LratV3.andB_eq_true warm666).2

theorem warm667 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t667 667) = true := by
  decide +kernel

theorem ok667 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t667 667 = true := (Snake9.LratV3.andB_eq_true warm667).2

theorem warm668 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t668 668) = true := by
  decide +kernel

theorem ok668 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t668 668 = true := (Snake9.LratV3.andB_eq_true warm668).2

theorem warm669 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t669 669) = true := by
  decide +kernel

theorem ok669 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t669 669 = true := (Snake9.LratV3.andB_eq_true warm669).2

theorem warm670 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t670 670) = true := by
  decide +kernel

theorem ok670 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t670 670 = true := (Snake9.LratV3.andB_eq_true warm670).2

theorem warm671 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t671 671) = true := by
  decide +kernel

theorem ok671 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t671 671 = true := (Snake9.LratV3.andB_eq_true warm671).2

theorem warm672 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t672 672) = true := by
  decide +kernel

theorem ok672 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t672 672 = true := (Snake9.LratV3.andB_eq_true warm672).2

theorem warm673 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t673 673) = true := by
  decide +kernel

theorem ok673 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t673 673 = true := (Snake9.LratV3.andB_eq_true warm673).2

theorem warm674 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t674 674) = true := by
  decide +kernel

theorem ok674 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t674 674 = true := (Snake9.LratV3.andB_eq_true warm674).2

theorem warm675 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t675 675) = true := by
  decide +kernel

theorem ok675 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t675 675 = true := (Snake9.LratV3.andB_eq_true warm675).2

theorem warm676 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t676 676) = true := by
  decide +kernel

theorem ok676 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t676 676 = true := (Snake9.LratV3.andB_eq_true warm676).2

theorem warm677 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t677 677) = true := by
  decide +kernel

theorem ok677 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t677 677 = true := (Snake9.LratV3.andB_eq_true warm677).2

theorem warm678 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t678 678) = true := by
  decide +kernel

theorem ok678 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t678 678 = true := (Snake9.LratV3.andB_eq_true warm678).2

theorem warm679 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 238) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t679 679) = true := by
  decide +kernel

theorem ok679 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t679 679 = true := (Snake9.LratV3.andB_eq_true warm679).2

theorem warm680 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t680 680) = true := by
  decide +kernel

theorem ok680 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t680 680 = true := (Snake9.LratV3.andB_eq_true warm680).2

theorem warm681 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t681 681) = true := by
  decide +kernel

theorem ok681 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t681 681 = true := (Snake9.LratV3.andB_eq_true warm681).2

theorem warm682 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 680) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t682 682) = true := by
  decide +kernel

theorem ok682 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t682 682 = true := (Snake9.LratV3.andB_eq_true warm682).2

theorem warm683 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 680) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t683 683) = true := by
  decide +kernel

theorem ok683 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t683 683 = true := (Snake9.LratV3.andB_eq_true warm683).2

theorem warm684 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t684 684) = true := by
  decide +kernel

theorem ok684 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t684 684 = true := (Snake9.LratV3.andB_eq_true warm684).2

theorem warm685 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t685 685) = true := by
  decide +kernel

theorem ok685 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t685 685 = true := (Snake9.LratV3.andB_eq_true warm685).2

theorem warm686 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t686 686) = true := by
  decide +kernel

theorem ok686 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t686 686 = true := (Snake9.LratV3.andB_eq_true warm686).2

theorem warm687 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 680) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t687 687) = true := by
  decide +kernel

theorem ok687 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t687 687 = true := (Snake9.LratV3.andB_eq_true warm687).2

theorem warm688 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t688 688) = true := by
  decide +kernel

theorem ok688 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t688 688 = true := (Snake9.LratV3.andB_eq_true warm688).2

theorem warm689 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t689 689) = true := by
  decide +kernel

theorem ok689 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t689 689 = true := (Snake9.LratV3.andB_eq_true warm689).2

theorem warm690 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t690 690) = true := by
  decide +kernel

theorem ok690 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t690 690 = true := (Snake9.LratV3.andB_eq_true warm690).2

theorem warm691 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t691 691) = true := by
  decide +kernel

theorem ok691 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t691 691 = true := (Snake9.LratV3.andB_eq_true warm691).2

theorem warm692 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t692 692) = true := by
  decide +kernel

theorem ok692 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t692 692 = true := (Snake9.LratV3.andB_eq_true warm692).2

theorem warm693 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t693 693) = true := by
  decide +kernel

theorem ok693 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t693 693 = true := (Snake9.LratV3.andB_eq_true warm693).2

theorem warm694 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t694 694) = true := by
  decide +kernel

theorem ok694 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t694 694 = true := (Snake9.LratV3.andB_eq_true warm694).2

theorem warm695 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t695 695) = true := by
  decide +kernel

theorem ok695 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t695 695 = true := (Snake9.LratV3.andB_eq_true warm695).2

theorem warm696 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t696 696) = true := by
  decide +kernel

theorem ok696 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t696 696 = true := (Snake9.LratV3.andB_eq_true warm696).2

theorem warm697 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t697 697) = true := by
  decide +kernel

theorem ok697 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t697 697 = true := (Snake9.LratV3.andB_eq_true warm697).2

theorem warm698 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 307) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t698 698) = true := by
  decide +kernel

theorem ok698 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t698 698 = true := (Snake9.LratV3.andB_eq_true warm698).2

theorem warm699 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t699 699) = true := by
  decide +kernel

theorem ok699 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t699 699 = true := (Snake9.LratV3.andB_eq_true warm699).2

theorem warm700 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t700 700) = true := by
  decide +kernel

theorem ok700 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t700 700 = true := (Snake9.LratV3.andB_eq_true warm700).2

theorem warm701 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 648) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t701 701) = true := by
  decide +kernel

theorem ok701 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t701 701 = true := (Snake9.LratV3.andB_eq_true warm701).2

theorem warm702 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t702 702) = true := by
  decide +kernel

theorem ok702 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t702 702 = true := (Snake9.LratV3.andB_eq_true warm702).2

theorem warm703 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 652) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t703 703) = true := by
  decide +kernel

theorem ok703 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t703 703 = true := (Snake9.LratV3.andB_eq_true warm703).2

theorem warm704 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t704 704) = true := by
  decide +kernel

theorem ok704 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t704 704 = true := (Snake9.LratV3.andB_eq_true warm704).2

theorem warm705 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 610) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t705 705) = true := by
  decide +kernel

theorem ok705 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t705 705 = true := (Snake9.LratV3.andB_eq_true warm705).2

theorem warm706 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 185) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 355) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 595) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 687) 2048)) true)
    (true)))))))
    (Snake9.LratV3.andB (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t706 706) (Snake9.LratV3.hasEmpty 14 16383 (Snake9.LratV3.segP Ps 706))) = true := by
  decide +kernel

theorem ok706 : Snake9.LratV3.andB (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t706 706) (Snake9.LratV3.hasEmpty 14 16383 (Snake9.LratV3.segP Ps 706)) = true := (Snake9.LratV3.andB_eq_true warm706).2

end Snake9.LocalWindow.V01203A4533
