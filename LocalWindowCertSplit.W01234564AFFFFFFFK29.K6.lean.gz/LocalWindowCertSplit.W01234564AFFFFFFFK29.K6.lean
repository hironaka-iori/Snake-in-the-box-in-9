module

-- LocalWindowCertSplit.W01234564AFFFFFFFK29: kernel checks of segments 188..218 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.W01234564AFFFFFFFK29.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.W01234564AFFFFFFFK29

theorem warm188 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t188 188) = true := by
  decide +kernel

theorem ok188 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t188 188 = true := (Snake9.LratV3.andB_eq_true warm188).2

theorem warm189 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t189 189) = true := by
  decide +kernel

theorem ok189 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t189 189 = true := (Snake9.LratV3.andB_eq_true warm189).2

theorem warm190 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t190 190) = true := by
  decide +kernel

theorem ok190 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t190 190 = true := (Snake9.LratV3.andB_eq_true warm190).2

theorem warm191 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t191 191) = true := by
  decide +kernel

theorem ok191 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t191 191 = true := (Snake9.LratV3.andB_eq_true warm191).2

theorem warm192 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t192 192) = true := by
  decide +kernel

theorem ok192 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t192 192 = true := (Snake9.LratV3.andB_eq_true warm192).2

theorem warm193 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t193 193) = true := by
  decide +kernel

theorem ok193 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t193 193 = true := (Snake9.LratV3.andB_eq_true warm193).2

theorem warm194 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t194 194) = true := by
  decide +kernel

theorem ok194 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t194 194 = true := (Snake9.LratV3.andB_eq_true warm194).2

theorem warm195 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t195 195) = true := by
  decide +kernel

theorem ok195 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t195 195 = true := (Snake9.LratV3.andB_eq_true warm195).2

theorem warm196 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t196 196) = true := by
  decide +kernel

theorem ok196 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t196 196 = true := (Snake9.LratV3.andB_eq_true warm196).2

theorem warm197 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t197 197) = true := by
  decide +kernel

theorem ok197 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t197 197 = true := (Snake9.LratV3.andB_eq_true warm197).2

theorem warm198 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 180) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t198 198) = true := by
  decide +kernel

theorem ok198 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t198 198 = true := (Snake9.LratV3.andB_eq_true warm198).2

theorem warm199 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t199 199) = true := by
  decide +kernel

theorem ok199 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t199 199 = true := (Snake9.LratV3.andB_eq_true warm199).2

theorem warm200 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t200 200) = true := by
  decide +kernel

theorem ok200 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t200 200 = true := (Snake9.LratV3.andB_eq_true warm200).2

theorem warm201 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t201 201) = true := by
  decide +kernel

theorem ok201 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t201 201 = true := (Snake9.LratV3.andB_eq_true warm201).2

theorem warm202 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t202 202) = true := by
  decide +kernel

theorem ok202 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t202 202 = true := (Snake9.LratV3.andB_eq_true warm202).2

theorem warm203 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t203 203) = true := by
  decide +kernel

theorem ok203 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t203 203 = true := (Snake9.LratV3.andB_eq_true warm203).2

theorem warm204 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t204 204) = true := by
  decide +kernel

theorem ok204 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t204 204 = true := (Snake9.LratV3.andB_eq_true warm204).2

theorem warm205 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t205 205) = true := by
  decide +kernel

theorem ok205 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t205 205 = true := (Snake9.LratV3.andB_eq_true warm205).2

theorem warm206 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t206 206) = true := by
  decide +kernel

theorem ok206 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t206 206 = true := (Snake9.LratV3.andB_eq_true warm206).2

theorem warm207 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t207 207) = true := by
  decide +kernel

theorem ok207 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t207 207 = true := (Snake9.LratV3.andB_eq_true warm207).2

theorem warm208 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t208 208) = true := by
  decide +kernel

theorem ok208 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t208 208 = true := (Snake9.LratV3.andB_eq_true warm208).2

theorem warm209 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t209 209) = true := by
  decide +kernel

theorem ok209 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t209 209 = true := (Snake9.LratV3.andB_eq_true warm209).2

theorem warm210 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t210 210) = true := by
  decide +kernel

theorem ok210 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t210 210 = true := (Snake9.LratV3.andB_eq_true warm210).2

theorem warm211 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t211 211) = true := by
  decide +kernel

theorem ok211 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t211 211 = true := (Snake9.LratV3.andB_eq_true warm211).2

theorem warm212 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 211) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t212 212) = true := by
  decide +kernel

theorem ok212 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t212 212 = true := (Snake9.LratV3.andB_eq_true warm212).2

theorem warm213 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t213 213) = true := by
  decide +kernel

theorem ok213 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t213 213 = true := (Snake9.LratV3.andB_eq_true warm213).2

theorem warm214 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t214 214) = true := by
  decide +kernel

theorem ok214 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t214 214 = true := (Snake9.LratV3.andB_eq_true warm214).2

theorem warm215 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t215 215) = true := by
  decide +kernel

theorem ok215 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t215 215 = true := (Snake9.LratV3.andB_eq_true warm215).2

theorem warm216 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 81) 2048)) true)
    (true)))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t216 216) = true := by
  decide +kernel

theorem ok216 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t216 216 = true := (Snake9.LratV3.andB_eq_true warm216).2

theorem warm217 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 211) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t217 217) = true := by
  decide +kernel

theorem ok217 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t217 217 = true := (Snake9.LratV3.andB_eq_true warm217).2

theorem warm218 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t218 218) = true := by
  decide +kernel

theorem ok218 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t218 218 = true := (Snake9.LratV3.andB_eq_true warm218).2

end Snake9.LocalWindow.W01234564AFFFFFFFK29
