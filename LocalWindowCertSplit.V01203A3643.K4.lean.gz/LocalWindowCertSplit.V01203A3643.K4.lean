module

-- LocalWindowCertSplit.V01203A3643: kernel checks of segments 530..662 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V01203A3643.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V01203A3643

theorem warm530 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t530 530) = true := by
  decide +kernel

theorem ok530 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t530 530 = true := (Snake9.LratV3.andB_eq_true warm530).2

theorem warm531 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t531 531) = true := by
  decide +kernel

theorem ok531 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t531 531 = true := (Snake9.LratV3.andB_eq_true warm531).2

theorem warm532 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t532 532) = true := by
  decide +kernel

theorem ok532 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t532 532 = true := (Snake9.LratV3.andB_eq_true warm532).2

theorem warm533 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t533 533) = true := by
  decide +kernel

theorem ok533 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t533 533 = true := (Snake9.LratV3.andB_eq_true warm533).2

theorem warm534 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t534 534) = true := by
  decide +kernel

theorem ok534 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t534 534 = true := (Snake9.LratV3.andB_eq_true warm534).2

theorem warm535 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t535 535) = true := by
  decide +kernel

theorem ok535 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t535 535 = true := (Snake9.LratV3.andB_eq_true warm535).2

theorem warm536 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t536 536) = true := by
  decide +kernel

theorem ok536 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t536 536 = true := (Snake9.LratV3.andB_eq_true warm536).2

theorem warm537 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t537 537) = true := by
  decide +kernel

theorem ok537 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t537 537 = true := (Snake9.LratV3.andB_eq_true warm537).2

theorem warm538 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t538 538) = true := by
  decide +kernel

theorem ok538 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t538 538 = true := (Snake9.LratV3.andB_eq_true warm538).2

theorem warm539 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t539 539) = true := by
  decide +kernel

theorem ok539 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t539 539 = true := (Snake9.LratV3.andB_eq_true warm539).2

theorem warm540 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t540 540) = true := by
  decide +kernel

theorem ok540 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t540 540 = true := (Snake9.LratV3.andB_eq_true warm540).2

theorem warm541 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t541 541) = true := by
  decide +kernel

theorem ok541 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t541 541 = true := (Snake9.LratV3.andB_eq_true warm541).2

theorem warm542 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t542 542) = true := by
  decide +kernel

theorem ok542 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t542 542 = true := (Snake9.LratV3.andB_eq_true warm542).2

theorem warm543 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t543 543) = true := by
  decide +kernel

theorem ok543 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t543 543 = true := (Snake9.LratV3.andB_eq_true warm543).2

theorem warm544 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t544 544) = true := by
  decide +kernel

theorem ok544 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t544 544 = true := (Snake9.LratV3.andB_eq_true warm544).2

theorem warm545 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t545 545) = true := by
  decide +kernel

theorem ok545 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t545 545 = true := (Snake9.LratV3.andB_eq_true warm545).2

theorem warm546 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t546 546) = true := by
  decide +kernel

theorem ok546 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t546 546 = true := (Snake9.LratV3.andB_eq_true warm546).2

theorem warm547 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t547 547) = true := by
  decide +kernel

theorem ok547 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t547 547 = true := (Snake9.LratV3.andB_eq_true warm547).2

theorem warm548 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t548 548) = true := by
  decide +kernel

theorem ok548 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t548 548 = true := (Snake9.LratV3.andB_eq_true warm548).2

theorem warm549 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t549 549) = true := by
  decide +kernel

theorem ok549 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t549 549 = true := (Snake9.LratV3.andB_eq_true warm549).2

theorem warm550 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t550 550) = true := by
  decide +kernel

theorem ok550 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t550 550 = true := (Snake9.LratV3.andB_eq_true warm550).2

theorem warm551 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t551 551) = true := by
  decide +kernel

theorem ok551 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t551 551 = true := (Snake9.LratV3.andB_eq_true warm551).2

theorem warm552 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t552 552) = true := by
  decide +kernel

theorem ok552 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t552 552 = true := (Snake9.LratV3.andB_eq_true warm552).2

theorem warm553 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t553 553) = true := by
  decide +kernel

theorem ok553 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t553 553 = true := (Snake9.LratV3.andB_eq_true warm553).2

theorem warm554 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t554 554) = true := by
  decide +kernel

theorem ok554 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t554 554 = true := (Snake9.LratV3.andB_eq_true warm554).2

theorem warm555 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t555 555) = true := by
  decide +kernel

theorem ok555 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t555 555 = true := (Snake9.LratV3.andB_eq_true warm555).2

theorem warm556 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t556 556) = true := by
  decide +kernel

theorem ok556 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t556 556 = true := (Snake9.LratV3.andB_eq_true warm556).2

theorem warm557 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t557 557) = true := by
  decide +kernel

theorem ok557 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t557 557 = true := (Snake9.LratV3.andB_eq_true warm557).2

theorem warm558 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t558 558) = true := by
  decide +kernel

theorem ok558 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t558 558 = true := (Snake9.LratV3.andB_eq_true warm558).2

theorem warm559 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t559 559) = true := by
  decide +kernel

theorem ok559 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t559 559 = true := (Snake9.LratV3.andB_eq_true warm559).2

theorem warm560 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t560 560) = true := by
  decide +kernel

theorem ok560 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t560 560 = true := (Snake9.LratV3.andB_eq_true warm560).2

theorem warm561 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t561 561) = true := by
  decide +kernel

theorem ok561 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t561 561 = true := (Snake9.LratV3.andB_eq_true warm561).2

theorem warm562 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t562 562) = true := by
  decide +kernel

theorem ok562 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t562 562 = true := (Snake9.LratV3.andB_eq_true warm562).2

theorem warm563 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t563 563) = true := by
  decide +kernel

theorem ok563 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t563 563 = true := (Snake9.LratV3.andB_eq_true warm563).2

theorem warm564 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t564 564) = true := by
  decide +kernel

theorem ok564 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t564 564 = true := (Snake9.LratV3.andB_eq_true warm564).2

theorem warm565 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t565 565) = true := by
  decide +kernel

theorem ok565 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t565 565 = true := (Snake9.LratV3.andB_eq_true warm565).2

theorem warm566 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t566 566) = true := by
  decide +kernel

theorem ok566 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t566 566 = true := (Snake9.LratV3.andB_eq_true warm566).2

theorem warm567 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t567 567) = true := by
  decide +kernel

theorem ok567 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t567 567 = true := (Snake9.LratV3.andB_eq_true warm567).2

theorem warm568 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t568 568) = true := by
  decide +kernel

theorem ok568 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t568 568 = true := (Snake9.LratV3.andB_eq_true warm568).2

theorem warm569 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t569 569) = true := by
  decide +kernel

theorem ok569 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t569 569 = true := (Snake9.LratV3.andB_eq_true warm569).2

theorem warm570 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t570 570) = true := by
  decide +kernel

theorem ok570 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t570 570 = true := (Snake9.LratV3.andB_eq_true warm570).2

theorem warm571 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t571 571) = true := by
  decide +kernel

theorem ok571 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t571 571 = true := (Snake9.LratV3.andB_eq_true warm571).2

theorem warm572 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t572 572) = true := by
  decide +kernel

theorem ok572 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t572 572 = true := (Snake9.LratV3.andB_eq_true warm572).2

theorem warm573 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t573 573) = true := by
  decide +kernel

theorem ok573 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t573 573 = true := (Snake9.LratV3.andB_eq_true warm573).2

theorem warm574 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t574 574) = true := by
  decide +kernel

theorem ok574 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t574 574 = true := (Snake9.LratV3.andB_eq_true warm574).2

theorem warm575 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t575 575) = true := by
  decide +kernel

theorem ok575 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t575 575 = true := (Snake9.LratV3.andB_eq_true warm575).2

theorem warm576 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t576 576) = true := by
  decide +kernel

theorem ok576 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t576 576 = true := (Snake9.LratV3.andB_eq_true warm576).2

theorem ok577 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t577 577 = true := by
  decide +kernel

theorem warm578 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t578 578) = true := by
  decide +kernel

theorem ok578 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t578 578 = true := (Snake9.LratV3.andB_eq_true warm578).2

theorem warm579 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t579 579) = true := by
  decide +kernel

theorem ok579 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t579 579 = true := (Snake9.LratV3.andB_eq_true warm579).2

theorem warm580 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t580 580) = true := by
  decide +kernel

theorem ok580 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t580 580 = true := (Snake9.LratV3.andB_eq_true warm580).2

theorem warm581 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t581 581) = true := by
  decide +kernel

theorem ok581 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t581 581 = true := (Snake9.LratV3.andB_eq_true warm581).2

theorem warm582 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t582 582) = true := by
  decide +kernel

theorem ok582 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t582 582 = true := (Snake9.LratV3.andB_eq_true warm582).2

theorem warm583 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t583 583) = true := by
  decide +kernel

theorem ok583 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t583 583 = true := (Snake9.LratV3.andB_eq_true warm583).2

theorem warm584 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t584 584) = true := by
  decide +kernel

theorem ok584 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t584 584 = true := (Snake9.LratV3.andB_eq_true warm584).2

theorem warm585 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t585 585) = true := by
  decide +kernel

theorem ok585 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t585 585 = true := (Snake9.LratV3.andB_eq_true warm585).2

theorem warm586 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t586 586) = true := by
  decide +kernel

theorem ok586 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t586 586 = true := (Snake9.LratV3.andB_eq_true warm586).2

theorem warm587 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t587 587) = true := by
  decide +kernel

theorem ok587 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t587 587 = true := (Snake9.LratV3.andB_eq_true warm587).2

theorem warm588 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t588 588) = true := by
  decide +kernel

theorem ok588 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t588 588 = true := (Snake9.LratV3.andB_eq_true warm588).2

theorem warm589 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t589 589) = true := by
  decide +kernel

theorem ok589 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t589 589 = true := (Snake9.LratV3.andB_eq_true warm589).2

theorem warm590 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t590 590) = true := by
  decide +kernel

theorem ok590 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t590 590 = true := (Snake9.LratV3.andB_eq_true warm590).2

theorem warm591 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t591 591) = true := by
  decide +kernel

theorem ok591 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t591 591 = true := (Snake9.LratV3.andB_eq_true warm591).2

theorem warm592 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t592 592) = true := by
  decide +kernel

theorem ok592 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t592 592 = true := (Snake9.LratV3.andB_eq_true warm592).2

theorem warm593 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t593 593) = true := by
  decide +kernel

theorem ok593 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t593 593 = true := (Snake9.LratV3.andB_eq_true warm593).2

theorem warm594 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t594 594) = true := by
  decide +kernel

theorem ok594 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t594 594 = true := (Snake9.LratV3.andB_eq_true warm594).2

theorem warm595 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t595 595) = true := by
  decide +kernel

theorem ok595 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t595 595 = true := (Snake9.LratV3.andB_eq_true warm595).2

theorem warm596 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 511) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t596 596) = true := by
  decide +kernel

theorem ok596 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t596 596 = true := (Snake9.LratV3.andB_eq_true warm596).2

theorem warm597 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t597 597) = true := by
  decide +kernel

theorem ok597 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t597 597 = true := (Snake9.LratV3.andB_eq_true warm597).2

theorem warm598 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t598 598) = true := by
  decide +kernel

theorem ok598 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t598 598 = true := (Snake9.LratV3.andB_eq_true warm598).2

theorem warm599 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t599 599) = true := by
  decide +kernel

theorem ok599 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t599 599 = true := (Snake9.LratV3.andB_eq_true warm599).2

theorem warm600 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t600 600) = true := by
  decide +kernel

theorem ok600 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t600 600 = true := (Snake9.LratV3.andB_eq_true warm600).2

theorem warm601 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t601 601) = true := by
  decide +kernel

theorem ok601 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t601 601 = true := (Snake9.LratV3.andB_eq_true warm601).2

theorem warm602 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t602 602) = true := by
  decide +kernel

theorem ok602 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t602 602 = true := (Snake9.LratV3.andB_eq_true warm602).2

theorem warm603 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t603 603) = true := by
  decide +kernel

theorem ok603 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t603 603 = true := (Snake9.LratV3.andB_eq_true warm603).2

theorem warm604 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t604 604) = true := by
  decide +kernel

theorem ok604 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t604 604 = true := (Snake9.LratV3.andB_eq_true warm604).2

theorem warm605 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t605 605) = true := by
  decide +kernel

theorem ok605 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t605 605 = true := (Snake9.LratV3.andB_eq_true warm605).2

theorem warm606 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t606 606) = true := by
  decide +kernel

theorem ok606 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t606 606 = true := (Snake9.LratV3.andB_eq_true warm606).2

theorem ok607 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t607 607 = true := by
  decide +kernel

theorem warm608 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t608 608) = true := by
  decide +kernel

theorem ok608 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t608 608 = true := (Snake9.LratV3.andB_eq_true warm608).2

theorem warm609 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t609 609) = true := by
  decide +kernel

theorem ok609 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t609 609 = true := (Snake9.LratV3.andB_eq_true warm609).2

theorem warm610 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t610 610) = true := by
  decide +kernel

theorem ok610 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t610 610 = true := (Snake9.LratV3.andB_eq_true warm610).2

theorem warm611 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t611 611) = true := by
  decide +kernel

theorem ok611 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t611 611 = true := (Snake9.LratV3.andB_eq_true warm611).2

theorem warm612 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t612 612) = true := by
  decide +kernel

theorem ok612 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t612 612 = true := (Snake9.LratV3.andB_eq_true warm612).2

theorem warm613 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 561) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t613 613) = true := by
  decide +kernel

theorem ok613 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t613 613 = true := (Snake9.LratV3.andB_eq_true warm613).2

theorem warm614 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t614 614) = true := by
  decide +kernel

theorem ok614 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t614 614 = true := (Snake9.LratV3.andB_eq_true warm614).2

theorem warm615 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t615 615) = true := by
  decide +kernel

theorem ok615 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t615 615 = true := (Snake9.LratV3.andB_eq_true warm615).2

theorem warm616 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t616 616) = true := by
  decide +kernel

theorem ok616 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t616 616 = true := (Snake9.LratV3.andB_eq_true warm616).2

theorem warm617 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 561) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t617 617) = true := by
  decide +kernel

theorem ok617 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t617 617 = true := (Snake9.LratV3.andB_eq_true warm617).2

theorem warm618 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t618 618) = true := by
  decide +kernel

theorem ok618 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t618 618 = true := (Snake9.LratV3.andB_eq_true warm618).2

theorem warm619 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t619 619) = true := by
  decide +kernel

theorem ok619 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t619 619 = true := (Snake9.LratV3.andB_eq_true warm619).2

theorem warm620 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t620 620) = true := by
  decide +kernel

theorem ok620 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t620 620 = true := (Snake9.LratV3.andB_eq_true warm620).2

theorem warm621 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t621 621) = true := by
  decide +kernel

theorem ok621 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t621 621 = true := (Snake9.LratV3.andB_eq_true warm621).2

theorem warm622 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t622 622) = true := by
  decide +kernel

theorem ok622 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t622 622 = true := (Snake9.LratV3.andB_eq_true warm622).2

theorem warm623 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t623 623) = true := by
  decide +kernel

theorem ok623 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t623 623 = true := (Snake9.LratV3.andB_eq_true warm623).2

theorem warm624 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t624 624) = true := by
  decide +kernel

theorem ok624 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t624 624 = true := (Snake9.LratV3.andB_eq_true warm624).2

theorem warm625 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t625 625) = true := by
  decide +kernel

theorem ok625 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t625 625 = true := (Snake9.LratV3.andB_eq_true warm625).2

theorem warm626 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 561) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t626 626) = true := by
  decide +kernel

theorem ok626 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t626 626 = true := (Snake9.LratV3.andB_eq_true warm626).2

theorem warm627 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t627 627) = true := by
  decide +kernel

theorem ok627 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t627 627 = true := (Snake9.LratV3.andB_eq_true warm627).2

theorem warm628 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t628 628) = true := by
  decide +kernel

theorem ok628 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t628 628 = true := (Snake9.LratV3.andB_eq_true warm628).2

theorem warm629 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t629 629) = true := by
  decide +kernel

theorem ok629 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t629 629 = true := (Snake9.LratV3.andB_eq_true warm629).2

theorem warm630 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t630 630) = true := by
  decide +kernel

theorem ok630 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t630 630 = true := (Snake9.LratV3.andB_eq_true warm630).2

theorem warm631 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t631 631) = true := by
  decide +kernel

theorem ok631 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t631 631 = true := (Snake9.LratV3.andB_eq_true warm631).2

theorem warm632 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t632 632) = true := by
  decide +kernel

theorem ok632 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t632 632 = true := (Snake9.LratV3.andB_eq_true warm632).2

theorem warm633 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t633 633) = true := by
  decide +kernel

theorem ok633 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t633 633 = true := (Snake9.LratV3.andB_eq_true warm633).2

theorem warm634 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t634 634) = true := by
  decide +kernel

theorem ok634 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t634 634 = true := (Snake9.LratV3.andB_eq_true warm634).2

theorem warm635 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t635 635) = true := by
  decide +kernel

theorem ok635 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t635 635 = true := (Snake9.LratV3.andB_eq_true warm635).2

theorem warm636 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t636 636) = true := by
  decide +kernel

theorem ok636 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t636 636 = true := (Snake9.LratV3.andB_eq_true warm636).2

theorem warm637 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t637 637) = true := by
  decide +kernel

theorem ok637 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t637 637 = true := (Snake9.LratV3.andB_eq_true warm637).2

theorem warm638 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t638 638) = true := by
  decide +kernel

theorem ok638 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t638 638 = true := (Snake9.LratV3.andB_eq_true warm638).2

theorem warm639 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t639 639) = true := by
  decide +kernel

theorem ok639 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t639 639 = true := (Snake9.LratV3.andB_eq_true warm639).2

theorem warm640 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t640 640) = true := by
  decide +kernel

theorem ok640 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t640 640 = true := (Snake9.LratV3.andB_eq_true warm640).2

theorem warm641 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t641 641) = true := by
  decide +kernel

theorem ok641 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t641 641 = true := (Snake9.LratV3.andB_eq_true warm641).2

theorem warm642 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t642 642) = true := by
  decide +kernel

theorem ok642 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t642 642 = true := (Snake9.LratV3.andB_eq_true warm642).2

theorem warm643 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t643 643) = true := by
  decide +kernel

theorem ok643 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t643 643 = true := (Snake9.LratV3.andB_eq_true warm643).2

theorem warm644 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t644 644) = true := by
  decide +kernel

theorem ok644 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t644 644 = true := (Snake9.LratV3.andB_eq_true warm644).2

theorem warm645 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t645 645) = true := by
  decide +kernel

theorem ok645 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t645 645 = true := (Snake9.LratV3.andB_eq_true warm645).2

theorem warm646 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t646 646) = true := by
  decide +kernel

theorem ok646 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t646 646 = true := (Snake9.LratV3.andB_eq_true warm646).2

theorem warm647 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t647 647) = true := by
  decide +kernel

theorem ok647 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t647 647 = true := (Snake9.LratV3.andB_eq_true warm647).2

theorem warm648 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t648 648) = true := by
  decide +kernel

theorem ok648 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t648 648 = true := (Snake9.LratV3.andB_eq_true warm648).2

theorem warm649 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t649 649) = true := by
  decide +kernel

theorem ok649 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t649 649 = true := (Snake9.LratV3.andB_eq_true warm649).2

theorem warm650 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t650 650) = true := by
  decide +kernel

theorem ok650 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t650 650 = true := (Snake9.LratV3.andB_eq_true warm650).2

theorem warm651 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t651 651) = true := by
  decide +kernel

theorem ok651 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t651 651 = true := (Snake9.LratV3.andB_eq_true warm651).2

theorem warm652 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t652 652) = true := by
  decide +kernel

theorem ok652 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t652 652 = true := (Snake9.LratV3.andB_eq_true warm652).2

theorem warm653 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t653 653) = true := by
  decide +kernel

theorem ok653 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t653 653 = true := (Snake9.LratV3.andB_eq_true warm653).2

theorem warm654 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t654 654) = true := by
  decide +kernel

theorem ok654 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t654 654 = true := (Snake9.LratV3.andB_eq_true warm654).2

theorem warm655 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t655 655) = true := by
  decide +kernel

theorem ok655 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t655 655 = true := (Snake9.LratV3.andB_eq_true warm655).2

theorem warm656 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t656 656) = true := by
  decide +kernel

theorem ok656 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t656 656 = true := (Snake9.LratV3.andB_eq_true warm656).2

theorem warm657 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t657 657) = true := by
  decide +kernel

theorem ok657 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t657 657 = true := (Snake9.LratV3.andB_eq_true warm657).2

theorem warm658 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t658 658) = true := by
  decide +kernel

theorem ok658 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t658 658 = true := (Snake9.LratV3.andB_eq_true warm658).2

theorem warm659 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 511) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t659 659) = true := by
  decide +kernel

theorem ok659 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t659 659 = true := (Snake9.LratV3.andB_eq_true warm659).2

theorem warm660 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t660 660) = true := by
  decide +kernel

theorem ok660 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t660 660 = true := (Snake9.LratV3.andB_eq_true warm660).2

theorem warm661 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t661 661) = true := by
  decide +kernel

theorem ok661 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t661 661 = true := (Snake9.LratV3.andB_eq_true warm661).2

theorem warm662 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t662 662) = true := by
  decide +kernel

theorem ok662 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t662 662 = true := (Snake9.LratV3.andB_eq_true warm662).2

end Snake9.LocalWindow.V01203A3643
