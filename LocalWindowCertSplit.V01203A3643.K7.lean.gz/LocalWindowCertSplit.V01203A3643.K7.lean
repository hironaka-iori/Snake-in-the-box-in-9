module

-- LocalWindowCertSplit.V01203A3643: kernel checks of segments 927..1058 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V01203A3643.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V01203A3643

theorem warm927 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t927 927) = true := by
  decide +kernel

theorem ok927 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t927 927 = true := (Snake9.LratV3.andB_eq_true warm927).2

theorem warm928 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t928 928) = true := by
  decide +kernel

theorem ok928 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t928 928 = true := (Snake9.LratV3.andB_eq_true warm928).2

theorem warm929 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t929 929) = true := by
  decide +kernel

theorem ok929 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t929 929 = true := (Snake9.LratV3.andB_eq_true warm929).2

theorem warm930 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t930 930) = true := by
  decide +kernel

theorem ok930 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t930 930 = true := (Snake9.LratV3.andB_eq_true warm930).2

theorem warm931 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 342) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t931 931) = true := by
  decide +kernel

theorem ok931 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t931 931 = true := (Snake9.LratV3.andB_eq_true warm931).2

theorem warm932 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t932 932) = true := by
  decide +kernel

theorem ok932 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t932 932 = true := (Snake9.LratV3.andB_eq_true warm932).2

theorem warm933 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t933 933) = true := by
  decide +kernel

theorem ok933 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t933 933 = true := (Snake9.LratV3.andB_eq_true warm933).2

theorem warm934 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t934 934) = true := by
  decide +kernel

theorem ok934 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t934 934 = true := (Snake9.LratV3.andB_eq_true warm934).2

theorem warm935 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t935 935) = true := by
  decide +kernel

theorem ok935 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t935 935 = true := (Snake9.LratV3.andB_eq_true warm935).2

theorem warm936 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t936 936) = true := by
  decide +kernel

theorem ok936 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t936 936 = true := (Snake9.LratV3.andB_eq_true warm936).2

theorem warm937 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t937 937) = true := by
  decide +kernel

theorem ok937 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t937 937 = true := (Snake9.LratV3.andB_eq_true warm937).2

theorem warm938 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t938 938) = true := by
  decide +kernel

theorem ok938 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t938 938 = true := (Snake9.LratV3.andB_eq_true warm938).2

theorem warm939 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 342) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t939 939) = true := by
  decide +kernel

theorem ok939 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t939 939 = true := (Snake9.LratV3.andB_eq_true warm939).2

theorem warm940 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t940 940) = true := by
  decide +kernel

theorem ok940 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t940 940 = true := (Snake9.LratV3.andB_eq_true warm940).2

theorem warm941 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 342) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t941 941) = true := by
  decide +kernel

theorem ok941 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t941 941 = true := (Snake9.LratV3.andB_eq_true warm941).2

theorem warm942 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t942 942) = true := by
  decide +kernel

theorem ok942 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t942 942 = true := (Snake9.LratV3.andB_eq_true warm942).2

theorem warm943 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t943 943) = true := by
  decide +kernel

theorem ok943 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t943 943 = true := (Snake9.LratV3.andB_eq_true warm943).2

theorem warm944 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t944 944) = true := by
  decide +kernel

theorem ok944 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t944 944 = true := (Snake9.LratV3.andB_eq_true warm944).2

theorem warm945 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t945 945) = true := by
  decide +kernel

theorem ok945 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t945 945 = true := (Snake9.LratV3.andB_eq_true warm945).2

theorem warm946 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t946 946) = true := by
  decide +kernel

theorem ok946 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t946 946 = true := (Snake9.LratV3.andB_eq_true warm946).2

theorem warm947 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t947 947) = true := by
  decide +kernel

theorem ok947 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t947 947 = true := (Snake9.LratV3.andB_eq_true warm947).2

theorem warm948 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t948 948) = true := by
  decide +kernel

theorem ok948 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t948 948 = true := (Snake9.LratV3.andB_eq_true warm948).2

theorem warm949 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t949 949) = true := by
  decide +kernel

theorem ok949 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t949 949 = true := (Snake9.LratV3.andB_eq_true warm949).2

theorem warm950 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t950 950) = true := by
  decide +kernel

theorem ok950 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t950 950 = true := (Snake9.LratV3.andB_eq_true warm950).2

theorem warm951 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 342) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t951 951) = true := by
  decide +kernel

theorem ok951 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t951 951 = true := (Snake9.LratV3.andB_eq_true warm951).2

theorem warm952 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t952 952) = true := by
  decide +kernel

theorem ok952 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t952 952 = true := (Snake9.LratV3.andB_eq_true warm952).2

theorem warm953 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t953 953) = true := by
  decide +kernel

theorem ok953 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t953 953 = true := (Snake9.LratV3.andB_eq_true warm953).2

theorem warm954 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t954 954) = true := by
  decide +kernel

theorem ok954 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t954 954 = true := (Snake9.LratV3.andB_eq_true warm954).2

theorem warm955 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t955 955) = true := by
  decide +kernel

theorem ok955 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t955 955 = true := (Snake9.LratV3.andB_eq_true warm955).2

theorem warm956 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t956 956) = true := by
  decide +kernel

theorem ok956 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t956 956 = true := (Snake9.LratV3.andB_eq_true warm956).2

theorem warm957 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t957 957) = true := by
  decide +kernel

theorem ok957 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t957 957 = true := (Snake9.LratV3.andB_eq_true warm957).2

theorem warm958 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 21) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t958 958) = true := by
  decide +kernel

theorem ok958 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t958 958 = true := (Snake9.LratV3.andB_eq_true warm958).2

theorem warm959 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t959 959) = true := by
  decide +kernel

theorem ok959 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t959 959 = true := (Snake9.LratV3.andB_eq_true warm959).2

theorem warm960 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t960 960) = true := by
  decide +kernel

theorem ok960 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t960 960 = true := (Snake9.LratV3.andB_eq_true warm960).2

theorem warm961 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t961 961) = true := by
  decide +kernel

theorem ok961 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t961 961 = true := (Snake9.LratV3.andB_eq_true warm961).2

theorem warm962 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t962 962) = true := by
  decide +kernel

theorem ok962 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t962 962 = true := (Snake9.LratV3.andB_eq_true warm962).2

theorem warm963 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t963 963) = true := by
  decide +kernel

theorem ok963 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t963 963 = true := (Snake9.LratV3.andB_eq_true warm963).2

theorem warm964 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t964 964) = true := by
  decide +kernel

theorem ok964 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t964 964 = true := (Snake9.LratV3.andB_eq_true warm964).2

theorem warm965 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t965 965) = true := by
  decide +kernel

theorem ok965 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t965 965 = true := (Snake9.LratV3.andB_eq_true warm965).2

theorem warm966 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t966 966) = true := by
  decide +kernel

theorem ok966 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t966 966 = true := (Snake9.LratV3.andB_eq_true warm966).2

theorem warm967 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t967 967) = true := by
  decide +kernel

theorem ok967 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t967 967 = true := (Snake9.LratV3.andB_eq_true warm967).2

theorem warm968 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t968 968) = true := by
  decide +kernel

theorem ok968 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t968 968 = true := (Snake9.LratV3.andB_eq_true warm968).2

theorem warm969 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t969 969) = true := by
  decide +kernel

theorem ok969 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t969 969 = true := (Snake9.LratV3.andB_eq_true warm969).2

theorem warm970 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t970 970) = true := by
  decide +kernel

theorem ok970 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t970 970 = true := (Snake9.LratV3.andB_eq_true warm970).2

theorem warm971 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t971 971) = true := by
  decide +kernel

theorem ok971 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t971 971 = true := (Snake9.LratV3.andB_eq_true warm971).2

theorem warm972 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t972 972) = true := by
  decide +kernel

theorem ok972 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t972 972 = true := (Snake9.LratV3.andB_eq_true warm972).2

theorem warm973 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t973 973) = true := by
  decide +kernel

theorem ok973 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t973 973 = true := (Snake9.LratV3.andB_eq_true warm973).2

theorem warm974 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t974 974) = true := by
  decide +kernel

theorem ok974 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t974 974 = true := (Snake9.LratV3.andB_eq_true warm974).2

theorem warm975 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t975 975) = true := by
  decide +kernel

theorem ok975 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t975 975 = true := (Snake9.LratV3.andB_eq_true warm975).2

theorem warm976 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t976 976) = true := by
  decide +kernel

theorem ok976 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t976 976 = true := (Snake9.LratV3.andB_eq_true warm976).2

theorem warm977 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t977 977) = true := by
  decide +kernel

theorem ok977 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t977 977 = true := (Snake9.LratV3.andB_eq_true warm977).2

theorem warm978 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t978 978) = true := by
  decide +kernel

theorem ok978 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t978 978 = true := (Snake9.LratV3.andB_eq_true warm978).2

theorem warm979 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t979 979) = true := by
  decide +kernel

theorem ok979 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t979 979 = true := (Snake9.LratV3.andB_eq_true warm979).2

theorem warm980 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 979) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t980 980) = true := by
  decide +kernel

theorem ok980 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t980 980 = true := (Snake9.LratV3.andB_eq_true warm980).2

theorem warm981 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t981 981) = true := by
  decide +kernel

theorem ok981 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t981 981 = true := (Snake9.LratV3.andB_eq_true warm981).2

theorem warm982 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t982 982) = true := by
  decide +kernel

theorem ok982 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t982 982 = true := (Snake9.LratV3.andB_eq_true warm982).2

theorem warm983 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t983 983) = true := by
  decide +kernel

theorem ok983 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t983 983 = true := (Snake9.LratV3.andB_eq_true warm983).2

theorem warm984 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t984 984) = true := by
  decide +kernel

theorem ok984 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t984 984 = true := (Snake9.LratV3.andB_eq_true warm984).2

theorem ok985 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t985 985 = true := by
  decide +kernel

theorem warm986 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t986 986) = true := by
  decide +kernel

theorem ok986 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t986 986 = true := (Snake9.LratV3.andB_eq_true warm986).2

theorem warm987 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t987 987) = true := by
  decide +kernel

theorem ok987 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t987 987 = true := (Snake9.LratV3.andB_eq_true warm987).2

theorem warm988 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t988 988) = true := by
  decide +kernel

theorem ok988 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t988 988 = true := (Snake9.LratV3.andB_eq_true warm988).2

theorem warm989 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t989 989) = true := by
  decide +kernel

theorem ok989 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t989 989 = true := (Snake9.LratV3.andB_eq_true warm989).2

theorem warm990 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t990 990) = true := by
  decide +kernel

theorem ok990 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t990 990 = true := (Snake9.LratV3.andB_eq_true warm990).2

theorem warm991 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 545) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t991 991) = true := by
  decide +kernel

theorem ok991 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t991 991 = true := (Snake9.LratV3.andB_eq_true warm991).2

theorem warm992 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t992 992) = true := by
  decide +kernel

theorem ok992 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t992 992 = true := (Snake9.LratV3.andB_eq_true warm992).2

theorem warm993 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 511) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t993 993) = true := by
  decide +kernel

theorem ok993 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t993 993 = true := (Snake9.LratV3.andB_eq_true warm993).2

theorem warm994 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t994 994) = true := by
  decide +kernel

theorem ok994 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t994 994 = true := (Snake9.LratV3.andB_eq_true warm994).2

theorem warm995 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t995 995) = true := by
  decide +kernel

theorem ok995 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t995 995 = true := (Snake9.LratV3.andB_eq_true warm995).2

theorem warm996 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t996 996) = true := by
  decide +kernel

theorem ok996 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t996 996 = true := (Snake9.LratV3.andB_eq_true warm996).2

theorem warm997 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t997 997) = true := by
  decide +kernel

theorem ok997 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t997 997 = true := (Snake9.LratV3.andB_eq_true warm997).2

theorem warm998 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t998 998) = true := by
  decide +kernel

theorem ok998 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t998 998 = true := (Snake9.LratV3.andB_eq_true warm998).2

theorem warm999 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 342) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t999 999) = true := by
  decide +kernel

theorem ok999 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t999 999 = true := (Snake9.LratV3.andB_eq_true warm999).2

theorem warm1000 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1000 1000) = true := by
  decide +kernel

theorem ok1000 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1000 1000 = true := (Snake9.LratV3.andB_eq_true warm1000).2

theorem warm1001 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1001 1001) = true := by
  decide +kernel

theorem ok1001 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1001 1001 = true := (Snake9.LratV3.andB_eq_true warm1001).2

theorem warm1002 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1002 1002) = true := by
  decide +kernel

theorem ok1002 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1002 1002 = true := (Snake9.LratV3.andB_eq_true warm1002).2

theorem warm1003 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1003 1003) = true := by
  decide +kernel

theorem ok1003 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1003 1003 = true := (Snake9.LratV3.andB_eq_true warm1003).2

theorem warm1004 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1004 1004) = true := by
  decide +kernel

theorem ok1004 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1004 1004 = true := (Snake9.LratV3.andB_eq_true warm1004).2

theorem warm1005 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1005 1005) = true := by
  decide +kernel

theorem ok1005 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1005 1005 = true := (Snake9.LratV3.andB_eq_true warm1005).2

theorem warm1006 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1006 1006) = true := by
  decide +kernel

theorem ok1006 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1006 1006 = true := (Snake9.LratV3.andB_eq_true warm1006).2

theorem warm1007 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1007 1007) = true := by
  decide +kernel

theorem ok1007 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1007 1007 = true := (Snake9.LratV3.andB_eq_true warm1007).2

theorem warm1008 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1008 1008) = true := by
  decide +kernel

theorem ok1008 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1008 1008 = true := (Snake9.LratV3.andB_eq_true warm1008).2

theorem warm1009 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1009 1009) = true := by
  decide +kernel

theorem ok1009 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1009 1009 = true := (Snake9.LratV3.andB_eq_true warm1009).2

theorem warm1010 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1010 1010) = true := by
  decide +kernel

theorem ok1010 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1010 1010 = true := (Snake9.LratV3.andB_eq_true warm1010).2

theorem warm1011 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1011 1011) = true := by
  decide +kernel

theorem ok1011 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1011 1011 = true := (Snake9.LratV3.andB_eq_true warm1011).2

theorem warm1012 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 511) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1012 1012) = true := by
  decide +kernel

theorem ok1012 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1012 1012 = true := (Snake9.LratV3.andB_eq_true warm1012).2

theorem warm1013 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1013 1013) = true := by
  decide +kernel

theorem ok1013 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1013 1013 = true := (Snake9.LratV3.andB_eq_true warm1013).2

theorem warm1014 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1014 1014) = true := by
  decide +kernel

theorem ok1014 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1014 1014 = true := (Snake9.LratV3.andB_eq_true warm1014).2

theorem warm1015 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1015 1015) = true := by
  decide +kernel

theorem ok1015 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1015 1015 = true := (Snake9.LratV3.andB_eq_true warm1015).2

theorem warm1016 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1016 1016) = true := by
  decide +kernel

theorem ok1016 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1016 1016 = true := (Snake9.LratV3.andB_eq_true warm1016).2

theorem ok1017 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1017 1017 = true := by
  decide +kernel

theorem warm1018 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 511) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1018 1018) = true := by
  decide +kernel

theorem ok1018 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1018 1018 = true := (Snake9.LratV3.andB_eq_true warm1018).2

theorem ok1019 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1019 1019 = true := by
  decide +kernel

theorem warm1020 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1020 1020) = true := by
  decide +kernel

theorem ok1020 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1020 1020 = true := (Snake9.LratV3.andB_eq_true warm1020).2

theorem warm1021 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1021 1021) = true := by
  decide +kernel

theorem ok1021 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1021 1021 = true := (Snake9.LratV3.andB_eq_true warm1021).2

theorem warm1022 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1022 1022) = true := by
  decide +kernel

theorem ok1022 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1022 1022 = true := (Snake9.LratV3.andB_eq_true warm1022).2

theorem warm1023 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1023 1023) = true := by
  decide +kernel

theorem ok1023 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1023 1023 = true := (Snake9.LratV3.andB_eq_true warm1023).2

theorem warm1024 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1024 1024) = true := by
  decide +kernel

theorem ok1024 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1024 1024 = true := (Snake9.LratV3.andB_eq_true warm1024).2

theorem warm1025 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1025 1025) = true := by
  decide +kernel

theorem ok1025 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1025 1025 = true := (Snake9.LratV3.andB_eq_true warm1025).2

theorem warm1026 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 398) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1026 1026) = true := by
  decide +kernel

theorem ok1026 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1026 1026 = true := (Snake9.LratV3.andB_eq_true warm1026).2

theorem warm1027 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1027 1027) = true := by
  decide +kernel

theorem ok1027 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1027 1027 = true := (Snake9.LratV3.andB_eq_true warm1027).2

theorem warm1028 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1028 1028) = true := by
  decide +kernel

theorem ok1028 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1028 1028 = true := (Snake9.LratV3.andB_eq_true warm1028).2

theorem warm1029 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1029 1029) = true := by
  decide +kernel

theorem ok1029 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1029 1029 = true := (Snake9.LratV3.andB_eq_true warm1029).2

theorem warm1030 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1030 1030) = true := by
  decide +kernel

theorem ok1030 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1030 1030 = true := (Snake9.LratV3.andB_eq_true warm1030).2

theorem warm1031 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1031 1031) = true := by
  decide +kernel

theorem ok1031 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1031 1031 = true := (Snake9.LratV3.andB_eq_true warm1031).2

theorem warm1032 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1032 1032) = true := by
  decide +kernel

theorem ok1032 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1032 1032 = true := (Snake9.LratV3.andB_eq_true warm1032).2

theorem warm1033 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1033 1033) = true := by
  decide +kernel

theorem ok1033 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1033 1033 = true := (Snake9.LratV3.andB_eq_true warm1033).2

theorem warm1034 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1034 1034) = true := by
  decide +kernel

theorem ok1034 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1034 1034 = true := (Snake9.LratV3.andB_eq_true warm1034).2

theorem warm1035 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1035 1035) = true := by
  decide +kernel

theorem ok1035 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1035 1035 = true := (Snake9.LratV3.andB_eq_true warm1035).2

theorem warm1036 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1036 1036) = true := by
  decide +kernel

theorem ok1036 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1036 1036 = true := (Snake9.LratV3.andB_eq_true warm1036).2

theorem warm1037 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1037 1037) = true := by
  decide +kernel

theorem ok1037 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1037 1037 = true := (Snake9.LratV3.andB_eq_true warm1037).2

theorem warm1038 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1038 1038) = true := by
  decide +kernel

theorem ok1038 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1038 1038 = true := (Snake9.LratV3.andB_eq_true warm1038).2

theorem warm1039 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1039 1039) = true := by
  decide +kernel

theorem ok1039 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1039 1039 = true := (Snake9.LratV3.andB_eq_true warm1039).2

theorem warm1040 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1040 1040) = true := by
  decide +kernel

theorem ok1040 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1040 1040 = true := (Snake9.LratV3.andB_eq_true warm1040).2

theorem warm1041 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1041 1041) = true := by
  decide +kernel

theorem ok1041 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1041 1041 = true := (Snake9.LratV3.andB_eq_true warm1041).2

theorem warm1042 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1042 1042) = true := by
  decide +kernel

theorem ok1042 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1042 1042 = true := (Snake9.LratV3.andB_eq_true warm1042).2

theorem warm1043 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1043 1043) = true := by
  decide +kernel

theorem ok1043 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1043 1043 = true := (Snake9.LratV3.andB_eq_true warm1043).2

theorem warm1044 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1044 1044) = true := by
  decide +kernel

theorem ok1044 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1044 1044 = true := (Snake9.LratV3.andB_eq_true warm1044).2

theorem warm1045 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1044) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1045 1045) = true := by
  decide +kernel

theorem ok1045 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1045 1045 = true := (Snake9.LratV3.andB_eq_true warm1045).2

theorem warm1046 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 879) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1044) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1046 1046) = true := by
  decide +kernel

theorem ok1046 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1046 1046 = true := (Snake9.LratV3.andB_eq_true warm1046).2

theorem warm1047 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1047 1047) = true := by
  decide +kernel

theorem ok1047 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1047 1047 = true := (Snake9.LratV3.andB_eq_true warm1047).2

theorem warm1048 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1048 1048) = true := by
  decide +kernel

theorem ok1048 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1048 1048 = true := (Snake9.LratV3.andB_eq_true warm1048).2

theorem warm1049 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1049 1049) = true := by
  decide +kernel

theorem ok1049 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1049 1049 = true := (Snake9.LratV3.andB_eq_true warm1049).2

theorem warm1050 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 880) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1050 1050) = true := by
  decide +kernel

theorem ok1050 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1050 1050 = true := (Snake9.LratV3.andB_eq_true warm1050).2

theorem warm1051 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 979) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1051 1051) = true := by
  decide +kernel

theorem ok1051 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1051 1051 = true := (Snake9.LratV3.andB_eq_true warm1051).2

theorem warm1052 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1052 1052) = true := by
  decide +kernel

theorem ok1052 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1052 1052 = true := (Snake9.LratV3.andB_eq_true warm1052).2

theorem warm1053 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1053 1053) = true := by
  decide +kernel

theorem ok1053 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1053 1053 = true := (Snake9.LratV3.andB_eq_true warm1053).2

theorem warm1054 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (true)))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1054 1054) = true := by
  decide +kernel

theorem ok1054 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1054 1054 = true := (Snake9.LratV3.andB_eq_true warm1054).2

theorem warm1055 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1055 1055) = true := by
  decide +kernel

theorem ok1055 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1055 1055 = true := (Snake9.LratV3.andB_eq_true warm1055).2

theorem warm1056 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1021) 2048)) true)
    (true))))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1056 1056) = true := by
  decide +kernel

theorem ok1056 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1056 1056 = true := (Snake9.LratV3.andB_eq_true warm1056).2

theorem warm1057 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1057 1057) = true := by
  decide +kernel

theorem ok1057 : Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1057 1057 = true := (Snake9.LratV3.andB_eq_true warm1057).2

theorem warm1058 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 2400 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 2400 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 978) 2048)) true)
    (true)))))
    (Snake9.LratV3.andB (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1058 1058) (Snake9.LratV3.hasEmpty 14 16383 (Snake9.LratV3.segP Ps 1058))) = true := by
  decide +kernel

theorem ok1058 : Snake9.LratV3.andB (Snake9.LratV3.check 2400 14 16383 8192 raw Ps t1058 1058) (Snake9.LratV3.hasEmpty 14 16383 (Snake9.LratV3.segP Ps 1058)) = true := (Snake9.LratV3.andB_eq_true warm1058).2

end Snake9.LocalWindow.V01203A3643
