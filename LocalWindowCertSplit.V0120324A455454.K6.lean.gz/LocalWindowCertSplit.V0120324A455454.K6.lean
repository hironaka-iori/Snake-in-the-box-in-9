module

-- LocalWindowCertSplit.V0120324A455454: kernel checks of segments 263..307 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V0120324A455454.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V0120324A455454

theorem warm263 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 146) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t263 263) = true := by
  decide +kernel

theorem ok263 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t263 263 = true := (Snake9.LratV3.andB_eq_true warm263).2

theorem warm264 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t264 264) = true := by
  decide +kernel

theorem ok264 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t264 264 = true := (Snake9.LratV3.andB_eq_true warm264).2

theorem warm265 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t265 265) = true := by
  decide +kernel

theorem ok265 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t265 265 = true := (Snake9.LratV3.andB_eq_true warm265).2

theorem warm266 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 77) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t266 266) = true := by
  decide +kernel

theorem ok266 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t266 266 = true := (Snake9.LratV3.andB_eq_true warm266).2

theorem warm267 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 4) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t267 267) = true := by
  decide +kernel

theorem ok267 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t267 267 = true := (Snake9.LratV3.andB_eq_true warm267).2

theorem warm268 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t268 268) = true := by
  decide +kernel

theorem ok268 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t268 268 = true := (Snake9.LratV3.andB_eq_true warm268).2

theorem warm269 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t269 269) = true := by
  decide +kernel

theorem ok269 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t269 269 = true := (Snake9.LratV3.andB_eq_true warm269).2

theorem warm270 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 212) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t270 270) = true := by
  decide +kernel

theorem ok270 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t270 270 = true := (Snake9.LratV3.andB_eq_true warm270).2

theorem warm271 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t271 271) = true := by
  decide +kernel

theorem ok271 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t271 271 = true := (Snake9.LratV3.andB_eq_true warm271).2

theorem warm272 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t272 272) = true := by
  decide +kernel

theorem ok272 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t272 272 = true := (Snake9.LratV3.andB_eq_true warm272).2

theorem warm273 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t273 273) = true := by
  decide +kernel

theorem ok273 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t273 273 = true := (Snake9.LratV3.andB_eq_true warm273).2

theorem warm274 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t274 274) = true := by
  decide +kernel

theorem ok274 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t274 274 = true := (Snake9.LratV3.andB_eq_true warm274).2

theorem warm275 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t275 275) = true := by
  decide +kernel

theorem ok275 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t275 275 = true := (Snake9.LratV3.andB_eq_true warm275).2

theorem warm276 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t276 276) = true := by
  decide +kernel

theorem ok276 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t276 276 = true := (Snake9.LratV3.andB_eq_true warm276).2

theorem warm277 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 146) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t277 277) = true := by
  decide +kernel

theorem ok277 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t277 277 = true := (Snake9.LratV3.andB_eq_true warm277).2

theorem warm278 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t278 278) = true := by
  decide +kernel

theorem ok278 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t278 278 = true := (Snake9.LratV3.andB_eq_true warm278).2

theorem warm279 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t279 279) = true := by
  decide +kernel

theorem ok279 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t279 279 = true := (Snake9.LratV3.andB_eq_true warm279).2

theorem warm280 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t280 280) = true := by
  decide +kernel

theorem ok280 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t280 280 = true := (Snake9.LratV3.andB_eq_true warm280).2

theorem warm281 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 146) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t281 281) = true := by
  decide +kernel

theorem ok281 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t281 281 = true := (Snake9.LratV3.andB_eq_true warm281).2

theorem warm282 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t282 282) = true := by
  decide +kernel

theorem ok282 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t282 282 = true := (Snake9.LratV3.andB_eq_true warm282).2

theorem warm283 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 212) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t283 283) = true := by
  decide +kernel

theorem ok283 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t283 283 = true := (Snake9.LratV3.andB_eq_true warm283).2

theorem warm284 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t284 284) = true := by
  decide +kernel

theorem ok284 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t284 284 = true := (Snake9.LratV3.andB_eq_true warm284).2

theorem warm285 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t285 285) = true := by
  decide +kernel

theorem ok285 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t285 285 = true := (Snake9.LratV3.andB_eq_true warm285).2

theorem warm286 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t286 286) = true := by
  decide +kernel

theorem ok286 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t286 286 = true := (Snake9.LratV3.andB_eq_true warm286).2

theorem warm287 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t287 287) = true := by
  decide +kernel

theorem ok287 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t287 287 = true := (Snake9.LratV3.andB_eq_true warm287).2

theorem warm288 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t288 288) = true := by
  decide +kernel

theorem ok288 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t288 288 = true := (Snake9.LratV3.andB_eq_true warm288).2

theorem warm289 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t289 289) = true := by
  decide +kernel

theorem ok289 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t289 289 = true := (Snake9.LratV3.andB_eq_true warm289).2

theorem warm290 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 146) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t290 290) = true := by
  decide +kernel

theorem ok290 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t290 290 = true := (Snake9.LratV3.andB_eq_true warm290).2

theorem warm291 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t291 291) = true := by
  decide +kernel

theorem ok291 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t291 291 = true := (Snake9.LratV3.andB_eq_true warm291).2

theorem warm292 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t292 292) = true := by
  decide +kernel

theorem ok292 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t292 292 = true := (Snake9.LratV3.andB_eq_true warm292).2

theorem warm293 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 212) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t293 293) = true := by
  decide +kernel

theorem ok293 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t293 293 = true := (Snake9.LratV3.andB_eq_true warm293).2

theorem warm294 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 292) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 293) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t294 294) = true := by
  decide +kernel

theorem ok294 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t294 294 = true := (Snake9.LratV3.andB_eq_true warm294).2

theorem warm295 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 212) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 292) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 293) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t295 295) = true := by
  decide +kernel

theorem ok295 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t295 295 = true := (Snake9.LratV3.andB_eq_true warm295).2

theorem warm296 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t296 296) = true := by
  decide +kernel

theorem ok296 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t296 296 = true := (Snake9.LratV3.andB_eq_true warm296).2

theorem warm297 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t297 297) = true := by
  decide +kernel

theorem ok297 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t297 297 = true := (Snake9.LratV3.andB_eq_true warm297).2

theorem warm298 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 293) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t298 298) = true := by
  decide +kernel

theorem ok298 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t298 298 = true := (Snake9.LratV3.andB_eq_true warm298).2

theorem warm299 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 293) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t299 299) = true := by
  decide +kernel

theorem ok299 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t299 299 = true := (Snake9.LratV3.andB_eq_true warm299).2

theorem warm300 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 38) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 292) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 293) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t300 300) = true := by
  decide +kernel

theorem ok300 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t300 300 = true := (Snake9.LratV3.andB_eq_true warm300).2

theorem warm301 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 212) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 292) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t301 301) = true := by
  decide +kernel

theorem ok301 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t301 301 = true := (Snake9.LratV3.andB_eq_true warm301).2

theorem warm302 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 292) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t302 302) = true := by
  decide +kernel

theorem ok302 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t302 302 = true := (Snake9.LratV3.andB_eq_true warm302).2

theorem warm303 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 77) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t303 303) = true := by
  decide +kernel

theorem ok303 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t303 303 = true := (Snake9.LratV3.andB_eq_true warm303).2

theorem warm304 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 146) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 292) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t304 304) = true := by
  decide +kernel

theorem ok304 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t304 304 = true := (Snake9.LratV3.andB_eq_true warm304).2

theorem warm305 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t305 305) = true := by
  decide +kernel

theorem ok305 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t305 305 = true := (Snake9.LratV3.andB_eq_true warm305).2

theorem warm306 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 270) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 279) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t306 306) = true := by
  decide +kernel

theorem ok306 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t306 306 = true := (Snake9.LratV3.andB_eq_true warm306).2

theorem warm307 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 108) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 145) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 182) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 234) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 5000 15 32767 16384 raw Ps t307 307) = true := by
  decide +kernel

theorem ok307 : Snake9.LratV3.check 5000 15 32767 16384 raw Ps t307 307 = true := (Snake9.LratV3.andB_eq_true warm307).2

end Snake9.LocalWindow.V0120324A455454
