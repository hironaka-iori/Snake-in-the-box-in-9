module

-- LocalWindowCertSplit.V01230243A6445456: kernel checks of segments 83..123 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V01230243A6445456.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V01230243A6445456

theorem warm83 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t83 83) = true := by
  decide +kernel

theorem ok83 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t83 83 = true := (Snake9.LratV3.andB_eq_true warm83).2

theorem warm84 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t84 84) = true := by
  decide +kernel

theorem ok84 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t84 84 = true := (Snake9.LratV3.andB_eq_true warm84).2

theorem warm85 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t85 85) = true := by
  decide +kernel

theorem ok85 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t85 85 = true := (Snake9.LratV3.andB_eq_true warm85).2

theorem warm86 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t86 86) = true := by
  decide +kernel

theorem ok86 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t86 86 = true := (Snake9.LratV3.andB_eq_true warm86).2

theorem warm87 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t87 87) = true := by
  decide +kernel

theorem ok87 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t87 87 = true := (Snake9.LratV3.andB_eq_true warm87).2

theorem warm88 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t88 88) = true := by
  decide +kernel

theorem ok88 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t88 88 = true := (Snake9.LratV3.andB_eq_true warm88).2

theorem warm89 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t89 89) = true := by
  decide +kernel

theorem ok89 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t89 89 = true := (Snake9.LratV3.andB_eq_true warm89).2

theorem warm90 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t90 90) = true := by
  decide +kernel

theorem ok90 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t90 90 = true := (Snake9.LratV3.andB_eq_true warm90).2

theorem warm91 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t91 91) = true := by
  decide +kernel

theorem ok91 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t91 91 = true := (Snake9.LratV3.andB_eq_true warm91).2

theorem warm92 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t92 92) = true := by
  decide +kernel

theorem ok92 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t92 92 = true := (Snake9.LratV3.andB_eq_true warm92).2

theorem warm93 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t93 93) = true := by
  decide +kernel

theorem ok93 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t93 93 = true := (Snake9.LratV3.andB_eq_true warm93).2

theorem warm94 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t94 94) = true := by
  decide +kernel

theorem ok94 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t94 94 = true := (Snake9.LratV3.andB_eq_true warm94).2

theorem warm95 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t95 95) = true := by
  decide +kernel

theorem ok95 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t95 95 = true := (Snake9.LratV3.andB_eq_true warm95).2

theorem warm96 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t96 96) = true := by
  decide +kernel

theorem ok96 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t96 96 = true := (Snake9.LratV3.andB_eq_true warm96).2

theorem warm97 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t97 97) = true := by
  decide +kernel

theorem ok97 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t97 97 = true := (Snake9.LratV3.andB_eq_true warm97).2

theorem warm98 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 34) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t98 98) = true := by
  decide +kernel

theorem ok98 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t98 98 = true := (Snake9.LratV3.andB_eq_true warm98).2

theorem warm99 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t99 99) = true := by
  decide +kernel

theorem ok99 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t99 99 = true := (Snake9.LratV3.andB_eq_true warm99).2

theorem warm100 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t100 100) = true := by
  decide +kernel

theorem ok100 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t100 100 = true := (Snake9.LratV3.andB_eq_true warm100).2

theorem warm101 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t101 101) = true := by
  decide +kernel

theorem ok101 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t101 101 = true := (Snake9.LratV3.andB_eq_true warm101).2

theorem warm102 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t102 102) = true := by
  decide +kernel

theorem ok102 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t102 102 = true := (Snake9.LratV3.andB_eq_true warm102).2

theorem warm103 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t103 103) = true := by
  decide +kernel

theorem ok103 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t103 103 = true := (Snake9.LratV3.andB_eq_true warm103).2

theorem warm104 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t104 104) = true := by
  decide +kernel

theorem ok104 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t104 104 = true := (Snake9.LratV3.andB_eq_true warm104).2

theorem warm105 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t105 105) = true := by
  decide +kernel

theorem ok105 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t105 105 = true := (Snake9.LratV3.andB_eq_true warm105).2

theorem warm106 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t106 106) = true := by
  decide +kernel

theorem ok106 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t106 106 = true := (Snake9.LratV3.andB_eq_true warm106).2

theorem warm107 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t107 107) = true := by
  decide +kernel

theorem ok107 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t107 107 = true := (Snake9.LratV3.andB_eq_true warm107).2

theorem warm108 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t108 108) = true := by
  decide +kernel

theorem ok108 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t108 108 = true := (Snake9.LratV3.andB_eq_true warm108).2

theorem warm109 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t109 109) = true := by
  decide +kernel

theorem ok109 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t109 109 = true := (Snake9.LratV3.andB_eq_true warm109).2

theorem warm110 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t110 110) = true := by
  decide +kernel

theorem ok110 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t110 110 = true := (Snake9.LratV3.andB_eq_true warm110).2

theorem warm111 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t111 111) = true := by
  decide +kernel

theorem ok111 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t111 111 = true := (Snake9.LratV3.andB_eq_true warm111).2

theorem warm112 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t112 112) = true := by
  decide +kernel

theorem ok112 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t112 112 = true := (Snake9.LratV3.andB_eq_true warm112).2

theorem warm113 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t113 113) = true := by
  decide +kernel

theorem ok113 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t113 113 = true := (Snake9.LratV3.andB_eq_true warm113).2

theorem warm114 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t114 114) = true := by
  decide +kernel

theorem ok114 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t114 114 = true := (Snake9.LratV3.andB_eq_true warm114).2

theorem warm115 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t115 115) = true := by
  decide +kernel

theorem ok115 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t115 115 = true := (Snake9.LratV3.andB_eq_true warm115).2

theorem warm116 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 34) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t116 116) = true := by
  decide +kernel

theorem ok116 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t116 116 = true := (Snake9.LratV3.andB_eq_true warm116).2

theorem warm117 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t117 117) = true := by
  decide +kernel

theorem ok117 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t117 117 = true := (Snake9.LratV3.andB_eq_true warm117).2

theorem warm118 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t118 118) = true := by
  decide +kernel

theorem ok118 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t118 118 = true := (Snake9.LratV3.andB_eq_true warm118).2

theorem warm119 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t119 119) = true := by
  decide +kernel

theorem ok119 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t119 119 = true := (Snake9.LratV3.andB_eq_true warm119).2

theorem warm120 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t120 120) = true := by
  decide +kernel

theorem ok120 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t120 120 = true := (Snake9.LratV3.andB_eq_true warm120).2

theorem warm121 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t121 121) = true := by
  decide +kernel

theorem ok121 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t121 121 = true := (Snake9.LratV3.andB_eq_true warm121).2

theorem warm122 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t122 122) = true := by
  decide +kernel

theorem ok122 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t122 122 = true := (Snake9.LratV3.andB_eq_true warm122).2

theorem warm123 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t123 123) = true := by
  decide +kernel

theorem ok123 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t123 123 = true := (Snake9.LratV3.andB_eq_true warm123).2

end Snake9.LocalWindow.V01230243A6445456
