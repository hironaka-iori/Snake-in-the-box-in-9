module

-- LocalWindowCertSplit.V012032A45454: kernel checks of segments 1379..1475 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V012032A45454.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V012032A45454

theorem warm1379 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 84) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1379 1379) = true := by
  decide +kernel

theorem ok1379 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1379 1379 = true := (Snake9.LratV3.andB_eq_true warm1379).2

theorem warm1380 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1380 1380) = true := by
  decide +kernel

theorem ok1380 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1380 1380 = true := (Snake9.LratV3.andB_eq_true warm1380).2

theorem warm1381 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1381 1381) = true := by
  decide +kernel

theorem ok1381 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1381 1381 = true := (Snake9.LratV3.andB_eq_true warm1381).2

theorem warm1382 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1382 1382) = true := by
  decide +kernel

theorem ok1382 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1382 1382 = true := (Snake9.LratV3.andB_eq_true warm1382).2

theorem warm1383 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1383 1383) = true := by
  decide +kernel

theorem ok1383 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1383 1383 = true := (Snake9.LratV3.andB_eq_true warm1383).2

theorem warm1384 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1384 1384) = true := by
  decide +kernel

theorem ok1384 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1384 1384 = true := (Snake9.LratV3.andB_eq_true warm1384).2

theorem warm1385 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1385 1385) = true := by
  decide +kernel

theorem ok1385 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1385 1385 = true := (Snake9.LratV3.andB_eq_true warm1385).2

theorem warm1386 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1386 1386) = true := by
  decide +kernel

theorem ok1386 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1386 1386 = true := (Snake9.LratV3.andB_eq_true warm1386).2

theorem warm1387 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1387 1387) = true := by
  decide +kernel

theorem ok1387 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1387 1387 = true := (Snake9.LratV3.andB_eq_true warm1387).2

theorem warm1388 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1388 1388) = true := by
  decide +kernel

theorem ok1388 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1388 1388 = true := (Snake9.LratV3.andB_eq_true warm1388).2

theorem warm1389 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1389 1389) = true := by
  decide +kernel

theorem ok1389 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1389 1389 = true := (Snake9.LratV3.andB_eq_true warm1389).2

theorem warm1390 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 104) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1390 1390) = true := by
  decide +kernel

theorem ok1390 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1390 1390 = true := (Snake9.LratV3.andB_eq_true warm1390).2

theorem warm1391 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1391 1391) = true := by
  decide +kernel

theorem ok1391 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1391 1391 = true := (Snake9.LratV3.andB_eq_true warm1391).2

theorem warm1392 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1392 1392) = true := by
  decide +kernel

theorem ok1392 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1392 1392 = true := (Snake9.LratV3.andB_eq_true warm1392).2

theorem warm1393 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1393 1393) = true := by
  decide +kernel

theorem ok1393 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1393 1393 = true := (Snake9.LratV3.andB_eq_true warm1393).2

theorem warm1394 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1394 1394) = true := by
  decide +kernel

theorem ok1394 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1394 1394 = true := (Snake9.LratV3.andB_eq_true warm1394).2

theorem warm1395 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1395 1395) = true := by
  decide +kernel

theorem ok1395 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1395 1395 = true := (Snake9.LratV3.andB_eq_true warm1395).2

theorem warm1396 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1396 1396) = true := by
  decide +kernel

theorem ok1396 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1396 1396 = true := (Snake9.LratV3.andB_eq_true warm1396).2

theorem warm1397 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1397 1397) = true := by
  decide +kernel

theorem ok1397 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1397 1397 = true := (Snake9.LratV3.andB_eq_true warm1397).2

theorem warm1398 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1398 1398) = true := by
  decide +kernel

theorem ok1398 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1398 1398 = true := (Snake9.LratV3.andB_eq_true warm1398).2

theorem warm1399 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1399 1399) = true := by
  decide +kernel

theorem ok1399 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1399 1399 = true := (Snake9.LratV3.andB_eq_true warm1399).2

theorem warm1400 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1400 1400) = true := by
  decide +kernel

theorem ok1400 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1400 1400 = true := (Snake9.LratV3.andB_eq_true warm1400).2

theorem warm1401 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1401 1401) = true := by
  decide +kernel

theorem ok1401 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1401 1401 = true := (Snake9.LratV3.andB_eq_true warm1401).2

theorem warm1402 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1402 1402) = true := by
  decide +kernel

theorem ok1402 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1402 1402 = true := (Snake9.LratV3.andB_eq_true warm1402).2

theorem warm1403 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1403 1403) = true := by
  decide +kernel

theorem ok1403 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1403 1403 = true := (Snake9.LratV3.andB_eq_true warm1403).2

theorem warm1404 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1404 1404) = true := by
  decide +kernel

theorem ok1404 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1404 1404 = true := (Snake9.LratV3.andB_eq_true warm1404).2

theorem warm1405 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1405 1405) = true := by
  decide +kernel

theorem ok1405 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1405 1405 = true := (Snake9.LratV3.andB_eq_true warm1405).2

theorem warm1406 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1406 1406) = true := by
  decide +kernel

theorem ok1406 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1406 1406 = true := (Snake9.LratV3.andB_eq_true warm1406).2

theorem warm1407 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1407 1407) = true := by
  decide +kernel

theorem ok1407 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1407 1407 = true := (Snake9.LratV3.andB_eq_true warm1407).2

theorem warm1408 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1408 1408) = true := by
  decide +kernel

theorem ok1408 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1408 1408 = true := (Snake9.LratV3.andB_eq_true warm1408).2

theorem warm1409 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1409 1409) = true := by
  decide +kernel

theorem ok1409 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1409 1409 = true := (Snake9.LratV3.andB_eq_true warm1409).2

theorem warm1410 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1410 1410) = true := by
  decide +kernel

theorem ok1410 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1410 1410 = true := (Snake9.LratV3.andB_eq_true warm1410).2

theorem warm1411 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1411 1411) = true := by
  decide +kernel

theorem ok1411 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1411 1411 = true := (Snake9.LratV3.andB_eq_true warm1411).2

theorem warm1412 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1412 1412) = true := by
  decide +kernel

theorem ok1412 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1412 1412 = true := (Snake9.LratV3.andB_eq_true warm1412).2

theorem warm1413 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1413 1413) = true := by
  decide +kernel

theorem ok1413 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1413 1413 = true := (Snake9.LratV3.andB_eq_true warm1413).2

theorem warm1414 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1414 1414) = true := by
  decide +kernel

theorem ok1414 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1414 1414 = true := (Snake9.LratV3.andB_eq_true warm1414).2

theorem warm1415 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1415 1415) = true := by
  decide +kernel

theorem ok1415 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1415 1415 = true := (Snake9.LratV3.andB_eq_true warm1415).2

theorem warm1416 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1416 1416) = true := by
  decide +kernel

theorem ok1416 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1416 1416 = true := (Snake9.LratV3.andB_eq_true warm1416).2

theorem warm1417 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1417 1417) = true := by
  decide +kernel

theorem ok1417 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1417 1417 = true := (Snake9.LratV3.andB_eq_true warm1417).2

theorem warm1418 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1418 1418) = true := by
  decide +kernel

theorem ok1418 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1418 1418 = true := (Snake9.LratV3.andB_eq_true warm1418).2

theorem warm1419 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1419 1419) = true := by
  decide +kernel

theorem ok1419 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1419 1419 = true := (Snake9.LratV3.andB_eq_true warm1419).2

theorem warm1420 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1420 1420) = true := by
  decide +kernel

theorem ok1420 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1420 1420 = true := (Snake9.LratV3.andB_eq_true warm1420).2

theorem warm1421 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1421 1421) = true := by
  decide +kernel

theorem ok1421 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1421 1421 = true := (Snake9.LratV3.andB_eq_true warm1421).2

theorem warm1422 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1422 1422) = true := by
  decide +kernel

theorem ok1422 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1422 1422 = true := (Snake9.LratV3.andB_eq_true warm1422).2

theorem warm1423 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1423 1423) = true := by
  decide +kernel

theorem ok1423 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1423 1423 = true := (Snake9.LratV3.andB_eq_true warm1423).2

theorem warm1424 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1424 1424) = true := by
  decide +kernel

theorem ok1424 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1424 1424 = true := (Snake9.LratV3.andB_eq_true warm1424).2

theorem warm1425 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1425 1425) = true := by
  decide +kernel

theorem ok1425 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1425 1425 = true := (Snake9.LratV3.andB_eq_true warm1425).2

theorem warm1426 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1426 1426) = true := by
  decide +kernel

theorem ok1426 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1426 1426 = true := (Snake9.LratV3.andB_eq_true warm1426).2

theorem warm1427 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1427 1427) = true := by
  decide +kernel

theorem ok1427 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1427 1427 = true := (Snake9.LratV3.andB_eq_true warm1427).2

theorem warm1428 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1428 1428) = true := by
  decide +kernel

theorem ok1428 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1428 1428 = true := (Snake9.LratV3.andB_eq_true warm1428).2

theorem warm1429 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1429 1429) = true := by
  decide +kernel

theorem ok1429 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1429 1429 = true := (Snake9.LratV3.andB_eq_true warm1429).2

theorem warm1430 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1430 1430) = true := by
  decide +kernel

theorem ok1430 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1430 1430 = true := (Snake9.LratV3.andB_eq_true warm1430).2

theorem warm1431 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1431 1431) = true := by
  decide +kernel

theorem ok1431 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1431 1431 = true := (Snake9.LratV3.andB_eq_true warm1431).2

theorem warm1432 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1432 1432) = true := by
  decide +kernel

theorem ok1432 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1432 1432 = true := (Snake9.LratV3.andB_eq_true warm1432).2

theorem warm1433 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1433 1433) = true := by
  decide +kernel

theorem ok1433 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1433 1433 = true := (Snake9.LratV3.andB_eq_true warm1433).2

theorem warm1434 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1434 1434) = true := by
  decide +kernel

theorem ok1434 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1434 1434 = true := (Snake9.LratV3.andB_eq_true warm1434).2

theorem warm1435 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1435 1435) = true := by
  decide +kernel

theorem ok1435 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1435 1435 = true := (Snake9.LratV3.andB_eq_true warm1435).2

theorem warm1436 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1436 1436) = true := by
  decide +kernel

theorem ok1436 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1436 1436 = true := (Snake9.LratV3.andB_eq_true warm1436).2

theorem warm1437 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1437 1437) = true := by
  decide +kernel

theorem ok1437 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1437 1437 = true := (Snake9.LratV3.andB_eq_true warm1437).2

theorem warm1438 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1438 1438) = true := by
  decide +kernel

theorem ok1438 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1438 1438 = true := (Snake9.LratV3.andB_eq_true warm1438).2

theorem warm1439 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1439 1439) = true := by
  decide +kernel

theorem ok1439 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1439 1439 = true := (Snake9.LratV3.andB_eq_true warm1439).2

theorem warm1440 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1440 1440) = true := by
  decide +kernel

theorem ok1440 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1440 1440 = true := (Snake9.LratV3.andB_eq_true warm1440).2

theorem warm1441 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1441 1441) = true := by
  decide +kernel

theorem ok1441 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1441 1441 = true := (Snake9.LratV3.andB_eq_true warm1441).2

theorem warm1442 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 84) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1442 1442) = true := by
  decide +kernel

theorem ok1442 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1442 1442 = true := (Snake9.LratV3.andB_eq_true warm1442).2

theorem warm1443 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1443 1443) = true := by
  decide +kernel

theorem ok1443 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1443 1443 = true := (Snake9.LratV3.andB_eq_true warm1443).2

theorem warm1444 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1444 1444) = true := by
  decide +kernel

theorem ok1444 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1444 1444 = true := (Snake9.LratV3.andB_eq_true warm1444).2

theorem warm1445 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1445 1445) = true := by
  decide +kernel

theorem ok1445 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1445 1445 = true := (Snake9.LratV3.andB_eq_true warm1445).2

theorem warm1446 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1446 1446) = true := by
  decide +kernel

theorem ok1446 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1446 1446 = true := (Snake9.LratV3.andB_eq_true warm1446).2

theorem warm1447 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1447 1447) = true := by
  decide +kernel

theorem ok1447 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1447 1447 = true := (Snake9.LratV3.andB_eq_true warm1447).2

theorem warm1448 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1448 1448) = true := by
  decide +kernel

theorem ok1448 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1448 1448 = true := (Snake9.LratV3.andB_eq_true warm1448).2

theorem warm1449 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1449 1449) = true := by
  decide +kernel

theorem ok1449 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1449 1449 = true := (Snake9.LratV3.andB_eq_true warm1449).2

theorem warm1450 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1450 1450) = true := by
  decide +kernel

theorem ok1450 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1450 1450 = true := (Snake9.LratV3.andB_eq_true warm1450).2

theorem warm1451 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1451 1451) = true := by
  decide +kernel

theorem ok1451 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1451 1451 = true := (Snake9.LratV3.andB_eq_true warm1451).2

theorem warm1452 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1452 1452) = true := by
  decide +kernel

theorem ok1452 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1452 1452 = true := (Snake9.LratV3.andB_eq_true warm1452).2

theorem warm1453 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1453 1453) = true := by
  decide +kernel

theorem ok1453 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1453 1453 = true := (Snake9.LratV3.andB_eq_true warm1453).2

theorem warm1454 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1454 1454) = true := by
  decide +kernel

theorem ok1454 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1454 1454 = true := (Snake9.LratV3.andB_eq_true warm1454).2

theorem warm1455 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1455 1455) = true := by
  decide +kernel

theorem ok1455 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1455 1455 = true := (Snake9.LratV3.andB_eq_true warm1455).2

theorem warm1456 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1456 1456) = true := by
  decide +kernel

theorem ok1456 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1456 1456 = true := (Snake9.LratV3.andB_eq_true warm1456).2

theorem warm1457 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1457 1457) = true := by
  decide +kernel

theorem ok1457 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1457 1457 = true := (Snake9.LratV3.andB_eq_true warm1457).2

theorem warm1458 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1458 1458) = true := by
  decide +kernel

theorem ok1458 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1458 1458 = true := (Snake9.LratV3.andB_eq_true warm1458).2

theorem warm1459 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1459 1459) = true := by
  decide +kernel

theorem ok1459 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1459 1459 = true := (Snake9.LratV3.andB_eq_true warm1459).2

theorem warm1460 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 589) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1054) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1460 1460) = true := by
  decide +kernel

theorem ok1460 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1460 1460 = true := (Snake9.LratV3.andB_eq_true warm1460).2

theorem warm1461 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 84) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1461 1461) = true := by
  decide +kernel

theorem ok1461 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1461 1461 = true := (Snake9.LratV3.andB_eq_true warm1461).2

theorem warm1462 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 588) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1462 1462) = true := by
  decide +kernel

theorem ok1462 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1462 1462 = true := (Snake9.LratV3.andB_eq_true warm1462).2

theorem warm1463 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 14) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1463 1463) = true := by
  decide +kernel

theorem ok1463 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1463 1463 = true := (Snake9.LratV3.andB_eq_true warm1463).2

theorem warm1464 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 18) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1464 1464) = true := by
  decide +kernel

theorem ok1464 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1464 1464 = true := (Snake9.LratV3.andB_eq_true warm1464).2

theorem warm1465 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (true)))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1465 1465) = true := by
  decide +kernel

theorem ok1465 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1465 1465 = true := (Snake9.LratV3.andB_eq_true warm1465).2

theorem warm1466 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1466 1466) = true := by
  decide +kernel

theorem ok1466 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1466 1466 = true := (Snake9.LratV3.andB_eq_true warm1466).2

theorem warm1467 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1465) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1466) 2048)) true)
    (true))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1467 1467) = true := by
  decide +kernel

theorem ok1467 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1467 1467 = true := (Snake9.LratV3.andB_eq_true warm1467).2

theorem warm1468 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1466) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1468 1468) = true := by
  decide +kernel

theorem ok1468 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1468 1468 = true := (Snake9.LratV3.andB_eq_true warm1468).2

theorem warm1469 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 172) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1466) 2048)) true)
    (true)))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1469 1469) = true := by
  decide +kernel

theorem ok1469 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1469 1469 = true := (Snake9.LratV3.andB_eq_true warm1469).2

theorem warm1470 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1466) 2048)) true)
    (true))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1470 1470) = true := by
  decide +kernel

theorem ok1470 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1470 1470 = true := (Snake9.LratV3.andB_eq_true warm1470).2

theorem warm1471 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1466) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1471 1471) = true := by
  decide +kernel

theorem ok1471 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1471 1471 = true := (Snake9.LratV3.andB_eq_true warm1471).2

theorem warm1472 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1466) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1472 1472) = true := by
  decide +kernel

theorem ok1472 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1472 1472 = true := (Snake9.LratV3.andB_eq_true warm1472).2

theorem warm1473 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 887) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1000) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1113) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1466) 2048)) true)
    (true))))))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1473 1473) = true := by
  decide +kernel

theorem ok1473 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1473 1473 = true := (Snake9.LratV3.andB_eq_true warm1473).2

theorem warm1474 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 642) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 803) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1244) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1296) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1466) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1474 1474) = true := by
  decide +kernel

theorem ok1474 : Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1474 1474 = true := (Snake9.LratV3.andB_eq_true warm1474).2

theorem warm1475 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 3000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 16) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 210) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 327) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 715) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 886) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 999) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1052) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1053) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1114) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 3000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1404) 2048)) true)
    (true))))))))))))))
    (Snake9.LratV3.andB (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1475 1475) (Snake9.LratV3.hasEmpty 15 32767 (Snake9.LratV3.segP Ps 1475))) = true := by
  decide +kernel

theorem ok1475 : Snake9.LratV3.andB (Snake9.LratV3.check 3000 15 32767 16384 raw Ps t1475 1475) (Snake9.LratV3.hasEmpty 15 32767 (Snake9.LratV3.segP Ps 1475)) = true := (Snake9.LratV3.andB_eq_true warm1475).2

end Snake9.LocalWindow.V012032A45454
