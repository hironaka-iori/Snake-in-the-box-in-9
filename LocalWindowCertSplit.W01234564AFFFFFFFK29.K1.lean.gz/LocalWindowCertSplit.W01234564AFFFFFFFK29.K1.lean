module

-- LocalWindowCertSplit.W01234564AFFFFFFFK29: kernel checks of segments 32..62 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.W01234564AFFFFFFFK29.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.W01234564AFFFFFFFK29

theorem warm32 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t32 32) = true := by
  decide +kernel

theorem ok32 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t32 32 = true := (Snake9.LratV3.andB_eq_true warm32).2

theorem warm33 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t33 33) = true := by
  decide +kernel

theorem ok33 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t33 33 = true := (Snake9.LratV3.andB_eq_true warm33).2

theorem warm34 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t34 34) = true := by
  decide +kernel

theorem ok34 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t34 34 = true := (Snake9.LratV3.andB_eq_true warm34).2

theorem warm35 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t35 35) = true := by
  decide +kernel

theorem ok35 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t35 35 = true := (Snake9.LratV3.andB_eq_true warm35).2

theorem warm36 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t36 36) = true := by
  decide +kernel

theorem ok36 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t36 36 = true := (Snake9.LratV3.andB_eq_true warm36).2

theorem warm37 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t37 37) = true := by
  decide +kernel

theorem ok37 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t37 37 = true := (Snake9.LratV3.andB_eq_true warm37).2

theorem warm38 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t38 38) = true := by
  decide +kernel

theorem ok38 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t38 38 = true := (Snake9.LratV3.andB_eq_true warm38).2

theorem warm39 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t39 39) = true := by
  decide +kernel

theorem ok39 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t39 39 = true := (Snake9.LratV3.andB_eq_true warm39).2

theorem warm40 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t40 40) = true := by
  decide +kernel

theorem ok40 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t40 40 = true := (Snake9.LratV3.andB_eq_true warm40).2

theorem warm41 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t41 41) = true := by
  decide +kernel

theorem ok41 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t41 41 = true := (Snake9.LratV3.andB_eq_true warm41).2

theorem warm42 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t42 42) = true := by
  decide +kernel

theorem ok42 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t42 42 = true := (Snake9.LratV3.andB_eq_true warm42).2

theorem warm43 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t43 43) = true := by
  decide +kernel

theorem ok43 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t43 43 = true := (Snake9.LratV3.andB_eq_true warm43).2

theorem warm44 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t44 44) = true := by
  decide +kernel

theorem ok44 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t44 44 = true := (Snake9.LratV3.andB_eq_true warm44).2

theorem warm45 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t45 45) = true := by
  decide +kernel

theorem ok45 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t45 45 = true := (Snake9.LratV3.andB_eq_true warm45).2

theorem warm46 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t46 46) = true := by
  decide +kernel

theorem ok46 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t46 46 = true := (Snake9.LratV3.andB_eq_true warm46).2

theorem warm47 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t47 47) = true := by
  decide +kernel

theorem ok47 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t47 47 = true := (Snake9.LratV3.andB_eq_true warm47).2

theorem warm48 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t48 48) = true := by
  decide +kernel

theorem ok48 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t48 48 = true := (Snake9.LratV3.andB_eq_true warm48).2

theorem warm49 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (true))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t49 49) = true := by
  decide +kernel

theorem ok49 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t49 49 = true := (Snake9.LratV3.andB_eq_true warm49).2

theorem warm50 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t50 50) = true := by
  decide +kernel

theorem ok50 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t50 50 = true := (Snake9.LratV3.andB_eq_true warm50).2

theorem warm51 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t51 51) = true := by
  decide +kernel

theorem ok51 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t51 51 = true := (Snake9.LratV3.andB_eq_true warm51).2

theorem warm52 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 35) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t52 52) = true := by
  decide +kernel

theorem ok52 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t52 52 = true := (Snake9.LratV3.andB_eq_true warm52).2

theorem warm53 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t53 53) = true := by
  decide +kernel

theorem ok53 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t53 53 = true := (Snake9.LratV3.andB_eq_true warm53).2

theorem warm54 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t54 54) = true := by
  decide +kernel

theorem ok54 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t54 54 = true := (Snake9.LratV3.andB_eq_true warm54).2

theorem warm55 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t55 55) = true := by
  decide +kernel

theorem ok55 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t55 55 = true := (Snake9.LratV3.andB_eq_true warm55).2

theorem warm56 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t56 56) = true := by
  decide +kernel

theorem ok56 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t56 56 = true := (Snake9.LratV3.andB_eq_true warm56).2

theorem warm57 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 23) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t57 57) = true := by
  decide +kernel

theorem ok57 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t57 57 = true := (Snake9.LratV3.andB_eq_true warm57).2

theorem warm58 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t58 58) = true := by
  decide +kernel

theorem ok58 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t58 58 = true := (Snake9.LratV3.andB_eq_true warm58).2

theorem warm59 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t59 59) = true := by
  decide +kernel

theorem ok59 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t59 59 = true := (Snake9.LratV3.andB_eq_true warm59).2

theorem warm60 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 5) 2048)) true)
    (true)))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t60 60) = true := by
  decide +kernel

theorem ok60 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t60 60 = true := (Snake9.LratV3.andB_eq_true warm60).2

theorem warm61 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 2) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 3) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 53) 2048)) true)
    (true))))))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t61 61) = true := by
  decide +kernel

theorem ok61 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t61 61 = true := (Snake9.LratV3.andB_eq_true warm61).2

theorem warm62 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 8192)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 10240)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 12288)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 14336)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 16384)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 18432)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 20480)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 22528)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 12000 (Snake9.LratV3.nthR raw 24576)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 12000 15 32767 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 1) 2048)) true)
    (true)))))))))))))))
    (Snake9.LratV3.check 12000 15 32767 16384 raw Ps t62 62) = true := by
  decide +kernel

theorem ok62 : Snake9.LratV3.check 12000 15 32767 16384 raw Ps t62 62 = true := (Snake9.LratV3.andB_eq_true warm62).2

end Snake9.LocalWindow.W01234564AFFFFFFFK29
