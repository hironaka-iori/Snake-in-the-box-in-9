module

-- LocalWindowCertSplit.V01230243A6445456: kernel checks of segments 290..331 (lean435/tools/split435.py; generator text, distributed over modules)
public import LocalWindowCertSplit.V01230243A6445456.Ps
public import LratV3

public section

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V01230243A6445456

theorem warm290 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t290 290) = true := by
  decide +kernel

theorem ok290 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t290 290 = true := (Snake9.LratV3.andB_eq_true warm290).2

theorem warm291 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t291 291) = true := by
  decide +kernel

theorem ok291 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t291 291 = true := (Snake9.LratV3.andB_eq_true warm291).2

theorem warm292 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 242) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t292 292) = true := by
  decide +kernel

theorem ok292 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t292 292 = true := (Snake9.LratV3.andB_eq_true warm292).2

theorem warm293 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 242) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t293 293) = true := by
  decide +kernel

theorem ok293 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t293 293 = true := (Snake9.LratV3.andB_eq_true warm293).2

theorem warm294 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t294 294) = true := by
  decide +kernel

theorem ok294 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t294 294 = true := (Snake9.LratV3.andB_eq_true warm294).2

theorem warm295 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t295 295) = true := by
  decide +kernel

theorem ok295 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t295 295 = true := (Snake9.LratV3.andB_eq_true warm295).2

theorem warm296 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t296 296) = true := by
  decide +kernel

theorem ok296 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t296 296 = true := (Snake9.LratV3.andB_eq_true warm296).2

theorem warm297 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t297 297) = true := by
  decide +kernel

theorem ok297 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t297 297 = true := (Snake9.LratV3.andB_eq_true warm297).2

theorem warm298 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t298 298) = true := by
  decide +kernel

theorem ok298 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t298 298 = true := (Snake9.LratV3.andB_eq_true warm298).2

theorem warm299 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t299 299) = true := by
  decide +kernel

theorem ok299 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t299 299 = true := (Snake9.LratV3.andB_eq_true warm299).2

theorem warm300 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 251) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t300 300) = true := by
  decide +kernel

theorem ok300 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t300 300 = true := (Snake9.LratV3.andB_eq_true warm300).2

theorem warm301 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t301 301) = true := by
  decide +kernel

theorem ok301 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t301 301 = true := (Snake9.LratV3.andB_eq_true warm301).2

theorem warm302 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t302 302) = true := by
  decide +kernel

theorem ok302 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t302 302 = true := (Snake9.LratV3.andB_eq_true warm302).2

theorem warm303 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t303 303) = true := by
  decide +kernel

theorem ok303 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t303 303 = true := (Snake9.LratV3.andB_eq_true warm303).2

theorem warm304 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t304 304) = true := by
  decide +kernel

theorem ok304 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t304 304 = true := (Snake9.LratV3.andB_eq_true warm304).2

theorem warm305 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t305 305) = true := by
  decide +kernel

theorem ok305 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t305 305 = true := (Snake9.LratV3.andB_eq_true warm305).2

theorem warm306 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 305) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t306 306) = true := by
  decide +kernel

theorem ok306 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t306 306 = true := (Snake9.LratV3.andB_eq_true warm306).2

theorem warm307 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 305) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t307 307) = true := by
  decide +kernel

theorem ok307 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t307 307 = true := (Snake9.LratV3.andB_eq_true warm307).2

theorem warm308 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t308 308) = true := by
  decide +kernel

theorem ok308 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t308 308 = true := (Snake9.LratV3.andB_eq_true warm308).2

theorem warm309 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t309 309) = true := by
  decide +kernel

theorem ok309 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t309 309 = true := (Snake9.LratV3.andB_eq_true warm309).2

theorem warm310 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t310 310) = true := by
  decide +kernel

theorem ok310 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t310 310 = true := (Snake9.LratV3.andB_eq_true warm310).2

theorem warm311 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 283) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t311 311) = true := by
  decide +kernel

theorem ok311 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t311 311 = true := (Snake9.LratV3.andB_eq_true warm311).2

theorem warm312 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t312 312) = true := by
  decide +kernel

theorem ok312 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t312 312 = true := (Snake9.LratV3.andB_eq_true warm312).2

theorem warm313 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t313 313) = true := by
  decide +kernel

theorem ok313 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t313 313 = true := (Snake9.LratV3.andB_eq_true warm313).2

theorem warm314 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t314 314) = true := by
  decide +kernel

theorem ok314 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t314 314 = true := (Snake9.LratV3.andB_eq_true warm314).2

theorem warm315 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t315 315) = true := by
  decide +kernel

theorem ok315 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t315 315 = true := (Snake9.LratV3.andB_eq_true warm315).2

theorem warm316 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t316 316) = true := by
  decide +kernel

theorem ok316 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t316 316 = true := (Snake9.LratV3.andB_eq_true warm316).2

theorem warm317 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t317 317) = true := by
  decide +kernel

theorem ok317 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t317 317 = true := (Snake9.LratV3.andB_eq_true warm317).2

theorem warm318 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 317) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t318 318) = true := by
  decide +kernel

theorem ok318 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t318 318 = true := (Snake9.LratV3.andB_eq_true warm318).2

theorem warm319 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t319 319) = true := by
  decide +kernel

theorem ok319 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t319 319 = true := (Snake9.LratV3.andB_eq_true warm319).2

theorem warm320 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 283) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 305) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 317) 2048)) true)
    (true))))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t320 320) = true := by
  decide +kernel

theorem ok320 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t320 320 = true := (Snake9.LratV3.andB_eq_true warm320).2

theorem warm321 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 305) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 317) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t321 321) = true := by
  decide +kernel

theorem ok321 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t321 321 = true := (Snake9.LratV3.andB_eq_true warm321).2

theorem warm322 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 305) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t322 322) = true := by
  decide +kernel

theorem ok322 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t322 322 = true := (Snake9.LratV3.andB_eq_true warm322).2

theorem warm323 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t323 323) = true := by
  decide +kernel

theorem ok323 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t323 323 = true := (Snake9.LratV3.andB_eq_true warm323).2

theorem warm324 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t324 324) = true := by
  decide +kernel

theorem ok324 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t324 324 = true := (Snake9.LratV3.andB_eq_true warm324).2

theorem warm325 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 305) 2048)) true)
    (true))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t325 325) = true := by
  decide +kernel

theorem ok325 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t325 325 = true := (Snake9.LratV3.andB_eq_true warm325).2

theorem warm326 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 283) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t326 326) = true := by
  decide +kernel

theorem ok326 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t326 326 = true := (Snake9.LratV3.andB_eq_true warm326).2

theorem warm327 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 242) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 305) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t327 327) = true := by
  decide +kernel

theorem ok327 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t327 327 = true := (Snake9.LratV3.andB_eq_true warm327).2

theorem warm328 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 242) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 251) 2048)) true)
    (true)))))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t328 328) = true := by
  decide +kernel

theorem ok328 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t328 328 = true := (Snake9.LratV3.andB_eq_true warm328).2

theorem warm329 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 6144)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (true)))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t329 329) = true := by
  decide +kernel

theorem ok329 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t329 329 = true := (Snake9.LratV3.andB_eq_true warm329).2

theorem warm330 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 283) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 305) 2048)) true)
    (true))))
    (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t330 330) = true := by
  decide +kernel

theorem ok330 : Snake9.LratV3.check 5000 14 16383 8192 raw Ps t330 330 = true := (Snake9.LratV3.andB_eq_true warm330).2

theorem warm331 : Snake9.LratV3.andB
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headR 5000 (Snake9.LratV3.nthR raw 4096)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 0) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 251) 2048)) true)
    (Snake9.LratV3.andB (Snake9.LratV3.seqN (Snake9.LratV3.headL 5000 14 16383 (Snake9.LratV3.nthN (Snake9.LratV3.segP Ps 330) 2048)) true)
    (true))))))
    (Snake9.LratV3.andB (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t331 331) (Snake9.LratV3.hasEmpty 14 16383 (Snake9.LratV3.segP Ps 331))) = true := by
  decide +kernel

theorem ok331 : Snake9.LratV3.andB (Snake9.LratV3.check 5000 14 16383 8192 raw Ps t331 331) (Snake9.LratV3.hasEmpty 14 16383 (Snake9.LratV3.segP Ps 331)) = true := (Snake9.LratV3.andB_eq_true warm331).2

end Snake9.LocalWindow.V01230243A6445456
