module

-- LocalWindowCert.V0120324A445545: the final module of a split certificate (lean435/tools/split435.py); its parts are private imports
public import LocalWindowShareCtx
import LocalWindowDirModel
import LocalWindowCnfPack
import LocalWindowTagsW
import LratV3
import ProofPack
import LocalWindowCertSplit.V0120324A445545.Cnf
import LocalWindowCertSplit.V0120324A445545.Ps
import LocalWindowCertSplit.V0120324A445545.K0
import LocalWindowCertSplit.V0120324A445545.K1
import LocalWindowCertSplit.V0120324A445545.K2
import LocalWindowCertSplit.V0120324A445545.K3
import LocalWindowCertSplit.V0120324A445545.K4
import LocalWindowCertSplit.V0120324A445545.K5
import LocalWindowCertSplit.V0120324A445545.K6
import LocalWindowCertSplit.V0120324A445545.K7
import LocalWindowCertSplit.V0120324A445545.K8
import LocalWindowCertSplit.V0120324A445545.K9
import LocalWindowCertSplit.V0120324A445545.K10
import LocalWindowCertSplit.V0120324A445545.K11
import LocalWindowCertSplit.V0120324A445545.K12
import LocalWindowCertSplit.V0120324A445545.K13
import LocalWindowCertSplit.V0120324A445545.K14
import LocalWindowCertSplit.V0120324A445545.K15

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option Elab.async false

namespace Snake9.LocalWindow.V0120324A445545

theorem unsat : Unsat cnf := by
  apply Snake9.LratV3.unsat_of_raw
  intro τ h
  have hoff : 0 < 4000 := by decide
  have hr : Snake9.LratV3.RawTrue 4000 τ raw := Snake9.LratV3.rawTrue_of_cnf hoff h
  have h0 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 0 := Snake9.LratV3.segsTrue_zero _ _ _ τ Ps
  have h1 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 1 := Snake9.LratV3.seg_step hoff hr ok0 h0
  have h2 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 2 := Snake9.LratV3.seg_step hoff hr ok1 h1
  have h3 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 3 := Snake9.LratV3.seg_step hoff hr ok2 h2
  have h4 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 4 := Snake9.LratV3.seg_step hoff hr ok3 h3
  have h5 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 5 := Snake9.LratV3.seg_step hoff hr ok4 h4
  have h6 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 6 := Snake9.LratV3.seg_step hoff hr ok5 h5
  have h7 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 7 := Snake9.LratV3.seg_step hoff hr ok6 h6
  have h8 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 8 := Snake9.LratV3.seg_step hoff hr ok7 h7
  have h9 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 9 := Snake9.LratV3.seg_step hoff hr ok8 h8
  have h10 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 10 := Snake9.LratV3.seg_step hoff hr ok9 h9
  have h11 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 11 := Snake9.LratV3.seg_step hoff hr ok10 h10
  have h12 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 12 := Snake9.LratV3.seg_step hoff hr ok11 h11
  have h13 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 13 := Snake9.LratV3.seg_step hoff hr ok12 h12
  have h14 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 14 := Snake9.LratV3.seg_step hoff hr ok13 h13
  have h15 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 15 := Snake9.LratV3.seg_step hoff hr ok14 h14
  have h16 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 16 := Snake9.LratV3.seg_step hoff hr ok15 h15
  have h17 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 17 := Snake9.LratV3.seg_step hoff hr ok16 h16
  have h18 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 18 := Snake9.LratV3.seg_step hoff hr ok17 h17
  have h19 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 19 := Snake9.LratV3.seg_step hoff hr ok18 h18
  have h20 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 20 := Snake9.LratV3.seg_step hoff hr ok19 h19
  have h21 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 21 := Snake9.LratV3.seg_step hoff hr ok20 h20
  have h22 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 22 := Snake9.LratV3.seg_step hoff hr ok21 h21
  have h23 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 23 := Snake9.LratV3.seg_step hoff hr ok22 h22
  have h24 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 24 := Snake9.LratV3.seg_step hoff hr ok23 h23
  have h25 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 25 := Snake9.LratV3.seg_step hoff hr ok24 h24
  have h26 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 26 := Snake9.LratV3.seg_step hoff hr ok25 h25
  have h27 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 27 := Snake9.LratV3.seg_step hoff hr ok26 h26
  have h28 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 28 := Snake9.LratV3.seg_step hoff hr ok27 h27
  have h29 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 29 := Snake9.LratV3.seg_step hoff hr ok28 h28
  have h30 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 30 := Snake9.LratV3.seg_step hoff hr ok29 h29
  have h31 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 31 := Snake9.LratV3.seg_step hoff hr ok30 h30
  have h32 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 32 := Snake9.LratV3.seg_step hoff hr ok31 h31
  have h33 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 33 := Snake9.LratV3.seg_step hoff hr ok32 h32
  have h34 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 34 := Snake9.LratV3.seg_step hoff hr ok33 h33
  have h35 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 35 := Snake9.LratV3.seg_step hoff hr ok34 h34
  have h36 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 36 := Snake9.LratV3.seg_step hoff hr ok35 h35
  have h37 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 37 := Snake9.LratV3.seg_step hoff hr ok36 h36
  have h38 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 38 := Snake9.LratV3.seg_step hoff hr ok37 h37
  have h39 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 39 := Snake9.LratV3.seg_step hoff hr ok38 h38
  have h40 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 40 := Snake9.LratV3.seg_step hoff hr ok39 h39
  have h41 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 41 := Snake9.LratV3.seg_step hoff hr ok40 h40
  have h42 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 42 := Snake9.LratV3.seg_step hoff hr ok41 h41
  have h43 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 43 := Snake9.LratV3.seg_step hoff hr ok42 h42
  have h44 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 44 := Snake9.LratV3.seg_step hoff hr ok43 h43
  have h45 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 45 := Snake9.LratV3.seg_step hoff hr ok44 h44
  have h46 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 46 := Snake9.LratV3.seg_step hoff hr ok45 h45
  have h47 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 47 := Snake9.LratV3.seg_step hoff hr ok46 h46
  have h48 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 48 := Snake9.LratV3.seg_step hoff hr ok47 h47
  have h49 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 49 := Snake9.LratV3.seg_step hoff hr ok48 h48
  have h50 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 50 := Snake9.LratV3.seg_step hoff hr ok49 h49
  have h51 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 51 := Snake9.LratV3.seg_step hoff hr ok50 h50
  have h52 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 52 := Snake9.LratV3.seg_step hoff hr ok51 h51
  have h53 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 53 := Snake9.LratV3.seg_step hoff hr ok52 h52
  have h54 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 54 := Snake9.LratV3.seg_step hoff hr ok53 h53
  have h55 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 55 := Snake9.LratV3.seg_step hoff hr ok54 h54
  have h56 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 56 := Snake9.LratV3.seg_step hoff hr ok55 h55
  have h57 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 57 := Snake9.LratV3.seg_step hoff hr ok56 h56
  have h58 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 58 := Snake9.LratV3.seg_step hoff hr ok57 h57
  have h59 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 59 := Snake9.LratV3.seg_step hoff hr ok58 h58
  have h60 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 60 := Snake9.LratV3.seg_step hoff hr ok59 h59
  have h61 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 61 := Snake9.LratV3.seg_step hoff hr ok60 h60
  have h62 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 62 := Snake9.LratV3.seg_step hoff hr ok61 h61
  have h63 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 63 := Snake9.LratV3.seg_step hoff hr ok62 h62
  have h64 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 64 := Snake9.LratV3.seg_step hoff hr ok63 h63
  have h65 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 65 := Snake9.LratV3.seg_step hoff hr ok64 h64
  have h66 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 66 := Snake9.LratV3.seg_step hoff hr ok65 h65
  have h67 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 67 := Snake9.LratV3.seg_step hoff hr ok66 h66
  have h68 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 68 := Snake9.LratV3.seg_step hoff hr ok67 h67
  have h69 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 69 := Snake9.LratV3.seg_step hoff hr ok68 h68
  have h70 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 70 := Snake9.LratV3.seg_step hoff hr ok69 h69
  have h71 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 71 := Snake9.LratV3.seg_step hoff hr ok70 h70
  have h72 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 72 := Snake9.LratV3.seg_step hoff hr ok71 h71
  have h73 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 73 := Snake9.LratV3.seg_step hoff hr ok72 h72
  have h74 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 74 := Snake9.LratV3.seg_step hoff hr ok73 h73
  have h75 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 75 := Snake9.LratV3.seg_step hoff hr ok74 h74
  have h76 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 76 := Snake9.LratV3.seg_step hoff hr ok75 h75
  have h77 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 77 := Snake9.LratV3.seg_step hoff hr ok76 h76
  have h78 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 78 := Snake9.LratV3.seg_step hoff hr ok77 h77
  have h79 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 79 := Snake9.LratV3.seg_step hoff hr ok78 h78
  have h80 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 80 := Snake9.LratV3.seg_step hoff hr ok79 h79
  have h81 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 81 := Snake9.LratV3.seg_step hoff hr ok80 h80
  have h82 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 82 := Snake9.LratV3.seg_step hoff hr ok81 h81
  have h83 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 83 := Snake9.LratV3.seg_step hoff hr ok82 h82
  have h84 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 84 := Snake9.LratV3.seg_step hoff hr ok83 h83
  have h85 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 85 := Snake9.LratV3.seg_step hoff hr ok84 h84
  have h86 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 86 := Snake9.LratV3.seg_step hoff hr ok85 h85
  have h87 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 87 := Snake9.LratV3.seg_step hoff hr ok86 h86
  have h88 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 88 := Snake9.LratV3.seg_step hoff hr ok87 h87
  have h89 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 89 := Snake9.LratV3.seg_step hoff hr ok88 h88
  have h90 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 90 := Snake9.LratV3.seg_step hoff hr ok89 h89
  have h91 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 91 := Snake9.LratV3.seg_step hoff hr ok90 h90
  have h92 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 92 := Snake9.LratV3.seg_step hoff hr ok91 h91
  have h93 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 93 := Snake9.LratV3.seg_step hoff hr ok92 h92
  have h94 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 94 := Snake9.LratV3.seg_step hoff hr ok93 h93
  have h95 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 95 := Snake9.LratV3.seg_step hoff hr ok94 h94
  have h96 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 96 := Snake9.LratV3.seg_step hoff hr ok95 h95
  have h97 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 97 := Snake9.LratV3.seg_step hoff hr ok96 h96
  have h98 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 98 := Snake9.LratV3.seg_step hoff hr ok97 h97
  have h99 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 99 := Snake9.LratV3.seg_step hoff hr ok98 h98
  have h100 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 100 := Snake9.LratV3.seg_step hoff hr ok99 h99
  have h101 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 101 := Snake9.LratV3.seg_step hoff hr ok100 h100
  have h102 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 102 := Snake9.LratV3.seg_step hoff hr ok101 h101
  have h103 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 103 := Snake9.LratV3.seg_step hoff hr ok102 h102
  have h104 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 104 := Snake9.LratV3.seg_step hoff hr ok103 h103
  have h105 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 105 := Snake9.LratV3.seg_step hoff hr ok104 h104
  have h106 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 106 := Snake9.LratV3.seg_step hoff hr ok105 h105
  have h107 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 107 := Snake9.LratV3.seg_step hoff hr ok106 h106
  have h108 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 108 := Snake9.LratV3.seg_step hoff hr ok107 h107
  have h109 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 109 := Snake9.LratV3.seg_step hoff hr ok108 h108
  have h110 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 110 := Snake9.LratV3.seg_step hoff hr ok109 h109
  have h111 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 111 := Snake9.LratV3.seg_step hoff hr ok110 h110
  have h112 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 112 := Snake9.LratV3.seg_step hoff hr ok111 h111
  have h113 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 113 := Snake9.LratV3.seg_step hoff hr ok112 h112
  have h114 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 114 := Snake9.LratV3.seg_step hoff hr ok113 h113
  have h115 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 115 := Snake9.LratV3.seg_step hoff hr ok114 h114
  have h116 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 116 := Snake9.LratV3.seg_step hoff hr ok115 h115
  have h117 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 117 := Snake9.LratV3.seg_step hoff hr ok116 h116
  have h118 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 118 := Snake9.LratV3.seg_step hoff hr ok117 h117
  have h119 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 119 := Snake9.LratV3.seg_step hoff hr ok118 h118
  have h120 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 120 := Snake9.LratV3.seg_step hoff hr ok119 h119
  have h121 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 121 := Snake9.LratV3.seg_step hoff hr ok120 h120
  have h122 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 122 := Snake9.LratV3.seg_step hoff hr ok121 h121
  have h123 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 123 := Snake9.LratV3.seg_step hoff hr ok122 h122
  have h124 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 124 := Snake9.LratV3.seg_step hoff hr ok123 h123
  have h125 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 125 := Snake9.LratV3.seg_step hoff hr ok124 h124
  have h126 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 126 := Snake9.LratV3.seg_step hoff hr ok125 h125
  have h127 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 127 := Snake9.LratV3.seg_step hoff hr ok126 h126
  have h128 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 128 := Snake9.LratV3.seg_step hoff hr ok127 h127
  have h129 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 129 := Snake9.LratV3.seg_step hoff hr ok128 h128
  have h130 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 130 := Snake9.LratV3.seg_step hoff hr ok129 h129
  have h131 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 131 := Snake9.LratV3.seg_step hoff hr ok130 h130
  have h132 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 132 := Snake9.LratV3.seg_step hoff hr ok131 h131
  have h133 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 133 := Snake9.LratV3.seg_step hoff hr ok132 h132
  have h134 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 134 := Snake9.LratV3.seg_step hoff hr ok133 h133
  have h135 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 135 := Snake9.LratV3.seg_step hoff hr ok134 h134
  have h136 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 136 := Snake9.LratV3.seg_step hoff hr ok135 h135
  have h137 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 137 := Snake9.LratV3.seg_step hoff hr ok136 h136
  have h138 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 138 := Snake9.LratV3.seg_step hoff hr ok137 h137
  have h139 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 139 := Snake9.LratV3.seg_step hoff hr ok138 h138
  have h140 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 140 := Snake9.LratV3.seg_step hoff hr ok139 h139
  have h141 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 141 := Snake9.LratV3.seg_step hoff hr ok140 h140
  have h142 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 142 := Snake9.LratV3.seg_step hoff hr ok141 h141
  have h143 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 143 := Snake9.LratV3.seg_step hoff hr ok142 h142
  have h144 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 144 := Snake9.LratV3.seg_step hoff hr ok143 h143
  have h145 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 145 := Snake9.LratV3.seg_step hoff hr ok144 h144
  have h146 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 146 := Snake9.LratV3.seg_step hoff hr ok145 h145
  have h147 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 147 := Snake9.LratV3.seg_step hoff hr ok146 h146
  have h148 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 148 := Snake9.LratV3.seg_step hoff hr ok147 h147
  have h149 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 149 := Snake9.LratV3.seg_step hoff hr ok148 h148
  have h150 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 150 := Snake9.LratV3.seg_step hoff hr ok149 h149
  have h151 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 151 := Snake9.LratV3.seg_step hoff hr ok150 h150
  have h152 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 152 := Snake9.LratV3.seg_step hoff hr ok151 h151
  have h153 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 153 := Snake9.LratV3.seg_step hoff hr ok152 h152
  have h154 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 154 := Snake9.LratV3.seg_step hoff hr ok153 h153
  have h155 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 155 := Snake9.LratV3.seg_step hoff hr ok154 h154
  have h156 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 156 := Snake9.LratV3.seg_step hoff hr ok155 h155
  have h157 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 157 := Snake9.LratV3.seg_step hoff hr ok156 h156
  have h158 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 158 := Snake9.LratV3.seg_step hoff hr ok157 h157
  have h159 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 159 := Snake9.LratV3.seg_step hoff hr ok158 h158
  have h160 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 160 := Snake9.LratV3.seg_step hoff hr ok159 h159
  have h161 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 161 := Snake9.LratV3.seg_step hoff hr ok160 h160
  have h162 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 162 := Snake9.LratV3.seg_step hoff hr ok161 h161
  have h163 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 163 := Snake9.LratV3.seg_step hoff hr ok162 h162
  have h164 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 164 := Snake9.LratV3.seg_step hoff hr ok163 h163
  have h165 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 165 := Snake9.LratV3.seg_step hoff hr ok164 h164
  have h166 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 166 := Snake9.LratV3.seg_step hoff hr ok165 h165
  have h167 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 167 := Snake9.LratV3.seg_step hoff hr ok166 h166
  have h168 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 168 := Snake9.LratV3.seg_step hoff hr ok167 h167
  have h169 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 169 := Snake9.LratV3.seg_step hoff hr ok168 h168
  have h170 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 170 := Snake9.LratV3.seg_step hoff hr ok169 h169
  have h171 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 171 := Snake9.LratV3.seg_step hoff hr ok170 h170
  have h172 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 172 := Snake9.LratV3.seg_step hoff hr ok171 h171
  have h173 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 173 := Snake9.LratV3.seg_step hoff hr ok172 h172
  have h174 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 174 := Snake9.LratV3.seg_step hoff hr ok173 h173
  have h175 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 175 := Snake9.LratV3.seg_step hoff hr ok174 h174
  have h176 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 176 := Snake9.LratV3.seg_step hoff hr ok175 h175
  have h177 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 177 := Snake9.LratV3.seg_step hoff hr ok176 h176
  have h178 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 178 := Snake9.LratV3.seg_step hoff hr ok177 h177
  have h179 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 179 := Snake9.LratV3.seg_step hoff hr ok178 h178
  have h180 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 180 := Snake9.LratV3.seg_step hoff hr ok179 h179
  have h181 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 181 := Snake9.LratV3.seg_step hoff hr ok180 h180
  have h182 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 182 := Snake9.LratV3.seg_step hoff hr ok181 h181
  have h183 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 183 := Snake9.LratV3.seg_step hoff hr ok182 h182
  have h184 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 184 := Snake9.LratV3.seg_step hoff hr ok183 h183
  have h185 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 185 := Snake9.LratV3.seg_step hoff hr ok184 h184
  have h186 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 186 := Snake9.LratV3.seg_step hoff hr ok185 h185
  have h187 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 187 := Snake9.LratV3.seg_step hoff hr ok186 h186
  have h188 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 188 := Snake9.LratV3.seg_step hoff hr ok187 h187
  have h189 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 189 := Snake9.LratV3.seg_step hoff hr ok188 h188
  have h190 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 190 := Snake9.LratV3.seg_step hoff hr ok189 h189
  have h191 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 191 := Snake9.LratV3.seg_step hoff hr ok190 h190
  have h192 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 192 := Snake9.LratV3.seg_step hoff hr ok191 h191
  have h193 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 193 := Snake9.LratV3.seg_step hoff hr ok192 h192
  have h194 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 194 := Snake9.LratV3.seg_step hoff hr ok193 h193
  have h195 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 195 := Snake9.LratV3.seg_step hoff hr ok194 h194
  have h196 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 196 := Snake9.LratV3.seg_step hoff hr ok195 h195
  have h197 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 197 := Snake9.LratV3.seg_step hoff hr ok196 h196
  have h198 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 198 := Snake9.LratV3.seg_step hoff hr ok197 h197
  have h199 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 199 := Snake9.LratV3.seg_step hoff hr ok198 h198
  have h200 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 200 := Snake9.LratV3.seg_step hoff hr ok199 h199
  have h201 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 201 := Snake9.LratV3.seg_step hoff hr ok200 h200
  have h202 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 202 := Snake9.LratV3.seg_step hoff hr ok201 h201
  have h203 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 203 := Snake9.LratV3.seg_step hoff hr ok202 h202
  have h204 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 204 := Snake9.LratV3.seg_step hoff hr ok203 h203
  have h205 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 205 := Snake9.LratV3.seg_step hoff hr ok204 h204
  have h206 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 206 := Snake9.LratV3.seg_step hoff hr ok205 h205
  have h207 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 207 := Snake9.LratV3.seg_step hoff hr ok206 h206
  have h208 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 208 := Snake9.LratV3.seg_step hoff hr ok207 h207
  have h209 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 209 := Snake9.LratV3.seg_step hoff hr ok208 h208
  have h210 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 210 := Snake9.LratV3.seg_step hoff hr ok209 h209
  have h211 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 211 := Snake9.LratV3.seg_step hoff hr ok210 h210
  have h212 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 212 := Snake9.LratV3.seg_step hoff hr ok211 h211
  have h213 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 213 := Snake9.LratV3.seg_step hoff hr ok212 h212
  have h214 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 214 := Snake9.LratV3.seg_step hoff hr ok213 h213
  have h215 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 215 := Snake9.LratV3.seg_step hoff hr ok214 h214
  have h216 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 216 := Snake9.LratV3.seg_step hoff hr ok215 h215
  have h217 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 217 := Snake9.LratV3.seg_step hoff hr ok216 h216
  have h218 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 218 := Snake9.LratV3.seg_step hoff hr ok217 h217
  have h219 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 219 := Snake9.LratV3.seg_step hoff hr ok218 h218
  have h220 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 220 := Snake9.LratV3.seg_step hoff hr ok219 h219
  have h221 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 221 := Snake9.LratV3.seg_step hoff hr ok220 h220
  have h222 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 222 := Snake9.LratV3.seg_step hoff hr ok221 h221
  have h223 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 223 := Snake9.LratV3.seg_step hoff hr ok222 h222
  have h224 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 224 := Snake9.LratV3.seg_step hoff hr ok223 h223
  have h225 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 225 := Snake9.LratV3.seg_step hoff hr ok224 h224
  have h226 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 226 := Snake9.LratV3.seg_step hoff hr ok225 h225
  have h227 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 227 := Snake9.LratV3.seg_step hoff hr ok226 h226
  have h228 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 228 := Snake9.LratV3.seg_step hoff hr ok227 h227
  have h229 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 229 := Snake9.LratV3.seg_step hoff hr ok228 h228
  have h230 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 230 := Snake9.LratV3.seg_step hoff hr ok229 h229
  have h231 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 231 := Snake9.LratV3.seg_step hoff hr ok230 h230
  have h232 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 232 := Snake9.LratV3.seg_step hoff hr ok231 h231
  have h233 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 233 := Snake9.LratV3.seg_step hoff hr ok232 h232
  have h234 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 234 := Snake9.LratV3.seg_step hoff hr ok233 h233
  have h235 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 235 := Snake9.LratV3.seg_step hoff hr ok234 h234
  have h236 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 236 := Snake9.LratV3.seg_step hoff hr ok235 h235
  have h237 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 237 := Snake9.LratV3.seg_step hoff hr ok236 h236
  have h238 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 238 := Snake9.LratV3.seg_step hoff hr ok237 h237
  have h239 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 239 := Snake9.LratV3.seg_step hoff hr ok238 h238
  have h240 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 240 := Snake9.LratV3.seg_step hoff hr ok239 h239
  have h241 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 241 := Snake9.LratV3.seg_step hoff hr ok240 h240
  have h242 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 242 := Snake9.LratV3.seg_step hoff hr ok241 h241
  have h243 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 243 := Snake9.LratV3.seg_step hoff hr ok242 h242
  have h244 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 244 := Snake9.LratV3.seg_step hoff hr ok243 h243
  have h245 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 245 := Snake9.LratV3.seg_step hoff hr ok244 h244
  have h246 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 246 := Snake9.LratV3.seg_step hoff hr ok245 h245
  have h247 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 247 := Snake9.LratV3.seg_step hoff hr ok246 h246
  have h248 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 248 := Snake9.LratV3.seg_step hoff hr ok247 h247
  have h249 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 249 := Snake9.LratV3.seg_step hoff hr ok248 h248
  have h250 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 250 := Snake9.LratV3.seg_step hoff hr ok249 h249
  have h251 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 251 := Snake9.LratV3.seg_step hoff hr ok250 h250
  have h252 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 252 := Snake9.LratV3.seg_step hoff hr ok251 h251
  have h253 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 253 := Snake9.LratV3.seg_step hoff hr ok252 h252
  have h254 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 254 := Snake9.LratV3.seg_step hoff hr ok253 h253
  have h255 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 255 := Snake9.LratV3.seg_step hoff hr ok254 h254
  have h256 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 256 := Snake9.LratV3.seg_step hoff hr ok255 h255
  have h257 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 257 := Snake9.LratV3.seg_step hoff hr ok256 h256
  have h258 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 258 := Snake9.LratV3.seg_step hoff hr ok257 h257
  have h259 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 259 := Snake9.LratV3.seg_step hoff hr ok258 h258
  have h260 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 260 := Snake9.LratV3.seg_step hoff hr ok259 h259
  have h261 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 261 := Snake9.LratV3.seg_step hoff hr ok260 h260
  have h262 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 262 := Snake9.LratV3.seg_step hoff hr ok261 h261
  have h263 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 263 := Snake9.LratV3.seg_step hoff hr ok262 h262
  have h264 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 264 := Snake9.LratV3.seg_step hoff hr ok263 h263
  have h265 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 265 := Snake9.LratV3.seg_step hoff hr ok264 h264
  have h266 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 266 := Snake9.LratV3.seg_step hoff hr ok265 h265
  have h267 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 267 := Snake9.LratV3.seg_step hoff hr ok266 h266
  have h268 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 268 := Snake9.LratV3.seg_step hoff hr ok267 h267
  have h269 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 269 := Snake9.LratV3.seg_step hoff hr ok268 h268
  have h270 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 270 := Snake9.LratV3.seg_step hoff hr ok269 h269
  have h271 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 271 := Snake9.LratV3.seg_step hoff hr ok270 h270
  have h272 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 272 := Snake9.LratV3.seg_step hoff hr ok271 h271
  have h273 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 273 := Snake9.LratV3.seg_step hoff hr ok272 h272
  have h274 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 274 := Snake9.LratV3.seg_step hoff hr ok273 h273
  have h275 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 275 := Snake9.LratV3.seg_step hoff hr ok274 h274
  have h276 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 276 := Snake9.LratV3.seg_step hoff hr ok275 h275
  have h277 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 277 := Snake9.LratV3.seg_step hoff hr ok276 h276
  have h278 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 278 := Snake9.LratV3.seg_step hoff hr ok277 h277
  have h279 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 279 := Snake9.LratV3.seg_step hoff hr ok278 h278
  have h280 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 280 := Snake9.LratV3.seg_step hoff hr ok279 h279
  have h281 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 281 := Snake9.LratV3.seg_step hoff hr ok280 h280
  have h282 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 282 := Snake9.LratV3.seg_step hoff hr ok281 h281
  have h283 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 283 := Snake9.LratV3.seg_step hoff hr ok282 h282
  have h284 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 284 := Snake9.LratV3.seg_step hoff hr ok283 h283
  have h285 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 285 := Snake9.LratV3.seg_step hoff hr ok284 h284
  have h286 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 286 := Snake9.LratV3.seg_step hoff hr ok285 h285
  have h287 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 287 := Snake9.LratV3.seg_step hoff hr ok286 h286
  have h288 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 288 := Snake9.LratV3.seg_step hoff hr ok287 h287
  have h289 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 289 := Snake9.LratV3.seg_step hoff hr ok288 h288
  have h290 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 290 := Snake9.LratV3.seg_step hoff hr ok289 h289
  have h291 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 291 := Snake9.LratV3.seg_step hoff hr ok290 h290
  have h292 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 292 := Snake9.LratV3.seg_step hoff hr ok291 h291
  have h293 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 293 := Snake9.LratV3.seg_step hoff hr ok292 h292
  have h294 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 294 := Snake9.LratV3.seg_step hoff hr ok293 h293
  have h295 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 295 := Snake9.LratV3.seg_step hoff hr ok294 h294
  have h296 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 296 := Snake9.LratV3.seg_step hoff hr ok295 h295
  have h297 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 297 := Snake9.LratV3.seg_step hoff hr ok296 h296
  have h298 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 298 := Snake9.LratV3.seg_step hoff hr ok297 h297
  have h299 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 299 := Snake9.LratV3.seg_step hoff hr ok298 h298
  have h300 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 300 := Snake9.LratV3.seg_step hoff hr ok299 h299
  have h301 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 301 := Snake9.LratV3.seg_step hoff hr ok300 h300
  have h302 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 302 := Snake9.LratV3.seg_step hoff hr ok301 h301
  have h303 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 303 := Snake9.LratV3.seg_step hoff hr ok302 h302
  have h304 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 304 := Snake9.LratV3.seg_step hoff hr ok303 h303
  have h305 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 305 := Snake9.LratV3.seg_step hoff hr ok304 h304
  have h306 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 306 := Snake9.LratV3.seg_step hoff hr ok305 h305
  have h307 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 307 := Snake9.LratV3.seg_step hoff hr ok306 h306
  have h308 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 308 := Snake9.LratV3.seg_step hoff hr ok307 h307
  have h309 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 309 := Snake9.LratV3.seg_step hoff hr ok308 h308
  have h310 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 310 := Snake9.LratV3.seg_step hoff hr ok309 h309
  have h311 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 311 := Snake9.LratV3.seg_step hoff hr ok310 h310
  have h312 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 312 := Snake9.LratV3.seg_step hoff hr ok311 h311
  have h313 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 313 := Snake9.LratV3.seg_step hoff hr ok312 h312
  have h314 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 314 := Snake9.LratV3.seg_step hoff hr ok313 h313
  have h315 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 315 := Snake9.LratV3.seg_step hoff hr ok314 h314
  have h316 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 316 := Snake9.LratV3.seg_step hoff hr ok315 h315
  have h317 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 317 := Snake9.LratV3.seg_step hoff hr ok316 h316
  have h318 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 318 := Snake9.LratV3.seg_step hoff hr ok317 h317
  have h319 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 319 := Snake9.LratV3.seg_step hoff hr ok318 h318
  have h320 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 320 := Snake9.LratV3.seg_step hoff hr ok319 h319
  have h321 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 321 := Snake9.LratV3.seg_step hoff hr ok320 h320
  have h322 : Snake9.LratV3.SegsTrue 4000 14 16383 τ Ps 322 := Snake9.LratV3.seg_step hoff hr ok321 h321
  exact Snake9.LratV3.final_false hoff hr ok322 h322

/-- The certificate, stated with literal parameters (lean435/tools/to435.py). -/
public theorem refuted : Refuted (winOf [0, 1, 2, 0, 3, 2, 4]) ([(4, 4), (4, 4), (5, 5), (5, 5), (4, 4), (5, 5)]) :=
  Tags.refuted_of_sat sat unsat

end Snake9.LocalWindow.V0120324A445545
